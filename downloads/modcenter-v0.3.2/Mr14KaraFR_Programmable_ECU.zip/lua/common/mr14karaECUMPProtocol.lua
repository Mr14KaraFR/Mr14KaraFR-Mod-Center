-- ECU multiplayer protocol. Only data is accepted; never executable Lua.
local P={version=1}
local function number(n,a,b) return type(n)=='number' and n==n and n>=a and n<=b end
function P.header(d)
  return type(d)=='table' and d.protocol==1 and type(d.key)=='string' and #d.key>0 and #d.key<=8000
    and number(d.revision,0,1000000000) and d.revision%1==0
end
function P.frame(d)
  if not P.header(d) or type(d.command)~='table' or type(d.sample)~='table' then return false end
  local c,s=d.command,d.sample
  for _,k in ipairs({'popAggression','popIrregularity'})do if c[k]~=nil and not number(c[k],0,100)then return false end end
  if c.rolling~=nil then
    local r=c.rolling
    if type(r)~='table' or #r~=5 or type(r[1])~='boolean' or type(r[2])~='boolean' or not number(r[3],0,100) or not number(r[4],0,100) or not number(r[5],1,12) then return false end
  end
  if c.bangs~=nil then
    local b=c.bangs;if type(b)~='table' or #b~=10 or type(b[1])~='boolean' or type(b[7])~='boolean' then return false end
    for i,r in pairs({[2]={0,1000},[3]={0,200},[4]={.05,1},[5]={10,100},[6]={1000,10000},[8]={0,1000},[9]={0,200},[10]={1,15}}) do if not number(b[i],r[1],r[2]) then return false end end
  end
  if s.transmissionActive~=nil and type(s.transmissionActive)~='boolean' then return false end
  if s.gearChangeTime~=nil and not number(s.gearChangeTime,.05,2) then return false end
  if s.lockupRatio~=nil and not number(s.lockupRatio,0,1) then return false end
  if type(c.managed)~='boolean' or type(c.active)~='boolean' or not number(c.demand,0,1)
    or not number(c.popHz,1,12) or not number(c.maxThrottle,0,100) or not number(c.rpm,0,30000)
    or not number(c.lambda,.01,100) or not number(c.extraFuel,0,40) or not number(c.advance,-100,100)
    or not number(c.baseAdvance,-100,100) or not number(c.retard,0,40) then return false end
  if c.mode~='off' and c.mode~='pops' and c.mode~='continuous' then return false end
  if c.style~='off' and c.style~='pops' and c.style~='continuous' and c.style~='launch' and c.style~='antilag' then return false end
  if c.exhaustTemperature~=nil and not number(c.exhaustTemperature,-100,3000) then return false end
  for k,r in pairs({rpm={0,30000},pedal={0,100},load={0,100},lambda={.01,100},fuelFactor={0,10},ignitionCutTime={0,2}}) do
    if not number(s[k],r[1],r[2]) then return false end
  end
  if s.rollingTargetRPM~=nil and not number(s.rollingTargetRPM,1500,8000) then return false end
  if s.idleTargetRPM~=nil and not number(s.idleTargetRPM,0,5000) then return false end
  if s.dieselFlameDemand~=nil and not number(s.dieselFlameDemand,0,1) then return false end
  if s.dieselEGT~=nil and not number(s.dieselEGT,0,1600) then return false end
  if s.dieselSmokeDemand~=nil and not number(s.dieselSmokeDemand,0,1) then return false end
  if s.dieselSmokeGain~=nil and not number(s.dieselSmokeGain,0,8) then return false end
  if s.boostPsi~=nil and not number(s.boostPsi,-100,1000) then return false end
  if s.dieselAirLimit~=nil and not number(s.dieselAirLimit,25,500) then return false end
  if s.dieselAirLimited~=nil and type(s.dieselAirLimited)~='boolean' then return false end
  if s.gear~=nil and (not number(s.gear,-100,100) or s.gear%1~=0) then return false end
  for _,k in ipairs({'commandedThrottle','mappedThrottle'}) do if s[k]~=nil and not number(s[k],0,100) then return false end end
  for _,k in ipairs({'pedalMapActive','boostByGearActive','rollingActive','rollingPrepActive'}) do if s[k]~=nil and type(s[k])~='boolean' then return false end end
  if s.limiterActive~=nil and type(s.limiterActive)~='boolean' or s.limiterCut~=nil and type(s.limiterCut)~='boolean' then return false end
  return type(s.engineRunning)=='boolean' and type(s.ignitionCut)=='boolean'
end
function P.tune(d) return P.header(d) and type(d.tune)=='table' and d.tune.version==1 and type(d.tune.tables)=='table' end
return P
