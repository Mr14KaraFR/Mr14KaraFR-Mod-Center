-- Owner-only speed ceiling. No brake or remote physics command; activation is never saved.
local M={}
local armed,cut=false,false
local state={armed=false,active=false,factor=1,reason='Désactivé'}
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<1e20 end
local function clamp(n,a,b) return math.max(a,math.min(b,n)) end
function M.defaults() return {enabled=false,speed=80,style='soft',brakeCancel=true} end
function M.valid(c)
 return type(c)=='table' and type(c.enabled)=='boolean' and finite(c.speed) and c.speed>=10 and c.speed<=400 and (c.style=='soft' or c.style=='cut') and type(c.brakeCancel)=='boolean'
end
function M.reset(reason) armed=false;cut=false;state={armed=false,active=false,factor=1,reason=reason or 'Désactivé'} end
local function brake()
 local e=electrics and electrics.values or {}
 return math.max(tonumber(e.brake_input) or 0,tonumber(input and input.brake) or 0)>.05
end
local function available(c,e,remote)
 if remote then return false,'Véhicule distant' end
 if not c or not c.enabled then return false,'Fonction désactivée' end
 if not playerInfo or not playerInfo.anyPlayerSeated then return false,'Aucun conducteur' end
 if not e or e.hasFuel==false or e.isDisabled or e.isStalled or (e.ignitionCoef or 1)<=0 or (e.outputAV1 or 0)<20 then return false,'Moteur arrêté' end
 if c.brakeCancel and brake() then return false,'Désactivé au freinage' end
 return true
end
function M.toggle(c,e,remote)
 if armed then M.reset();return false end
 local ok,reason=available(c,e,remote)
 if not ok then M.reset(reason);return false end
 armed=true;cut=false;state={armed=true,active=false,factor=1,reason='Prêt',target=c.speed};return true
end
function M.status() return state end
function M.update(dt,c,e,remote)
 local ok,reason=available(c,e,remote)
 if not ok then M.reset(reason);return 1 end
 if not armed then return 1 end
 -- Ground velocity avoids false interventions caused by wheelspin.
 local speed
 if obj and obj.getVelocity then
  local velocity=obj:getVelocity()
  if velocity and velocity.length then speed=velocity:length()*3.6 end
 end
 if not finite(speed) then M.reset('Vitesse véhicule indisponible');return 1 end
 local factor
 if c.style=='cut' then
  if speed>=c.speed then cut=true elseif speed<=c.speed-1 then cut=false end
  factor=cut and 0 or 1
 else
  local band=clamp(c.speed*.04,2,8)
  factor=clamp((c.speed+.3-speed)/band,0,1)
 end
 state={armed=true,active=factor<.995,factor=factor,speed=speed,target=c.speed,reason=factor<.995 and 'Limitation du couple' or 'Prêt'}
 return factor
end
return M
