-- Optional short-return character. Fuel/timing/temperature eligibility stays
-- in the controller; cadence and pulse force are independent controls.
local M={}
local axis={1200,2000,3000,4000,5000,6000,7000,8000,9000,10000,12000}
local function finite(n)return type(n)=='number'and n==n and math.abs(n)<math.huge end
local function clamp(n,a,b)return math.max(a,math.min(b,n))end
function M.defaults(hz)
 local c={enabled=false,byRPM=false,aggression=50,irregularity=50,aggressionRPM={},hzRPM={},irregularityRPM={}}
 for i=1,11 do c.aggressionRPM[i]=50;c.hzRPM[i]=hz or 5;c.irregularityRPM[i]=50 end
 return c
end
function M.validate(o)
 local c=o.popControl;if c==nil then return true end
 if type(c)~='table'or type(c.enabled)~='boolean'or type(c.byRPM)~='boolean'then return false,'Activation des detonations pied leve invalide.'end
 for _,k in ipairs({'aggression','irregularity'})do if not finite(c[k])or c[k]<0 or c[k]>100 then return false,'Detonations : '..k..' doit etre de 0 a 100.'end end
 for k,r in pairs({aggressionRPM={0,100},hzRPM={1,12},irregularityRPM={0,100}})do
  local a=c[k];if type(a)~='table'then return false,'Table de detonations manquante : '..k end
  local count=0;for i,n in pairs(a)do
   if type(i)~='number'or i%1~=0 or i<1 or i>11 or not finite(n)or n<r[1]or n>r[2]then return false,'Cellule de detonations invalide : '..k end
   count=count+1
  end
  if count~=11 then return false,'Table de detonations : 11 colonnes requises.'end
 end
 return true
end
local function value(a,rpm,x)
 if rpm<=x[1]then return a[1]end
 for i=2,11 do if rpm<=x[i]then local t=(rpm-x[i-1])/(x[i]-x[i-1]);return a[i-1]+(a[i]-a[i-1])*t end end
 return a[11]
end
function M.apply(command,o,rpm)
 command.popAggression,command.popIrregularity=nil,nil
 local c=o and o.popControl
 if not c or not c.enabled or command.style~='pops'then return command end
 local aggression,irregularity,hz=c.aggression,c.irregularity,o.popHz
 if c.byRPM then
  local x=o.rpmMap and o.rpmMap.axis or axis
  aggression=value(c.aggressionRPM,rpm,x);irregularity=value(c.irregularityRPM,rpm,x);hz=value(c.hzRPM,rpm,x)
 end
 command.popAggression=clamp(aggression,0,100);command.popIrregularity=clamp(irregularity,0,100);command.popHz=clamp(hz,1,12)
 return command
end
local function pick(key,salt)local n=math.sin(key*127.1+salt*311.7)*43758.5453;return n-math.floor(n)end
function M.pulse(p,serial,state)
 local pressure=clamp(p.demand or 0,0,1);local heat=clamp(p.heat or .65,0,1)
 local a=clamp(p.aggression or 50,0,100)/100;local irregular=clamp(p.irregularity or 50,0,100)/100
 local base=clamp(p.period or .2,1/12,1);local key=serial+(state.seed or 0)*.137
 local late=clamp(p.retard or 0,0,1);local fuel=clamp(p.fuel or 0,0,1);local warm=.35+.65*heat
 local r=pick(key,3);local chance=.78*a^1.55*(.12+.88*pressure)*warm*(.25+.75*late)
 local kind=pressure>.10 and r<chance and 'bang'or r>(.40+.55*a)and 'crackle'or 'pop'
 local spacing,train=1,false
 if irregular<=0 then state.remaining=0;state.spacingDebt=0
 elseif (state.remaining or 0)>0 then
  train=true;state.remaining=state.remaining-1
  if state.remaining==0 then spacing=1+(state.spacingDebt or 0);state.spacingDebt=0
  else spacing=math.max(.04/base,1-.65*irregular);state.spacingDebt=(state.spacingDebt or 0)+1-spacing end
 elseif pick(key,7)<.28*irregular then
  train=true;state.remaining=1+math.floor(2*pick(key,29));state.cycle=(state.cycle or 0)+1
  spacing=math.max(.04/base,1-.65*irregular);state.spacingDebt=1-spacing
 else spacing=math.max(.04/base,1+irregular*.55*(2*pick(key,17)-1))end
 local multiplier=kind=='bang'and 1.18 or kind=='crackle'and .48 or .90
 local dose=clamp(pressure*(.26+.92*a)*(.86+.24*pick(key,11))*multiplier,0,1)
 if pressure<=0 or fuel<=0 or late<=0 then dose=0 end
 return {demand=dose,period=math.max(.04,base*spacing),boost=kind=='bang'and 1+.42*dose or 1,kind=kind,
  duration=(kind=='bang'and .96+.24*dose or kind=='crackle'and .70+.10*dose or .78+.30*dose)*(.88+.12*fuel),train=train,remaining=state.remaining or 0}
end
return M
