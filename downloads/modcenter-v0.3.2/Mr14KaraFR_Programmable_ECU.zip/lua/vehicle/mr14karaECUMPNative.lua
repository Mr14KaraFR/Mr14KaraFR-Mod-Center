-- Use BeamMP's existing custom-electrics transport. No server plugin required.
local M={}
-- Launcher ServerSend aborts if any packet >500 bytes contains "Zp",
-- including inside custom-electrics data. Replace Z in our private alphabet.
local alphabet='ABCDEFGHIJKLMNOPQRSTUVWXY_abcdefghijklmnopqrstuvwxyz0123456789+/'
local values={};for i=1,#alphabet do values[alphabet:sub(i,i)]=i-1 end
local elapsed,tuneAge,serial,lastRevision=0,5,0,nil
local lastTune,lastFrame
local outgoing,sendIndex,transferID
local incoming,completed
local stats={sent=0,frames=0,tunes=0,received=0}
local commandFields={'managed','active','demand','mode','style','popHz','popAggression','popIrregularity','maxThrottle','rpm','lambda','extraFuel','advance','baseAdvance','retard','exhaustTemperature','shiftKind','shiftGear','shiftBusy','shiftCut','shiftPedal','shiftLoad','shiftFuel','shiftRetard','shiftMaxRPM','shiftAllowed','bangs','rolling'}
local function wireNumber(n)
  if type(n)~='number' or n~=n or math.abs(n)==math.huge then return n end
  return (n<0 and -1 or 1)*math.floor(math.abs(n)*1000+.5)/1000
end
local function compactValues(t)
  for k,n in pairs(t) do if type(n)=='table' then compactValues(n) else t[k]=wireNumber(n) end end
  return t
end
local function checksum(s)
  local a,b=1,0
  for i=1,#s do a=(a+s:byte(i))%65521;b=(b+a)%65521 end
  return string.format('%.0f',b*65536+a)
end
local function encode(s)
  local out={}
  for i=1,#s,3 do
    local a,b,c=s:byte(i,i+2);local n=a*65536+(b or 0)*256+(c or 0)
    local x,y,z,w=math.floor(n/262144)%64,math.floor(n/4096)%64,math.floor(n/64)%64,n%64
    out[#out+1]=alphabet:sub(x+1,x+1)..alphabet:sub(y+1,y+1)..(b and alphabet:sub(z+1,z+1) or '=')..(c and alphabet:sub(w+1,w+1) or '=')
  end
  return table.concat(out)
end
local function decode(s)
  if type(s)~='string' or #s>45000 then return end
  local encoded=s:match('^F2:%d+:([A-Y_a-z0-9+/=]+)$')
  if not encoded or #encoded%4~=0 then return end
  local out={}
  for i=1,#encoded,4 do
    local a,b,c,d=encoded:sub(i,i),encoded:sub(i+1,i+1),encoded:sub(i+2,i+2),encoded:sub(i+3,i+3)
    if not values[a] or not values[b] or c=='=' and d~='=' or (c=='=' or d=='=') and i+3~=#encoded then return end
    if c~='=' and values[c]==nil or d~='=' and values[d]==nil then return end
    local n=values[a]*262144+values[b]*4096+(values[c] or 0)*64+(values[d] or 0)
    out[#out+1]=string.char(math.floor(n/65536)%256)..(c~='=' and string.char(math.floor(n/256)%256) or '')..(d~='=' and string.char(n%256) or '')
  end
  return table.concat(out)
end
-- The active mode is already present at the root. Omit its bank only when
-- strictly identical, then restore it at reception (also understood by old ECU migration).
local function equal(a,b)
 if type(a)~=type(b) then return false end
 if type(a)~='table' then return a==b end
 for k,v in pairs(a) do if not equal(v,b[k]) then return false end end
 for k in pairs(b) do if a[k]==nil then return false end end
 return true
end
local function modePayload(t)
 local p=deepcopy(t);p.modeMaps=nil;p.activeMode=nil;p.profileMeta=nil;return p
end
function M.publish(dt,key,revision,tune,command,sample,cutTime)
  elapsed=elapsed+dt;tuneAge=tuneAge+dt
  if elapsed<.1 then return true end;elapsed=0;serial=(serial+1)%1000000000
  if lastRevision~=revision or not outgoing and tuneAge>=5 then
    local shared=deepcopy(tune);shared.profileMeta=nil
    if shared.modeMaps and (shared.activeMode=='eco' or shared.activeMode=='route' or shared.activeMode=='sport') and equal(shared.modeMaps[shared.activeMode],modePayload(shared)) then shared.modeMaps[shared.activeMode]=nil end

    local json=jsonEncode({protocol=1,key=key,revision=revision,tune=shared})
    if #json>32768 then return false,'Cartographie trop volumineuse pour la liaison BeamMP native.' end
    local encoded=encode(json);outgoing={};transferID=checksum(encoded)
    for i=1,#encoded,384 do outgoing[#outgoing+1]=encoded:sub(i,i+383) end
    sendIndex=1
    lastRevision=revision;tuneAge=0
  end
  -- A small fragment replaces the previous fragment; it never accumulates fields.
  if outgoing then
    electrics.values.mr14ecu_tune='C2:'..transferID..':'..sendIndex..':'..#outgoing..':'..outgoing[sendIndex]
    sendIndex=sendIndex+1
    if sendIndex>#outgoing then outgoing=nil;tuneAge=0 end
  end
  local frameError
  if sample.rpm and command then
    local wireCommand={};for _,k in ipairs(commandFields) do wireCommand[k]=type(command[k])=='table' and deepcopy(command[k]) or command[k] end
    if wireCommand.style~='pops' then wireCommand.popAggression=nil;wireCommand.popIrregularity=nil end
    if tune and tune.fuelType=='diesel' then wireCommand.popAggression=nil;wireCommand.popIrregularity=nil;for _,k in ipairs({'shiftKind','shiftGear','shiftBusy','shiftCut','shiftPedal','shiftLoad','shiftFuel','shiftRetard','shiftMaxRPM','shiftAllowed','bangs','rolling'}) do wireCommand[k]=nil end end
    local frame={protocol=1,key=key,revision=revision,command=compactValues(wireCommand),sample={rpm=sample.rpm,load=sample.load,pedal=sample.pedal,
      transmissionActive=sample.transmissionActive,gearChangeTime=sample.gearChangeTime,lockupRatio=sample.lockupRatio,rollingActive=sample.rollingActive,rollingPrepActive=sample.rollingPrepActive,rollingTargetRPM=sample.rollingTargetRPM,lambda=sample.lambda,fuelFactor=sample.fuelFactor,gear=sample.gear,commandedThrottle=sample.commandedThrottle,mappedThrottle=sample.mappedThrottle,pedalMapActive=sample.pedalMapActive,boostByGearActive=sample.boostByGearActive,dieselFlameDemand=sample.dieselFlameDemand,dieselEGT=sample.dieselEGT,dieselSmokeDemand=sample.dieselSmokeDemand,dieselSmokeGain=sample.dieselSmokeGain,boostPsi=sample.boostPsi,dieselAirLimit=sample.dieselAirLimit,dieselAirLimited=sample.dieselAirLimited,idleTargetRPM=sample.idleTargetRPM,limiterActive=sample.limiterActive==true,limiterCut=sample.limiterCut==true,ignitionCutTime=math.min(math.max(cutTime or 0,0),2),engineRunning=sample.engineRunning==true,ignitionCut=sample.ignitionCut==true}}
    -- Gasoline rolling frames do not need diesel-only telemetry. Keep that
    -- headroom for the cut signal, even with longer modded-engine identifiers.
    if tune and tune.fuelType=='gasoline' then for _,k in ipairs({'dieselFlameDemand','dieselEGT','dieselSmokeDemand','dieselSmokeGain','dieselAirLimit','dieselAirLimited'}) do frame.sample[k]=nil end end
    compactValues(frame.sample)
    local json=jsonEncode(frame);stats.frameBytes=#json;stats.frameLimit=1200
    if #json<=1200 then
      electrics.values.mr14ecu_frame='F2:'..serial..':'..encode(json)
      if stats.error=='Etat des effets trop volumineux' then stats.error=nil end
    else
      electrics.values.mr14ecu_frame=nil;frameError='Etat des effets trop volumineux';stats.error=frameError
    end
  end
  -- Send every fragment explicitly through the existing owned-vehicle transport.
  -- Polling electrics later can skip overwritten fragments when frames are delayed.
  if obj.queueGameEngineLua then
    local packet=jsonEncode({mr14ecu_tune=electrics.values.mr14ecu_tune,mr14ecu_frame=electrics.values.mr14ecu_frame})
    obj:queueGameEngineLua('if MPElectricsGE then MPElectricsGE.sendElectrics('..string.format('%q',packet)..','..obj:getID()..') end')
  end
  stats.sent=stats.sent+1
  if frameError then return false,frameError end
  return true
end
function M.receive(controller)
  local e=electrics.values
  if type(e.mr14ecu_tune)=='string' and e.mr14ecu_tune~=lastTune then
    stats.received=stats.received+1
    lastTune=e.mr14ecu_tune
    if #lastTune<=430 then
      local id,index,total,chunk=lastTune:match('^C2:(%d+):(%d+):(%d+):([A-Y_a-z0-9+/=]+)$')
      index,total=tonumber(index),tonumber(total)
      if id and #id<=10 and index and total and total>=1 and total<=114 and index>=1 and index<=total and #chunk<=384 and id~=completed then
        if not incoming or incoming.id~=id or incoming.total~=total then incoming={id=id,total=total,parts={},count=0} end
        if not incoming.parts[index] then incoming.count=incoming.count+1 end
        incoming.parts[index]=chunk
        if incoming.count==total then
          local encoded=table.concat(incoming.parts)
          if #encoded<=43700 and checksum(encoded)==id then
            local json=decode('F2:0:'..encoded)
            if json then
              local decodedOK,d=pcall(jsonDecode,json)
              if decodedOK and type(d)=='table' and type(d.tune)=='table' then
                local t=d.tune
                if type(t.modeMaps)=='table' and (t.activeMode=='eco' or t.activeMode=='route' or t.activeMode=='sport') and t.modeMaps[t.activeMode]==nil then t.modeMaps[t.activeMode]=modePayload(t);json=jsonEncode(d) end
              end
              local ok,reason=controller.receiveMultiplayerJSON('tune',json)
              if ok then completed=id;stats.tunes=stats.tunes+1;stats.error=nil else stats.error=reason or 'Cartographie refusee' end
            end
          end
          incoming=nil
        end
      end
    end
  end
  if type(e.mr14ecu_frame)=='string' and e.mr14ecu_frame~=lastFrame then
    lastFrame=e.mr14ecu_frame;local json=decode(lastFrame)
    if json then
      local ok,reason=controller.receiveMultiplayerJSON('frame',json)
      if ok then stats.frames=stats.frames+1;stats.error=nil else stats.error=reason or 'Etat des effets refuse' end
    end
  end
end
function M.status()
  local s=deepcopy(stats);s.parts=incoming and incoming.count or 0;s.total=incoming and incoming.total or 0;return s
end
function M.reset()
  elapsed,tuneAge,serial,lastRevision=0,5,0,nil;lastTune,lastFrame=nil,nil
  outgoing,sendIndex,transferID,incoming,completed=nil,nil,nil,nil,nil
  stats={sent=0,frames=0,tunes=0,received=0}
  electrics.values.mr14ecu_tune=nil;electrics.values.mr14ecu_frame=nil
end
return M
