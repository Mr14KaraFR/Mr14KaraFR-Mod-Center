-- Bounded exhaust-combustion appearance model; not a chemistry solver.
local M={}
local function clamp(v,a,b) return math.max(a,math.min(b,v)) end
local function number(v,fallback) v=tonumber(v);if not v or v~=v or math.abs(v)>100000 then return fallback end;return v end
function M.resolve(s)
 local kind=s.style or s.mode
 local id=kind=='pops' and 1 or kind=='continuous' and 2 or kind=='launch' and 3 or kind=='antilag' and 4 or 0
 local fuel=clamp(number(s.extraFuel,0),0,40)
 local lambda=clamp(number(s.lambda,1)/(1+fuel/100),.45,2)
 local rich=clamp((1-lambda)/.5,0,1)
 local timing=clamp((number(s.baseAdvance,number(s.advance,0))-number(s.advance,0))/30,-1,1)
 -- Demand already includes injected fuel, requested retard, heat and mode
 -- intensity from the controller. Main fuel/timing maps modulate efficiency
 -- without flattening all strong settings into the same saturated jet.
 local energy=clamp(number(s.demand,0),0,1)*(.70+.30*rich)*(.90+.10*timing)
 if fuel<=0 or number(s.retard,0)<=0 then energy=0 end
 local demand=clamp(energy,0,1)
 local period=id==1 and 1/clamp(number(s.popHz,5),1,30) or id==3 and .065 or id==4 and .05 or .05
 local hold=id==2 and .14 or id==4 and .11 or id==3 and .075 or 0
 local temperature=number(s.exhaustTemperature,464.5)
 return {aggression=s.popAggression,irregularity=s.popIrregularity,id=id,demand=demand,fuel=fuel/40,rich=rich,retard=clamp(number(s.retard,0)/40,0,1),period=period,hold=hold,heat=clamp((temperature-120)/530,0,1)}
end
-- Seeded variation changes individual salves without using global math.random.
local function pick(serial,salt)
 local n=math.sin(serial*127.1+salt*311.7)*43758.5453
 return n-math.floor(n)
end
-- One scheduler per vehicle. Train state never outlives ECU eligibility.
function M.newPopState(seed)
 return {seed=math.floor(number(seed,0))%65521,remaining=0,cycle=0}
end
function M.clearPopTrain(state)
 if state then state.remaining=0;state.spacingDebt=0 end
end
function M.pulse(profile,serial,state)
 state=state or M.newPopState(0)
 if profile.aggression~=nil then return require('mr14karaECUPopControl').pulse(profile,serial,state)end
 local pressure=clamp(number(profile.demand,0),0,1)
 local heat=clamp(number(profile.heat,.65),0,1)
 local base=clamp(number(profile.period,.2),1/30,1)
 local key=serial+(state.seed or 0)*.137
 local fuel=clamp(number(profile.fuel,1),0,1);local late=clamp(number(profile.retard,1),0,1)
 local r=pick(key,3);local warm=.35+.65*heat
 local follow=(state.remaining or 0)>0
 local bang=pressure>.18 and r<pressure^1.4*(.12+.32*warm)*(.45+.55*late)
 local kind=bang and 'bang' or r>.66 and 'crackle' or 'pop'
 local spacing=.85+.40*pick(key,17)
 local train=false
 if follow then
  state.remaining=state.remaining-1;train=true
  -- A train is a few distinct impulses, never a continuous flame command.
  if not bang and pick(key,5)>.36 then kind='crackle' end
  spacing=.42+.24*pick(key,23)
  if state.remaining==0 then spacing=1.65+.95*pick(key,19) end
 elseif pressure>.12 and pick(key,7)<.10+.36*pressure*warm*(.55+.45*fuel) then
  state.remaining=1+math.floor(3*pick(key,29));state.cycle=(state.cycle or 0)+1
  spacing=.46+.20*pick(key,23);train=true
 elseif pick(key,31)<.13 then spacing=1.5+.70*pick(key,19) end
 local multiplier=kind=='bang' and (1.04+.20*warm) or kind=='crackle' and (.34+.16*pick(key,37)) or (.78+.22*pick(key,41))
 local dose=clamp(pressure*(.82+.24*pick(key,11))*multiplier,0,1)
 local duration=kind=='bang' and (.96+.24*dose) or kind=='crackle' and (.70+.10*dose) or (.78+.30*dose)
 return {demand=dose,period=math.max(.040,base*spacing*(1.15-.15*late)),boost=kind=='bang' and 1+.42*dose or 1,
   kind=kind,duration=duration*(.88+.12*fuel),train=train,remaining=state.remaining or 0}
end
return M
