-- Local nonblocking HTTP bridge; only named ECU actions are accepted.
local M={}
local socket=require('socket.socket')
local listener,clients,events=nil,{},{}
local sequence=0
local host='127.0.0.1:8724'
local token=''
local launcherState='/settings/mr14kara_ecu_external_launcher.json'
local launcherRequest='/settings/mr14kara_ecu_external_request.json'
local pendingOpen,openAge,launcherPoll=nil,0,0
local allowed={Mr14ECUMultiplayerStatus=true,Mr14ECUFaults=true,Mr14ECUState=true,Mr14ECUSample=true,Mr14ECUNotice=true,Mr14ECUProfiles=true,Mr14ECUProfileIndex=true,Mr14ECUFileNotice=true,Mr14ECULoadedTune=true}
local function publish(event,json)
  if not allowed[event] or type(json)~='string' or #json>4000000 then return end
  local ok,data=pcall(jsonDecode,json);if not ok then return end
  if type(data)=='table' and type(data.hardwareKey)=='string' and hashStringSHA256 then data.hardwareKey=hashStringSHA256(data.hardwareKey) end
  if #jsonEncode(data)>65000 then return end
  sequence=sequence+1;events[#events+1]={id=sequence,event=event,data=data}
  if #events>64 then table.remove(events,1) end
end
local function emit(event,data) guihooks.trigger(event,data);publish(event,jsonEncode(data)) end
local function action(data)
  if type(data)~='table' or type(data.action)~='string' then return false,'Commande invalide' end
  local commands={toggleSpeedLimiter='if c.toggleSpeedLimiter then c.toggleSpeedLimiter() end',testDetonation='if c.testDetonation then c.testDetonation() else guihooks.trigger("Mr14ECUNotice",{ok=false,message="Redémarre BeamNG avec le nouveau ZIP ECU."}) end',getState='c.requestState()',getSample='c.requestSample()',getFaults='c.requestFaults()',clearFaults='c.clearFaults()',resetTune='c.resetTune()'}
  local code=commands[data.action]
  if data.action=='applyTune' then
    if type(data.tune)~='table' or #jsonEncode(data.tune)>60000 then return false,'Cartographie invalide' end
    code='if c.setTuneJSON('..string.format('%q',jsonEncode(data.tune))..') then c.requestState() end'
  end
  if code then
    local vehicle=getPlayerVehicle(0)
    if not vehicle then emit('Mr14ECUState',{installed=false,vehicleId=0});return true end
    if (data.action=='toggleSpeedLimiter' or data.action=='testDetonation' or data.action=='applyTune' or data.action=='resetTune' or data.action=='clearFaults') and data.vehicleId~=vehicle:getID() then return false,'Vehicule change : reconnecter avant application' end
    local missing='local d={installed=false,vehicleId=obj:getID()}; guihooks.trigger("Mr14ECUState",d); obj:queueGameEngineLua("if extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.publish("..string.format("%q","Mr14ECUState")..","..string.format("%q",jsonEncode(d))..") end")'
    vehicle:queueLuaCommand('local c=controller.getController("mr14karaECU"); if c then '..code..' else '..missing..' end')
    return true
  end
  local validStorage={listTunes=true,saveTune=true,loadTune=true,exportLog=true}
  if not validStorage[data.action] then return false,'Commande inconnue' end
  if not extensions.mr14karaECUStorage then extensions.load('mr14karaECUStorage') end
  local storage=extensions.mr14karaECUStorage
  if not storage then return false,'Stockage indisponible' end
  if data.action=='listTunes' then storage.listTunes()
  elseif data.action=='saveTune' then
    if type(data.tune)~='table' then return false,'Cartographie invalide' end
    storage.saveTune(data.name,jsonEncode(data.tune))
  elseif data.action=='loadTune' then storage.loadTune(data.name)
  elseif data.action=='exportLog' then storage.exportLog(data.csv) end
  return true
end
local function response(status,kind,body)
  return 'HTTP/1.1 '..status..'\r\nContent-Type: '..kind..'\r\nContent-Length: '..#body..'\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nContent-Security-Policy: frame-ancestors \'none\'\r\n\r\n'..body
end
local assets={
  ['/ui/modules/apps/Mr14KaraECU/app.js']={'/ui/modules/apps/Mr14KaraECU/app.js','application/javascript'},
  ['/ui/modules/apps/Mr14KaraECU/app.html']={'/ui/modules/apps/Mr14KaraECU/app.html','text/html; charset=utf-8'},
  ['/ui/modules/apps/Mr14KaraECU/style.css']={'/ui/modules/apps/Mr14KaraECU/style.css','text/css'},
  ['/external.js']={'/ui/modules/apps/Mr14KaraECU/external.js','application/javascript'},
  ['/angular.js']={'/ui/lib/ext/angular/angular.js','application/javascript'}
}
-- Keep this extension's UI version available even if its ZIP is later unmounted.
local bundledOK,bundled=pcall(require,'common/mr14karaECUWebAssets')
local webAssets=bundledOK and type(bundled)=='table' and bundled or {}
local function webFile(path)
  -- BeamMP can mount a newer server ZIP while this GE extension stays loaded.
  -- Prefer its current UI; retained assets are only a fallback after unmount.
  local content=readFile(path)
  if type(content)=='string' and #content>0 then webAssets[path]=content;return content end
  return webAssets[path]
end
-- The Angular runtime belongs to the game, not to the ECU ZIP.
webFile('/ui/lib/ext/angular/angular.js')
local function handle(method,path,headers,body)
  if headers.host~=host then return response('403 Forbidden','text/plain','Host invalide') end
  if headers.origin and headers.origin~='http://'..host then return response('403 Forbidden','text/plain','Origin invalide') end
  if method=='GET' and (path=='/' or path=='/index.html') then
    local html=webFile('/ui/modules/apps/Mr14KaraECU/external.html')
    if not html then return response('503 Service Unavailable','text/plain; charset=utf-8','Interface ECU indisponible. Activez le mod ECU puis redemarrez BeamNG. En multijoueur, le serveur doit distribuer le nouveau ZIP ECU.') end
    return response('200 OK','text/html; charset=utf-8',html:gsub('__ECU_TOKEN__',token))
  end
  if method=='GET' and assets[path] then
    local a=assets[path];local content=webFile(a[1])
    return response(content and '200 OK' or '404 Not Found',a[2],content or 'Fichier absent')
  end
  if headers['x-ecu-token']~=token then return response('403 Forbidden','application/json','{"ok":false,"error":"Session invalide"}') end
  if method=='GET' and path:match('^/api/events%?after=%d+$') then
    local after=tonumber(path:match('after=(%d+)')) or 0
    local selected={};for _,e in ipairs(events) do if e.id>after then selected[#selected+1]=e end end
    return response('200 OK','application/json',jsonEncode({cursor=sequence,events=selected}))
  end
  if method=='POST' and path=='/api/action' then
    local ok,data=pcall(jsonDecode,body)
    if not ok then return response('400 Bad Request','application/json','{"ok":false,"error":"JSON invalide"}') end
    local accepted,message=action(data)
    return response('200 OK','application/json',jsonEncode({ok=accepted,error=message}))
  end
  return response('404 Not Found','text/plain','Introuvable')
end
local function drop(i) clients[i].socket:close();table.remove(clients,i) end
local function onUpdate(dtReal)
  if pendingOpen then
    openAge=openAge+(dtReal or 0.016);launcherPoll=launcherPoll+(dtReal or 0.016)
    if launcherPoll>=0.25 then
      launcherPoll=0
      local state=jsonReadFile(launcherState)
      if state and state.requestId==pendingOpen then
        emit('Mr14ECUFileNotice',{ok=state.ok==true,message=state.ok and 'Editeur externe ouvert dans votre navigateur Windows.' or 'Windows n a pas pu ouvrir le navigateur.'})
        pendingOpen=nil
      elseif openAge>10 then
        emit('Mr14ECUFileNotice',{ok=false,message='Le lanceur Windows ne repond pas. Relancez ECU External Launcher.'});pendingOpen=nil
      end
    end
  end
  if not listener then return end
  for _=1,4 do
    local c=listener:accept();if not c then break end;c:settimeout(0)
    if #clients>=12 then c:close() else clients[#clients+1]={socket=c,buffer='',age=0} end
  end
  for i=#clients,1,-1 do
    local c=clients[i];c.age=c.age+(dtReal or 0.016)
    if c.age>15 then drop(i)
    elseif c.output then
      local sent,err,partial=c.socket:send(c.output,c.position or 1)
      c.position=(sent or partial or ((c.position or 1)-1))+1
      if c.position>#c.output or (err and err~='timeout') then drop(i) end
    else
      local text,err,partial=c.socket:receive(32768)
      c.buffer=c.buffer..(text or partial or '')
      if #c.buffer>4100000 then drop(i)
      elseif err=='closed' then drop(i)
      else
        local boundary=c.buffer:find('\r\n\r\n',1,true)
        if boundary then
          local method,path=c.buffer:match('^(%u+) ([^ ]+) HTTP/1%.[01]\r\n')
          local headers={};for name,value in c.buffer:sub(1,boundary):gmatch('\r\n([^:\r\n]+):%s*([^\r\n]*)') do headers[name:lower()]=value end
          local length=tonumber(headers['content-length']) or 0
          if not method or length<0 or length>4000000 or headers['transfer-encoding'] then drop(i)
          elseif #c.buffer>=boundary+3+length then
            local ok,out=pcall(handle,method,path,headers,c.buffer:sub(boundary+4,boundary+3+length))
            c.output=ok and out or response('500 Internal Server Error','text/plain','Erreur du calculateur');c.position=1
            if not ok then log('E','mr14karaECUExternal',tostring(out)) end
          end
        elseif #c.buffer>16384 then drop(i) end
      end
    end
  end
end
local function stop()
  for i=#clients,1,-1 do drop(i) end
  if listener then listener:close();listener=nil end
end
local function start()
  if listener then return true end
  local c=socket.tcp();c:settimeout(0)
  local ok,err=c:bind('127.0.0.1',8724)
  if not ok then c:close();guihooks.trigger('Mr14ECUFileNotice',{ok=false,message='Port 8724 indisponible : '..tostring(err)});return false end
  local listening,listenError=c:listen(12)
  if not listening then c:close();guihooks.trigger('Mr14ECUFileNotice',{ok=false,message='Impossible de demarrer la liaison externe : '..tostring(listenError)});return false end
  listener=c;events={};sequence=0
  token=tostring(os.time())..tostring(math.random(100000000,999999999))..tostring(math.random(100000000,999999999))
  return true
end
-- Direct browser shortcut requires no companion. An already running optional
-- Windows companion can still open the fixed URL from the in-game button.
local function open()
  if not start() then return false end
  local state=jsonReadFile(launcherState)
  if not state or type(state.time)~='number' or math.abs(os.time()-state.time)>8 then
    emit('Mr14ECUFileNotice',{ok=true,message='Editeur pret. Ouvrez le raccourci ECU Studio ou cette adresse dans votre navigateur : http://'..host..'/'})
    return true
  end
  pendingOpen=tostring(os.time())..'-'..tostring(math.random(100000000,999999999));openAge=0;launcherPoll=0
  jsonWriteFile(launcherRequest,{operation='openECU',requestId=pendingOpen})
  emit('Mr14ECUFileNotice',{ok=true,message='Ouverture de l editeur externe en cours...'})
  return true
end
M.start=start;M.open=open;M.stop=stop;M.publish=publish
M.onUpdate=onUpdate;M.onExtensionUnloaded=stop
return M
