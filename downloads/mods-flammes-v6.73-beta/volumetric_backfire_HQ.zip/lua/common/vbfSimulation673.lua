local base=require('common/vbfSimulation669');local size=require('common/vbfTurboDiameter673')
local M={new=base.new}
function M.step(p,dt,wx,wy,wz)local alive=base.step(p,dt,wx,wy,wz);size.packet(p);return alive end
return M
