-- Read the same outer radius / wall thickness used by Movable Turbo's open
-- tube mesh. No mesh guessing, scene mutation, or replacement exhaust source.
local M={}
local function number(n,default)n=tonumber(n);if not n or n~=n or math.abs(n)==math.huge then return default end;return n end
local function clamp(n,a,b)return math.max(a,math.min(b,n))end
function M.resolve(bundle,finish,start)
 local nodes=bundle and bundle.vdata and bundle.vdata.nodes
 local last,first=nodes and nodes[finish],nodes and nodes[start]
 if not last or not first then return end
 local vars=bundle.config and bundle.config.vars or {}
 local key,outer
 if last.name=='mr14turbo_fx_end'and first.name=='mr14turbo_fx_start'and number(vars['$mr14turbo_freeExhaust'],0)>.5 then key='free';outer=.027
 elseif last.name=='mr14wg_fx_end'and first.name=='mr14wg_fx_start'and number(vars['$mr14turbo_wastegate_on'],0)>.5 and number(vars['$mr14turbo_pipes'],1)>.5 then
  key='wgExit';outer=clamp(number(vars['$mr14turbo_wastegate_bore'],44),40,60)*.00047
 end
 if not key then return end
 local mm=number(vars['$mr14turbo_'..key..'_diameter'],0)
 if mm>0 then outer=clamp(mm/2000,.004,.07)end
 local inner=outer-math.min(.0015,outer*.12)
 return {key=key,outer=outer,inner=inner,mouth=inner*.98}
end
local function get(p)
 if not core_vehicle_manager or not core_vehicle_manager.getVehicleData or p.vehicle==nil or p.apertureFinish==nil or p.apertureStart==nil then return end
 return M.resolve(core_vehicle_manager.getVehicleData(p.vehicle),p.apertureFinish,p.apertureStart)
end
function M.root(p)
 local d=get(p);if not d then return end
 -- Remove the generic outlet-size factor before applying the real bore.
 -- Preserve length, heat, fuel, pop timing and physical outlet attachment.
 p.radius=p.radius*(d.inner/.04)/clamp(number(p.outletScale,1),.65,1.45)
 p.mouthRadius=d.mouth
 p.turboDiameter=d.outer*2
end
function M.capture(p,outletScale)
 local d=get(p);if not d then return end
 -- Detached gas keeps its emitted size if the workshop is edited later.
 p.turboBoreScale=(d.inner/.04)/clamp(number(outletScale,1),.65,1.45)
 p.apertureRadius=d.inner+.025
end
function M.packet(p)
 if p.turboBoreScale then p.renderRadius=p.renderRadius*p.turboBoreScale end
end
return M
