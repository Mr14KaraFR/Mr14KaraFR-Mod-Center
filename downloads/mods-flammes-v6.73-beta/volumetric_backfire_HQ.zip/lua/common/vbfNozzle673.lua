local base=require('common/vbfNozzle671');local size=require('common/vbfTurboDiameter673')
local M={pose=base.pose}
function M.anchor(p,pose,remaining)base.anchor(p,pose,remaining);size.root(p)end
return M
