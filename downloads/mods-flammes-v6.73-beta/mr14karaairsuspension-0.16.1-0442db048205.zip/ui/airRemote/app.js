(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const corners = ['FL','FR','RL','RR'];
  const dampingKeys=['compression','rebound','rearCompression','rearRebound'];
  const dampingValue=(state,key) => number(state[key],key==='rearCompression' ? number(state.compression,.5) : key==='rearRebound' ? number(state.rebound,.5) : .5);
  let token = '', snapshot = null, online = false, lastSeen = 0;
  let pollTimer = null, toastTimer = null, hold = null, chain = Promise.resolve(), pending = 0;
  let hardwareDirty = false;
  let dampingDirty = false, comfortDirty = false, volumeDirty = false, polling = false, selecting = false, vehicleSignature = "";
  let pagePaused=false,pauseRequest=Promise.resolve();
  try { token = sessionStorage.getItem('mr14air-session') || localStorage.getItem('mr14air-session') || '';if(token)localStorage.setItem('mr14air-session',token); } catch (_) {}
  const number = (n, fallback = 0) => Number.isFinite(n) ? n : fallback;
  const fixed = n => number(n).toLocaleString('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1});
  function heightStep() {
    const value=Number($('height-step').value);
    return [.1,1,5,10].includes(value) ? value/100 : .01;
  }
  function toast(text) {
    $('toast').textContent = text; $('toast').hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { $('toast').hidden = true; },4000);
  }
  function canControl() {
    return !!(!pagePaused && token && online && !selecting && snapshot && snapshot.owner && snapshot.state.installed && !snapshot.state.remote && snapshot.age<=1.5 && Date.now()-lastSeen<2200);
  }
  function stopHold() {
    if (hold) { clearInterval(hold.timer); hold.element.classList.remove('pressed'); hold = null; }
  }
  function showSession() { $('pairing').hidden = !!token; $('dashboard').hidden = !token; }
  function forgetSession() {
    stopHold();clearTimeout(pollTimer);token='';snapshot=null;online=false;hardwareDirty=false;
    try { sessionStorage.removeItem('mr14air-session');localStorage.removeItem('mr14air-session'); } catch (_) {}
    showSession();render();
  }
  async function api(path, body) {
    const controller = new AbortController();const timeout = setTimeout(() => controller.abort(),4000);
    try {
      const headers = {'X-Air-Session':token};
      const options = {headers,signal:controller.signal,cache:'no-store',credentials:'omit'};
      if (body!==undefined) { options.method='POST';headers['Content-Type']='application/json';options.body=JSON.stringify(body); }
      const response = await fetch(path,options);
      const result = await response.json();
      if (!response.ok || !result.ok) {
        const error = new Error(result.error || 'Connexion refusée');error.status=response.status;throw error;
      }
      return result;
    } finally { clearTimeout(timeout); }
  }
  function render() {
    const controllable=canControl();const state=snapshot && snapshot.state || {};
    $('connection').textContent = !token ? 'À connecter' : online ? 'Connecté' : 'Hors ligne';
    $('connection').className = 'badge '+(!token ? '' : online ? 'online' : 'offline');
    document.querySelectorAll('[data-control]').forEach(element => {
      const group=element.dataset.group;
      element.disabled=!controllable || (state.workshop && !!(element.dataset.step || element.dataset.preset || element.dataset.show || element.id==='apply-profile')) || (corners.includes(group) && !(state.available && state.available[group]));
    });
    if (!controllable) stopHold();
    if (!token) return;
    const vehicles=Array.isArray(snapshot && snapshot.vehicles) ? snapshot.vehicles : [];
    const signature=JSON.stringify(vehicles);
    if (signature!==vehicleSignature) {
      vehicleSignature=signature;
      $('vehicle-select').replaceChildren(...vehicles.map(v => new Option(String(v.model).toUpperCase()+(v.profileName ? ' · '+v.profileName : '')+' · #'+v.id,String(v.id))));
      if (!vehicles.length) $('vehicle-select').add(new Option('Aucune voiture personnelle',''));
    }
    $('vehicle-select').value=String(snapshot && snapshot.vehicleId || '');
    $('vehicle-select').disabled=!online || selecting || !vehicles.length;
    $('diag-link').textContent=online ? 'Connectée · état reçu il y a '+fixed(snapshot.age)+' s' : 'Hors ligne · commandes interrompues';
    const last=snapshot && snapshot.lastCommand;
    const labels={hardware:'Installation',profile:'Profil voiture',step:'Hauteur',preset:'Rappel mémoire',savePreset:'Mémorisation',show:'Mode show',comfort:'Confort',damping:'Amortisseurs',axleDamping:'Amortisseurs avant / arrière',workshop:'Mode atelier',expo:'Mode expo',lift:'Lift temporaire',drivingMode:'Profil de conduite',volume:'Volume',automatic:'Route automatique',parking:'Parking automatique',enabled:'Activation'};
    $('diag-command').textContent=last ? (labels[last.action] || last.action)+(last.group ? ' · '+last.group : '')+' · transmise au jeu' : 'Aucune sur cette voiture';
    $('diag-suspension').textContent=state.diagnostic || 'En attente du véhicule';
    $('vehicle-name').textContent = state.model ? 'Véhicule '+String(state.model).toUpperCase() : 'Ta voiture';
    let notice='';
    if (!online) notice='Liaison perdue. Vérifie que BeamNG et la connexion Téléphone sont actifs.';
    else if (!snapshot || snapshot.vehicleId===0) notice='Charge une voiture dans BeamNG.';
    else if (!state.installed) notice='Monte le kit pneumatique sur ta voiture.';
    else if (!snapshot.owner || state.remote) notice='Voiture d’un autre joueur : lecture seule.';
    else if (snapshot.age>1.5) notice='Actualisation de la voiture en cours…';
    else if (!state.enabled) notice='Suspension désactivée. Tu peux la réactiver dans Modes & sons.';
    else if (!state.calibrated) notice='Calibrage : reste à l’arrêt deux secondes.';
    else if (state.workshop) notice='Mode atelier actif : correction de hauteur suspendue. Les fuites restent actives.';
    else if (state.leakCount>0) notice=state.diagnostic;
    else if (state.liftActive) notice='Lift actif : retour par le bouton ou dès 30 km/h.';
    else if (state.expoActive) notice='Mode expo : position basse. Retour à la hauteur Route dès 3 km/h.';
    else if (state.parkingActive) notice='Parking automatique actif.';
    else if (state.autoActive) notice='Retour automatique à la hauteur Route.';
    else if (state.assist) notice='Suspension à lames/torsion : abaissement limité par les ressorts d’origine.';
    $('notice').textContent=notice;$('notice').className='notice'+(!online || !controllable || state.leakCount>0 ? ' warn' : '');
    $('tank').textContent=state.installed ? fixed(state.tank) : '—';
    $('compressor').textContent=state.compressor ? 'En marche' : number(state.tank)<7 ? 'En attente' : 'Au repos';
    for (const corner of corners) {
      const available=state.available && state.available[corner];
      const p=state.cornerPressure && state.cornerPressure[corner];
      const h=state.cornerHeight && state.cornerHeight[corner];
      document.querySelector('[data-corner="'+corner+'"]').classList.toggle('leaking',!!(state.leakingCorners && state.leakingCorners[corner]));
      const leaking=state.leakingCorners && state.leakingCorners[corner],failed=state.failedCorners && state.failedCorners[corner];
      const loss=number(state.cornerLeakRate && state.cornerLeakRate[corner]).toLocaleString('fr-FR',{minimumFractionDigits:2,maximumFractionDigits:2});
      $('leak-'+corner).textContent=failed ? 'RUPTURE' : leaking ? (number(p)>.01 ? 'FUITE' : 'VIDE · FUITE')+' · perte estimée '+loss+' bar/s' : '';
      $('leak-diagnostic-'+corner).textContent=!available ? 'Indisponible' : failed ? 'Rupture' : leaking ? (number(p)>.01 ? 'Fuite' : 'Vide · fuite présente')+' · '+loss+' bar/s' : 'Étanche';
      $('pressure-'+corner).textContent=available ? fixed(p)+' bar' : '—';
      $('height-'+corner).textContent=available ? fixed(h)+' cm' : 'Non disponible';
      $('target-'+corner).textContent=fixed(number(state[corner])*100)+' %';
      $('meter-'+corner).value=Math.max(0,Math.min(9,number(p)));
    }
    const modeNames={off:'Arrêté',roll:'Gauche / droite',pitch:'Avant / arrière',wave:'Vague'};
    $('lift').textContent=state.liftActive ? 'LIFT actif · Revenir à la hauteur précédente' : 'LIFT · Passage d’obstacle';$('lift').setAttribute('aria-pressed',String(!!state.liftActive));
    $('lift').disabled=!controllable || !!state.workshop || !state.calibrated || !state.enabled || (!state.liftActive && (number(state.speedKmh)>=30 || number(state.tank)<=2));
    $('workshop').textContent=state.workshop ? 'ON · Reprendre la correction' : 'Activer le mode atelier';$('workshop').setAttribute('aria-pressed',String(!!state.workshop));
    $('workshop').disabled=!controllable || !state.calibrated || !state.enabled;
    $('show-state').textContent=modeNames[state.showMode] || 'Arrêté';
    document.querySelectorAll('[data-show]').forEach(button => {button.classList.toggle('active',button.dataset.show===state.showMode);button.disabled=!controllable || !!state.workshop || !state.calibrated;});
    for (const [id,key] of [['automatic','autoEnabled'],['parking','parkingEnabled'],['expo','expoEnabled']]) {
      $(id).textContent=state[key] ? 'ON' : 'OFF';$(id).setAttribute('aria-pressed',String(!!state[key]));
    }
    $('expo-state').textContent=!state.expoEnabled ? 'Désactivé' : state.workshop ? 'Suspendu · atelier' : state.liftActive ? 'Suspendu · lift' : state.expoActive ? 'Position basse active' : 'Armé · Route en roulant';
    const compressors={single:'Standard',fast:'Rapide',dual:'Double'};
    $('hardware-current').textContent=(state.tankLiters || 40)+' L · '+(compressors[state.compressorType] || 'Standard');
    if (!hardwareDirty || ($('tank-type').value===state.tankType && $('compressor-type').value===state.compressorType)) {
      $('tank-type').value=state.tankType || 'standard';$('compressor-type').value=state.compressorType || 'single';hardwareDirty=false;
    }
    $('hardware-rate').textContent='Recharge actuelle : '+fixed(state.rechargeRate)+' bar/s · contact actif';
    $('profile-current').textContent=state.profileName || 'Commun au modèle · choisis un nom pour cette voiture';
    $('enabled').textContent=state.enabled ? 'Désactiver la suspension' : 'Activer la suspension';
    const drivingNames={comfort:'Confort',sport:'Sport',custom:'Personnalisé'};
    $('driving-current').textContent=drivingNames[state.drivingMode] || 'Personnalisé';
    document.querySelectorAll('[data-driving]').forEach(button=>{button.setAttribute('aria-pressed',String(button.dataset.driving===(state.drivingMode || 'custom')));});
    if (state.remote || !dampingDirty || dampingKeys.every(key=>Math.abs(dampingValue(state,key)-Number($(key).value)/100)<.005)) {
      for(const key of dampingKeys) $(key).value=Math.round(dampingValue(state,key)*100);dampingDirty=false;
    }
    for (const key of dampingKeys) $(key+'-label').textContent=$(key).value+' %';
    if (!comfortDirty || Math.abs(number(state.comfort)-Number($('comfort').value)/100)<.005) {
      $('comfort').value=Math.round(number(state.comfort,.5)*100);comfortDirty=false;
    }
    if (!volumeDirty || Math.abs(number(state.soundVolume)-Number($('volume').value)/100)<.005) {
      $('volume').value=Math.round(number(state.soundVolume,.7)*100);volumeDirty=false;
    }
    $('comfort-label').textContent=$('comfort').value+' %';$('volume-label').textContent=$('volume').value+' %';
  }
  async function poll() {
    clearTimeout(pollTimer);if (!token || polling || pagePaused) return;
    polling=true;const session=token;
    try {
      const result=await api('/api/state');
      if (token!==session || pagePaused) return;
      if (snapshot && (result.vehicleId!==snapshot.vehicleId || result.generation!==snapshot.generation)) {stopHold();dampingDirty=false;comfortDirty=false;volumeDirty=false;hardwareDirty=false;}
      if (snapshot && result.state.profileName!==snapshot.state.profileName) {hardwareDirty=false;dampingDirty=false;comfortDirty=false;}
      if (snapshot && result.state.drivingMode!==snapshot.state.drivingMode) {dampingDirty=false;comfortDirty=false;}
      snapshot=result;online=true;lastSeen=Date.now();render();
    } catch (error) {
      if (token!==session || pagePaused) return;
      online=false;stopHold();
      if (error.status===401) { forgetSession();toast('Entre le code affiché dans le jeu pour reconnecter le téléphone.');return; }
      render();
    } finally {
      polling=false;
      if (token && !pagePaused) pollTimer=setTimeout(poll,online && !document.hidden ? 250 : 1000);
    }
  }
  function command(data,repeat=false) {
    if (!canControl()) { if (!repeat) toast('Attends que ta voiture soit disponible.');return Promise.resolve(false); }
    if (repeat && pending>0) return Promise.resolve(false);
    if (pending>=3) {stopHold();toast('Connexion occupée : relâche et réessaie.');return Promise.resolve(false);}
    const vehicleId=snapshot.vehicleId,generation=snapshot.generation,session=token;
    pending++;
    chain=chain.catch(() => {}).then(async () => {
      if (!canControl() || token!==session || snapshot.vehicleId!==vehicleId || snapshot.generation!==generation) return;
      await api('/api/action',{...data,vehicleId,generation});return true;
    }).catch(error => {
      stopHold();toast(error.message || 'Commande non envoyée');
      if (error.status===401) forgetSession();
      else if (!error.status) {online=false;render();}
      return false;
    }).finally(() => {pending--;});
    return chain;
  }
  async function pairWithPin(pin,fromQr=false) {
    if (!/^\d{6}$/.test(pin)) {toast('Recopie les six chiffres affichés dans l’ATH.');return;}
    $('pair-button').disabled=true;
    try {
      const result=await api('/api/pair',{pin});token=result.token;
      try {sessionStorage.setItem('mr14air-session',token);localStorage.setItem('mr14air-session',token);} catch (_) {}
      $('pin').value='';showSession();await poll();
    } catch (error) {if(fromQr)forgetSession();toast(error.message || 'Impossible de joindre le PC.');}
    finally {$('pair-button').disabled=false;}
  }
  $('pair-form').addEventListener('submit',event => {event.preventDefault();pairWithPin($('pin').value.trim());});
  $('vehicle-select').addEventListener('change',async () => {
    if (!online || !snapshot || selecting) return;
    const targetVehicleId=Number($('vehicle-select').value),generation=snapshot.generation;
    stopHold();selecting=true;render();
    try { await api('/api/select',{targetVehicleId,generation});snapshot=null;online=false; }
    catch (error) {toast(error.message || 'Sélection impossible');}
    finally { selecting=false;await poll(); }
  });
  $('disconnect').addEventListener('click',() => {
    const oldToken=token;forgetSession();
    if (oldToken) fetch('/api/unpair',{method:'POST',headers:{'Content-Type':'application/json','X-Air-Session':oldToken},body:'{}',keepalive:true,credentials:'omit'}).catch(() => {});
  });
  document.querySelectorAll('[data-step]').forEach(button => {
    const action=() => ({action:'step',group:button.dataset.group,delta:Math.sign(Number(button.dataset.step))*heightStep()});
    button.addEventListener('pointerdown',event => {
      if (event.button!==0 || !canControl() || button.disabled) return;
      event.preventDefault();stopHold();
      try {button.setPointerCapture(event.pointerId);} catch (_) {}
      button.classList.add('pressed');command(action());
      hold={element:button,timer:setInterval(() => {command(action(),true);},140)};
    });
    for (const name of ['pointerup','pointercancel','lostpointercapture']) button.addEventListener(name,stopHold);
    button.addEventListener('click',event => {if (event.detail===0 && !button.disabled) command(action());});
  });
  $('height-step').addEventListener('change',stopHold);
  for (const name of ['blur','pagehide']) window.addEventListener(name,stopHold);
  document.addEventListener('visibilitychange',() => {stopHold();if (!document.hidden && token) poll();});
  document.querySelectorAll('[data-preset]').forEach(button => button.addEventListener('click',() => command({action:'preset',name:button.dataset.preset})));
  document.querySelectorAll('[data-save]').forEach(button => button.addEventListener('click',() => {command({action:'savePreset',name:button.dataset.save}).then(ok => {if (ok) toast('Demande de mémorisation envoyée.');});}));
  document.querySelectorAll('[data-show]').forEach(button => button.addEventListener('click',() => command({action:'show',mode:button.dataset.show})));
  $('stop-show').addEventListener('click',() => {stopHold();command({action:'show',mode:'off'});});
  for (const id of ['tank-type','compressor-type']) $(id).addEventListener('change',() => {hardwareDirty=true;});
  $('apply-hardware').addEventListener('click',() => command({action:'hardware',tank:$('tank-type').value,compressor:$('compressor-type').value}));
  $('apply-profile').addEventListener('click',() => {
    const name=$('profile-name').value.trim();
    if (!/^[A-Za-z0-9 _-]{1,32}$/.test(name)) {toast('Utilise 1 à 32 lettres sans accents, chiffres, espaces, - ou _.');return;}
    stopHold();command({action:'profile',name});
  });
  $('automatic').addEventListener('click',() => command({action:'automatic',enabled:!snapshot.state.autoEnabled}));
  document.querySelectorAll('[data-driving]').forEach(button=>button.addEventListener('click',()=>{dampingDirty=false;comfortDirty=false;command({action:'drivingMode',mode:button.dataset.driving});}));
  $('lift').addEventListener('click',() => {stopHold();command({action:'lift',enabled:!snapshot.state.liftActive});});
  $('expo').addEventListener('click',() => {stopHold();command({action:'expo',enabled:!snapshot.state.expoEnabled});});
  $('parking').addEventListener('click',() => command({action:'parking',enabled:!snapshot.state.parkingEnabled}));
  $('enabled').addEventListener('click',() => command({action:'enabled',enabled:!snapshot.state.enabled}));
  $('workshop').addEventListener('click',() => {stopHold();command({action:'workshop',enabled:!snapshot.state.workshop});});
  for (const key of dampingKeys) $(key).addEventListener('input',() => {dampingDirty=true;$(key+'-label').textContent=$(key).value+' %';});
  function dampingCommand() {return {action:'axleDamping',frontCompression:Number($('compression').value)/100,frontRebound:Number($('rebound').value)/100,rearCompression:Number($('rearCompression').value)/100,rearRebound:Number($('rearRebound').value)/100};}
  $('apply-damping').addEventListener('click',() => command(dampingCommand()));
  $('reset-damping').addEventListener('click',() => {for (const key of dampingKeys) {$(key).value=50;$(key+'-label').textContent='50 %';}dampingDirty=true;command(dampingCommand());});
  $('comfort').addEventListener('input',() => {comfortDirty=true;$('comfort-label').textContent=$('comfort').value+' %';});
  $('volume').addEventListener('input',() => {volumeDirty=true;$('volume-label').textContent=$('volume').value+' %';});
  $('apply-comfort').addEventListener('click',() => command({action:'comfort',value:Number($('comfort').value)/100}));
  $('apply-volume').addEventListener('click',() => command({action:'volume',value:Number($('volume').value)/100}));
  for (const tab of ['control','modes']) $('tab-'+tab).addEventListener('click',() => {
    stopHold();
    for (const name of ['control','modes']) {$(name+'-panel').hidden=name!==tab;$('tab-'+name).setAttribute('aria-selected',String(name===tab));}
  });
  window.mr14AirRemotePause=function(){pagePaused=true;stopHold();clearTimeout(pollTimer);online=false;render();pauseRequest=token ? api('/api/pause',{}).catch(()=>{}) : Promise.resolve();return pauseRequest;};
  window.mr14AirRemoteResume=async function(){await pauseRequest;pagePaused=false;if(token){await api('/api/resume',{}).catch(()=>{});await poll();}};
  function consumeQr(){
    const match=location.hash.match(/^#pair=(\d{6})$/);
    // Consume the credential before requests or sharing, also on same-page scans.
    if(location.hash.startsWith('#pair='))history.replaceState(null,'',location.pathname+location.search);
    if(match){stopHold();pairWithPin(match[1],true);return true;}return false;
  }
  window.addEventListener('hashchange',consumeQr);
  showSession();render();if(!consumeQr()&&token)window.mr14AirRemoteResume();
})();
