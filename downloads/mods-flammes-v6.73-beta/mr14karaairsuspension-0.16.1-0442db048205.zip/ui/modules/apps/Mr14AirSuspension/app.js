angular.module('beamng.apps').directive('mr14AirSuspension', function () {
  return {
    templateUrl: '/ui/modules/apps/Mr14AirSuspension/app.html', replace: true, restrict: 'EA',
    controller: ['$scope', '$interval', function ($scope, $interval) {
      $scope.air = {installed:false};
      $scope.tab = 'height';
      $scope.heightControl = {step:1};
      $scope.damperControl={compression:50,rebound:50,rearCompression:50,rearRebound:50,dirty:false};
      $scope.profileDraft = '';
      $scope.equipment={tank:'standard',compressor:'single',dirty:false};
      $scope.compressorNames={single:'Standard',fast:'Rapide',dual:'Double'};
      $scope.hardware = function(tank,compressor) { if(['small','standard','large'].indexOf(tank)<0 || ['single','fast','dual'].indexOf(compressor)<0) return;run('c.setHardware('+JSON.stringify(tank)+','+JSON.stringify(compressor)+')'); };
      $scope.profile = function (value) { var name=String(value || '').trim();if (!/^[A-Za-z0-9 _-]{1,32}$/.test(name)) return;run('c.setProfile('+JSON.stringify(name)+')'); };
      $scope.remoteInfo = {running:false,urls:[]};
      $scope.phoneQr = '';
      $scope.phoneConnected = false;
      $scope.volume = null;
      $scope.comfortControl={value:50,dirty:false};
      $scope.corners = [{key:'FL',label:'Avant gauche'},{key:'FR',label:'Avant droit'},{key:'RL',label:'Arriere gauche'},{key:'RR',label:'Arriere droit'}];
      var allowed = ['front','rear','FL','FR','RL','RR'];
      function run(code) { bngApi.activeObjectLua("local c=controller.getController('mr14karaAirSuspension'); if c then "+code+" end"); }
      function query() {
        if (typeof bngApi.engineLua==='function') bngApi.engineLua("if extensions.mr14karaAirRemote then extensions.mr14karaAirRemote.showInfo() end");
        bngApi.activeObjectLua("local c=controller.getController('mr14karaAirSuspension'); if c then c.requestState() else guihooks.trigger('Mr14AirState',{installed=false}) end"); }
      $scope.preset = function (name, save) {
        if (['low','road','high'].indexOf(name)<0) return;
        run('c.'+(save ? 'savePreset' : 'recallPreset')+'("'+name+'")');
      };
      $scope.step = function (n, group) {
        n=Number(n);if (!Number.isFinite(n) || allowed.indexOf(group)<0) return;
        var step=Number($scope.heightControl.step);
        if ([.1,1,5,10].indexOf(step)<0 || n===0) return;
        run('c.stepHeight('+(Math.sign(n)*step/100)+',"'+group+'")');
      };
      $scope.toggle = function () { run('c.toggle()'); };
      $scope.phone = function (start) {
        if (typeof bngApi.engineLua!=='function') { $scope.remoteInfo.error='Disponible dans BeamNG avec le nouveau ZIP.'; return; }
        var init="if not extensions.mr14karaAirRemote then extensions.load('mr14karaAirRemote');setExtensionUnloadMode('mr14karaAirRemote','manual') end;";
        bngApi.engineLua(init+" if extensions.mr14karaAirRemote then extensions.mr14karaAirRemote."+(start ? 'start()' : 'stop()')+" end");
      };
      $scope.$on('Mr14AirRemote',function (_,data) { $scope.$evalAsync(function () {
        $scope.remoteInfo=data;
        $scope.phoneQr=data.urls && data.urls[0] ? data.urls[0]+(/^\d{6}$/.test(data.pin || '') ? '#pair='+data.pin : '') : '';
        $scope.phoneConnected=data.running===true && data.connected===true;
      }); });
      $scope.automatic = function () { run('c.toggleAutomatic()'); };
      $scope.lift = function () { run('c.toggleLift()'); };
      $scope.workshop = function () { run('c.toggleWorkshop()'); };
      $scope.expo = function () { run('c.toggleExpo()'); };
      $scope.parking = function () { run('c.toggleParking()'); };
      $scope.show = function (mode) {
        if (['off','roll','pitch','wave'].indexOf(mode)>=0) run('c.setShow("'+mode+'")');
      };
      $scope.driving = function (mode) {
        if ($scope.air.remote || ['comfort','sport','custom'].indexOf(mode)<0) return;
        $scope.damperControl.dirty=false;$scope.comfortControl.dirty=false;run('c.setDrivingMode('+JSON.stringify(mode)+')');
      };
      $scope.applyComfort = function (value) {
        var n=typeof value==='number' ? value : Number($scope.comfortControl.value)/100;
        if (!Number.isFinite(n)) return;
        n=Math.max(0,Math.min(1,n));$scope.comfortControl.value=Math.round(n*100);$scope.comfortControl.dirty=true;
        run('c.setComfort('+n+')');
      };
      $scope.applyDamping = function (reset) {
        if ($scope.air.remote) return;
        var d=$scope.damperControl,keys=['compression','rebound','rearCompression','rearRebound'],values=keys.map(function(k){return reset ? 50 : Number(d[k]);});
        if (!values.every(Number.isFinite)) return;
        values=values.map(function(n){return Math.max(0,Math.min(100,n));});
        keys.forEach(function(k,i){d[k]=values[i];});d.dirty=true;
        run('c.setAxleDamping('+values.map(function(n){return n/100;}).join(',')+')');
      };
      $scope.applyVolume = function () {
        var n=Number($scope.volume);if(!Number.isFinite(n)) return;
        run('c.setSoundVolume('+Math.max(0,Math.min(100,n))/100+')');
      };
      $scope.$on('Mr14AirState', function (_, data) {
        $scope.$evalAsync(function () {
          if ($scope.air.profileName!==data.profileName) {$scope.equipment.dirty=false;$scope.comfortControl.dirty=false;$scope.damperControl.dirty=false;}
          if ($scope.air.drivingMode!==data.drivingMode) {$scope.comfortControl.dirty=false;$scope.damperControl.dirty=false;}
          var d=$scope.damperControl,keys=['compression','rebound','rearCompression','rearRebound'];
          var values=keys.map(function(k){var n=data[k];if (!Number.isFinite(n) && (k==='rearCompression' || k==='rearRebound')) n=data[k==='rearCompression' ? 'compression' : 'rebound'];return Number.isFinite(n) ? Math.round(n*100) : 50;});
          if (data.remote || !d.dirty || keys.every(function(k,i){return Math.abs(d[k]-values[i])<.05;})) {keys.forEach(function(k,i){d[k]=values[i];});d.dirty=false;}
          if (!$scope.equipment.dirty || ($scope.equipment.tank===data.tankType && $scope.equipment.compressor===data.compressorType)) {
            $scope.equipment.tank=data.tankType || 'standard';$scope.equipment.compressor=data.compressorType || 'single';$scope.equipment.dirty=false;
          }
          $scope.air = data;
          if (Number.isFinite(data.comfort) && (data.remote || !$scope.comfortControl.dirty || Math.abs($scope.comfortControl.value-data.comfort*100)<.05)) {$scope.comfortControl.value=Math.round(data.comfort*100);$scope.comfortControl.dirty=false;}
          if ($scope.volume===null && Number.isFinite(data.soundVolume)) $scope.volume=Math.round(data.soundVolume*100);
        });
      });
      $scope.$on('VehicleChange', function () { $scope.air={installed:false};$scope.equipment.dirty=false;$scope.damperControl.dirty=false;$scope.volume=null;$scope.comfortControl.dirty=false;query(); });
      var timer=$interval(query,1000); query();
      $scope.$on('$destroy', function () { $interval.cancel(timer); });
    }]
  };
});

angular.module('beamng.apps').directive('mr14AirQr', function () {
  var loading;
  function library() {
    if (typeof window.QRCode==='function') return Promise.resolve();
    if (!loading) loading=new Promise(function(resolve,reject) {
      var script=document.createElement('script');script.src='/ui/lib/ext/qrcode.min.js';
      script.onload=resolve;script.onerror=reject;document.head.appendChild(script);
    });
    return loading;
  }
  return {restrict:'A',scope:{url:'=mr14AirQr'},link:function(scope,element) {
    var disposed=false,revision=0;
    scope.$watch('url',function(url) {
      var epoch=++revision;element.empty();
      if (!/^http:\/\/(?:10\.|192\.168\.|172\.(?:1[6-9]|2[0-9]|3[01])\.|169\.254\.)[0-9.]+:8725\/(?:#pair=\d{6})?$/.test(url || '')) return;
      library().then(function() {
        if (disposed || epoch!==revision) return;
        new window.QRCode(element[0],{text:url,width:144,height:144,correctLevel:window.QRCode.CorrectLevel.L});
      }).catch(function() {if (!disposed) element.text('QR indisponible : utilise l adresse ci-dessus.');});
    });
    scope.$on('$destroy',function(){disposed=true;revision++;});
  }};
});
