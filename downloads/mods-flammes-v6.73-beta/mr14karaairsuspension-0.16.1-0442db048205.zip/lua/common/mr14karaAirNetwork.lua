-- Compact, bounded atomic frames carried by BeamMP custom electrics.
-- No BeamMP source overrides or server-side plugin.
local M={key='mr14air_sync_v5'}
local hardware=require('mr14karaAirHardware')
local function integer(s,lo,hi)
  if type(s)~='string' or not s:match('^%-?%d+$') then return end
  local n=tonumber(s)
  if n and n>=lo and n<=hi then return n end
end
local function split(s,sep)
  local out={}
  for field in (s..sep):gmatch('(.-)'..sep) do out[#out+1]=field end
  return out
end
local function round(n) return math.floor(n+0.5) end
function M.encode(serial,state,bags)
  local header={'MA10',tostring(serial),state.enabled and '1' or '0',state.calibrated and '1' or '0',tostring(round(state.tank*100)),state.compressor and '1' or '0',tostring(round(state.front*1000)),tostring(round(state.rear*1000)),tostring(round(state.airIn*1000)),tostring(round(state.airOut*1000)),tostring(#bags),tostring(round(state.corners.FL*1000)),tostring(round(state.corners.FR*1000)),tostring(round(state.corners.RL*1000)),tostring(round(state.corners.RR*1000)),state.autoEnabled and '1' or '0',state.autoActive and '1' or '0',tostring(round(state.comfort*1000)),tostring(({off=0,roll=1,pitch=2,wave=3})[state.showMode]),state.parkingEnabled and '1' or '0',state.parkingActive and '1' or '0',tostring(hardware.tanks[state.tankType or 'standard'].index),tostring(hardware.compressors[state.compressorType or 'single'].index)}
  header[#header+1]=tostring(round((state.compression or 0.5)*1000))
  header[#header+1]=tostring(round((state.rebound or 0.5)*1000))
  header[#header+1]=tostring(round((state.rearCompression or state.compression or 0.5)*1000))
  header[#header+1]=tostring(round((state.rearRebound or state.rebound or 0.5)*1000))
  header[#header+1]=state.workshop and '1' or '0'
  header[#header+1]=state.expoEnabled and '1' or '0'
  header[#header+1]=state.expoActive and '1' or '0'
  header[#header+1]=state.liftActive and '1' or '0'
  header[#header+1]=tostring(({custom=0,comfort=1,sport=2})[state.drivingMode or 'custom'])
  for _,b in ipairs(bags) do
    header[#header+1]=string.format('%d,%d,%d,%d,%d',b.netID,round(b.charge or 0),round((b.base or b.rest)*1000),b.failed and 1 or 0,round((b.leak or 0)*1000))
  end
  return table.concat(header,';')
end
function M.decode(wire)
  if type(wire)~='string' or #wire>8192 then return end
  local f=split(wire,';')
  local headerSize=f[1]=='MA10' and 32 or f[1]=='MA9' and 31 or f[1]=='MA8' and 30 or f[1]=='MA7' and 28 or f[1]=='MA6' and 25 or f[1]=='MA5' and 23
  if not headerSize or #f<headerSize then return end
  local limits={{0,999999999},{0,1},{0,1},{0,1000},{0,1},{-1000,1000},{-1000,1000},{0,1000},{0,1000},{0,64},{-1000,1000},{-1000,1000},{-1000,1000},{-1000,1000},{0,1},{0,1},{0,1000},{0,3},{0,1},{0,1},{1,3},{1,3}}
  if headerSize>=25 then limits[#limits+1]={0,1000};limits[#limits+1]={0,1000} end
  if headerSize>=28 then limits[#limits+1]={0,1000};limits[#limits+1]={0,1000};limits[#limits+1]={0,1} end
  if headerSize>=30 then limits[#limits+1]={0,1};limits[#limits+1]={0,1} end
  if headerSize>=31 then limits[#limits+1]={0,1} end
  if headerSize==32 then limits[#limits+1]={0,2} end
  local n={}
  for i,limit in ipairs(limits) do n[i]=integer(f[i+1],limit[1],limit[2]);if not n[i] then return end end
  if #f~=headerSize+n[10] then return end
  local out={serial=n[1],enabled=n[2]==1,calibrated=n[3]==1,tank=n[4]/100,compressor=n[5]==1,front=n[6]/1000,rear=n[7]/1000,airIn=n[8]/1000,airOut=n[9]/1000,corners={FL=n[11]/1000,FR=n[12]/1000,RL=n[13]/1000,RR=n[14]/1000},autoEnabled=n[15]==1,autoActive=n[16]==1,comfort=n[17]/1000,showMode=({[0]='off',[1]='roll',[2]='pitch',[3]='wave'})[n[18]],parkingEnabled=n[19]==1,parkingActive=n[20]==1,tankType=hardware.tankNames[n[21]],compressorType=hardware.compressorNames[n[22]],bags={}}
  out.compression=headerSize>=25 and n[23]/1000 or 0.5
  out.rebound=headerSize>=25 and n[24]/1000 or 0.5
  out.rearCompression=headerSize>=28 and n[25]/1000 or out.compression
  out.rearRebound=headerSize>=28 and n[26]/1000 or out.rebound
  out.workshop=headerSize>=28 and n[27]==1 or false
  out.expoEnabled=headerSize>=30 and n[28]==1 or false
  out.expoActive=headerSize>=30 and n[29]==1 or false
  if out.expoActive and not out.expoEnabled then return end
  out.liftActive=headerSize>=31 and n[30]==1 or false
  if out.liftActive and (out.workshop or not out.enabled or not out.calibrated) then return end
  out.drivingMode=headerSize==32 and ({[0]='custom',[1]='comfort',[2]='sport'})[n[31]] or 'custom'
  for i=headerSize+1,#f do
    local parts=split(f[i],',')
    if #parts~=5 then return end
    local id=integer(parts[1],0,4095)
    local charge=integer(parts[2],0,4000000)
    local base=integer(parts[3],40,3600)
    local failed=integer(parts[4],0,1)
    local leak=integer(parts[5],0,1000)
    if not leak or not id or not charge or not base or not failed or out.bags[id] then return end
    out.bags[id]={charge=charge,base=base/1000,failed=failed==1,leak=leak/1000}
  end
  return out
end
function M.newer(serial,previous)
  if previous==nil then return true end
  local distance=(serial-previous)%1000000000
  return distance>0 and distance<500000000
end
return M
