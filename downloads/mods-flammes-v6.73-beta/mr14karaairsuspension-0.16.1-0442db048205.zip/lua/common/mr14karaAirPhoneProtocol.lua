-- Named commands and a bounded HTTP parser; no browser-supplied Lua is evaluated.
local M={}
local hardware=require('common/mr14karaAirHardware')
local groups={all=true,front=true,rear=true,FL=true,FR=true,RL=true,RR=true}
local presets={low=true,road=true,high=true}
local shows={off=true,roll=true,pitch=true,wave=true}
local function finite(n,lo,hi) return type(n)=='number' and n==n and n>=lo and n<=hi end
function M.privateIP(ip)
  if type(ip)~='string' then return false end
  local a,b,c,d=ip:match('^(%d+)%.(%d+)%.(%d+)%.(%d+)$')
  a,b,c,d=tonumber(a),tonumber(b),tonumber(c),tonumber(d)
  if not a or a>255 or b>255 or c>255 or d>255 then return false end
  return a==127 or a==10 or (a==172 and b>=16 and b<=31) or (a==192 and b==168) or (a==169 and b==254)
end
function M.validHost(host,port)
  if type(host)~='string' then return false end
  local ip,p=host:match('^([%d%.]+):(%d+)$')
  return tonumber(p)==port and M.privateIP(ip) or host=='localhost:'..port
end
function M.command(data)
  if type(data)~='table' then return nil,'Commande invalide' end
  local name=data.action
  if name=='step' and groups[data.group] and finite(data.delta,-0.15,0.15) and data.delta~=0 then
    return string.format('c.stepHeight(%.5f,%q)',data.delta,data.group)
  elseif (name=='preset' or name=='savePreset') and presets[data.name] then
    return 'c.'..(name=='preset' and 'recallPreset' or 'savePreset')..'('..string.format('%q',data.name)..')'
  elseif name=='hardware' and hardware.valid(data.tank,data.compressor) then return string.format('c.setHardware(%q,%q)',data.tank,data.compressor)
  elseif name=='profile' and type(data.name)=='string' and #data.name>=1 and #data.name<=32 and data.name:match('^[%w _%-]+$') and data.name:match('%S') then return 'c.setProfile('..string.format('%q',data.name)..')'
  elseif name=='show' and shows[data.mode] then return 'c.setShow('..string.format('%q',data.mode)..')'
  elseif name=='drivingMode' and (data.mode=='custom' or data.mode=='comfort' or data.mode=='sport') then return 'c.setDrivingMode('..string.format('%q',data.mode)..')'
  elseif name=='comfort' and finite(data.value,0,1) then return string.format('c.setComfort(%.4f)',data.value)
  elseif name=='damping' and finite(data.compression,0,1) and finite(data.rebound,0,1) then return string.format('c.setDamping(%.4f,%.4f)',data.compression,data.rebound)
  elseif name=='axleDamping' and finite(data.frontCompression,0,1) and finite(data.frontRebound,0,1) and finite(data.rearCompression,0,1) and finite(data.rearRebound,0,1) then return string.format('c.setAxleDamping(%.4f,%.4f,%.4f,%.4f)',data.frontCompression,data.frontRebound,data.rearCompression,data.rearRebound)
  elseif name=='lift' and type(data.enabled)=='boolean' then return 'c.setLift('..tostring(data.enabled)..')'
  elseif name=='workshop' and type(data.enabled)=='boolean' then return 'c.setWorkshop('..tostring(data.enabled)..')'
  elseif name=='volume' and finite(data.value,0,1) then return string.format('c.setSoundVolume(%.4f)',data.value)
  elseif (name=='automatic' or name=='parking' or name=='expo') and type(data.enabled)=='boolean' then
    return 'c.'..(name=='automatic' and 'setAutomatic' or name=='expo' and 'setExpo' or 'setParking')..'('..tostring(data.enabled)..')'
  elseif name=='enabled' and type(data.enabled)=='boolean' then
    return 'if c.getStatus().enabled~='..tostring(data.enabled)..' then c.toggle() end'
  end
  return nil,'Commande inconnue ou valeur invalide'
end
function M.parse(raw)
  if type(raw)~='string' or #raw>24576 then return nil,'large' end
  local boundary=raw:find('\r\n\r\n',1,true)
  if not boundary then return nil,#raw>8192 and 'large' or 'wait' end
  if boundary>8192 then return nil,'large' end
  local method,path=raw:match('^(%u+) ([^%s]+) HTTP/1%.[01]\r\n')
  if not method or #path>200 then return nil,'bad' end
  local headers={}
  for line in raw:sub(1,boundary+1):gmatch('([^\r\n]+)\r\n') do
    if not line:match('^%u+ ') then
      local k,value=line:match('^([%w%-]+):%s*(.-)%s*$')
      if not k or headers[k:lower()]~=nil then return nil,'bad' end
      headers[k:lower()]=value
    end
  end
  if not headers.host or headers['transfer-encoding'] then return nil,'bad' end
  local len=headers['content-length']
  if len and not len:match('^%d+$') then return nil,'bad' end
  len=tonumber(len) or 0
  if len>8192 then return nil,'large' end
  if #raw<boundary+3+len then return nil,'wait' end
  if #raw>boundary+3+len then return nil,'bad' end -- no pipelining/request smuggling
  if method=='POST' and not headers['content-length'] then return nil,'bad' end
  return {method=method,path=path,headers=headers,body=raw:sub(boundary+4,boundary+3+len)}
end
function M.response(status,kind,body)
  return 'HTTP/1.1 '..status..'\r\nContent-Type: '..kind..'\r\nContent-Length: '..#body..'\r\nConnection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nReferrer-Policy: no-referrer\r\nContent-Security-Policy: default-src \'self\'; script-src \'self\'; style-src \'self\'; img-src \'self\' data:; connect-src \'self\'; frame-ancestors \'none\'; base-uri \'none\'\r\n\r\n'..body
end
return M
