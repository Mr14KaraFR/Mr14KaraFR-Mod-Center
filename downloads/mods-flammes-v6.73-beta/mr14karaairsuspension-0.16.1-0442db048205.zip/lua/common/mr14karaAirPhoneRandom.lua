-- OS random bytes, used only when the local user enables the phone bridge.
local M={}
function M.bytes(count)
  assert(type(count)=='number' and count>=1 and count<=256 and count%1==0,'Invalid random byte count')
  -- BeamNG 0.40 exposes its system RNG to mods but blocks ffi.load.
  -- Request enough hex characters whether an older build counts bytes or characters.
  if SecureComm and type(SecureComm.getRandomBytesHexSlow)=='function' then
    local hex=SecureComm.getRandomBytesHexSlow(count*2)
    if type(hex)~='string' or #hex<count*2 or not hex:match('^%x+$') then error('System RNG unavailable') end
    return (hex:sub(1,count*2):gsub('%x%x',function(pair) return string.char(tonumber(pair,16)) end))
  end
  local ffi=require('ffi')
  if ffi.os=='Windows' then
    pcall(ffi.cdef,'long __stdcall BCryptGenRandom(void*, unsigned char*, unsigned long, unsigned long);')
    local library=ffi.load('bcrypt')
    local buffer=ffi.new('unsigned char[?]',count)
    if library.BCryptGenRandom(nil,buffer,count,2)~=0 then error('System RNG unavailable') end
    return ffi.string(buffer,count)
  end
  local f=assert(io.open('/dev/urandom','rb'));local bytes=f:read(count);f:close()
  if not bytes or #bytes~=count then error('System RNG unavailable') end
  return bytes
end
function M.hex(bytes) return (bytes:gsub('.',function(c) return string.format('%02x',c:byte()) end)) end
function M.pin(bytes)
  local n=0;for i=1,4 do n=n*256+bytes:byte(i) end
  return string.format('%06d',n%1000000)
end
return M
