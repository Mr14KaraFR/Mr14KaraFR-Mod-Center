-- Gameplay equipment, in litres and bar-litres per second (nominal flow).
local M={}
M.tanks={small={liters=20,index=1},standard={liters=40,index=2},large={liters=80,index=3}}
M.compressors={single={flow=40,index=1,gain=0.45},fast={flow=80,index=2,gain=0.55},dual={flow=120,index=3,gain=0.65}}
M.tankNames={'small','standard','large'}
M.compressorNames={'single','fast','dual'}
function M.valid(tank,compressor) return type(tank)=='string' and type(compressor)=='string' and M.tanks[tank]~=nil and M.compressors[compressor]~=nil end
return M
