-- Local visual layout selection; hardware and pressure still use the MA5 snapshot.
local M={}
function M.select(layout,config,data)
  if not layout or not layout.profiles then return nil end
  local chosen=layout.default or 'standard'
  local priority=-1
  local selected={}
  for _,part in pairs(config and config.parts or {}) do selected[part]=true end
  -- Modern native part configurations can be trees rather than flat parts maps.
  -- Geometry provenance is resolved by JBeam and also works on BeamMP vehicles.
  for path,part in pairs(data and data.activeParts or {}) do
    selected[path]=true
    if type(part)=='string' then selected[part]=true end
  end
  for _,node in pairs(data and data.nodes or {}) do
    if node.partOrigin then selected[node.partOrigin]=true end
  end
  for _,mesh in pairs(data and data.flexbodies or {}) do
    if mesh.partOrigin then selected[mesh.partOrigin]=true end
  end
  for key,profile in pairs(layout.profiles) do
    local match=key==layout.default
    for _,part in pairs(profile.whenParts or {}) do if selected[part] then match=true;break end end
    if match and (profile.priority or 0)>priority then chosen=key;priority=profile.priority or 0 end
  end
  return chosen
end
function M.visible(component,tank,compressor)
  return component=='base' or component=='tank_'..tank or component=='compressor_'..compressor
end
return M
