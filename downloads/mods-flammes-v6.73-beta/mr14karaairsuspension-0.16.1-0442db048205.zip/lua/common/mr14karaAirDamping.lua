-- Change recognised dampers while preserving factory travel and bump stops.
local M={}
local function number(value,fallback) return type(value)=='number' and value or fallback end
function M.apply(object,beam,factor,reboundFactor,state)
  reboundFactor=reboundFactor or factor
  local damp=number(beam.beamDamp,0)
  local selected=factor
  -- Ordinary symmetric dampers have no native rebound field. Follow actual
  -- beam motion, preserving the direction near standstill to avoid chatter.
  if beam.beamType~=2 and beam.beamType~=1 and state and object.getBeamLength then
    local length=object:getBeamLength(beam.cid)
    if state.length then
      if length-state.length>0.0000001 then state.extending=true
      elseif state.length-length>0.0000001 then state.extending=false end
    end
    state.length=length
    if state.extending then selected=reboundFactor end
  end
  object:setBeamSpringDamp(beam.cid,number(beam.beamSpring,0),damp*selected,-1,-1)
  if beam.beamType==2 and object.setBeamBounded then
    local long=type(beam.longBoundRange)=='number' and -math.max(0,beam.longBoundRange) or math.max(0,number(beam.beamLongBound,1))
    local short=type(beam.shortBoundRange)=='number' and -math.max(0,beam.shortBoundRange) or math.max(0,number(beam.beamShortBound,1))
    local limitDamp=number(beam.beamLimitDamp,1)
    local rebound=number(beam.beamDampRebound,damp)
    local split=number(beam.beamDampVelocitySplit,math.huge)
    object:setBeamBounded(beam.cid,long,short,number(beam.beamLimitSpring,1),limitDamp,number(beam.beamLimitDampRebound,limitDamp),rebound*reboundFactor,number(beam.beamDampFast,damp)*factor,number(beam.beamDampReboundFast,rebound)*reboundFactor,split,number(beam.beamDampVelocitySplitRebound,split),number(beam.boundZone,1))
  elseif beam.beamType==1 and object.setBeamAnisotropic then
    local long=type(beam.beamLongExtent)=='number' and -math.max(0,beam.beamLongExtent) or math.max(0,number(beam.beamLongBound,math.huge))
    object:setBeamAnisotropic(beam.cid,number(beam.springExpansion,number(beam.beamSpring,0)),number(beam.dampExpansion,damp)*reboundFactor,number(beam.transitionZone,0),long)
  end
end
return M
