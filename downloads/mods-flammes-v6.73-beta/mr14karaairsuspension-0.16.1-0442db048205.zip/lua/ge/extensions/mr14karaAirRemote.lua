-- Optional LAN bridge for the Android browser remote. Disabled until enabled in the ATH.
local M={}
local protocol=require('common/mr14karaAirPhoneProtocol')
local random=require('common/mr14karaAirPhoneRandom')
local trunkLayouts=require('common/mr14karaAirTrunk')
local trunkHidden={}
local socketOK,socket=pcall(require,'socket.socket')
local listener,clients=nil,{}
local port,pin,clock=8725,'',0
local sessions,attempts={},{}
local urls={}
local currentID,generation=0,0
local state,stateAge=nil,999
local pollAge=0
local lastCommand=nil
local phoneConnected=false
local function hasPairedPhone()
  if not listener then return false end
  for _,session in pairs(sessions) do
    -- Android suspends browser polling when locked. Pairing survives that pause.
    if session.expires>=clock and not session.paused then return true end
  end
  return false
end
local function emit(error)
  phoneConnected=hasPairedPhone()
  guihooks.trigger('Mr14AirRemote',{running=listener~=nil,connected=phoneConnected,pin=pin,urls=urls,port=port,error=error})
end
local function activeVehicle()
  local vehicle=getPlayerVehicle(0)
  return vehicle,vehicle and vehicle:getID() or 0
end
local function refreshVehicle()
  local vehicle,id=activeVehicle()
  if id~=currentID then currentID=id;generation=generation+1;state=nil;stateAge=999;lastCommand=nil end
  return vehicle
end
local function ownVehicle(id)
  if MPCoreNetwork and MPCoreNetwork.isMPSession and MPCoreNetwork.isMPSession() then
    return MPVehicleGE and MPVehicleGE.isOwn and MPVehicleGE.isOwn(id)==true or false
  end
  return true
end
local function vehicleList()
  local out={}
  for _,vehicle in pairs(getAllVehicles() or {}) do
    local id=vehicle:getID()
    if id>0 and ownVehicle(id) and #out<64 then
      local manager=extensions.core_vehicle_manager or core_vehicle_manager
      local data=manager and manager.getVehicleData(id)
      out[#out+1]={id=id,model=vehicle:getJBeamFilename(),active=id==currentID,profileName=data and data.config and data.config.mr14AirProfile or ''}
    end
  end
  table.sort(out,function(a,b) return a.id<b.id end)
  return out
end
local function queryVehicle()
  local vehicle=refreshVehicle()
  if not vehicle then return end
  local code='local c=controller.getController("mr14karaAirSuspension"); local data=c and c.getStatus() or {installed=false}; obj:queueGameEngineLua("if extensions.mr14karaAirRemote then extensions.mr14karaAirRemote.receive('..currentID..','..generation..',"..string.format("%q",jsonEncode(data))..") end")'
  vehicle:queueLuaCommand(code)
end
function M.receive(id,epoch,json)
  if not listener or id~=currentID or epoch~=generation or type(json)~='string' or #json>32768 then return end
  local ok,data=pcall(jsonDecode,json)
  if ok and type(data)=='table' and type(data.installed)=='boolean' then state=data;stateAge=0 end
end
local function discoverURLs()
  local out,seen={},{}
  local function add(ip)
    if protocol.privateIP(ip) and not ip:match('^127%.') and not seen[ip] then
      seen[ip]=true;out[#out+1]='http://'..ip..':'..port..'/'
    end
  end
  pcall(function()
    local udp=socket.udp();udp:setpeername('192.0.2.1',9)
    local ip=udp:getsockname();udp:close();add(ip)
  end)
  pcall(function()
    for _,entry in ipairs(socket.dns.getaddrinfo(socket.dns.gethostname()) or {}) do add(entry.addr) end
  end)
  if #out==0 then out[1]='http://ADRESSE-IP-DU-PC:'..port..'/' end
  out[#out+1]='http://127.0.0.1:'..port..'/'
  return out
end
local function jsonResponse(status,data) return protocol.response(status,'application/json; charset=utf-8',jsonEncode(data)) end
local assets={['/']={'index.html','text/html; charset=utf-8'},['/app.js']={'app.js','application/javascript; charset=utf-8'},['/style.css']={'style.css','text/css; charset=utf-8'},['/icon.svg']={'icon.svg','image/svg+xml'},['/manifest.webmanifest']={'manifest.webmanifest','application/manifest+json'}}
local function handle(request,ip)
  local h=request.headers
  if not protocol.privateIP(ip) or not protocol.validHost(h.host,port) then return jsonResponse('403 Forbidden',{ok=false,error='Acces reseau local uniquement'}) end
  if h.origin and h.origin~='http://'..h.host then return jsonResponse('403 Forbidden',{ok=false,error='Origine refusee'}) end
  if request.method=='GET' and assets[request.path] then
    local file=assets[request.path];local content=readFile('/ui/airRemote/'..file[1])
    return protocol.response(content and '200 OK' or '404 Not Found',file[2],content or 'Fichier absent')
  end
  if request.method=='POST' then
    local contentType=(h['content-type'] or ''):lower()
    if contentType~='application/json' and not contentType:match('^application/json%s*;%s*charset=utf%-8%s*$') then return jsonResponse('415 Unsupported Media Type',{ok=false,error='JSON requis'}) end
  end
  if request.method=='POST' and request.path=='/api/pair' then
    local bucket=attempts[ip]
    if not bucket or clock-bucket.since>=30 then bucket={since=clock,count=0};attempts[ip]=bucket end
    bucket.count=bucket.count+1
    if bucket.count>5 then return jsonResponse('429 Too Many Requests',{ok=false,error='Trop de tentatives. Attends 30 secondes.'}) end
    local ok,data=pcall(jsonDecode,request.body)
    if not ok or type(data)~='table' or type(data.pin)~='string' or data.pin~=pin then return jsonResponse('401 Unauthorized',{ok=false,error='Code incorrect'}) end
    local existing=sessions[h['x-air-session'] or '']
    if existing and existing.expires>=clock then
      existing.expires=clock+3600;existing.paused=false;emit()
      return jsonResponse('200 OK',{ok=true,token=h['x-air-session']})
    end
    local count=0
    for token,s in pairs(sessions) do if s.expires<clock then sessions[token]=nil else count=count+1 end end
    if count>=4 then return jsonResponse('429 Too Many Requests',{ok=false,error='Quatre telephones sont deja connectes. Redemarre la liaison pour les deconnecter.'}) end
    local token=random.hex(random.bytes(24));sessions[token]={expires=clock+3600,window=clock,count=0}
    emit()
    return jsonResponse('200 OK',{ok=true,token=token})
  end
  local session=sessions[h['x-air-session'] or '']
  if not session or session.expires<clock then return jsonResponse('401 Unauthorized',{ok=false,error='Code de connexion requis'}) end
  session.expires=clock+3600
  if request.method=='POST' and (request.path=='/api/pause' or request.path=='/api/resume') then
    session.paused=request.path=='/api/pause';emit()
    return jsonResponse('200 OK',{ok=true})
  end
  if request.method=='POST' and request.path=='/api/unpair' then
    sessions[h['x-air-session']]=nil
    emit()
    return jsonResponse('200 OK',{ok=true})
  end
  if request.method=='GET' and request.path=='/api/state' then
    if not phoneConnected then emit() end
    refreshVehicle()
    return jsonResponse('200 OK',{ok=true,vehicleId=currentID,generation=generation,age=stateAge,owner=currentID>0 and ownVehicle(currentID) and not (state and state.remote),state=state or {installed=false},version='0.16.1 beta',vehicles=vehicleList(),lastCommand=lastCommand})
  end
  if request.method=='POST' and (request.path=='/api/action' or request.path=='/api/select') then
    if session.paused then return jsonResponse('409 Conflict',{ok=false,error='Reprends la telecommande avant de commander la voiture'}) end
    if clock-session.window>=1 then session.window=clock;session.count=0 end
    session.count=session.count+1
    if session.count>20 then return jsonResponse('429 Too Many Requests',{ok=false,error='Trop de commandes'}) end
  end
  if request.method=='POST' and request.path=='/api/select' then
    local ok,data=pcall(jsonDecode,request.body)
    refreshVehicle()
    if not ok or type(data)~='table' or type(data.targetVehicleId)~='number' or data.targetVehicleId%1~=0 then return jsonResponse('400 Bad Request',{ok=false,error='Voiture invalide'}) end
    if data.generation~=generation then return jsonResponse('409 Conflict',{ok=false,error='Liste actualisee : recommence la selection'}) end
    local target=nil
    for _,entry in ipairs(vehicleList()) do if entry.id==data.targetVehicleId then target=be:getObjectByID(entry.id);break end end
    if not target or not ownVehicle(data.targetVehicleId) then return jsonResponse('409 Conflict',{ok=false,error='Cette voiture ne t appartient pas ou a disparu'}) end
    if data.targetVehicleId~=currentID then be:enterVehicle(0,target) end
    refreshVehicle();queryVehicle()
    return jsonResponse('200 OK',{ok=true,vehicleId=currentID,generation=generation})
  end
  if request.method=='POST' and request.path=='/api/action' then
    local ok,data=pcall(jsonDecode,request.body)
    if not ok or type(data)~='table' then return jsonResponse('400 Bad Request',{ok=false,error='JSON invalide'}) end
    local vehicle=refreshVehicle()
    if not vehicle or data.vehicleId~=currentID or data.generation~=generation then return jsonResponse('409 Conflict',{ok=false,error='Voiture changee : attends son actualisation'}) end
    if not ownVehicle(currentID) or not state or not state.installed or state.remote or stateAge>1.5 then return jsonResponse('409 Conflict',{ok=false,error='Ta voiture et son kit doivent etre actifs. Les voitures des autres joueurs sont en lecture seule.'}) end
    local code,err=protocol.command(data)
    if not code then return jsonResponse('400 Bad Request',{ok=false,error=err}) end
    vehicle:queueLuaCommand('local c=controller.getController("mr14karaAirSuspension"); if c and not c.getStatus().remote then '..code..'; c.requestState() end')
    lastCommand={action=data.action,group=data.group,name=data.name,delta=data.delta,at=clock,vehicleId=currentID,status='queued'}
    return jsonResponse('202 Accepted',{ok=true})
  end
  return jsonResponse('404 Not Found',{ok=false,error='Introuvable'})
end
local function drop(i) clients[i].socket:close();table.remove(clients,i) end
function M.stop()
  for i=#clients,1,-1 do drop(i) end
  if listener then listener:close();listener=nil end
  pin='';sessions={};attempts={};urls={};state=nil;stateAge=999;lastCommand=nil
  emit()
end
function M.start()
  if listener then emit();return true end
  if not socketOK then emit('Liaison reseau indisponible dans cette installation.');return false end
  local ok,bytes=pcall(random.bytes,8)
  if not ok then emit('Impossible de generer un code de connexion securise.');return false end
  local c=socket.tcp();c:settimeout(0)
  local bound,err=c:bind('0.0.0.0',port)
  if not bound then c:close();emit('Port '..port..' indisponible : '..tostring(err));return false end
  local listening=c:listen(8)
  if not listening then c:close();emit('Impossible de demarrer la liaison.');return false end
  listener=c;pin=random.pin(bytes);clock=0;sessions={};attempts={};clients={}
  currentID=0;generation=generation+1;state=nil;stateAge=999;pollAge=0
  urls=discoverURLs();queryVehicle();emit();return true
end
-- Works without enabling the phone listener; native config saving deep-copies this table.
function M.bindProfile(id,name)
  if type(id)~='number' or not ownVehicle(id) or type(name)~='string' or #name<1 or #name>32 or not name:match('^[%w _%-]+$') or not name:match('%S') then return false end
  local manager=extensions.core_vehicle_manager or core_vehicle_manager
  local data=manager and manager.getVehicleData(id)
  local vehicle=be and be:getObjectByID(id)
  if not data or not data.config or not vehicle then return false end
  data.config.mr14AirProfile=name
  -- Keep the scene configuration in step with the native manager for respawn/reload.
  vehicle:setField('partConfig','',serialize(data.config))
  return true
end
-- Cosmetic meshes use only hard-coded names and the equipment catalog, never browser input as a mesh name.
function M.syncTrunk(id,tankName,compressorName)
  if type(id)~='number' or not ({small=true,standard=true,large=true})[tankName] or not ({single=true,fast=true,dual=true})[compressorName] then return false end
  local vehicle=be and be:getObjectByID(id)
  if not vehicle or not vehicle.setMeshAlpha then return false end
  local hidden={}
  trunkHidden[id]=hidden
  local function show(mesh,visible)
    vehicle:setMeshAlpha(visible and 1 or 0,mesh,false)
    if not visible then hidden[#hidden+1]=mesh end
  end
  local manager=extensions and extensions.core_vehicle_manager or core_vehicle_manager
  local data=manager and manager.getVehicleData(id)
  local layout=data and data.vdata and data.vdata.mr14airTrunk3D
  if layout and layout.profiles then
    local profile=trunkLayouts.select(layout,data.config,data.vdata)
    for _,mesh in pairs(data.vdata.flexbodies or {}) do
      if mesh.mr14airProfile and mesh.mr14airComponent and mesh.meshLoaded then
        local visible=mesh.mr14airProfile==profile and trunkLayouts.visible(mesh.mr14airComponent,tankName,compressorName)
        show(mesh.mesh,visible)
      end
    end
    return true
  end
  show('mr14air_trunk_base',true)
  for _,name in ipairs({'small','standard','large'}) do show('mr14air_trunk_tank_'..name,name==tankName) end
  for _,name in ipairs({'single','fast','dual'}) do show('mr14air_trunk_compressor_'..name,name==compressorName) end
  return true
end
-- Part highlighting restores every mesh's alpha, including unused equipment.
-- Re-hide only unused meshes after that update; leave selected part fading alone.
function M.onPreRender()
  for id,meshes in pairs(trunkHidden) do
    local vehicle=be and be:getObjectByID(id)
    if vehicle then
      for _,mesh in ipairs(meshes) do vehicle:setMeshAlpha(0,mesh,false) end
    else trunkHidden[id]=nil end
  end
end
function M.onVehicleDestroyed(id) trunkHidden[id]=nil end
function M.onVehicleSpawned(id) trunkHidden[id]=nil end
function M.onClientEndMission() trunkHidden={} end
function M.showInfo() emit() end
function M.onUpdate(dtReal)
  if not listener then return end
  local dt=math.max(0,math.min(dtReal or .016,10));clock=clock+dt;stateAge=stateAge+dt;pollAge=pollAge+dt
  refreshVehicle()
  if pollAge>=.25 then pollAge=0;queryVehicle() end
  for token,s in pairs(sessions) do if s.expires<clock then sessions[token]=nil end end
  for ip,b in pairs(attempts) do if clock-b.since>60 then attempts[ip]=nil end end
  for _=1,4 do
    local c=listener:accept();if not c then break end
    local ip=c:getpeername();c:settimeout(0)
    if #clients>=8 or not protocol.privateIP(ip) then c:close() else clients[#clients+1]={socket=c,ip=ip,buffer='',age=0} end
  end
  for i=#clients,1,-1 do
    local client=clients[i];client.age=client.age+dt
    if client.age>10 then drop(i)
    elseif client.output then
      local sent,err,partial=client.socket:send(client.output,client.position or 1)
      client.position=(sent or partial or ((client.position or 1)-1))+1
      if client.position>#client.output or err and err~='timeout' then drop(i) end
    else
      local chunk,err,partial=client.socket:receive(24576)
      client.buffer=client.buffer..(chunk or partial or '')
      local request,reason=protocol.parse(client.buffer)
      if request then
        local ok,out=pcall(handle,request,client.ip)
        client.output=ok and out or jsonResponse('500 Internal Server Error',{ok=false,error='Erreur de liaison. Redemarre la connexion depuis le jeu.'})
        client.position=1
      elseif reason~='wait' then client.output=jsonResponse('400 Bad Request',{ok=false,error='Requete invalide'});client.position=1
      elseif err=='closed' then drop(i) end
    end
  end
  if phoneConnected~=hasPairedPhone() then emit() end
end
function M.onVehicleSpawned(id) if id==currentID then generation=generation+1;state=nil;stateAge=999;lastCommand=nil end end
M.onExtensionUnloaded=M.stop
return M
