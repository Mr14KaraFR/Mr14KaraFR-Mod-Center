-- Mr14KaraFR Air Suspension 0.16.1. Native pressured beams, optional kit.
local M = {type = 'auxiliary'}
local network=require('mr14karaAirNetwork')
local damping=require('mr14karaAirDamping')
local hardware=require('mr14karaAirHardware')
local tankType,compressorType='standard','single'
local lastTrunkKey=nil
local gaugeMP=nil
local trunkLayouts=require('mr14karaAirTrunk')
local trunkProfile=nil
local function tankLiters() return hardware.tanks[tankType].liters end
local dampers={}
local comfort=0.5
local compression,rebound=0.5,0.5
local damperStates={}
local damperAxles={}
local rearCompression,rearRebound=0.5,0.5
local drivingMode='custom'
local customDrive={comfort=.5,compression=.5,rebound=.5,rearCompression=.5,rearRebound=.5}
local drivePresets={comfort={comfort=.2,compression=.35,rebound=.4,rearCompression=.35,rearRebound=.4},sport={comfort=.85,compression=.65,rebound=.75,rearCompression=.65,rearRebound=.75}}
local workshop=false
local liftActive,liftSaved,liftButtonDown=false,nil,false
local expoEnabled,expoActive,expoTimer,expoSaved=false,false,0,nil
local showMode,showTime,showSaved='off',0,nil
local parkingEnabled,parkingActive,parkingTimer,parkingSaved=false,false,0,nil
local serial,sendTimer,lastWire,receivedSequence,netAge,receivedFrames=0,0,nil,nil,999,0
local remoteFrame,remoteApplied,wasRemote=nil,false,false
local function isRemote() return v.mpVehicleType=='R' end
local min, max, abs = math.min, math.max, math.abs
local bags, helpers = {}, {}
local damageBags={}
local targets = {front=0,rear=0,FL=0,FR=0,RL=0,RR=0}
local presets
local soundVolume,autoEnabled,autoActive,autoSaved=0.7,false,false,nil
local settingsSaved=false
local profileName=""
local function validProfile(name) return type(name)=="string" and #name>=1 and #name<=32 and name:match("^[%w _%-]+$")~=nil and name:match("%S")~=nil end
local function matches(b,group) return b.axle==group or b.corner==group end
local elapsed, enabled, calibrated = 0, true, false
local tank, compressor = 10, false
local notifyTimer = 0
local held = {}
local rechargeDemand=false
local soundSources={}
local airIn,airOut=0,0
local function positive(value) return value==true or (tonumber(value) or 0)>0 end
local function powerAvailable()
  local e=electrics.values
  return positive(e.ignitionLevel) or positive(e.engineRunning) or (tonumber(e.rpm) or 0)>300
end
local function updateReservoir(dt)
  if tank<7 then rechargeDemand=true elseif tank>=10 then rechargeDemand=false end
  compressor=rechargeDemand and powerAvailable()
  tank=math.min(10,tank+(compressor and dt*hardware.compressors[compressorType].flow/tankLiters() or 0))
end
local function clamp(x,a,b) return min(b,max(a,x)) end
local function finite(n) return type(n)=='number' and n==n and abs(n)<math.huge end
local function driveSnapshot()
  return {comfort=comfort,compression=compression,rebound=rebound,rearCompression=rearCompression,rearRebound=rearRebound}
end
local function assignDrive(t)
  comfort=t.comfort;compression=t.compression;rebound=t.rebound;rearCompression=t.rearCompression;rearRebound=t.rearRebound
end
local function markCustomDrive() drivingMode='custom';customDrive=driveSnapshot() end
local function snapshot(t)
  return {FL=t.FL,FR=t.FR,RL=t.RL,RR=t.RR}
end
local function refreshAxles()
  targets.front=(targets.FL+targets.FR)*0.5;targets.rear=(targets.RL+targets.RR)*0.5
end
local function applyCorners(t)
  for _,corner in ipairs({'FL','FR','RL','RR'}) do targets[corner]=clamp(t[corner] or 0,-1,1) end
  refreshAxles()
end
local function defaultPresets()
  return {low={FL=-1,FR=-1,RL=-1,RR=-1},road={FL=0,FR=0,RL=0,RR=0},high={FL=1,FR=1,RL=1,RR=1}}
end
local function settingsPath(legacy)
  local model=v.data.model or (v.data.vehicleDirectory or ''):match('/vehicles/([%w_%-]+)/') or 'vehicle'
  if not tostring(model):match('^[%w_%-]+$') then model='vehicle' end
  local suffix=''
  if not legacy and profileName~='' then suffix='--'..profileName:gsub('.',function(c) return string.format('%02x',string.byte(c)) end) end
  return 'settings/mr14karaAirSuspension/'..model..suffix..'.json' 
end
local function persistSettings()
  settingsSaved=false
  if isRemote() or type(jsonWriteFile)~='function' then return false end
  local ok,result=pcall(function()
    if FS and FS.directoryCreate then FS:directoryCreate('settings/mr14karaAirSuspension',true) end
    return jsonWriteFile(settingsPath(),{version=1,profile=profileName,presets=presets,volume=soundVolume,autoEnabled=autoEnabled,comfort=comfort,driving={mode=drivingMode,custom=customDrive},damping={compression=compression,rebound=rebound,rearCompression=rearCompression,rearRebound=rearRebound},parkingEnabled=parkingEnabled,expoEnabled=expoEnabled,hardware={tank=tankType,compressor=compressorType}},true)
  end)
  settingsSaved=ok and result~=false
  return settingsSaved
end
local function loadSettings()
  tankType='standard';compressorType='single';compression=0.5;rebound=0.5;rearCompression=0.5;rearRebound=0.5
  drivingMode='custom';customDrive={comfort=.5,compression=.5,rebound=.5,rearCompression=.5,rearRebound=.5}
  expoEnabled=false;expoActive=false;expoTimer=0;expoSaved=nil
  presets=defaultPresets();comfort=0.5;showMode='off';showTime=0;showSaved=nil;parkingEnabled=false;parkingActive=false;parkingTimer=0;parkingSaved=nil;soundVolume=0.7;autoEnabled=false;autoActive=false;autoSaved=nil;settingsSaved=false
  if type(jsonReadFile)~='function' then return end
  local ok,data=pcall(jsonReadFile,settingsPath())
  if (not ok or type(data)~='table') and profileName~='' then ok,data=pcall(jsonReadFile,settingsPath(true)) end
  if not ok or type(data)~='table' or data.version~=1 then return end
  if type(data.hardware)=='table' and hardware.valid(data.hardware.tank,data.hardware.compressor) then tankType=data.hardware.tank;compressorType=data.hardware.compressor end
  if finite(data.volume) then soundVolume=clamp(data.volume,0,1) end
  autoEnabled=data.autoEnabled==true
  parkingEnabled=data.parkingEnabled==true
  expoEnabled=data.expoEnabled==true
  if finite(data.comfort) then comfort=clamp(data.comfort,0,1) end
  if type(data.damping)=='table' then
    if finite(data.damping.compression) then compression=clamp(data.damping.compression,0,1) end
    if finite(data.damping.rebound) then rebound=clamp(data.damping.rebound,0,1) end
    rearCompression=finite(data.damping.rearCompression) and clamp(data.damping.rearCompression,0,1) or compression
    rearRebound=finite(data.damping.rearRebound) and clamp(data.damping.rearRebound,0,1) or rebound
  end
  customDrive=driveSnapshot()
  if type(data.driving)=='table' and drivePresets[data.driving.mode] then
    local saved=data.driving.custom
    local valid=type(saved)=='table'
    if valid then for key in pairs(customDrive) do if not finite(saved[key]) or saved[key]<0 or saved[key]>1 then valid=false;break end end end
    if valid then for key in pairs(customDrive) do customDrive[key]=saved[key] end end
    drivingMode=data.driving.mode;assignDrive(drivePresets[drivingMode])
  end
  if type(data.presets)=='table' then
    for _,name in ipairs({'low','road','high'}) do
      local t=data.presets[name]
      if type(t)=='table' then
        for _,corner in ipairs({'FL','FR','RL','RR'}) do
          if finite(t[corner]) then presets[name][corner]=clamp(t[corner],-1,1) end
        end
      end
    end
  end
  settingsSaved=true
end
local function pair(a,b) if a>b then a,b=b,a end return tostring(a)..':'..tostring(b) end
local function ambient() return powertrain.currentEnvPressure or 101325 end
local function gasScale(b,length,value)
  value=value or comfort
  -- Total pressure/length exponent: 0.65 soft, 1 balanced, 2 firm.
  -- A firmer cushion develops more restoring force under the same compression.
  local exponent=value<=0.5 and (value-0.5)*0.7 or (value-0.5)*2
  return clamp((max(b.base or length,0.04)/max(length,0.04))^exponent,0.25,4)
end
local function rebaseComfort(previous,value)
  if previous==value then return end
  for _,b in ipairs(bags) do
    if b.base then
      local length=max(obj:getBeamLength(b.cid),0.04)
      local ratio=gasScale(b,length,previous)/gasScale(b,length,value)
      -- Keep current supporting pressure when changing stiffness at any height.
      -- This is a change of gas-law coordinates, not inflation or venting.
      if b.charge then b.charge=b.charge*ratio end
      if b.remoteCharge then b.remoteCharge=b.remoteCharge*ratio end
    end
  end
end
local function applyComfort(factor,stock)
  for _,beam in ipairs(dampers) do
    local rear=damperAxles[beam.cid]=='rear'
    local c=stock and 1 or factor*(0.5+(rear and rearCompression or compression))
    local r=stock and 1 or factor*(0.5+(rear and rearRebound or rebound))
    damperStates[beam.cid]=damperStates[beam.cid] or {}
    damping.apply(obj,beam,c,r,damperStates[beam.cid])
  end
end
local function pressure(b,p)
  obj:setBeamPressureRel(b.cid,clamp(p,0,900000),100000000,0,0)
end
local function restore()
  applyComfort(1,true)
  for _,b in ipairs(bags) do
    b.p=0;b.remoteActive=false;b.remoteCharge=nil
    for _,s in ipairs(b.springs) do obj:setBeamSpringDamp(s.cid,s.k,s.d,-1,-1) end
  end
  for _,b in ipairs(helpers) do
    obj:setBeamPressured(b.cid,ambient(),1e-12,1,100000000,ambient()+900000)
    obj:setBeamPressureRel(b.cid,0,100000000,0,0)
  end
end
local function status()
  local out={speedKmh=abs(tonumber(electrics.values.wheelspeed) or 0)*3.6,tankType=tankType,compressorType=compressorType,tankLiters=tankLiters(),compressorFlow=hardware.compressors[compressorType].flow,rechargeRate=hardware.compressors[compressorType].flow/tankLiters(),tankMax=10,profileName=profileName,model=v.data.model,version='0.16.1 beta',comfort=comfort,compression=compression,rebound=rebound,rearCompression=rearCompression,rearRebound=rearRebound,drivingMode=drivingMode,workshop=workshop,liftActive=liftActive,expoEnabled=expoEnabled,expoActive=expoActive,showMode=showMode,parkingEnabled=parkingEnabled,parkingActive=parkingActive,cornerPressure={},cornerHeight={},ecuInstalled=controller and controller.getController and controller.getController('mr14karaECU')~=nil or false,FL=targets.FL,FR=targets.FR,RL=targets.RL,RR=targets.RR,presets=presets,soundVolume=soundVolume,autoEnabled=autoEnabled,autoActive=autoActive,settingsSaved=settingsSaved,available={},remote=isRemote(),networkFrames=receivedFrames,networkAge=netAge,installed=true,enabled=enabled,calibrated=calibrated,count=#bags,tank=tank,compressor=compressor,powered=powerAvailable(),front=targets.front,rear=targets.rear,frontPressure=0,rearPressure=0,assist=false}
  out.failedCorners={};out.leakingCorners={};out.leakCount=0;out.cornerLeakRate={}
  local n={front=0,rear=0,FL=0,FR=0,RL=0,RR=0}
  for _,b in ipairs(bags) do
    out.available[b.corner]=true
    if b.failed then out.failedCorners[b.corner]=true end
    if (b.leak or 0)>0 then
      if not out.leakingCorners[b.corner] then out.leakCount=out.leakCount+1 end
      out.leakingCorners[b.corner]=max(out.leakingCorners[b.corner] or 0,b.leak)
    end
    local rate=enabled and calibrated and not b.failed and (b.leak or 0)>0 and min(max(0,b.p or 0)/100000,0.1+1.4*b.leak) or 0
    out.cornerLeakRate[b.corner]=(out.cornerLeakRate[b.corner] or 0)+rate
    n[b.corner]=n[b.corner]+1
    out.cornerPressure[b.corner]=(out.cornerPressure[b.corner] or 0)+(b.p or 0)/100000
    local measured=calibrated and b.base and (obj:getBeamLength(b.cid)-b.base)*100/max(b.vertical,0.2) or 0
    out.cornerHeight[b.corner]=(out.cornerHeight[b.corner] or 0)+measured
    local key=b.axle..'Pressure';out[key]=out[key]+(b.p or 0)/100000;n[b.axle]=n[b.axle]+1
    if b.assist then out.assist=true end
  end
  for _,a in ipairs({'front','rear'}) do if n[a]>0 then out[a..'Pressure']=out[a..'Pressure']/n[a] end end
  for _,corner in ipairs({'FL','FR','RL','RR'}) do
    if n[corner]>0 then out.cornerPressure[corner]=out.cornerPressure[corner]/n[corner];out.cornerHeight[corner]=out.cornerHeight[corner]/n[corner];out.cornerLeakRate[corner]=out.cornerLeakRate[corner]/n[corner] end
  end
  if out.remote then out.diagnostic='Voiture distante : lecture seule.'
  elseif not enabled then out.diagnostic='Suspension desactivee.'
  elseif #bags==0 then out.diagnostic='Aucun coussin pneumatique detecte.'
  elseif not calibrated then out.diagnostic='Calibrage : reste a l arret deux secondes.'
  elseif workshop then out.diagnostic='Mode atelier : correction de hauteur suspendue. Les fuites restent actives. Reprise manuelle ou au-dessus de 5 km/h.'
  elseif out.leakCount>0 then out.diagnostic='Fuite d air : '..out.leakCount..' coin(s) touche(s). Alimentation isolee : repare ou reinitialise la voiture.'
  elseif next(out.failedCorners) then out.diagnostic='Suspension endommagee : repare la voiture.'
  elseif tank<=2 then out.diagnostic=out.powered and 'Reservoir faible : recharge en cours. La montee attend de l air.' or 'Reservoir faible : mets le contact pour recharger.'
  elseif liftActive then out.diagnostic='Lift temporaire actif : retour par le bouton ou des 30 km/h.'
  elseif expoActive then out.diagnostic='Mode expo : position basse. Retour a la hauteur Route des 3 km/h.'
  elseif parkingActive then out.diagnostic='Parking automatique actif.'
  elseif autoActive then out.diagnostic='Hauteur Route automatique active.'
  elseif showMode~='off' then out.diagnostic='Animation show active.'
  elseif out.assist then out.diagnostic='Assistance lames / torsion : descente limitee par les ressorts d origine.'
  else out.diagnostic='Prete. Si la hauteur ne change plus, une consigne ou une butee d origine peut etre atteinte.' end
  return out
end
local function requestState() guihooks.trigger('Mr14AirState',status()) end
local function stopLift(restoreHeight)
  if liftActive and restoreHeight then applyCorners(liftSaved or presets.road) end
  liftActive=false;liftSaved=nil
end
local function setLift(value)
  if isRemote() or type(value)~='boolean' or value==liftActive then return end
  if value then
    local speed=abs(tonumber(electrics.values.wheelspeed) or 0)*3.6
    if workshop or not enabled or not calibrated or speed>=30 or tank<=2 then
      if guihooks.message then guihooks.message('Lift : suspension calibree, hors atelier, sous 30 km/h et reservoir au-dessus de 2 bar.',3,'mr14air.lift') end
      return
    end
    if showSaved then applyCorners(showSaved) end
    showMode='off';showSaved=nil;showTime=0;held={}
    liftSaved=snapshot(targets);liftActive=true
    local raised={}
    for _,corner in ipairs({'FL','FR','RL','RR'}) do raised[corner]=max(targets[corner],0.5) end
    applyCorners(raised)
  else stopLift(true) end
  requestState()
end
local function toggleLift() setLift(not liftActive) end
local function setLiftInput(down)
  if isRemote() or type(down)~='boolean' then return end
  if down then
    if liftButtonDown then return end
    liftButtonDown=true;toggleLift()
  else liftButtonDown=false end
end
local function cancelAutoForManual()
  stopLift(true)
  if expoEnabled then
    if expoActive then applyCorners(expoSaved or presets.road) end
    expoEnabled=false;expoActive=false;expoTimer=0;expoSaved=nil;persistSettings()
  end
  if showMode~='off' then
    if showSaved then applyCorners(showSaved) end
    showMode='off';showSaved=nil;showTime=0
  end
  if parkingActive then
    if parkingSaved then applyCorners(parkingSaved) end
    parkingActive=false;parkingSaved=nil;parkingTimer=0;parkingEnabled=false;persistSettings()
  end
  if autoActive then
    if autoSaved then applyCorners(autoSaved) end
    autoActive=false;autoSaved=nil;autoEnabled=false;persistSettings()
  end
end
local function setHeight(value,axle)
  if isRemote() or workshop then return end
  value=tonumber(value);if not finite(value) then return end
  cancelAutoForManual();value=clamp(value,-1,1)
  if axle=='front' then targets.FL=value;targets.FR=value
  elseif axle=='rear' then targets.RL=value;targets.RR=value
  elseif axle=='FL' or axle=='FR' or axle=='RL' or axle=='RR' then targets[axle]=value
  else targets.FL=value;targets.FR=value;targets.RL=value;targets.RR=value end
  refreshAxles();requestState()
end
local function savePreset(name)
  if isRemote() or not presets[name] then return end
  presets[name]=snapshot(targets)
  local saved=persistSettings()
  if guihooks.message then guihooks.message(saved and 'Hauteur memorisee pour ce profil.' or 'Hauteur memorisee pour cette session.',2,'mr14air.preset') end
  requestState()
end
local function recallPreset(name)
  if isRemote() or workshop or not presets[name] then return end
  cancelAutoForManual();applyCorners(presets[name]);requestState()
end
local function setSoundVolume(value)
  if isRemote() or not finite(value) then return end
  soundVolume=clamp(value,0,1);persistSettings();requestState()
end
local function setAutomatic(value)
  if isRemote() then return end
  stopLift(true)
  if not value and autoActive and autoSaved then applyCorners(autoSaved) end
  autoEnabled=value==true;autoActive=false;autoSaved=nil;persistSettings();requestState()
end
local function toggleAutomatic() setAutomatic(not autoEnabled) end
local function updateAutomatic()
  if not autoEnabled or not enabled or not calibrated then return end
  local speed=abs(tonumber(electrics.values.wheelspeed) or 0)*3.6
  if speed>=60 and not autoActive then
    autoSaved=snapshot(targets);autoActive=true;applyCorners(presets.road)
  elseif speed<=40 and autoActive then
    if autoSaved then applyCorners(autoSaved) end
    autoSaved=nil;autoActive=false
  end
end
local function setDrivingMode(mode)
  if isRemote() or (mode~='custom' and not drivePresets[mode]) or mode==drivingMode then return end
  if drivingMode=='custom' then customDrive=driveSnapshot() end
  local chosen=mode=='custom' and customDrive or drivePresets[mode]
  rebaseComfort(comfort,chosen.comfort);assignDrive(chosen);drivingMode=mode
  if enabled and calibrated then applyComfort(0.6+comfort*0.8) end
  persistSettings();requestState()
end
local function setComfort(value)
  if isRemote() or not finite(value) then return end
  value=clamp(value,0,1);rebaseComfort(comfort,value);comfort=value;markCustomDrive()
  if enabled and calibrated then applyComfort(0.6+comfort*0.8) end
  persistSettings();requestState()
end
local function setAxleDamping(fc,fr,rc,rr)
  if isRemote() or not finite(fc) or not finite(fr) or not finite(rc) or not finite(rr) then return end
  compression=clamp(fc,0,1);rebound=clamp(fr,0,1);rearCompression=clamp(rc,0,1);rearRebound=clamp(rr,0,1);markCustomDrive()
  if enabled and calibrated then applyComfort(0.6+comfort*0.8) end
  persistSettings();requestState()
end
local function setDamping(c,r,axle)
  if not finite(c) or not finite(r) then return end
  if axle=='front' then setAxleDamping(c,r,rearCompression,rearRebound)
  elseif axle=='rear' then setAxleDamping(compression,rebound,c,r)
  elseif axle==nil or axle=='all' then setAxleDamping(c,r,c,r) end
end
local function setExpo(value)
  if isRemote() or type(value)~='boolean' or value==expoEnabled then return end
  stopLift(true)
  if value then
    if showSaved then applyCorners(showSaved) end
    if parkingSaved then applyCorners(parkingSaved) end
    if autoSaved then applyCorners(autoSaved) end
    if expoSaved then applyCorners(expoSaved) end
    expoActive=false;expoSaved=nil;expoTimer=0
    showMode='off';showSaved=nil;showTime=0;parkingActive=false;parkingSaved=nil;parkingTimer=0;autoActive=false;autoSaved=nil;held={}
    if not workshop and abs(tonumber(electrics.values.wheelspeed) or 0)*3.6>=3 then applyCorners(presets.road) end
  elseif expoActive then applyCorners(expoSaved or presets.road) end
  expoEnabled=value;expoActive=false;expoSaved=nil;expoTimer=0;persistSettings();requestState()
end
local function toggleExpo() setExpo(not expoEnabled) end
local function updateExpo(dt,speed)
  if speed>=3 then
    applyCorners(presets.road);expoActive=false;expoSaved=nil;expoTimer=0
  elseif not expoActive and speed<0.5 then
    expoTimer=expoTimer+dt
    if expoTimer>=3 then
      expoSaved=snapshot(targets);expoActive=true;held={}
      applyCorners({FL=-1,FR=-1,RL=-1,RR=-1})
    end
  elseif not expoActive then expoTimer=0 end
end
local function setWorkshop(value)
  if isRemote() or type(value)~='boolean' or value==workshop then return end
  if value and (not enabled or not calibrated or abs(tonumber(electrics.values.wheelspeed) or 0)*3.6>5) then return end
  if value then
    stopLift(true)
    -- Restore the user's targets, retaining their automatic-mode preferences.
    if showSaved then applyCorners(showSaved) end
    if parkingSaved then applyCorners(parkingSaved) end
    if autoSaved then applyCorners(autoSaved) end
    if expoSaved then applyCorners(expoSaved) end
    expoActive=false;expoSaved=nil;expoTimer=0
    showMode='off';showSaved=nil;showTime=0;parkingActive=false;parkingSaved=nil;parkingTimer=0;autoActive=false;autoSaved=nil
  end
  workshop=value;held={};airIn=0;airOut=0;requestState()
end
local function toggleWorkshop() setWorkshop(not workshop) end
local function setParking(value)
  if isRemote() then return end
  stopLift(true)
  if not value and parkingActive then
    applyCorners(parkingSaved or presets.road)
    parkingActive=false;parkingSaved=nil
  end
  parkingEnabled=value==true;parkingTimer=0;persistSettings();requestState()
end
local function toggleParking() setParking(not parkingEnabled) end
local function stopShow()
  if showSaved then applyCorners(showSaved) end
  showMode='off';showTime=0;showSaved=nil
end
local function setShow(mode)
  if isRemote() or (mode~='off' and mode~='roll' and mode~='pitch' and mode~='wave') then return end
  if mode=='off' or mode==showMode then stopShow();requestState();return end
  local speed=abs(tonumber(electrics.values.wheelspeed) or 0)*3.6
  if workshop or not enabled or not calibrated or speed>5 then
    if guihooks.message then guihooks.message('Mode show : suspension active, calibree et voiture a l arret.',3,'mr14air.show') end
    return
  end
  cancelAutoForManual();showSaved=snapshot(targets);showMode=mode;showTime=0;held={};requestState()
end
local function updateModes(dt)
  local speed=abs(tonumber(electrics.values.wheelspeed) or 0)*3.6
  if liftActive then
    if speed>=30 then stopLift(true) else return end
  end
  if showMode~='off' then
    if speed>5 or tank<=2 then stopShow()
    else
      showTime=showTime+dt
      local phase=showTime*math.pi/6
      local a=math.sin(phase)*0.3
      local b=math.cos(phase)*0.3
      local offset=showMode=='roll' and {FL=a,FR=-a,RL=a,RR=-a}
        or showMode=='pitch' and {FL=a,FR=a,RL=-a,RR=-a}
        or {FL=a,FR=b,RL=-b,RR=-a}
      local t={}
      for _,corner in ipairs({'FL','FR','RL','RR'}) do t[corner]=presets.road[corner]+offset[corner] end
      applyCorners(t);return
    end
  end
  -- Expo owns automatic height while enabled; parking/road preferences remain saved.
  if expoEnabled then updateExpo(dt,speed);return end
  if parkingEnabled then
    if parkingActive and (powerAvailable() or speed>3) then
      applyCorners(parkingSaved or presets.road)
      parkingActive=false;parkingSaved=nil;parkingTimer=0
    elseif not parkingActive and not powerAvailable() and speed<1 then
      parkingTimer=parkingTimer+dt
      if parkingTimer>=1.5 then
        parkingSaved=snapshot(targets);parkingActive=true
        -- Automatic parking always vents to the lowest target. The editable
        -- manual Parking memory may contain 0% or even a raised position.
        applyCorners({FL=-1,FR=-1,RL=-1,RR=-1})
      end
    else parkingTimer=0 end
    if parkingActive then return end
  end
  updateAutomatic()
end
-- Rebase a reversing command on actual height instead of a queued target
-- beyond a physical stop. A single reverse tap must start reversing the request.
local function stepAxle(delta,axle)
  if calibrated then
    local total,count=0,0
    for _,bag in ipairs(bags) do
      if matches(bag,axle) and not bag.failed then
        local displacement=(bag.filtered or bag.base)-bag.base
        local scale=(displacement>=0 and 0.40 or 0.25)*bag.vertical
        total=total+displacement/max(scale,0.001);count=count+1
      end
    end
    if count>0 then
      local actual=clamp(total/count,-1,1)
      if (delta<0 and targets[axle]>actual+0.02) or (delta>0 and targets[axle]<actual-0.02) then
        targets[axle]=actual
        for _,bag in ipairs(bags) do
          if matches(bag,axle) then
            bag.offset=(bag.filtered or bag.base)-bag.base
            if delta<0 then bag.quickVent=true end
          end
        end
      end
    end
  end
  setHeight(targets[axle]+delta,axle)
end
local function stepHeight(delta,axle)
  if workshop or isRemote() then return end
  if axle=='front' or axle=='rear' or axle=='FL' or axle=='FR' or axle=='RL' or axle=='RR' then stepAxle(delta,axle)
  else stepAxle(delta,'front');stepAxle(delta,'rear') end
end
local function inputFeedback()
  if not guihooks.message then return end
  local text
  if not enabled then text='Suspension desactivee : utilise Activer / desactiver.'
  elseif #bags==0 then text='Aucune suspension reconnue sur cette configuration.'
  elseif not calibrated then text='Calibrage : reste a l arret pendant 2 secondes.'
  elseif tank<=2 and powerAvailable() then text='Reservoir faible : recharge du compresseur en cours.'
  elseif tank<=2 then text='Reservoir faible : mets le contact pour recharger.'
  else text=string.format('Pneumatique : avant %.1f%% / arriere %.1f%%',targets.front*100,targets.rear*100) end
  guihooks.message(text,2,'mr14air.input')
end
local function setHeightInput(direction,down,axle)
  if workshop or isRemote() then return end
  direction=tonumber(direction)
  if direction~=1 and direction~=-1 then return end
  if axle~='front' and axle~='rear' and axle~='FL' and axle~='FR' and axle~='RL' and axle~='RR' then axle='all' end
  local key=axle..':'..direction
  if not down then held[key]=nil;return end
  if held[key] then return end -- ignore duplicate key-down events
  held[key]={direction=direction,axle=axle,elapsed=0,nextRepeat=0.25}
  stepHeight(direction*0.01,axle)
  inputFeedback()
end
local function updateHeld(dt)
  local movement={front=0,rear=0,FL=0,FR=0,RL=0,RR=0}
  for _,h in pairs(held) do
    h.elapsed=h.elapsed+dt
    if h.elapsed>=h.nextRepeat then
      local delta=h.direction*(h.elapsed<0.8 and 0.01 or 0.65*0.08)
      h.nextRepeat=h.nextRepeat+0.08
      if h.axle=='all' then movement.front=movement.front+delta;movement.rear=movement.rear+delta
      else movement[h.axle]=movement[h.axle]+delta end
    end
  end
  for _,axle in ipairs({'front','rear','FL','FR','RL','RR'}) do if movement[axle]~=0 then stepAxle(movement[axle],axle) end end
end
local function toggle()
  if isRemote() then return end
  stopLift(true)
  if showMode~='off' then stopShow() end
  if expoActive then applyCorners(expoSaved or presets.road) end
  expoActive=false;expoSaved=nil;expoTimer=0
  held={};workshop=false;enabled=not enabled;restore();elapsed=0;calibrated=false;requestState()
end
local function init()
  liftActive=false;liftSaved=nil;liftButtonDown=false
  lastTrunkKey=nil
  trunkProfile=nil
  sendTimer=0;lastWire=nil;receivedSequence=nil;netAge=999;receivedFrames=0
  remoteFrame=nil;remoteApplied=false;wasRemote=isRemote()
  electrics.values[network.key]=nil
  held={};bags={};helpers={};dampers={};damperStates={};damperAxles={};workshop=false;targets={front=0,rear=0,FL=0,FR=0,RL=0,RR=0};elapsed=0;enabled=true;calibrated=false;tank=10;compressor=false;rechargeDemand=false;airIn=0;airOut=0
  local nodes, original, byName = {}, {}, {}
  -- Generated tyre/wheel nodes do not necessarily have a name.
  for cid,n in pairs(v.data.nodes or {}) do
    if type(n)=='table' and type(n.name)=='string' then nodes[n.name]=n.cid or cid end
  end
  for _,b in pairs(v.data.beams or {}) do
    if b.name and b.name:find('mr14air_bag_',1,true)==1 then helpers[#helpers+1]=b;byName[b.name]=b
    else
      local key=pair(b.id1,b.id2);original[key]=original[key] or {};original[key][#original[key]+1]=b
    end
  end
  local chosen={}
  local damperIDs={}
  for _,s in pairs(v.data.mr14airSelectors or {}) do
    local na,nb=nodes[s.nodeA],nodes[s.nodeB]
    if na and nb and byName[s.bagName] then
      for _,b in ipairs(original[pair(na,nb)] or {}) do
        local k,d=b.beamSpring or 0,b.beamDamp or 0
        local match=b.partOrigin==s.part and ((s.kind=='spring' and k>=1000 and k<=500000 and d<=150) or (s.kind=='assist' and k==0 and d>=200))
        if match then
          if s.kind=='assist' and not damperIDs[b.cid] then
            damperIDs[b.cid]=true;dampers[#dampers+1]=b
          end
          local n1,n2=v.data.nodes[na],v.data.nodes[nb]
          local length=(n1.pos-n2.pos):length()
          local vertical=abs(n1.pos.z-n2.pos.z)/max(length,0.001)
          if length>=0.10 and length<=1.8 and vertical>=0.2 then
            local key=s.bagName
            if not chosen[key] then
              chosen[key]={netID=tonumber(key:match('mr14air_bag_(%d+)')),cid=byName[key].cid,springs={},k=0,rest=length,y=(n1.pos.y+n2.pos.y)*0.5,vertical=vertical,assist=true,area=0.015,left=(n1.pos.x+n2.pos.x)>=0}
            end
            local entry=chosen[key]
            if s.kind=='spring' then
              local exists=false;for _,old in ipairs(entry.springs) do if old.cid==b.cid then exists=true end end
              if not exists then entry.springs[#entry.springs+1]={cid=b.cid,k=k,d=d,rest=length*(b.beamPrecompression or 1)};entry.k=entry.k+k end
              entry.assist=false
            end
          end
        end
      end
    end
  end
  local lo,hi=math.huge,-math.huge
  for _,b in pairs(chosen) do lo=min(lo,b.y);hi=max(hi,b.y) end
  local hasSpring={front=false,rear=false}
  for _,b in pairs(chosen) do b.axle=b.y<(lo+hi)*0.5 and 'front' or 'rear';b.corner=(b.axle=='front' and 'F' or 'R')..(b.left and 'L' or 'R');if not b.assist then hasSpring[b.axle]=true end end
  for _,b in pairs(chosen) do
    if not b.assist or not hasSpring[b.axle] then bags[#bags+1]=b end
  end
  for _,beam in ipairs(dampers) do
    local a,b=v.data.nodes[beam.id1],v.data.nodes[beam.id2]
    damperAxles[beam.cid]=(a.pos.y+b.pos.y)*0.5<(lo+hi)*0.5 and 'front' or 'rear'
  end
  local configured=v.config and v.config.mr14AirProfile
  profileName=validProfile(configured) and configured or ''
  damageBags={}
  for _,bag in ipairs(bags) do
    bag.leak=0
    local nodes={}
    for _,spring in ipairs(bag.springs) do local beam=v.data.beams[spring.cid];if beam then nodes[beam.id1]=true;nodes[beam.id2]=true end end
    for _,beam in pairs(v.data.beams) do
      if (nodes[beam.id1] or nodes[beam.id2]) and (beam.beamSpring or 0)>0 and not (type(beam.name)=='string' and beam.name:find('mr14air_bag_',1,true)) then
        damageBags[beam.cid]=damageBags[beam.cid] or {};table.insert(damageBags[beam.cid],bag)
      end
    end
  end
  loadSettings();if profileName~='' then applyCorners(presets.road) end;restore()
end
local function beamDeformed(id,ratio)
  if isRemote() or not calibrated or not finite(ratio) or ratio<0.12 then return end
  local affected=damageBags[id]
  if not affected then return end
  for _,bag in ipairs(affected) do bag.leak=max(bag.leak or 0,clamp((ratio-0.08)*2,0.08,1)) end
  if showMode~='off' then stopShow() end
  requestState()
end
local function calibrate()
  for _,b in ipairs(bags) do
    b.base=max(obj:getBeamLength(b.cid),0.08)
    -- Match the force carried by each removed coil spring before substitution.
    local force=0
    for _,s in ipairs(b.springs) do force=force+max(0,s.k*(s.rest-b.base)) end
    b.p=clamp(force/b.area,0,800000)
    b.supportPressure=b.p;b.quickVent=false
    b.charge=(ambient()+b.p)*b.base
    b.filtered=b.base;b.offset=0;b.failed=false
    for _,s in ipairs(b.springs) do obj:setBeamSpringDamp(s.cid,0,s.d,-1,-1) end
    obj:setBeamPressured(b.cid,ambient()+b.p,b.area,1,100000000,ambient()+900000)
    pressure(b,b.p)
  end
  calibrated=true;requestState()
end
local function updateRemote(dt)
  netAge=netAge+dt
  local wire=electrics.values[network.key]
  if wire~=lastWire then
    lastWire=wire
    local decoded=network.decode(wire)
    if decoded and network.newer(decoded.serial,receivedSequence) then
      remoteFrame=decoded;receivedSequence=decoded.serial;netAge=0;receivedFrames=receivedFrames+1
      lastWire=wire
    end
  end
  local frame=remoteFrame
  if not frame then compressor=false;airIn=0;airOut=0;return end
  tankType=frame.tankType;compressorType=frame.compressorType
  applyCorners(frame.corners);autoEnabled=frame.autoEnabled;autoActive=frame.autoActive;tank=frame.tank
  local comfortChanged=comfort~=frame.comfort or compression~=frame.compression or rebound~=frame.rebound or rearCompression~=frame.rearCompression or rearRebound~=frame.rearRebound
  if comfortChanged then rebaseComfort(comfort,frame.comfort) end
  comfort=frame.comfort
  compression=frame.compression;rebound=frame.rebound;rearCompression=frame.rearCompression;rearRebound=frame.rearRebound;workshop=frame.workshop;liftActive=frame.liftActive;drivingMode=frame.drivingMode;expoEnabled=frame.expoEnabled;expoActive=frame.expoActive
  showMode=frame.showMode;parkingEnabled=frame.parkingEnabled;parkingActive=frame.parkingActive
  enabled=frame.enabled;calibrated=frame.calibrated
  compressor=netAge<1.5 and frame.compressor
  airIn=netAge<1.5 and frame.airIn or 0;airOut=netAge<1.5 and frame.airOut or 0
  if not enabled or not calibrated then
    if remoteApplied then restore();remoteApplied=false end
    return
  end
  if comfortChanged then applyComfort(0.6+comfort*0.8) end
  for _,b in ipairs(bags) do
    local data=frame.bags[b.netID]
    if data then
      if not b.remoteActive then
        for _,spring in ipairs(b.springs) do obj:setBeamSpringDamp(spring.cid,0,spring.d,-1,-1) end
        obj:setBeamPressured(b.cid,ambient(),b.area,1,100000000,ambient()+900000)
        b.remoteCharge=data.charge;b.remoteActive=true
      end
      b.base=data.base;b.failed=data.failed;b.leak=data.leak
      b.remoteCharge=(b.remoteCharge or data.charge)+(data.charge-(b.remoteCharge or data.charge))*min(1,dt*20)
      local length=max(obj:getBeamLength(b.cid),0.04)
      b.p=data.failed and 0 or clamp(b.remoteCharge/length*gasScale(b,length)-ambient(),0,900000)
      if obj:beamIsBroken(b.cid) then b.p=0 end
      pressure(b,b.p)
    else
      -- A mismatched/missing bag must retain its original mechanical support.
      b.remoteActive=false;b.remoteCharge=nil;b.leak=0
      for _,spring in ipairs(b.springs) do obj:setBeamSpringDamp(spring.cid,spring.k,spring.d,-1,-1) end
      obj:setBeamPressured(b.cid,ambient(),1e-12,1,100000000,ambient()+900000)
      b.p=0
    end
  end
  if comfort~=0.5 or compression~=0.5 or rebound~=0.5 or rearCompression~=0.5 or rearRebound~=0.5 then applyComfort(0.6+comfort*0.8) end
  remoteApplied=true
end
local function updateFixedStep(dt)
  local remote=isRemote()
  if remote~=wasRemote then
    stopLift(false);liftButtonDown=false
    restore();held={};workshop=false;expoActive=false;expoSaved=nil;expoTimer=0;calibrated=false;elapsed=0;remoteApplied=false
    remoteFrame=nil;lastWire=nil;receivedSequence=nil;netAge=999;wasRemote=remote
    if not remote then enabled=true;electrics.values[network.key]=nil end
  end
  if remote then updateRemote(dt);return end
  updateReservoir(dt)
  airIn=0;airOut=0
  if not enabled then return end
  elapsed=elapsed+dt
  if not calibrated then if elapsed>=2 and abs(electrics.values.wheelspeed or 0)<0.5 then calibrate() end;return end
  if workshop and abs(tonumber(electrics.values.wheelspeed) or 0)*3.6>5 then setWorkshop(false) end
  if not workshop then updateHeld(dt);updateModes(dt) end
  if comfort~=0.5 or compression~=0.5 or rebound~=0.5 or rearCompression~=0.5 or rearRebound~=0.5 then applyComfort(0.6+comfort*0.8) end
  local use=0
  for _,b in ipairs(bags) do
    if not obj:beamIsBroken(b.cid) then
      local failed=false
      for _,spring in ipairs(b.springs) do if obj:beamIsBroken(spring.cid) then failed=true end end
      if failed then b.failed=true end
      local len=max(obj:getBeamLength(b.cid),0.04)
      -- The gas law acts immediately; levelling has a slower response than bumps.
      b.filtered=b.filtered+(len-b.filtered)*min(1,dt*2)
      local command=targets[b.corner]
      local requested=command*(command>=0 and 0.40 or 0.25)*b.vertical
      if b.assist then requested=max(0,requested) end
      if not workshop then b.offset=b.offset+clamp(requested-b.offset,-dt*0.06,dt*0.06) end
      local target=clamp(b.base+b.offset,max(0.06,b.rest*0.20),b.rest*2.0)
      local err=target-b.filtered
      local flow=abs(err)>0.004 and clamp(err*800000,-300000,300000) or 0
      if b.quickVent then
        if (b.p or 0)>(b.supportPressure or 0)+10000 then flow=min(flow,-300000)
        else b.quickVent=false end
      end
      -- Isolate a damaged line: levelling must not refill the leaking bag or drain the tank.
      if flow>0 and (tank<=2 or (b.leak or 0)>0) then flow=0 end
      if workshop then flow=0 end
      local delta=flow*dt*len
      local previousCharge=b.charge
      if not workshop then b.charge=max(ambient()*len/gasScale(b,len),b.charge+delta) end
      local p=clamp(b.charge/len*gasScale(b,len)-ambient(),0,min(900000,workshop and 900000 or tank*100000))
      -- Prevent accumulated charge beyond the available pressure from delaying reversal.
      if not workshop then b.charge=min(b.charge,(ambient()+min(900000,tank*100000))*len/gasScale(b,len)) end
      local accepted=b.charge-previousCharge
      if not b.failed then
        if accepted>0 and flow>0 then
          use=use+accepted*b.area/(tankLiters()*100) -- Pa*m3 / (litres * 100) = bar consumed
          airIn=airIn+min(1,accepted/max(dt*len*300000,0.001))
        elseif accepted<0 and flow<0 then
          airOut=airOut+min(1,-accepted/max(dt*len*300000,0.001))
        end
      end
      if (b.leak or 0)>0 and not b.failed then
        local scale=gasScale(b,len)
        b.charge=b.charge-min(max(0,b.charge-ambient()*len/scale),dt*(10000+140000*b.leak)*len/scale)
        p=clamp(b.charge/len*scale-ambient(),0,min(900000,workshop and 900000 or tank*100000))
      end
      if b.failed then p=0 end
      b.p=p;pressure(b,p)
    else b.p=0;b.failed=true;pressure(b,0) end
  end
  tank=clamp(tank-use,0,10)
  airIn=airIn/max(1,#bags);airOut=airOut/max(1,#bags)
end
local function setSound(name,volume)
  local source=soundSources[name]
  if not source then return end
  volume=volume*soundVolume
  source.volume=source.volume+(volume-source.volume)*0.35
  if source.volume<0.005 then source.volume=0 end
  if source.volume>0 and not source.playing then obj:playSFX(source.id);source.playing=true end
  if name=='compressor' and obj.setVolumePitchCT then obj:setVolumePitchCT(source.id,source.volume,1,0.5,0)
  else obj:setVolumePitch(source.id,source.volume,1) end
  if source.volume==0 and source.playing then obj:stopSFX(source.id);source.playing=false end
end
local function resetSounds()
  for _,source in pairs(soundSources) do
    obj:setVolumePitch(source.id,0,1);obj:stopSFX(source.id)
    source.volume=0;source.playing=false
  end
  airIn=0;airOut=0
end
local function initSounds()
  resetSounds();soundSources={}
  if not obj.createSFXSource2 then return end
  local node=0
  if bags[1] then
    local beam=v.data.beams[bags[1].cid]
    if beam then node=beam.id1 end
  end
  local events={compressor='Air_Compressor',inflate='Suspension_Up',deflate='Suspension_Down',leak='Suspension_Down'}
  for name,event in pairs(events) do
    local ok,id=pcall(obj.createSFXSource2,obj,'event:>Vehicle>Pneumatics>'..event,'AudioDefaultLoop3D','mr14air_'..name,node,name=='compressor' and 1 or 0)
    if ok and id then soundSources[name]={id=id,volume=0,playing=false};obj:setVolumePitch(id,0,1) end
  end
end
local function updateGFX(dt)
  -- The pressure already travels in MA10. Avoid a redundant electrics stream.
  local mp=extensions and extensions.MPElectricsVE
  if mp and mp~=gaugeMP and mp.excludeElectric then
    mp.excludeElectric('mr14air_tank_bar');gaugeMP=mp
  end
  -- Native props read this on every graphics tick, including remote vehicles.
  -- A mechanical gauge keeps indicating stored air with the ignition off.
  electrics.values.mr14air_tank_bar=clamp(tank,0,10)
  if v.data.mr14airTrunk3D and v.data.mr14airTrunk3D.enabled and obj.queueGameEngineLua and obj.getID then
    local layout=v.data.mr14airTrunk3D
    if not lastTrunkKey then
      trunkProfile=trunkLayouts.select(layout,v.config,v.data)
      for _,prop in pairs(v.data.props or {}) do
        if prop.mr14airProfile then prop.hidden=prop.mr14airProfile~=trunkProfile end
      end
    end
    local key=(trunkProfile or '')..':'..tankType..':'..compressorType
    if key~=lastTrunkKey then
      lastTrunkKey=key
      obj:queueGameEngineLua(string.format('if extensions.mr14karaAirRemote then extensions.mr14karaAirRemote.syncTrunk(%d,%q,%q) end',obj:getID(),tankType,compressorType))
    end
  end
  if v.mpVehicleType=='L' then
    sendTimer=sendTimer+dt
    if sendTimer>=0.1 then
      sendTimer=sendTimer%0.1;serial=(serial+1)%1000000000
      local state={enabled=enabled,calibrated=calibrated,tank=tank,compressor=compressor,front=targets.front,rear=targets.rear,corners=snapshot(targets),autoEnabled=autoEnabled,autoActive=autoActive,comfort=comfort,compression=compression,rebound=rebound,rearCompression=rearCompression,rearRebound=rearRebound,drivingMode=drivingMode,workshop=workshop,liftActive=liftActive,expoEnabled=expoEnabled,expoActive=expoActive,showMode=showMode,parkingEnabled=parkingEnabled,parkingActive=parkingActive,airIn=airIn,airOut=airOut,tankType=tankType,compressorType=compressorType}
      -- BeamMP's owned-vehicle electrics channel relays this atomic string.
      -- Sequence changes also publish unchanged state to late joiners.
      electrics.values[network.key]=network.encode(serial,state,bags)
    end
  end
  local active=dt>0
  setSound('compressor',active and compressor and #bags>0 and hardware.compressors[compressorType].gain or 0)
  setSound('inflate',active and enabled and min(0.65,airIn*0.9) or 0)
  setSound('deflate',active and enabled and min(0.8,airOut) or 0)
  local leakSound=0
  if active and enabled and calibrated and (not isRemote() or netAge<1.5) then
    for _,bag in ipairs(bags) do if not bag.failed then leakSound=max(leakSound,(bag.leak or 0)*min(1,(bag.p or 0)/100000)) end end
  end
  setSound('leak',min(0.75,leakSound*0.75))
  notifyTimer=notifyTimer+dt
  if notifyTimer>=0.2 then
    notifyTimer=0
    if not playerInfo or playerInfo.anyPlayerSeated then requestState() end
  end
end
local function reset()
  stopLift(false);liftButtonDown=false
  workshop=false;expoActive=false;expoSaved=nil;expoTimer=0
  lastTrunkKey=nil
  trunkProfile=nil
  electrics.values.mr14air_tank_bar=10
  electrics.values[network.key]=nil;lastWire=nil;remoteFrame=nil;remoteApplied=false
  receivedSequence=nil;receivedFrames=0;netAge=999;sendTimer=0;wasRemote=isRemote()
  showMode='off';showSaved=nil;showTime=0;parkingActive=false;parkingTimer=0;parkingSaved=nil
  autoActive=false;autoSaved=nil;held={};resetSounds();restore();targets={front=0,rear=0,FL=0,FR=0,RL=0,RR=0};elapsed=0;calibrated=false;tank=10;compressor=false;rechargeDemand=false
  for _,bag in ipairs(bags) do bag.leak=0;bag.failed=false end
  if profileName~='' then applyCorners(presets.road) end
end
local function setHardware(tankName,compressorName)
  if isRemote() or not hardware.valid(tankName,compressorName) then return false end
  local oldLiters=tankLiters()
  tankType=tankName;compressorType=compressorName
  -- Preserve stored air on swaps; excess air is vented when the smaller tank reaches 10 bar.
  tank=clamp(tank*oldLiters/tankLiters(),0,10)
  updateReservoir(0);persistSettings();requestState();return true
end
local function setProfile(name)
  if isRemote() or workshop or not validProfile(name) then return false end
  stopLift(true)
  name=name:match('^%s*(.-)%s*$')
  if name==profileName then return true end
  if expoActive then applyCorners(expoSaved or presets.road) end
  expoActive=false;expoSaved=nil;expoTimer=0
  held={};showMode='off';showSaved=nil;showTime=0;autoActive=false;autoSaved=nil;parkingActive=false;parkingSaved=nil;parkingTimer=0
  profileName=name
  local oldLiters=tankLiters()
  local oldComfort=comfort
  local ok,data=false,nil
  if type(jsonReadFile)=='function' then ok,data=pcall(jsonReadFile,settingsPath()) end
  if ok and type(data)=='table' and data.version==1 then loadSettings();applyCorners(presets.road) end
  rebaseComfort(oldComfort,comfort)
  tank=clamp(tank*oldLiters/tankLiters(),0,10);updateReservoir(0)
  persistSettings();if enabled and calibrated then applyComfort(0.6+comfort*0.8) end
  v.config=v.config or {};v.config.mr14AirProfile=name
  if obj.queueGameEngineLua and obj.getID then
    obj:queueGameEngineLua(string.format('if extensions.mr14karaAirRemote then extensions.mr14karaAirRemote.bindProfile(%d,%q) end',obj:getID(),name))
  end
  requestState();return true
end
local function initLastStage()
  local qa=extensions.core_quickAccess
  if not qa then return end
  local addEntry=qa.addEntry or qa.registerMenuEntry
  if type(addEntry)~='function' then return end
  addEntry({level='/root/playerVehicle/general/',uniqueID='mr14air',title='Suspension pneumatique',icon='settings',['goto']='/root/playerVehicle/mr14air/'})
  for _,e in ipairs({{'Monter',function() stepHeight(0.01) end},{'Descendre',function() stepHeight(-0.01) end},{'Hauteur route',function() recallPreset('road') end},{'Position basse',function() recallPreset('low') end},{'Position haute',function() recallPreset('high') end},{'Activer / desactiver',toggle}}) do
    local title,action=e[1],e[2]
    addEntry({level='/root/playerVehicle/mr14air/',uniqueID=title,title=title,icon='settings',onSelect=function() action();return {'reload'} end})
  end
end
M.initSounds=initSounds;M.resetSounds=resetSounds;M.init=init;M.initLastStage=initLastStage;M.reset=reset;M.updateFixedStep=updateFixedStep;M.updateGFX=updateGFX
M.setHardware=setHardware;M.beamDeformed=beamDeformed;M.setProfile=setProfile;M.setComfort=setComfort;M.setDamping=setDamping;M.setAxleDamping=setAxleDamping;M.setDrivingMode=setDrivingMode;M.setLift=setLift;M.toggleLift=toggleLift;M.setLiftInput=setLiftInput;M.setExpo=setExpo;M.toggleExpo=toggleExpo;M.setWorkshop=setWorkshop;M.toggleWorkshop=toggleWorkshop;M.setShow=setShow;M.setParking=setParking;M.toggleParking=toggleParking;M.savePreset=savePreset;M.recallPreset=recallPreset;M.setSoundVolume=setSoundVolume;M.setAutomatic=setAutomatic;M.toggleAutomatic=toggleAutomatic;M.setHeightInput=setHeightInput;M.setHeight=setHeight;M.stepHeight=stepHeight;M.toggle=toggle;M.getStatus=status;M.requestState=requestState
return M
