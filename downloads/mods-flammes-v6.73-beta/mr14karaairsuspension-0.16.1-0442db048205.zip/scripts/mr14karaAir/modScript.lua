extensions.load('mr14karaAirRemote')
setExtensionUnloadMode('mr14karaAirRemote','manual')
