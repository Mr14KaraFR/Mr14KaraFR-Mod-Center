// Integrates emissive 3D density along the actual camera ray.
// There are no camera-facing cards, textured flame planes or debug spheres.
#include "shaders/common/postFx/postFx.h.hlsl"
uniform_sampler2D(prepassTex,0);
uniform_sampler2D(prepassDepthTex,1);
cbuffer perDraw : register(b0)
{
  uniform float3 eyePosWorld;
  uniform float exposure;
  uniform float vbfCount;
  uniform float vbfNight;
  uniform float4 vbfBounds;
    uniform float4 vbfPos0;
  uniform float4 vbfHeat0;
  uniform float4 vbfAxis0;
  uniform float4 vbfFlow0;
  uniform float4 vbfStyle0;
uniform float4 vbfStyle1;
uniform float4 vbfStyle2;
uniform float4 vbfStyle3;
uniform float4 vbfStyle4;
uniform float4 vbfStyle5;
uniform float4 vbfStyle6;
uniform float4 vbfStyle7;
uniform float4 vbfStyle8;
uniform float4 vbfStyle9;
uniform float4 vbfStyle10;
uniform float4 vbfStyle11;
uniform float4 vbfStyle12;
uniform float4 vbfStyle13;
uniform float4 vbfStyle14;
uniform float4 vbfStyle15;
uniform float4 vbfStyle16;
uniform float4 vbfStyle17;
uniform float4 vbfStyle18;
uniform float4 vbfStyle19;
uniform float4 vbfStyle20;
uniform float4 vbfStyle21;
uniform float4 vbfStyle22;
uniform float4 vbfStyle23;
uniform float4 vbfStyle24;
uniform float4 vbfStyle25;
uniform float4 vbfStyle26;
uniform float4 vbfStyle27;
uniform float4 vbfStyle28;
uniform float4 vbfStyle29;
uniform float4 vbfStyle30;
uniform float4 vbfStyle31;
uniform float4 vbfStyle32;
uniform float4 vbfStyle33;
uniform float4 vbfStyle34;
uniform float4 vbfStyle35;
uniform float4 vbfStyle36;
uniform float4 vbfStyle37;
uniform float4 vbfStyle38;
uniform float4 vbfStyle39;
uniform float4 vbfStyle40;
uniform float4 vbfStyle41;
uniform float4 vbfStyle42;
uniform float4 vbfStyle43;
uniform float4 vbfStyle44;
uniform float4 vbfStyle45;
uniform float4 vbfStyle46;
uniform float4 vbfStyle47;
uniform float4 vbfStyle48;
uniform float4 vbfStyle49;
uniform float4 vbfStyle50;
uniform float4 vbfStyle51;
uniform float4 vbfStyle52;
uniform float4 vbfStyle53;
uniform float4 vbfStyle54;
uniform float4 vbfStyle55;
uniform float4 vbfStyle56;
uniform float4 vbfStyle57;
uniform float4 vbfStyle58;
uniform float4 vbfStyle59;
uniform float4 vbfStyle60;
uniform float4 vbfStyle61;
uniform float4 vbfStyle62;
uniform float4 vbfStyle63;
uniform float4 vbfStyle64;
uniform float4 vbfStyle65;
uniform float4 vbfStyle66;
uniform float4 vbfStyle67;
uniform float4 vbfStyle68;
uniform float4 vbfStyle69;
uniform float4 vbfStyle70;
uniform float4 vbfStyle71;
uniform float4 vbfStyle72;
uniform float4 vbfStyle73;
uniform float4 vbfStyle74;
uniform float4 vbfStyle75;
uniform float4 vbfStyle76;
uniform float4 vbfStyle77;
uniform float4 vbfStyle78;
uniform float4 vbfStyle79;
uniform float4 vbfStyle80;
uniform float4 vbfStyle81;
uniform float4 vbfStyle82;
uniform float4 vbfStyle83;
uniform float4 vbfStyle84;
uniform float4 vbfStyle85;
uniform float4 vbfStyle86;
uniform float4 vbfStyle87;
uniform float4 vbfStyle88;
uniform float4 vbfStyle89;
uniform float4 vbfStyle90;
uniform float4 vbfStyle91;
uniform float4 vbfStyle92;
uniform float4 vbfStyle93;
uniform float4 vbfStyle94;
uniform float4 vbfStyle95;
  uniform float4 vbfGround0;
  uniform float4 vbfPos1;
  uniform float4 vbfHeat1;
  uniform float4 vbfAxis1;
  uniform float4 vbfFlow1;
  uniform float4 vbfGround1;
  uniform float4 vbfPos2;
  uniform float4 vbfHeat2;
  uniform float4 vbfAxis2;
  uniform float4 vbfFlow2;
  uniform float4 vbfGround2;
  uniform float4 vbfPos3;
  uniform float4 vbfHeat3;
  uniform float4 vbfAxis3;
  uniform float4 vbfFlow3;
  uniform float4 vbfGround3;
  uniform float4 vbfPos4;
  uniform float4 vbfHeat4;
  uniform float4 vbfAxis4;
  uniform float4 vbfFlow4;
  uniform float4 vbfGround4;
  uniform float4 vbfPos5;
  uniform float4 vbfHeat5;
  uniform float4 vbfAxis5;
  uniform float4 vbfFlow5;
  uniform float4 vbfGround5;
  uniform float4 vbfPos6;
  uniform float4 vbfHeat6;
  uniform float4 vbfAxis6;
  uniform float4 vbfFlow6;
  uniform float4 vbfGround6;
  uniform float4 vbfPos7;
  uniform float4 vbfHeat7;
  uniform float4 vbfAxis7;
  uniform float4 vbfFlow7;
  uniform float4 vbfGround7;
  uniform float4 vbfPos8;
  uniform float4 vbfHeat8;
  uniform float4 vbfAxis8;
  uniform float4 vbfFlow8;
  uniform float4 vbfGround8;
  uniform float4 vbfPos9;
  uniform float4 vbfHeat9;
  uniform float4 vbfAxis9;
  uniform float4 vbfFlow9;
  uniform float4 vbfGround9;
  uniform float4 vbfPos10;
  uniform float4 vbfHeat10;
  uniform float4 vbfAxis10;
  uniform float4 vbfFlow10;
  uniform float4 vbfGround10;
  uniform float4 vbfPos11;
  uniform float4 vbfHeat11;
  uniform float4 vbfAxis11;
  uniform float4 vbfFlow11;
  uniform float4 vbfGround11;
  uniform float4 vbfPos12;
  uniform float4 vbfHeat12;
  uniform float4 vbfAxis12;
  uniform float4 vbfFlow12;
  uniform float4 vbfGround12;
  uniform float4 vbfPos13;
  uniform float4 vbfHeat13;
  uniform float4 vbfAxis13;
  uniform float4 vbfFlow13;
  uniform float4 vbfGround13;
  uniform float4 vbfPos14;
  uniform float4 vbfHeat14;
  uniform float4 vbfAxis14;
  uniform float4 vbfFlow14;
  uniform float4 vbfGround14;
  uniform float4 vbfPos15;
  uniform float4 vbfHeat15;
  uniform float4 vbfAxis15;
  uniform float4 vbfFlow15;
  uniform float4 vbfGround15;
  uniform float4 vbfPos16;
  uniform float4 vbfHeat16;
  uniform float4 vbfAxis16;
  uniform float4 vbfFlow16;
  uniform float4 vbfGround16;
  uniform float4 vbfPos17;
  uniform float4 vbfHeat17;
  uniform float4 vbfAxis17;
  uniform float4 vbfFlow17;
  uniform float4 vbfGround17;
  uniform float4 vbfPos18;
  uniform float4 vbfHeat18;
  uniform float4 vbfAxis18;
  uniform float4 vbfFlow18;
  uniform float4 vbfGround18;
  uniform float4 vbfPos19;
  uniform float4 vbfHeat19;
  uniform float4 vbfAxis19;
  uniform float4 vbfFlow19;
  uniform float4 vbfGround19;
  uniform float4 vbfPos20;
  uniform float4 vbfHeat20;
  uniform float4 vbfAxis20;
  uniform float4 vbfFlow20;
  uniform float4 vbfGround20;
  uniform float4 vbfPos21;
  uniform float4 vbfHeat21;
  uniform float4 vbfAxis21;
  uniform float4 vbfFlow21;
  uniform float4 vbfGround21;
  uniform float4 vbfPos22;
  uniform float4 vbfHeat22;
  uniform float4 vbfAxis22;
  uniform float4 vbfFlow22;
  uniform float4 vbfGround22;
  uniform float4 vbfPos23;
  uniform float4 vbfHeat23;
  uniform float4 vbfAxis23;
  uniform float4 vbfFlow23;
  uniform float4 vbfGround23;
  uniform float4 vbfPos24;
  uniform float4 vbfHeat24;
  uniform float4 vbfAxis24;
  uniform float4 vbfFlow24;
  uniform float4 vbfGround24;
  uniform float4 vbfPos25;
  uniform float4 vbfHeat25;
  uniform float4 vbfAxis25;
  uniform float4 vbfFlow25;
  uniform float4 vbfGround25;
  uniform float4 vbfPos26;
  uniform float4 vbfHeat26;
  uniform float4 vbfAxis26;
  uniform float4 vbfFlow26;
  uniform float4 vbfGround26;
  uniform float4 vbfPos27;
  uniform float4 vbfHeat27;
  uniform float4 vbfAxis27;
  uniform float4 vbfFlow27;
  uniform float4 vbfGround27;
  uniform float4 vbfPos28;
  uniform float4 vbfHeat28;
  uniform float4 vbfAxis28;
  uniform float4 vbfFlow28;
  uniform float4 vbfGround28;
  uniform float4 vbfPos29;
  uniform float4 vbfHeat29;
  uniform float4 vbfAxis29;
  uniform float4 vbfFlow29;
  uniform float4 vbfGround29;
  uniform float4 vbfPos30;
  uniform float4 vbfHeat30;
  uniform float4 vbfAxis30;
  uniform float4 vbfFlow30;
  uniform float4 vbfGround30;
  uniform float4 vbfPos31;
  uniform float4 vbfHeat31;
  uniform float4 vbfAxis31;
  uniform float4 vbfFlow31;
  uniform float4 vbfGround31;
  uniform float4 vbfPos32;
  uniform float4 vbfHeat32;
  uniform float4 vbfAxis32;
  uniform float4 vbfFlow32;
  uniform float4 vbfGround32;
  uniform float4 vbfPos33;
  uniform float4 vbfHeat33;
  uniform float4 vbfAxis33;
  uniform float4 vbfFlow33;
  uniform float4 vbfGround33;
  uniform float4 vbfPos34;
  uniform float4 vbfHeat34;
  uniform float4 vbfAxis34;
  uniform float4 vbfFlow34;
  uniform float4 vbfGround34;
  uniform float4 vbfPos35;
  uniform float4 vbfHeat35;
  uniform float4 vbfAxis35;
  uniform float4 vbfFlow35;
  uniform float4 vbfGround35;
  uniform float4 vbfPos36;
  uniform float4 vbfHeat36;
  uniform float4 vbfAxis36;
  uniform float4 vbfFlow36;
  uniform float4 vbfGround36;
  uniform float4 vbfPos37;
  uniform float4 vbfHeat37;
  uniform float4 vbfAxis37;
  uniform float4 vbfFlow37;
  uniform float4 vbfGround37;
  uniform float4 vbfPos38;
  uniform float4 vbfHeat38;
  uniform float4 vbfAxis38;
  uniform float4 vbfFlow38;
  uniform float4 vbfGround38;
  uniform float4 vbfPos39;
  uniform float4 vbfHeat39;
  uniform float4 vbfAxis39;
  uniform float4 vbfFlow39;
  uniform float4 vbfGround39;
  uniform float4 vbfPos40;
  uniform float4 vbfHeat40;
  uniform float4 vbfAxis40;
  uniform float4 vbfFlow40;
  uniform float4 vbfGround40;
  uniform float4 vbfPos41;
  uniform float4 vbfHeat41;
  uniform float4 vbfAxis41;
  uniform float4 vbfFlow41;
  uniform float4 vbfGround41;
  uniform float4 vbfPos42;
  uniform float4 vbfHeat42;
  uniform float4 vbfAxis42;
  uniform float4 vbfFlow42;
  uniform float4 vbfGround42;
  uniform float4 vbfPos43;
  uniform float4 vbfHeat43;
  uniform float4 vbfAxis43;
  uniform float4 vbfFlow43;
  uniform float4 vbfGround43;
  uniform float4 vbfPos44;
  uniform float4 vbfHeat44;
  uniform float4 vbfAxis44;
  uniform float4 vbfFlow44;
  uniform float4 vbfGround44;
  uniform float4 vbfPos45;
  uniform float4 vbfHeat45;
  uniform float4 vbfAxis45;
  uniform float4 vbfFlow45;
  uniform float4 vbfGround45;
  uniform float4 vbfPos46;
  uniform float4 vbfHeat46;
  uniform float4 vbfAxis46;
  uniform float4 vbfFlow46;
  uniform float4 vbfGround46;
  uniform float4 vbfPos47;
  uniform float4 vbfHeat47;
  uniform float4 vbfAxis47;
  uniform float4 vbfFlow47;
  uniform float4 vbfGround47;
  uniform float4 vbfPos48;
  uniform float4 vbfHeat48;
  uniform float4 vbfAxis48;
  uniform float4 vbfFlow48;
  uniform float4 vbfGround48;
  uniform float4 vbfPos49;
  uniform float4 vbfHeat49;
  uniform float4 vbfAxis49;
  uniform float4 vbfFlow49;
  uniform float4 vbfGround49;
  uniform float4 vbfPos50;
  uniform float4 vbfHeat50;
  uniform float4 vbfAxis50;
  uniform float4 vbfFlow50;
  uniform float4 vbfGround50;
  uniform float4 vbfPos51;
  uniform float4 vbfHeat51;
  uniform float4 vbfAxis51;
  uniform float4 vbfFlow51;
  uniform float4 vbfGround51;
  uniform float4 vbfPos52;
  uniform float4 vbfHeat52;
  uniform float4 vbfAxis52;
  uniform float4 vbfFlow52;
  uniform float4 vbfGround52;
  uniform float4 vbfPos53;
  uniform float4 vbfHeat53;
  uniform float4 vbfAxis53;
  uniform float4 vbfFlow53;
  uniform float4 vbfGround53;
  uniform float4 vbfPos54;
  uniform float4 vbfHeat54;
  uniform float4 vbfAxis54;
  uniform float4 vbfFlow54;
  uniform float4 vbfGround54;
  uniform float4 vbfPos55;
  uniform float4 vbfHeat55;
  uniform float4 vbfAxis55;
  uniform float4 vbfFlow55;
  uniform float4 vbfGround55;
  uniform float4 vbfPos56;
  uniform float4 vbfHeat56;
  uniform float4 vbfAxis56;
  uniform float4 vbfFlow56;
  uniform float4 vbfGround56;
  uniform float4 vbfPos57;
  uniform float4 vbfHeat57;
  uniform float4 vbfAxis57;
  uniform float4 vbfFlow57;
  uniform float4 vbfGround57;
  uniform float4 vbfPos58;
  uniform float4 vbfHeat58;
  uniform float4 vbfAxis58;
  uniform float4 vbfFlow58;
  uniform float4 vbfGround58;
  uniform float4 vbfPos59;
  uniform float4 vbfHeat59;
  uniform float4 vbfAxis59;
  uniform float4 vbfFlow59;
  uniform float4 vbfGround59;
  uniform float4 vbfPos60;
  uniform float4 vbfHeat60;
  uniform float4 vbfAxis60;
  uniform float4 vbfFlow60;
  uniform float4 vbfGround60;
  uniform float4 vbfPos61;
  uniform float4 vbfHeat61;
  uniform float4 vbfAxis61;
  uniform float4 vbfFlow61;
  uniform float4 vbfGround61;
  uniform float4 vbfPos62;
  uniform float4 vbfHeat62;
  uniform float4 vbfAxis62;
  uniform float4 vbfFlow62;
  uniform float4 vbfGround62;
  uniform float4 vbfPos63;
  uniform float4 vbfHeat63;
  uniform float4 vbfAxis63;
  uniform float4 vbfFlow63;
  uniform float4 vbfGround63;
  uniform float4 vbfPos64;
  uniform float4 vbfHeat64;
  uniform float4 vbfAxis64;
  uniform float4 vbfFlow64;
  uniform float4 vbfGround64;
  uniform float4 vbfPos65;
  uniform float4 vbfHeat65;
  uniform float4 vbfAxis65;
  uniform float4 vbfFlow65;
  uniform float4 vbfGround65;
  uniform float4 vbfPos66;
  uniform float4 vbfHeat66;
  uniform float4 vbfAxis66;
  uniform float4 vbfFlow66;
  uniform float4 vbfGround66;
  uniform float4 vbfPos67;
  uniform float4 vbfHeat67;
  uniform float4 vbfAxis67;
  uniform float4 vbfFlow67;
  uniform float4 vbfGround67;
  uniform float4 vbfPos68;
  uniform float4 vbfHeat68;
  uniform float4 vbfAxis68;
  uniform float4 vbfFlow68;
  uniform float4 vbfGround68;
  uniform float4 vbfPos69;
  uniform float4 vbfHeat69;
  uniform float4 vbfAxis69;
  uniform float4 vbfFlow69;
  uniform float4 vbfGround69;
  uniform float4 vbfPos70;
  uniform float4 vbfHeat70;
  uniform float4 vbfAxis70;
  uniform float4 vbfFlow70;
  uniform float4 vbfGround70;
  uniform float4 vbfPos71;
  uniform float4 vbfHeat71;
  uniform float4 vbfAxis71;
  uniform float4 vbfFlow71;
  uniform float4 vbfGround71;
  uniform float4 vbfPos72;
  uniform float4 vbfHeat72;
  uniform float4 vbfAxis72;
  uniform float4 vbfFlow72;
  uniform float4 vbfGround72;
  uniform float4 vbfPos73;
  uniform float4 vbfHeat73;
  uniform float4 vbfAxis73;
  uniform float4 vbfFlow73;
  uniform float4 vbfGround73;
  uniform float4 vbfPos74;
  uniform float4 vbfHeat74;
  uniform float4 vbfAxis74;
  uniform float4 vbfFlow74;
  uniform float4 vbfGround74;
  uniform float4 vbfPos75;
  uniform float4 vbfHeat75;
  uniform float4 vbfAxis75;
  uniform float4 vbfFlow75;
  uniform float4 vbfGround75;
  uniform float4 vbfPos76;
  uniform float4 vbfHeat76;
  uniform float4 vbfAxis76;
  uniform float4 vbfFlow76;
  uniform float4 vbfGround76;
  uniform float4 vbfPos77;
  uniform float4 vbfHeat77;
  uniform float4 vbfAxis77;
  uniform float4 vbfFlow77;
  uniform float4 vbfGround77;
  uniform float4 vbfPos78;
  uniform float4 vbfHeat78;
  uniform float4 vbfAxis78;
  uniform float4 vbfFlow78;
  uniform float4 vbfGround78;
  uniform float4 vbfPos79;
  uniform float4 vbfHeat79;
  uniform float4 vbfAxis79;
  uniform float4 vbfFlow79;
  uniform float4 vbfGround79;
  uniform float4 vbfPos80;
  uniform float4 vbfHeat80;
  uniform float4 vbfAxis80;
  uniform float4 vbfFlow80;
  uniform float4 vbfGround80;
  uniform float4 vbfPos81;
  uniform float4 vbfHeat81;
  uniform float4 vbfAxis81;
  uniform float4 vbfFlow81;
  uniform float4 vbfGround81;
  uniform float4 vbfPos82;
  uniform float4 vbfHeat82;
  uniform float4 vbfAxis82;
  uniform float4 vbfFlow82;
  uniform float4 vbfGround82;
  uniform float4 vbfPos83;
  uniform float4 vbfHeat83;
  uniform float4 vbfAxis83;
  uniform float4 vbfFlow83;
  uniform float4 vbfGround83;
  uniform float4 vbfPos84;
  uniform float4 vbfHeat84;
  uniform float4 vbfAxis84;
  uniform float4 vbfFlow84;
  uniform float4 vbfGround84;
  uniform float4 vbfPos85;
  uniform float4 vbfHeat85;
  uniform float4 vbfAxis85;
  uniform float4 vbfFlow85;
  uniform float4 vbfGround85;
  uniform float4 vbfPos86;
  uniform float4 vbfHeat86;
  uniform float4 vbfAxis86;
  uniform float4 vbfFlow86;
  uniform float4 vbfGround86;
  uniform float4 vbfPos87;
  uniform float4 vbfHeat87;
  uniform float4 vbfAxis87;
  uniform float4 vbfFlow87;
  uniform float4 vbfGround87;
  uniform float4 vbfPos88;
  uniform float4 vbfHeat88;
  uniform float4 vbfAxis88;
  uniform float4 vbfFlow88;
  uniform float4 vbfGround88;
  uniform float4 vbfPos89;
  uniform float4 vbfHeat89;
  uniform float4 vbfAxis89;
  uniform float4 vbfFlow89;
  uniform float4 vbfGround89;
  uniform float4 vbfPos90;
  uniform float4 vbfHeat90;
  uniform float4 vbfAxis90;
  uniform float4 vbfFlow90;
  uniform float4 vbfGround90;
  uniform float4 vbfPos91;
  uniform float4 vbfHeat91;
  uniform float4 vbfAxis91;
  uniform float4 vbfFlow91;
  uniform float4 vbfGround91;
  uniform float4 vbfPos92;
  uniform float4 vbfHeat92;
  uniform float4 vbfAxis92;
  uniform float4 vbfFlow92;
  uniform float4 vbfGround92;
  uniform float4 vbfPos93;
  uniform float4 vbfHeat93;
  uniform float4 vbfAxis93;
  uniform float4 vbfFlow93;
  uniform float4 vbfGround93;
  uniform float4 vbfPos94;
  uniform float4 vbfHeat94;
  uniform float4 vbfAxis94;
  uniform float4 vbfFlow94;
  uniform float4 vbfGround94;
  uniform float4 vbfPos95;
  uniform float4 vbfHeat95;
  uniform float4 vbfAxis95;
  uniform float4 vbfFlow95;
  uniform float4 vbfGround95;
  POSTFX_UNIFORMS
};
#include "shaders/common/postFx/postFx.hlsl"

#ifdef SHADER_STAGE_VS
PFXVertToPix main(PFXVert IN) { return processPostFxVert(IN); }
#else
float hash31(float3 p)
{
  return frac(sin(dot(p,float3(127.1,311.7,74.7)))*43758.5453);
}
float noise3(float3 p)
{
  float3 i=floor(p),f=frac(p); f=f*f*(3-2*f);
  return lerp(lerp(lerp(hash31(i),hash31(i+float3(1,0,0)),f.x),
                   lerp(hash31(i+float3(0,1,0)),hash31(i+float3(1,1,0)),f.x),f.y),
              lerp(lerp(hash31(i+float3(0,0,1)),hash31(i+float3(1,0,1)),f.x),
                   lerp(hash31(i+float3(0,1,1)),hash31(i+float3(1,1,1)),f.x),f.y),f.z);
}
void volumeData(int i,out float4 position,out float4 state,out float4 axis,out float4 flow,out float4 ground,out float4 style)
{
  // Read only the current volume from the constant buffer, instead of
  // initializing four local arrays of 96 vectors for each screen pixel.
  switch(i)
  {
    case 0: position=vbfPos0; state=vbfHeat0; axis=vbfAxis0; flow=vbfFlow0; ground=vbfGround0; style=vbfStyle0; break;
case 1: position=vbfPos1; state=vbfHeat1; axis=vbfAxis1; flow=vbfFlow1; ground=vbfGround1; style=vbfStyle1; break;
case 2: position=vbfPos2; state=vbfHeat2; axis=vbfAxis2; flow=vbfFlow2; ground=vbfGround2; style=vbfStyle2; break;
case 3: position=vbfPos3; state=vbfHeat3; axis=vbfAxis3; flow=vbfFlow3; ground=vbfGround3; style=vbfStyle3; break;
case 4: position=vbfPos4; state=vbfHeat4; axis=vbfAxis4; flow=vbfFlow4; ground=vbfGround4; style=vbfStyle4; break;
case 5: position=vbfPos5; state=vbfHeat5; axis=vbfAxis5; flow=vbfFlow5; ground=vbfGround5; style=vbfStyle5; break;
case 6: position=vbfPos6; state=vbfHeat6; axis=vbfAxis6; flow=vbfFlow6; ground=vbfGround6; style=vbfStyle6; break;
case 7: position=vbfPos7; state=vbfHeat7; axis=vbfAxis7; flow=vbfFlow7; ground=vbfGround7; style=vbfStyle7; break;
case 8: position=vbfPos8; state=vbfHeat8; axis=vbfAxis8; flow=vbfFlow8; ground=vbfGround8; style=vbfStyle8; break;
case 9: position=vbfPos9; state=vbfHeat9; axis=vbfAxis9; flow=vbfFlow9; ground=vbfGround9; style=vbfStyle9; break;
case 10: position=vbfPos10; state=vbfHeat10; axis=vbfAxis10; flow=vbfFlow10; ground=vbfGround10; style=vbfStyle10; break;
case 11: position=vbfPos11; state=vbfHeat11; axis=vbfAxis11; flow=vbfFlow11; ground=vbfGround11; style=vbfStyle11; break;
case 12: position=vbfPos12; state=vbfHeat12; axis=vbfAxis12; flow=vbfFlow12; ground=vbfGround12; style=vbfStyle12; break;
case 13: position=vbfPos13; state=vbfHeat13; axis=vbfAxis13; flow=vbfFlow13; ground=vbfGround13; style=vbfStyle13; break;
case 14: position=vbfPos14; state=vbfHeat14; axis=vbfAxis14; flow=vbfFlow14; ground=vbfGround14; style=vbfStyle14; break;
case 15: position=vbfPos15; state=vbfHeat15; axis=vbfAxis15; flow=vbfFlow15; ground=vbfGround15; style=vbfStyle15; break;
case 16: position=vbfPos16; state=vbfHeat16; axis=vbfAxis16; flow=vbfFlow16; ground=vbfGround16; style=vbfStyle16; break;
case 17: position=vbfPos17; state=vbfHeat17; axis=vbfAxis17; flow=vbfFlow17; ground=vbfGround17; style=vbfStyle17; break;
case 18: position=vbfPos18; state=vbfHeat18; axis=vbfAxis18; flow=vbfFlow18; ground=vbfGround18; style=vbfStyle18; break;
case 19: position=vbfPos19; state=vbfHeat19; axis=vbfAxis19; flow=vbfFlow19; ground=vbfGround19; style=vbfStyle19; break;
case 20: position=vbfPos20; state=vbfHeat20; axis=vbfAxis20; flow=vbfFlow20; ground=vbfGround20; style=vbfStyle20; break;
case 21: position=vbfPos21; state=vbfHeat21; axis=vbfAxis21; flow=vbfFlow21; ground=vbfGround21; style=vbfStyle21; break;
case 22: position=vbfPos22; state=vbfHeat22; axis=vbfAxis22; flow=vbfFlow22; ground=vbfGround22; style=vbfStyle22; break;
case 23: position=vbfPos23; state=vbfHeat23; axis=vbfAxis23; flow=vbfFlow23; ground=vbfGround23; style=vbfStyle23; break;
case 24: position=vbfPos24; state=vbfHeat24; axis=vbfAxis24; flow=vbfFlow24; ground=vbfGround24; style=vbfStyle24; break;
case 25: position=vbfPos25; state=vbfHeat25; axis=vbfAxis25; flow=vbfFlow25; ground=vbfGround25; style=vbfStyle25; break;
case 26: position=vbfPos26; state=vbfHeat26; axis=vbfAxis26; flow=vbfFlow26; ground=vbfGround26; style=vbfStyle26; break;
case 27: position=vbfPos27; state=vbfHeat27; axis=vbfAxis27; flow=vbfFlow27; ground=vbfGround27; style=vbfStyle27; break;
case 28: position=vbfPos28; state=vbfHeat28; axis=vbfAxis28; flow=vbfFlow28; ground=vbfGround28; style=vbfStyle28; break;
case 29: position=vbfPos29; state=vbfHeat29; axis=vbfAxis29; flow=vbfFlow29; ground=vbfGround29; style=vbfStyle29; break;
case 30: position=vbfPos30; state=vbfHeat30; axis=vbfAxis30; flow=vbfFlow30; ground=vbfGround30; style=vbfStyle30; break;
case 31: position=vbfPos31; state=vbfHeat31; axis=vbfAxis31; flow=vbfFlow31; ground=vbfGround31; style=vbfStyle31; break;
case 32: position=vbfPos32; state=vbfHeat32; axis=vbfAxis32; flow=vbfFlow32; ground=vbfGround32; style=vbfStyle32; break;
case 33: position=vbfPos33; state=vbfHeat33; axis=vbfAxis33; flow=vbfFlow33; ground=vbfGround33; style=vbfStyle33; break;
case 34: position=vbfPos34; state=vbfHeat34; axis=vbfAxis34; flow=vbfFlow34; ground=vbfGround34; style=vbfStyle34; break;
case 35: position=vbfPos35; state=vbfHeat35; axis=vbfAxis35; flow=vbfFlow35; ground=vbfGround35; style=vbfStyle35; break;
case 36: position=vbfPos36; state=vbfHeat36; axis=vbfAxis36; flow=vbfFlow36; ground=vbfGround36; style=vbfStyle36; break;
case 37: position=vbfPos37; state=vbfHeat37; axis=vbfAxis37; flow=vbfFlow37; ground=vbfGround37; style=vbfStyle37; break;
case 38: position=vbfPos38; state=vbfHeat38; axis=vbfAxis38; flow=vbfFlow38; ground=vbfGround38; style=vbfStyle38; break;
case 39: position=vbfPos39; state=vbfHeat39; axis=vbfAxis39; flow=vbfFlow39; ground=vbfGround39; style=vbfStyle39; break;
case 40: position=vbfPos40; state=vbfHeat40; axis=vbfAxis40; flow=vbfFlow40; ground=vbfGround40; style=vbfStyle40; break;
case 41: position=vbfPos41; state=vbfHeat41; axis=vbfAxis41; flow=vbfFlow41; ground=vbfGround41; style=vbfStyle41; break;
case 42: position=vbfPos42; state=vbfHeat42; axis=vbfAxis42; flow=vbfFlow42; ground=vbfGround42; style=vbfStyle42; break;
case 43: position=vbfPos43; state=vbfHeat43; axis=vbfAxis43; flow=vbfFlow43; ground=vbfGround43; style=vbfStyle43; break;
case 44: position=vbfPos44; state=vbfHeat44; axis=vbfAxis44; flow=vbfFlow44; ground=vbfGround44; style=vbfStyle44; break;
case 45: position=vbfPos45; state=vbfHeat45; axis=vbfAxis45; flow=vbfFlow45; ground=vbfGround45; style=vbfStyle45; break;
case 46: position=vbfPos46; state=vbfHeat46; axis=vbfAxis46; flow=vbfFlow46; ground=vbfGround46; style=vbfStyle46; break;
case 47: position=vbfPos47; state=vbfHeat47; axis=vbfAxis47; flow=vbfFlow47; ground=vbfGround47; style=vbfStyle47; break;
case 48: position=vbfPos48; state=vbfHeat48; axis=vbfAxis48; flow=vbfFlow48; ground=vbfGround48; style=vbfStyle48; break;
case 49: position=vbfPos49; state=vbfHeat49; axis=vbfAxis49; flow=vbfFlow49; ground=vbfGround49; style=vbfStyle49; break;
case 50: position=vbfPos50; state=vbfHeat50; axis=vbfAxis50; flow=vbfFlow50; ground=vbfGround50; style=vbfStyle50; break;
case 51: position=vbfPos51; state=vbfHeat51; axis=vbfAxis51; flow=vbfFlow51; ground=vbfGround51; style=vbfStyle51; break;
case 52: position=vbfPos52; state=vbfHeat52; axis=vbfAxis52; flow=vbfFlow52; ground=vbfGround52; style=vbfStyle52; break;
case 53: position=vbfPos53; state=vbfHeat53; axis=vbfAxis53; flow=vbfFlow53; ground=vbfGround53; style=vbfStyle53; break;
case 54: position=vbfPos54; state=vbfHeat54; axis=vbfAxis54; flow=vbfFlow54; ground=vbfGround54; style=vbfStyle54; break;
case 55: position=vbfPos55; state=vbfHeat55; axis=vbfAxis55; flow=vbfFlow55; ground=vbfGround55; style=vbfStyle55; break;
case 56: position=vbfPos56; state=vbfHeat56; axis=vbfAxis56; flow=vbfFlow56; ground=vbfGround56; style=vbfStyle56; break;
case 57: position=vbfPos57; state=vbfHeat57; axis=vbfAxis57; flow=vbfFlow57; ground=vbfGround57; style=vbfStyle57; break;
case 58: position=vbfPos58; state=vbfHeat58; axis=vbfAxis58; flow=vbfFlow58; ground=vbfGround58; style=vbfStyle58; break;
case 59: position=vbfPos59; state=vbfHeat59; axis=vbfAxis59; flow=vbfFlow59; ground=vbfGround59; style=vbfStyle59; break;
case 60: position=vbfPos60; state=vbfHeat60; axis=vbfAxis60; flow=vbfFlow60; ground=vbfGround60; style=vbfStyle60; break;
case 61: position=vbfPos61; state=vbfHeat61; axis=vbfAxis61; flow=vbfFlow61; ground=vbfGround61; style=vbfStyle61; break;
case 62: position=vbfPos62; state=vbfHeat62; axis=vbfAxis62; flow=vbfFlow62; ground=vbfGround62; style=vbfStyle62; break;
case 63: position=vbfPos63; state=vbfHeat63; axis=vbfAxis63; flow=vbfFlow63; ground=vbfGround63; style=vbfStyle63; break;
case 64: position=vbfPos64; state=vbfHeat64; axis=vbfAxis64; flow=vbfFlow64; ground=vbfGround64; style=vbfStyle64; break;
case 65: position=vbfPos65; state=vbfHeat65; axis=vbfAxis65; flow=vbfFlow65; ground=vbfGround65; style=vbfStyle65; break;
case 66: position=vbfPos66; state=vbfHeat66; axis=vbfAxis66; flow=vbfFlow66; ground=vbfGround66; style=vbfStyle66; break;
case 67: position=vbfPos67; state=vbfHeat67; axis=vbfAxis67; flow=vbfFlow67; ground=vbfGround67; style=vbfStyle67; break;
case 68: position=vbfPos68; state=vbfHeat68; axis=vbfAxis68; flow=vbfFlow68; ground=vbfGround68; style=vbfStyle68; break;
case 69: position=vbfPos69; state=vbfHeat69; axis=vbfAxis69; flow=vbfFlow69; ground=vbfGround69; style=vbfStyle69; break;
case 70: position=vbfPos70; state=vbfHeat70; axis=vbfAxis70; flow=vbfFlow70; ground=vbfGround70; style=vbfStyle70; break;
case 71: position=vbfPos71; state=vbfHeat71; axis=vbfAxis71; flow=vbfFlow71; ground=vbfGround71; style=vbfStyle71; break;
case 72: position=vbfPos72; state=vbfHeat72; axis=vbfAxis72; flow=vbfFlow72; ground=vbfGround72; style=vbfStyle72; break;
case 73: position=vbfPos73; state=vbfHeat73; axis=vbfAxis73; flow=vbfFlow73; ground=vbfGround73; style=vbfStyle73; break;
case 74: position=vbfPos74; state=vbfHeat74; axis=vbfAxis74; flow=vbfFlow74; ground=vbfGround74; style=vbfStyle74; break;
case 75: position=vbfPos75; state=vbfHeat75; axis=vbfAxis75; flow=vbfFlow75; ground=vbfGround75; style=vbfStyle75; break;
case 76: position=vbfPos76; state=vbfHeat76; axis=vbfAxis76; flow=vbfFlow76; ground=vbfGround76; style=vbfStyle76; break;
case 77: position=vbfPos77; state=vbfHeat77; axis=vbfAxis77; flow=vbfFlow77; ground=vbfGround77; style=vbfStyle77; break;
case 78: position=vbfPos78; state=vbfHeat78; axis=vbfAxis78; flow=vbfFlow78; ground=vbfGround78; style=vbfStyle78; break;
case 79: position=vbfPos79; state=vbfHeat79; axis=vbfAxis79; flow=vbfFlow79; ground=vbfGround79; style=vbfStyle79; break;
case 80: position=vbfPos80; state=vbfHeat80; axis=vbfAxis80; flow=vbfFlow80; ground=vbfGround80; style=vbfStyle80; break;
case 81: position=vbfPos81; state=vbfHeat81; axis=vbfAxis81; flow=vbfFlow81; ground=vbfGround81; style=vbfStyle81; break;
case 82: position=vbfPos82; state=vbfHeat82; axis=vbfAxis82; flow=vbfFlow82; ground=vbfGround82; style=vbfStyle82; break;
case 83: position=vbfPos83; state=vbfHeat83; axis=vbfAxis83; flow=vbfFlow83; ground=vbfGround83; style=vbfStyle83; break;
case 84: position=vbfPos84; state=vbfHeat84; axis=vbfAxis84; flow=vbfFlow84; ground=vbfGround84; style=vbfStyle84; break;
case 85: position=vbfPos85; state=vbfHeat85; axis=vbfAxis85; flow=vbfFlow85; ground=vbfGround85; style=vbfStyle85; break;
case 86: position=vbfPos86; state=vbfHeat86; axis=vbfAxis86; flow=vbfFlow86; ground=vbfGround86; style=vbfStyle86; break;
case 87: position=vbfPos87; state=vbfHeat87; axis=vbfAxis87; flow=vbfFlow87; ground=vbfGround87; style=vbfStyle87; break;
case 88: position=vbfPos88; state=vbfHeat88; axis=vbfAxis88; flow=vbfFlow88; ground=vbfGround88; style=vbfStyle88; break;
case 89: position=vbfPos89; state=vbfHeat89; axis=vbfAxis89; flow=vbfFlow89; ground=vbfGround89; style=vbfStyle89; break;
case 90: position=vbfPos90; state=vbfHeat90; axis=vbfAxis90; flow=vbfFlow90; ground=vbfGround90; style=vbfStyle90; break;
case 91: position=vbfPos91; state=vbfHeat91; axis=vbfAxis91; flow=vbfFlow91; ground=vbfGround91; style=vbfStyle91; break;
case 92: position=vbfPos92; state=vbfHeat92; axis=vbfAxis92; flow=vbfFlow92; ground=vbfGround92; style=vbfStyle92; break;
case 93: position=vbfPos93; state=vbfHeat93; axis=vbfAxis93; flow=vbfFlow93; ground=vbfGround93; style=vbfStyle93; break;
case 94: position=vbfPos94; state=vbfHeat94; axis=vbfAxis94; flow=vbfFlow94; ground=vbfGround94; style=vbfStyle94; break;
case 95: position=vbfPos95; state=vbfHeat95; axis=vbfAxis95; flow=vbfFlow95; ground=vbfGround95; style=vbfStyle95; break;
    default: style=0; position=0; state=0; axis=0; flow=0; ground=float4(0,0,0,1); break;
  }
}
float4 main(PFXVertToPix IN) : SV_Target
{
  float rayLength=length(IN.wsEyeRay);
  float3 rd=IN.wsEyeRay/max(rayLength,0.00001);
  // Reject empty pixels before depth sampling and density integration.
  float3 boundsOC=eyePosWorld-vbfBounds.xyz;
  float boundsB=dot(boundsOC,rd);
  [branch] if(vbfCount<0.5 || boundsB*boundsB-dot(boundsOC,boundsOC)+vbfBounds.w*vbfBounds.w<=0 ||
             (boundsB>0 && dot(boundsOC,boundsOC)>vbfBounds.w*vbfBounds.w)) discard;
  float depth=decodeGBuffer(TEX_SAMPLER(prepassDepthTex),TEX_SAMPLER(prepassTex),IN.uv0,projParams).w;
  float sceneDistance=depth*rayLength;
  float3 radiance=0;
  [loop] for(int i=0;i<min((int)vbfCount,96);i++)
  {
    float4 position,state,axisData,flowData,groundData,styleData;
    volumeData(i,position,state,axisData,flowData,groundData,styleData);
    // Style is integer-valued: packing the fade here leaves the noise seed
    // exact, so the tongue cannot change family during its extinction.
    float fadeCode=floor(styleData.x/8);
    float coreFade=saturate(fadeCode/63);styleData.x-=fadeCode*8;
    float variant=frac(sin(state.w*12.9898+78.233)*43758.5453);
    float3 center=position.xyz;
    float radius=position.w;
    float3 axis=axisData.xyz;
    float halfLength=abs(axisData.w);
    bool anchored=axisData.w<0;
    bool pop=styleData.x>0.5 && styleData.x<1.5;
    float packedOutlet=floor(styleData.w+0.5);
      float packedRadius=floor(packedOutlet*0.25);
      int outlet=(int)(packedOutlet-packedRadius*4.0);
      float mouthRadius=packedRadius*0.0001;
    // Includes downstream widening and centerline flutter of the attached jet.
    float3 crossFlow=flowData.xyz-axis*dot(flowData.xyz,axis);
    // Rearward slipstream stretches the jet; side/hood crossflow retains
    // the existing bending path. No camera-facing geometry is introduced.
    float airSpeed=length(flowData.xyz);
    float axialAir=max(0,dot(flowData.xyz,axis));
    float alignment=axialAir/max(airSpeed,.001);
    float stream=anchored ? smoothstep(8,45,axialAir)*alignment*alignment : 0;
    float bendBound=min(0.55,length(crossFlow)*0.028);
    float boundRadius=anchored ? sqrt(pow(3*radius+0.15+bendBound,2)+halfLength*halfLength) : sqrt(4*radius*radius+halfLength*halfLength);
    float3 oc=eyePosWorld-center;
    float b=dot(oc,rd);
    float h=b*b-dot(oc,oc)+boundRadius*boundRadius;
    if(h<=0) continue;
    h=sqrt(h);
    float begin=max(0,-b-h),end=min(sceneDistance,-b+h);
    if(end<=begin) continue;
    float3 tangent=normalize(cross(axis,abs(axis.z)<0.9 ? float3(0,0,1) : float3(0,1,0)));
    float3 bitangent=cross(axis,tangent);
    {
      // Clip the ray to an oriented box before marching. The broad sphere
      // wastes most samples on empty space and makes a narrow bent jet alias.
      float3 driftLimit=crossFlow*0.028*min(1,0.55/max(length(crossFlow)*0.028,0.0001));
      float3 extent=float3(3*radius+0.15+abs(dot(driftLimit,tangent)),
        3*radius+0.15+abs(dot(driftLimit,bitangent)),halfLength);
      if(anchored) {
        // Spend the same samples on the narrower aligned jet rather than air.
        float streamExtent=max(mouthRadius*2.05,2.85*radius+.10);
        extent.xy=lerp(extent.xy,float2(streamExtent+abs(dot(driftLimit,tangent)),
          streamExtent+abs(dot(driftLimit,bitangent))),stream);
      }
      if(!anchored) extent=float3(2*radius,2*radius,halfLength);
      float3 o=float3(dot(oc,tangent),dot(oc,bitangent),dot(oc,axis));
      float3 d=float3(dot(rd,tangent),dot(rd,bitangent),dot(rd,axis));
      if((abs(d.x)<0.00001 && abs(o.x)>extent.x) ||
         (abs(d.y)<0.00001 && abs(o.y)>extent.y) ||
         (abs(d.z)<0.00001 && abs(o.z)>extent.z)) continue;
      float3 safeD=float3(d.x>=0 ? max(d.x,0.00001) : min(d.x,-0.00001),
        d.y>=0 ? max(d.y,0.00001) : min(d.y,-0.00001),
        d.z>=0 ? max(d.z,0.00001) : min(d.z,-0.00001));
      float3 a=(-extent-o)/safeD,c=(extent-o)/safeD;
      float3 lo=min(a,c),hi=max(a,c);
      begin=max(begin,max(lo.x,max(lo.y,lo.z)));
      end=min(end,min(hi.x,min(hi.y,hi.z)));
      if(end<=begin) continue;
    }
    int samples=begin<25 ? (anchored ? 48 : 24) : 16;
    float stepSize=(end-begin)/samples;
    float densityIntegral=0;
    float3 emissionIntegral=0;
    float heat=saturate(state.x);
    float exhaustHeat=saturate(state.y);
    float coldBias=saturate((0.65-exhaustHeat)/0.65);
    float hotBias=saturate((exhaustHeat-0.65)/0.35);
    float thermalGain=1-0.28*coldBias+0.18*hotBias;
    [loop] for(int s=0;s<samples;s++)
    {
      float distance=begin+(s+0.5)*stepSize;
      float3 worldPos=eyePosWorld+rd*distance;
      // Static ground contact applies from every camera, including below the road.
      if(dot(groundData.xyz,worldPos)+groundData.w<.003) continue;
      float3 relative=worldPos-center;
      float axial=dot(relative,axis);
      float3 radial=relative-axis*axial;
      float3 localPos=radial/radius+axis*(axial/max(halfLength,0.0001));
      float edge=saturate(1-dot(localPos,localPos));
      float longitudinal=1;
      float along=0;
      float shapeNoise=0;
      float age=state.z;
      float phase=state.w;
      bool contacted=flowData.w<0;
      float turbulence=abs(flowData.w);
      float3 flow=worldPos*25+float3(phase,age*9,-age*14);
      if(anchored)
      {
        // Nozzle-local 3D coordinates: the fire moves with the exhaust, while
        // turbulent sheets advect along its axis. Perspective never rotates it.
        along=(axial/halfLength+1)*0.5;
        float u=saturate(along);
        float bend=smoothstep(0.04,0.85,u);
        float2 q=float2(dot(radial,tangent),dot(radial,bitangent));
        if(outlet==3) q*=float2(0.8,1.25);
        float3 crosswind=flowData.xyz-axis*dot(flowData.xyz,axis);
        float3 drift=crosswind*(0.028*u*u);
        drift*=min(1,0.55/max(length(drift),0.0001));
        drift+=float3(0,0,0.065*u*u);
        q-=float2(dot(drift,tangent),dot(drift,bitangent));
        float flutter=(0.25+turbulence*0.8)*(pop ? 0.65 : 1);
        flutter*=lerp(1,.22,stream);
        q-=radius*bend*float2((sin(u*10-age*32+phase)+0.35*sin(u*19-age*53+phase))*flutter,
                             (sin(u*14-age*37+phase*1.7)+0.25*sin(u*23-age*61))*flutter*0.7);
        // Slow pressure waves ride the existing fast flutter, rooted at the mouth.
        float pressure=(0.90+0.10*sin(age*31+phase+u*13))
          *(1+bend*(0.065*sin(age*9+phase-u*6)+0.025*sin(age*23+phase*1.7-u*11)));
        // The root remains narrow; the hot body opens into a broad ragged fan.
        float opening=0.88+0.20*sin(age*8-phase+u*5);
        float originalWidth=(0.40+2.45*smoothstep(0.04,0.42,u))*(1-0.55*u);
        float streamWidth=(0.40+1.02*smoothstep(0.04,0.42,u))*(1-0.73*u);
        float width=radius*lerp(originalWidth,streamWidth,stream)*pressure*lerp(1,opening,bend);
        if(pop) {
          width*=lerp(0.88,1.08,smoothstep(0.02,0.16,u))*(1-0.20*u);
          // Individual pressure tongues: narrow single jet, fork or three lobes.
          // Rotation belongs to the physical outlet basis, never the camera.
          float turn=(variant*6.2831853+0.16*sin(age*21+phase))*bend;
          float sn=sin(turn),cs=cos(turn);q=float2(cs*q.x-sn*q.y,sn*q.x+cs*q.y);
          width*=lerp(1,.88+.14*variant,bend);
        }
        if(outlet==1) width*=1-0.22*smoothstep(0.08,0.85,u);
        else if(outlet==2) width*=1+0.20*smoothstep(0.06,0.62,u);
          // Match large physical lips, merging into the existing turbulent
          // body downstream. Zero radius is exactly the old small-tip path.
          float lip=max(width,mouthRadius);
          width=lerp(lip,width,smoothstep(0.0,0.32,u));
        if(along<0 || along>1 || dot(q,q)>width*width*2.6) continue;
        flow=float3(q.x/radius*3,q.y/radius*3,u*9-age*23)+phase;
        float shape=noise3(flow*1.1);
        shapeNoise=shape;
        // Uneven tip and torn edges, rather than a smooth glowing cone.
        // Reuse the advected contour eddy for the evolving ragged tip.
        float tipNoise=saturate(shape+0.10*sin(u*17-age*11+phase));
        float tip=clamp(0.56+0.40*tipNoise+0.035*sin(age*9+phase),0.54,1.0);
        tip=lerp(tip,clamp(.72+.25*tipNoise+.025*sin(age*9+phase),.70,1.0),stream);
        longitudinal=1-smoothstep(tip-0.07,tip,u);
        // Overlapping irregular tongues form one connected 3D flame body.
        // Shape changes only: airflow, flutter and advection above are retained.
        float elliptical=dot(q,q)/(width*width);
        float twist=age*7+phase+u*11;
        float2 tongueA=q-width*bend*float2(0.66+0.15*sin(twist),0.24+0.22*cos(twist*0.83));
        float2 tongueB=q+width*bend*float2(0.40+0.20*cos(twist*0.71),0.62+0.15*sin(twist*1.13));
        float lobeA=1-dot(tongueA,tongueA)/(width*width*0.40);
        float lobeB=1-dot(tongueB,tongueB)/(width*width*0.30);
        float lobes=max(lobeA,lobeB)*smoothstep(0.15,0.55,u);
        if(pop) {
          float2 tongueC=q-width*bend*float2(-0.52+0.20*sin(twist*1.41),0.35+0.18*cos(twist));
          float lobeC=1-dot(tongueC,tongueC)/(width*width*0.18);
          lobes*=lerp(.24,1.08,smoothstep(.27,.50,variant));
          lobes=max(lobes,lobeC*smoothstep(0.18,0.60,u)*smoothstep(.66,.82,variant));
        }
        // A downstream neck separates hot tongues without cutting the mouth.
        float neck=smoothstep(0.28,0.65,u)*(0.5+0.5*sin(u*19-age*21+phase));
        float body=(1-elliptical)*(1-0.72*neck);
        if(pop) {
          // A growing, wandering central seam leaves separate axial tongues.
          // Restrict splitting downstream: the physical mouth stays connected.
          float split=smoothstep(0.18,0.52,u)*smoothstep(0.006,0.045,age);
          float2 seam=q-width*bend*float2(.16*sin(twist*.91),.12*cos(twist*1.17));
          float channel=saturate(1-dot(seam,seam)/max(width*width*.24,0.000001));
          body*=1-lerp(.35,.97,smoothstep(.25,.55,variant))*split*channel;
          lobes*=1+.12*split;
        }
        float contour=max(body,lobes);
        // A wandering axial seam separates slender tongues downstream.
        // The first centimetres and the physical outlet lip remain connected.
        float split=stream*smoothstep(.28,.64,u);
        float2 seam=q-width*bend*float2(.12*sin(twist*.91),.10*cos(twist*1.13));
        float channel=saturate(1-dot(seam,seam)/max(width*width*.13,.000001));
        contour*=1-.82*split*channel;
        edge=saturate((contour+(shape-0.5)*bend*1.95)*1.4);
      }
      else
      {
        // Every detached gas packet becomes an eroding 3D tongue.
        if(abs(axial)>halfLength) continue;
        along=saturate((axial/max(halfLength,0.0001)+1)*0.5);
        float2 q=float2(dot(radial,tangent),dot(radial,bitangent));
        if(outlet==3) q*=float2(0.8,1.25);
        // Wide, hollow-edged sheets roll open and split with packet age.
        float width=radius*(0.46+0.90*smoothstep(0,0.26,along))*(1-0.58*along);
        if(outlet==1) width*=1-0.18*along;else if(outlet==2) width*=1+0.15*along;
        float bend=smoothstep(0.08,0.80,along);
        flow=float3(q/max(radius,0.0001)*3,along*8-age*21)+phase;
        // Empty-space rejection before coherent noise; includes both lobes.
        if(dot(q,q)>4*radius*radius) continue;
        float shape=noise3(flow*1.13);
        shapeNoise=shape;
        q-=radius*bend*float2(shape-0.5,0.5*sin(along*13-age*27+phase))*0.65;
        if(pop) {
          float turn=variant*6.2831853*bend;float sn=sin(turn),cs=cos(turn);
          q=float2(cs*q.x-sn*q.y,sn*q.x+cs*q.y);
        }
        float2 a=q-width*bend*float2(0.45,0.32);
        float2 b=q+width*bend*float2(0.28,0.48);
        float hollow=smoothstep(0.055,0.17,age)*bend;
        float center=1-dot(q,q)/(width*width);
        // Older gas opens a hole inside a winding sheet, rather than retaining
        // the white circular center of an emissive billboard.
        center-=hollow*1.25*saturate(1-dot(q,q)/(width*width*0.38));
        if(pop) {
          // Sheared ribbons: an off-centre hollow rolls outward with age.
          float split=smoothstep(.018,.105,age)*smoothstep(.12,.65,along);
          float2 seam=q-width*bend*float2(.20*sin(phase+age*11),.18*cos(phase+age*13));
          center-=split*.95*saturate(1-dot(seam,seam)/max(width*width*.28,.000001));
        }
        float contour=max(center,
          max(1-dot(a,a)/(width*width*(pop ? .22 : .32)),1-dot(b,b)/(width*width*(pop ? .16 : .25)))*bend);
        edge=saturate((contour+(shape-0.5)*bend)*1.4);
        float tip=0.66+0.30*shape;
        longitudinal=(1-smoothstep(tip-0.08,tip,along))*smoothstep(0,0.10,along);
        if(abs(axial)>halfLength || edge<=0) continue;
      }
      // Empty samples contribute no density or radiance.
      if(edge<=0 || longitudinal<=0) continue;
      // Three scales remain; share the coarse contour noise with turbulence.
      float n=shapeNoise*0.57+noise3(flow*2.03)*0.29+noise3(flow*4.11)*0.14;
      float erosion=anchored ? 0 : smoothstep(0.035,0.26,age);
      float torn=smoothstep(anchored ? 0.38 : lerp(0.43,0.58,erosion),0.69,n);
      // Connected mouth, with increasingly torn sheets downstream.
      float modulation=anchored ? lerp(0.9,torn,smoothstep(0.06,0.52,along)) : torn;
      if(pop) modulation*=0.65+0.70*smoothstep(0.30,0.66,n);
      float groundFade=contacted ? smoothstep(.003,.030,dot(groundData.xyz,worldPos)+groundData.w) : 1;
      float burnout=(!anchored && pop) ? 1-smoothstep(.16,.32,age) : 1;
      float density=pow(edge,1.3)*modulation*longitudinal*groundFade*burnout;
      // Coherent pockets break the smooth core without cutting the attached base.
      float pocket=anchored ? lerp(1,0.82+0.36*smoothstep(0.30,0.70,n),smoothstep(0.06,0.36,along)) : 1;
      float core=smoothstep(0.4,0.9,saturate(edge*pocket));
      // Blue lives at the mouth, orange/yellow in the burning downstream gas.
      float rich=saturate(styleData.y);
      float blueExtent=(0.16-0.06*coldBias+0.08*hotBias)*(1-0.30*rich);
      float blue=(anchored ? 1-smoothstep(0.035,blueExtent,along) : 0)*(1-coreFade);
      float3 envelope=lerp(float3(1.1,0.065,0.008),float3(2.1,0.52,0.055),heat);
      envelope=lerp(envelope,float3(1.6,0.22,0.025),coldBias*0.55);
      envelope=lerp(envelope,float3(2.2,0.82,0.16),hotBias*0.45);
      if(styleData.x>0.5) envelope=lerp(envelope,float3(2.4,0.30,0.025),rich*0.45);
      float violet=anchored ? smoothstep(0.55,0.90,along)*(1-heat)*0.55 : (1-heat)*0.25;
      float3 emission=lerp(envelope,float3(0.60,0.18,1.8),saturate(blue+violet));
      // HDR core and cooler translucent envelope; white comes from radiance,
      // rather than painting a uniformly yellow cone.
      float hotCore=pow(core,2)*heat*(anchored ? 1-smoothstep(0.38,0.94,along) : 0.15);
      float nightCore=pow(core,3.5)*heat*(anchored ? 1-smoothstep(.30,.88,along) : .10);
      hotCore=lerp(hotCore,nightCore,saturate(vbfNight));
      if(pop) hotCore*=lerp(0.45,0.85,saturate(n))*(1-smoothstep(0.14,0.80,along));
      hotCore*=pow(1-coreFade,1.7);
      float3 coreLight=lerp(float3(6.5,5.6,4.3),float3(5.8,4.7,3.4),saturate(vbfNight));
      emission+=coreLight*hotCore*(1-0.25*coldBias+0.25*hotBias);
      float pulse=anchored ? 1+0.10*sin(age*9+phase)+0.04*sin(age*23+phase*1.7) : 1;
      if(styleData.x>2.5 && styleData.x<3.5) pulse*=1+0.18*sin(age*46+phase);
      else if(styleData.x>3.5) pulse*=1+0.12*sin(age*65+phase);
      emission*=pulse;
      densityIntegral+=density*stepSize;
      emissionIntegral+=emission*density*stepSize;
    }
    float opticalDepth=densityIntegral*(anchored ? 36 : 16)*heat;
    float3 emission=emissionIntegral/max(densityIntegral,0.00001);
    radiance+=emission*(1-exp(-opticalDepth))*heat*(anchored ? 1.35 : 0.40)*thermalGain;
  }
  // Additive emission before translucency; opaque depth clips the volume.
  // Scene-referred highlight knee keeps chromatic tongues around the hot
  // core at night. A scalar knee preserves hue; daytime emission is unchanged.
  float peak=max(radiance.x,max(radiance.y,radiance.z));
  float3 nightRadiance=radiance/(1+.09*peak);
  radiance=lerp(radiance,nightRadiance,saturate(vbfNight));
  return hdrEncode(float4(radiance*exposure,0));
}
#endif
