-- Vehicle-side bridge for native and assisted afterfire, with spatial audio.
local M = {}
local audio = require('common/vbfAudio648')
local blast = require('common/vbfBlast')
local blastState=blast.new(1)
local profile = require('common/vbfProfile657')
local shift = require('common/vbfShift')
local settings = require('common/vbfSettings').resolve()
local combustion=require('common/vbfCombustion640')
local combustionState=combustion.new()
local heat=require('common/vbfHeat647')
local thermalState=heat.new()
local character = profile.character()
local shiftState, shiftSupported = shift.new(),false
local exhaustClass, engineMaxRPM, pulseSerial = 0,8000,0
local raceParts, highLoadTime, liftSerial, holdTime, holdCooldown = 0,0,0,0,0
local preparedParts=0
local holdWindow,holdDelay,rngState=0,0,1
local engineState,holdEnergy,holdInitial=nil,0,0
local holdBoomPending=false
local nativeSounds, flameStrengths={},{}
local nativeDose={}
local function randomHold()
  rngState=(rngState*48271)%2147483647
  return rngState/2147483647
end
local ready, retry, clock = false, 0, 0
local pending, lastEmission = {}, {}
local previousThrottle, assistTime, assistCooldown, scanTime = 0, 0, 0, 0
local pipes = {}
local nativeTime = -100
local nativeAudioTime, assistPulse = -100, 0
local reportedEmission = false

local function requestRenderer()
  obj:queueGameEngineLua("extensions.load('volumetricBackfireRenderer'); if extensions.volumetricBackfireRenderer then extensions.volumetricBackfireRenderer.connect(" .. obj:getId() .. ") end")
end

function M.setInterior(value) audio.setInterior(value,obj) end

function M.setReady(value)
  if ready ~= (value == true) then log('I','volumetricBackfire','renderer ready='..tostring(value)) end
  ready = value == true
end

local function combustionAllowed(held)
  local e=electrics.values or {}
  local limiter=e.revLimiterActive==true or (type(e.revLimiterActive)=='number' and e.revLimiterActive>0)
  return combustion.allowed(combustionState,e.throttle_input or e.throttle,e.rpm,engineMaxRPM,limiter,held)
end
local function dieselOutlet(node)
  for _,engine in pairs(powertrain.getDevices() or {}) do
    if engine.type=='combustionEngine' then
      local diesel=tostring(engine.requiredEnergyType or ''):lower()=='diesel'
      for _,pipe in pairs(engine.thermals and engine.thermals.exhaustEndNodes or {}) do
        if pipe.finish==node then return diesel end
      end
    end
  end
  return engineState and tostring(engineState.requiredEnergyType or ''):lower()=='diesel' or false
end
function M.playNativeAudio(event,node,volume,pitch,color,texture,fuelRatio)
  if dieselOutlet(node) then return true end
  nativeAudioTime=clock
  nativeDose[node]={time=clock,value=math.max(0,math.min(1,((tonumber(fuelRatio) or 1)-1)/3))}
  -- The unmodified thermals sound accompanies native afterfire. ECU-owned
  -- audio is emitted by its adapter, never by this passive replacement.
  return false
end

function M.emit(finish, start, assisted, terminal)
  if dieselOutlet(finish) then return true end
  if not assisted then nativeTime = clock end
  -- Returning false keeps BeamNG's normal afterfire for an ordinary exhaust.
  if exhaustClass==0 then return false end
  if assisted or terminal then return true end -- ECU events use their own adapter
  local key = tostring(finish) .. ':' .. tostring(start)
  if clock - (lastEmission[key] or -100) < 0.035 then return ready end
  if obj:inWater(finish) then return true end
  local p = obj:getNodePosition(finish)
  local direction = p - obj:getNodePosition(start)
  if direction:length() < 0.0001 then return false end
  direction:normalize()
  p = p + obj:getPosition()
  local velocity = obj:getNodeVelocityVector(finish)
  -- Node IDs let the GE renderer anchor the base to the current physics pose.
  pulseSerial=pulseSerial+1
  local dose=nativeDose[finish]
  local energy=dose and clock-dose.time<.12 and dose.value or .35
  local strength=math.max(.12,math.min(.34,.12+.22*energy))
  local attachedDuration=0
  local wx,wy,wz=0,0,0
  if obj.getWind then
    local ok,w=pcall(obj.getWind,obj)
    if ok and w then wx,wy,wz=w.x or 0,w.y or 0,w.z or 0 end
  end
  pending[#pending + 1] = {p.x,p.y,p.z,direction.x,direction.y,direction.z,velocity.x,velocity.y,velocity.z,finish,start,strength,attachedDuration,character.duration,wx,wy,wz,terminal=='massive' and 1.65 or 1,thermalState.value}
  local emitted=pending[#pending]
  emitted[20]=0 -- native source, not an ECU pop/hold program
  emitted[14]=.7
  emitted[25],emitted[26]=0,.55 -- explicit provenance and bounded gas scale
  emitted[21],emitted[22],emitted[23]=0,0,profile.tipScale(v and v.data,finish)
  emitted[24]=profile.tipForm(v and v.data,finish)
  flameStrengths[finish]={strength=strength,time=clock}
  -- No autonomous breath/held-flame session for native afterfire.
  if not assisted then
    for _,sound in ipairs(nativeSounds) do
      if sound.node==finish then sound.flameStrength=strength end
    end
  end
  if not reportedEmission then log('I','volumetricBackfire','first exhaust event queued'); reportedEmission=true end
  lastEmission[key] = clock
  return ready
end

local function findPipes()
  pipes = {}
  raceParts=profile.raceEngineParts(v and v.data)
  preparedParts=profile.preparedEngineParts(v and v.data)
  local seen = {}
  shiftSupported=false
  local engine
  for _,device in pairs(powertrain.getDevices() or {}) do
    if shift.supports(device.type) then shiftSupported=true end
    if device.thermals then engine=device; if device.maxRPM then engineMaxRPM=device.maxRPM end end
    for _,pipe in pairs(device.thermals and device.thermals.exhaustEndNodes or {}) do
      if pipe.finish ~= nil and pipe.start ~= nil then
        local key = tostring(pipe.finish)..':'..tostring(pipe.start)
        if not seen[key] then pipes[#pipes+1]=pipe; seen[key]=true end
      end
    end
  end
  exhaustClass=profile.exhaustClass(v and v.data,pipes)
  character=profile.character(engine,raceParts)
  engineState=engine
end

local function finishFlame(node,strength)
  if dieselOutlet(node) then return end
  if exhaustClass==0 then return end
  for _,pipe in ipairs(pipes) do
    if pipe.finish==node and not obj:inWater(node) then
      local key=tostring(pipe.finish)..':'..tostring(pipe.start)
      local before=lastEmission[key]
      local massive=blast.pick(blastState,clock,holdEnergy,preparedParts>=1)
      M.emit(pipe.finish,pipe.start,true,massive and 'massive' or true)
      if lastEmission[key]~=before then
        if not ready then
          for id=61,65 do obj:addParticleByNodesRelative(pipe.finish,pipe.start,-10,id,0,1) end
        end
        audio.finish(obj,node,strength,clock,#pipes,settings.soundVolume,massive,exhaustClass)
      end
      return
    end
  end
end

local function assist(dt)
  scanTime=scanTime-dt
  if scanTime<=0 then findPipes(); scanTime=1 end
  local e=electrics.values or {}
  local throttle=tonumber(e.throttle_input) or tonumber(e.throttle) or 0
  local rpm=tonumber(e.rpm) or 0
  local revRatio=math.max(0,math.min(1,rpm/math.max(engineMaxRPM,1)))
  local flowFloor=math.max(1500,engineMaxRPM*0.22)
  local load=math.max(throttle*0.65,math.max(0,math.min(1,tonumber(engineState and engineState.engineLoad) or 0)))
  local temperature=tonumber(engineState and engineState.thermals and engineState.thermals.exhaustTemperature)
  local warmth=temperature and math.max(0,math.min(1,(temperature-40)/160)) or 1
  local wasHolding=holdTime>0
  holdCooldown=math.max(0,holdCooldown-dt)
  holdTime=math.max(0,holdTime-dt)
  holdWindow=math.max(0,holdWindow-dt)
  if throttle>0.45 and load>.55 and revRatio>0.28 then
    -- Accumulated load is a bounded residual-fuel proxy, not a fixed RPM band.
    highLoadTime=math.min(1.5,highLoadTime+dt*load*revRatio)
  elseif throttle>0.1 then highLoadTime=math.max(0,highLoadTime-dt*0.25) end
  if previousThrottle>0.1 and throttle<=0.1 and rpm>flowFloor then
    assistTime=0.28*character.duration; assistPulse=0
    if exhaustClass==2 and preparedParts>=1 and highLoadTime>=0.04 and combustionAllowed(false) then
      liftSerial=liftSerial+1
      holdEnergy=math.min(1,highLoadTime/0.4)*(0.35+0.65*warmth)
      holdWindow=1.5+holdEnergy*1.5
      holdDelay=0.025+0.07*randomHold()
    end
    highLoadTime=0
  end
  -- Stop residual combustion on throttle reapplication or insufficient flow.
  if throttle>0.2 or rpm<flowFloor or exhaustClass~=2 or preparedParts<1 then
    holdTime,holdWindow=0,0
    if wasHolding then assistTime=0 end
  end
  -- Heat, preceding load and preparation govern overrun ignition and duration.
  if holdWindow>0 and holdTime<=0 and holdCooldown<=0 then
    holdDelay=holdDelay-dt
    if holdDelay<=0 then
      if randomHold()<(0.35+0.6*holdEnergy) then
        local prep=math.min(4,raceParts+preparedParts*0.25)
        holdTime=math.min(1.8,(0.2+holdEnergy*0.95)*(1+prep*0.12)*(0.8+0.4*randomHold()))
        holdInitial=holdTime
        holdWindow=0
        holdCooldown=holdTime+0.65+1.6*randomHold()
        assistTime=math.max(assistTime,holdTime)
        assistPulse=0
        holdBoomPending=true
      else holdDelay=0.07+0.15*randomHold() end
    end
  end
  previousThrottle=throttle
  assistCooldown=math.max(0,assistCooldown-dt)
  if shift.update(shiftState,dt,e,shiftSupported,exhaustClass>0,engineMaxRPM,
    clock-nativeTime,clock-nativeAudioTime) then
    -- One short source/audio pulse, without starting a lift/hold timer.
    for _,pipe in ipairs(pipes) do
      if not obj:inWater(pipe.finish) then
        local key=tostring(pipe.finish)..':'..tostring(pipe.start)
        local before=lastEmission[key]
        M.emit(pipe.finish,pipe.start,true)
        if lastEmission[key]~=before then audio.assisted(obj,pipe,rpm,true,#pipes,'shift',character,settings.soundVolume,flameStrengths[pipe.finish].strength,clock) end
      end
    end
    assistCooldown=math.max(assistCooldown,0.13)
  end
  local limiter=e.revLimiterActive==true or (type(e.revLimiterActive)=='number' and e.revLimiterActive>0)
  if exhaustClass>0 and (assistTime>0 or limiter) and rpm>2000
    and (holdTime>0 or (clock-nativeTime>0.15 and clock-nativeAudioTime>0.18)) and assistCooldown<=0 then
    assistPulse=assistPulse+1
    local boom=holdTime>0 and holdBoomPending
    local audibleBoom=false
    for _,pipe in ipairs(pipes) do
      if not obj:inWater(pipe.finish) then
        local emittedBefore=lastEmission[tostring(pipe.finish)..':'..tostring(pipe.start)]
        if not M.emit(pipe.finish,pipe.start,true) then
          for id=61,65 do obj:addParticleByNodesRelative(pipe.finish,pipe.start,-10,id,0,1) end
        end
        -- Audio is tied to an accepted flame event, never a separate timer.
        local emittedAfter=lastEmission[tostring(pipe.finish)..':'..tostring(pipe.start)]
        if emittedAfter~=emittedBefore and clock-nativeAudioTime>0.18 then
          local mode=holdTime>0 and (boom and 'detonation' or 'hold') or 'lift'
          local played=audio.assisted(obj,pipe,rpm,boom or assistPulse==1,#pipes,mode,character,settings.soundVolume,flameStrengths[pipe.finish].strength,clock)
          if boom and played~=false then audibleBoom=true end
        end
      end
    end
    if audibleBoom then holdBoomPending=false end
    assistCooldown=(holdTime>0 and 0.075 or 0.095)+0.05*(0.5+0.5*math.sin(assistPulse*2.399963))
  end
  assistTime=math.max(0,assistTime-dt)
end

local function init()
  if audio.reset then audio.reset() end
  rawset(_G, 'volumetricBackfireBridge', M)
  ready, retry, clock = false, 0, 0
  pending, lastEmission = {}, {}
  exhaustClass,engineMaxRPM,pulseSerial=0,8000,0
  raceParts,highLoadTime,liftSerial,holdTime,holdCooldown=0,0,0,0,0
  preparedParts=0
  holdWindow,holdDelay=0,0
  holdEnergy,holdInitial=0,0
  holdBoomPending=false; nativeSounds={}; flameStrengths={};nativeDose={}
  combustionState=combustion.new()
  thermalState=heat.new()
  blastState=blast.new((obj:getId() or 1)*131+41)
  rngState=((obj:getId() or 1)*7919+17)%2147483646+1
  shiftState,shiftSupported=shift.new(),false
  previousThrottle, assistTime, assistCooldown, scanTime = 0,0,0,0
  nativeTime=-100; nativeAudioTime=-100; assistPulse=0; reportedEmission=false
  log('I','volumetricBackfire','vehicle bridge 6.62 passive native afterfire; ECU controls injected flames')
  requestRenderer()
  findPipes()
end

function M.updateGFX(dt)
  heat.update(thermalState,dt,engineState and engineState.thermals and engineState.thermals.exhaustTemperature)
  local e=electrics.values or {}
  local throttle=tonumber(e.throttle_input) or tonumber(e.throttle) or 0
  local load=math.max(throttle*.65,math.max(0,math.min(1,tonumber(engineState and engineState.engineLoad) or 0)))
  combustion.update(combustionState,dt,throttle,load,e.rpm,engineMaxRPM)
  clock = clock + math.max(dt, 0)
  for _,sound in ipairs(nativeSounds) do
    if sound.flameStrength then
      audio.flame(obj,sound.event,sound.node,sound.volume*settings.soundVolume,
        sound.pitch,sound.color,sound.texture,sound.flameStrength,sound.rpm,clock,#pipes,settings.soundVolume)
    else
      audio.play(obj,sound.event,sound.node,sound.volume*settings.soundVolume,
        sound.pitch,sound.color,sound.texture,sound.strength,sound.rpm)
    end
  end
  nativeSounds={}
  scanTime=scanTime-math.max(dt,0)
  if scanTime<=0 then findPipes();scanTime=1 end
  -- Passive native replacement: no generated lift/limiter/shift events,
  -- held flame timers or terminal explosions without an ECU command.
  retry = retry - dt
  if retry <= 0 then requestRenderer(); retry = 2 end
  if #pending > 0 then
    obj:queueGameEngineLua('if extensions.volumetricBackfireRenderer then extensions.volumetricBackfireRenderer.burst(' .. obj:getId() .. ',' .. serialize(pending) .. ') end')
    pending = {}
  end
end

function M.onExtensionUnloaded()
  rawset(_G, 'volumetricBackfireBridge', nil)
  obj:queueGameEngineLua('if extensions.volumetricBackfireRenderer then extensions.volumetricBackfireRenderer.removeVehicle(' .. obj:getId() .. ') end')
end
M.onExtensionLoaded = init
M.onReset = init
return M
