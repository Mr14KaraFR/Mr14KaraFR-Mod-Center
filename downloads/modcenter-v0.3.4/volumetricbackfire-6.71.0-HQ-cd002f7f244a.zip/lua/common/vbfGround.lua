-- Local static-ground contact for reduced flame parcels. No rigid-body bounce.
local M={}
local function finite(x) return type(x)=='number' and x==x and math.abs(x)<1e8 end
function M.sample(cast,vector,x,y,z)
  if type(cast)~='function' then return nil end
  local function height(px,py)
    local top=z+.3;local reach=3.3
    local ok,d=pcall(cast,vector(px,py,top),vector(0,0,-1),reach)
    if not ok or not finite(d) or d<0 or d>=reach-.001 then return nil end
    return top-d
  end
  local h=height(x,y);if not h then return nil end
  local hx,hy=height(x+.25,y),height(x,y+.25)
  local nx,ny=-(hx and (hx-h)/.25 or 0),-(hy and (hy-h)/.25 or 0)
  local norm=math.sqrt(nx*nx+ny*ny+1)
  -- Discontinuous ledges are not extrapolated as an extremely steep ramp.
  if norm>2.8 then nx,ny,norm=0,0,1 end
  nx,ny=nx/norm,ny/norm
  local nz=1/norm
  return {nx,ny,nz,-nx*x-ny*y-nz*h,x=x,y=y,height=h}
end
function M.new(cast,vector)
  local cache,clock,used={},0,0
  local api={}
  function api.beginFrame(dt)
    clock=clock+math.max(0,dt or 0);used=0
    -- Spatial cells survive only briefly and are bounded under fast driving.
    local count=0
    for key,e in pairs(cache) do if clock-e.time>.5 then cache[key]=nil else count=count+1 end end
    if count>256 then cache={} end
  end
  function api.query(x,y,z,previous)
    -- Start above the last known surface even after a fast downward step.
    -- This avoids casting from inside the ground and missing the top face.
    if previous and previous[3]>.35 then
      z=math.max(z,-(previous[1]*x+previous[2]*y+previous[4])/previous[3]+.05)
    end
    local key=math.floor(x/.5)..':'..math.floor(y/.5)..':'..math.floor(z)
    local e=cache[key]
    if e and clock-e.time<.12 then return e.plane end
    if used>=6 then
      if previous and (x-previous.x)^2+(y-previous.y)^2<.36 then return previous end
      return e and e.plane or nil
    end
    used=used+1
    local plane=M.sample(cast,vector,x,y,z)
    cache[key]={plane=plane,time=clock}
    return plane
  end
  function api.count() return used end
  return api
end
local function distance(p,g) return p.x*g[1]+p.y*g[2]+p.z*g[3]+g[4] end
function M.root(p,pose,g)
  p.ground=g;p.contactDistance=nil
  if not g then return end
  local mouth=pose[1]*g[1]+pose[2]*g[2]+pose[3]*g[3]+g[4]
  local toward=p.dx*g[1]+p.dy*g[2]+p.dz*g[3]
  if toward<-.025 and mouth>=0 then
    local contact=math.max(0,(mouth-.006)/-toward)
    if contact<p.halfLength*2 then
      p.contactDistance=contact
      p.halfLength=math.max(.001,contact*.5)
      p.x=pose[1]+p.dx*p.halfLength;p.y=pose[2]+p.dy*p.halfLength;p.z=pose[3]+p.dz*p.halfLength
    end
  end
end
function M.spawn(p,pose,root,along)
  local g=root.ground
  if not g or not root.contactDistance then return end
  -- Keep the parcel at the nozzle: it must travel to the floor first.
  -- Teleporting every parcel to the impact made an artificial glowing patch.
  p.ground=g
  p.contactPhase=(p.seed or 0)+(root.noiseAge or root.age or 0)*37
  M.constrain(p,g,0)

end
function M.constrain(p,g,dt,force)
  p.ground=g
  if not g then return false end
  local ax=p.dx*g[1]+p.dy*g[2]+p.dz*g[3]
  local support=math.sqrt(math.max(0,p.radius*p.radius+(p.halfLength*p.halfLength-p.radius*p.radius)*ax*ax))
  local gap=distance(p,g)-support-.006
  if gap>=0 and not force then return false end
  -- Project flow into the surface: spread and cool, do not reflect like a ball.
  local vn=p.vx*g[1]+p.vy*g[2]+p.vz*g[3]
  if vn<0 then p.vx=p.vx-vn*g[1];p.vy=p.vy-vn*g[2];p.vz=p.vz-vn*g[3] end
  if not p.contacted then
    local tx,ty,tz=p.dx-ax*g[1],p.dy-ax*g[2],p.dz-ax*g[3]
    local len=math.sqrt(tx*tx+ty*ty+tz*tz)
    local phase=p.contactPhase or ((p.seed or 0)+(p.age or 0)*37)
    if len<.001 then
      tx,ty,tz=math.cos(phase),math.sin(phase),0
      local dot=tx*g[1]+ty*g[2];tx,ty,tz=tx-dot*g[1],ty-dot*g[2],-dot*g[3]
      len=math.sqrt(tx*tx+ty*ty+tz*tz)
    end
    tx,ty,tz=tx/len,ty/len,tz/len
    local bx,by,bz=g[2]*tz-g[3]*ty,g[3]*tx-g[1]*tz,g[1]*ty-g[2]*tx
    local yaw=.55*math.sin(phase*1.31)
    tx,ty,tz=tx*math.cos(yaw)+bx*math.sin(yaw),ty*math.cos(yaw)+by*math.sin(yaw),tz*math.cos(yaw)+bz*math.sin(yaw)
    -- Convert incoming jet momentum into a wall jet, with a hot rising edge.
    -- This is entrainment/thermal lift, not elastic reflection of the jet.
    local spread=.85+math.min(2,math.max(0,-vn)*.28)
    p.vx=p.vx+tx*spread;p.vy=p.vy+ty*spread;p.vz=p.vz+tz*spread
    local rise=(.9+.5*(.5+.5*math.sin(phase*1.7)))*math.max(.3,p.heat)
    p.vx=p.vx+g[1]*rise;p.vy=p.vy+g[2]*rise;p.vz=p.vz+g[3]*rise
    p.radius=math.max(p.radius,.042+.014*(.5+.5*math.sin(phase)))
    -- Gas contacting the surface must not keep the source's shared phase.
    -- Independent contact eddies break the coherent thin orange filament.
    p.seed=(p.seed or 0)+phase*.37
    local sideways=.55*math.sin(phase*1.73)
    p.vx=p.vx+bx*sideways;p.vy=p.vy+by*sideways;p.vz=p.vz+bz*sideways
    local tilt=.35+.25*(.5+.5*math.cos(phase*1.3))
    local norm=math.sqrt(1+tilt*tilt)
    p.dx,p.dy,p.dz=(tx+g[1]*tilt)/norm,(ty+g[2]*tilt)/norm,(tz+g[3]*tilt)/norm
  end
  -- Reorient first, then compute the ellipsoid clearance in its new direction.
  local newAxis=p.dx*g[1]+p.dy*g[2]+p.dz*g[3]
  support=math.sqrt(math.max(0,p.radius*p.radius+(p.halfLength*p.halfLength-p.radius*p.radius)*newAxis*newAxis))
  local lift=math.max(0,support+.006-distance(p,g))
  p.x=p.x+g[1]*lift;p.y=p.y+g[2]*lift;p.z=p.z+g[3]*lift
  p.heat=p.heat*math.exp(-2.5*math.max(0,dt or 0))
  p.contacted=true
  return true
end
return M
