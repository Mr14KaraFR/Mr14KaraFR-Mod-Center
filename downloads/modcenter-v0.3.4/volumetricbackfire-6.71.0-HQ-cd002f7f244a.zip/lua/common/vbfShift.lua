-- Discrete drive-gear changes; no fake shifts from selector changes or CVTs.
local M={}
function M.supports(kind)
  return kind=='automaticGearbox' or kind=='dctGearbox' or kind=='sequentialGearbox'
end
function M.new() return {gear=nil,rpm=0,throttle=0,cooldown=0,pending=nil} end
function M.update(s,dt,e,supported,eligible,maxRPM,nativeAge,audioAge)
  local gear=tonumber(e.gearIndex)
  local rpm=tonumber(e.rpm) or 0
  local throttle=tonumber(e.throttle_input) or tonumber(e.throttle) or 0
  s.cooldown=math.max(0,s.cooldown-dt)
  if not supported or not eligible then s.pending=nil end
  if supported and eligible and gear and s.gear and gear>0 and s.gear>0
    and gear~=s.gear and s.cooldown<=0
    and math.max(throttle,s.throttle)>0.45
    and math.max(rpm,s.rpm)>math.max(2500,(maxRPM or 8000)*0.5) then
    s.pending={age=0}
  end
  s.gear,s.rpm,s.throttle=gear,rpm,throttle
  if not s.pending then return false end
  if not gear or gear<=0 or rpm<2000 then s.pending=nil; return false end
  local p=s.pending
  p.age=p.age+dt
  local shifting=e.isShifting==true or (type(e.isShifting)=='number' and e.isShifting>0)
  if p.age>=0.06 and not shifting then
    s.pending=nil
    s.cooldown=0.35
    -- Let the native engine's ignition-cut pulse and sound take precedence.
    return nativeAge>0.18 and audioAge>0.18
  end
  if p.age>0.3 then s.pending=nil end
  return false
end
return M
