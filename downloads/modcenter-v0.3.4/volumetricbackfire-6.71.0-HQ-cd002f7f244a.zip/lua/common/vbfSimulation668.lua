-- Physical trajectories and wake burnout stay in the approved 6.65 solver.
local base=require('common/vbfSimulation665')
local M={new=base.new}
function M.step(p,dt,wx,wy,wz)
 local alive=base.step(p,dt,wx,wy,wz)
 local t=math.max(0,math.min(1,((p.age or 0)-.018)/.077))
 p.coreFade=t*t*(3-2*t)
 return alive
end
return M
