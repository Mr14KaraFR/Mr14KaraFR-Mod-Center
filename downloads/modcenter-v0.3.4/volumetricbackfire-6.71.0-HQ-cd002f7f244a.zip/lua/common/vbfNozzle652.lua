-- Reads the actual exhaust node pose every render frame (also when paused).
local M={}
function M.pose(vehicle,finish,start)
  local p=vehicle:getNodePosition(finish)
  local d=p-vehicle:getNodePosition(start)
  if d:length()<0.0001 then return nil end
  d:normalize()
  p=p+vehicle:getPosition()
  return {p.x,p.y,p.z,d.x,d.y,d.z}
end
-- Smooth seeded noise: no frame-dependent random calls and no repeating sine envelope.
local function noise(t,seed)
  local i=math.floor(t);local f=t-i;f=f*f*(3-2*f)
  local function value(n) local v=math.sin(n*127.1+seed*311.7)*43758.5453;return v-math.floor(v) end
  return value(i)*(1-f)+value(i+1)*f
end
function M.anchor(p,pose,remaining)
  p.dx,p.dy,p.dz=pose[4],pose[5],pose[6]
  local strength=p.strength or 1
  -- Continuous pressure jet; avoid stitching the main flame from round puffs.
  local age,seed=p.noiseAge or p.age or 0,p.seed or 0
  -- Unequal frequencies modulate pressure/width/brightness during a held jet.
  -- The mouth stays fixed; only the downstream volume expands and contracts.
  local pressure=noise(age*9,seed)*.65+noise(age*23,seed+17)*.35
  local flicker=.55+.43*pressure+.08*math.sin(age*19+seed)
  local dot=(p.wx or 0)*p.dx+(p.wy or 0)*p.dy+(p.wz or 0)*p.dz
  local cross=math.sqrt(math.max(0,(p.wx or 0)^2+(p.wy or 0)^2+(p.wz or 0)^2-dot*dot))
  -- Transverse air compresses the upright jet; the shader bends its downstream
  -- gas while the first centimetres still follow the physical outlet axis.
  -- Preserve a substantial 3D body even in strong crossflow.
  local flatten=math.max(.60,1/(1+cross*.010))
  local axialFlow=math.max(.75,math.min(1.40,1+dot*.006))
  p.halfLength=(0.12+0.46*strength*strength)*flicker*flatten*axialFlow
  -- The upstream cap is exactly the engine's exhaust finish node.
  p.x=pose[1]+p.dx*p.halfLength
  p.y=pose[2]+p.dy*p.halfLength
  p.z=pose[3]+p.dz*p.halfLength
  p.radius=(0.030+0.060*strength)*(.75+.25*noise(age*15,seed+31))
  local boost=math.max(1,math.min(1.65,p.visualBoost or 1))
  p.radius=p.radius*boost*math.max(.65,math.min(1.45,p.outletScale or 1))
  p.halfLength=p.halfLength*(1+.4*(boost-1))
  local style=p.ecuStyle or 0
  local lengthScale=style==1 and (.90*(.80+.32*math.min(1,(p.popAge or 0)/.025))) or style==3 and .82 or style==4 and 1.12 or 1
  local widthScale=style==1 and .86 or style==3 and 1.20 or style==4 and .86 or 1
  p.halfLength=p.halfLength*lengthScale;p.radius=p.radius*widthScale
  p.x=pose[1]+p.dx*p.halfLength;p.y=pose[2]+p.dy*p.halfLength;p.z=pose[3]+p.dz*p.halfLength
  p.heat=(0.80+0.12*strength)*(.85+.15*noise(age*19,seed+53))*math.min(1,math.max(0,remaining)/0.035)
  p.fuel=0.95
  p.anchored=true
end
return M
