-- Bounded pool of actual scene lights; simulation pause freezes flicker too.
local M={}
function M.new(create,vector)
  local pool,disabled={},false
  local api={}
  function api.clear()
    for _,light in ipairs(pool) do pcall(function() light:delete() end) end
    pool={}
  end
  function api.update(roots,camera)
    if disabled then return end
    local near={}
    for _,p in ipairs(roots) do
      local x,y,z=p.x-camera.x,p.y-camera.y,p.z-camera.z
      if x*x+y*y+z*z<1600 and p.heat>0 then near[#near+1]=p end
    end
    table.sort(near,function(a,b)
      local function d(p) return (p.x-camera.x)^2+(p.y-camera.y)^2+(p.z-camera.z)^2 end
      return d(a)<d(b)
    end)
    local ok,err=pcall(function()
      for i=1,math.min(8,#near) do
        local p=near[i]
        local l=pool[i]
        if not l then
          l=create('PointLight'); pool[i]=l
          l.canSave=false; l.castShadows=true
          -- Let opaque body panels block the fire illumination at night.
          -- Use engine shadow maps; do not dim or recolour the flame lights.
          l:setField('castShadows',0,'true')
          l:setField('texSize',0,'1024')
          l:setField('color',0,'1 0.32 0.09 1')
          l:registerObject('VBFExhaustLight'..i)
        end
        local s=p.strength or 1
        local flicker=0.86+0.14*math.sin(p.age*61+p.seed)
        l.radius=1.4+2.4*s
        l.intensity=(180+2100*s*s)*p.heat*flicker
        l.isEnabled=true
        -- A few centimetres outside the mouth, not inside the vehicle body.
        local offset=p.halfLength*0.7
        l:setPosition(vector(p.x-p.dx*offset,p.y-p.dy*offset,p.z-p.dz*offset))
        l:postApply()
      end
      for i=math.min(8,#near)+1,#pool do pool[i].isEnabled=false; pool[i]:postApply() end
    end)
    if not ok then api.clear(); disabled=true; return false,tostring(err) end
    return true
  end
  return api
end
return M
