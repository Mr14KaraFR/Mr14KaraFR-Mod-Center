-- Preserve approved long-jet geometry; individual short pops vary downstream.
local base=require('common/vbfNozzle664')
local M={pose=base.pose}
local function smooth(a,b,x)local t=math.max(0,math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)end
local function pick(seed,salt)local n=math.sin(seed*127.1+salt*311.7)*43758.5453;return n-math.floor(n)end
function M.anchor(p,pose,remaining)
 base.anchor(p,pose,remaining)
 if p.popVariant then
  local seed=p.seed or 0
  local develop=smooth(0,.035,p.popAge or 0)
  local length=.86+.30*pick(seed,3)
  -- Keep average body volume near the original and retain the full mouth.
  p.halfLength=p.halfLength*(1+(length-1)*develop)
  p.radius=p.radius*(1+((length^(-.5))-1)*develop)
  p.x=pose[1]+p.dx*p.halfLength;p.y=pose[2]+p.dy*p.halfLength;p.z=pose[3]+p.dz*p.halfLength
 end
 -- White core quenches before the last gas; no extension of luminous lifetime.
 local start=math.min(.065,(p.lifeSpan or .10)*.8)
 p.coreFade=1-smooth(.004,start,math.max(0,remaining))
end
return M
