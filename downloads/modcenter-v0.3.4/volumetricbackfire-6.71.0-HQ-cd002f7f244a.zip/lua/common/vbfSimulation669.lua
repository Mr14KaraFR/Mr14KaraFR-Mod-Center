local base=require('common/vbfSimulation668');local M={new=base.new}
local function smooth(a,b,x)local t=math.max(0,math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)end
function M.step(p,dt,wx,wy,wz)
 local alive=base.step(p,dt,wx,wy,wz)
 if not p.hood then return alive end
 -- Same physical advection; exposed gas keeps a narrow, rolling 3D volume.
 local stretch=1.20+.45*math.min(1,(p.speed or 0)/45)*smooth(.012,.08,p.age)
 p.halfLength=p.halfLength*stretch;p.renderRadius=p.renderRadius/math.sqrt(stretch)
 local flow=math.min(1,(p.speed or 0)/55)
 local fade=1-smooth(.085-.025*flow,.235-.055*flow,p.age)
 local t=p.travelAge or p.age
 local x=p.x-(p.originX or p.x)-p.sourceVx*t
 local y=p.y-(p.originY or p.y)-p.sourceVy*t
 local z=p.z-(p.originZ or p.z)-p.sourceVz*t
 local distance=math.sqrt(x*x+y*y+z*z)
 p.visibility=fade*(1-smooth(.55,1.05,distance))
 if p.nativeAfterfire then p.visibility=math.min(p.visibility,1-smooth(.06,.14,p.age))end
 p.renderHeat=p.heat*p.visibility
 return p.visibility>.001 and p.age<(p.nativeAfterfire and .14 or .26)and p.heat>.055
end
return M
