-- Reduced Lagrangian combustion model, SI seconds/metres.
-- Fuel burn, heat loss, entrainment, buoyancy and deterministic turbulence.
-- Not a pressure-grid/Navier-Stokes solver. Independent of BeamNG APIs.
local M = {}
function M.new(x,y,z,dx,dy,dz,vx,vy,vz,seed,strength)
  strength=math.max(0.2,math.min(1,strength or 1))
  local jet=4.2*(0.75+0.25*strength)
  local speed=math.sqrt(vx*vx+vy*vy)
  return {x=x,y=y,z=z,vx=vx+dx*jet,vy=vy+dy*jet,vz=vz+dz*jet,
    dx=dx,dy=dy,dz=dz,halfLength=0.045+0.012*strength,strength=strength,
    sourceVx=vx,sourceVy=vy,sourceVz=vz,speed=speed,hoodWake=math.abs(dz)>.6 and speed>10,
    age=0,fuel=1,heat=0.72+0.18*strength,radius=0.02+0.008*strength,seed=seed}
end
local function smoothNoise(t,seed)
 local i=math.floor(t);local f=t-i;f=f*f*(3-2*f)
 local function value(n)local v=math.sin(n*127.1+seed*311.7)*43758.5453;return (v-math.floor(v))*2-1 end
 return value(i)*(1-f)+value(i+1)*f
end
function M.step(p,dt,wx,wy,wz)
  wx,wy,wz=wx or 0,wy or 0,wz or 0
  p.speed=math.sqrt((p.sourceVx-wx)^2+(p.sourceVy-wy)^2+(p.sourceVz-wz)^2)
  p.age = p.age + dt
  local burn = p.fuel * (1 - math.exp(-18*dt))
  p.fuel = p.fuel - burn
  -- Forced convection cools a high-speed wake faster than a stationary plume.
  p.heat = math.min(1,(p.heat + burn*0.7) * math.exp(-((p.hoodWake and 5.5 or 7)+math.min(p.speed,90)*0.06)*dt))
  local t = p.age*31 + p.seed
  -- Entraining stationary ambient air makes the gas trail behind a moving car.
  -- More entrainment at higher road speed; the nozzle itself stays attached.
  local drag = math.exp(-(1.5+math.min(p.speed,90)*0.11)*dt)
  -- Keep the first few centimetres laminar; turbulence grows downstream.
  local mix=math.min(1,p.age/0.09)
  local gust=2+math.min(p.speed,90)*0.12
  local gx,gy=math.sin(t*1.13),math.cos(t*0.91)
  if p.ecuStyle==1 then
    gx=smoothNoise(p.age*19,p.seed);gy=smoothNoise(p.age*23,p.seed+17)
  end
  p.vx = wx+(p.vx-wx)*drag + gx*gust*mix*dt
  p.vy = wy+(p.vy-wy)*drag + gy*gust*mix*dt
  -- Separate vehicle vertical motion from hot-gas motion. No downward gravity
  -- term: buoyancy plus bounded turbulence cannot pull a horizontal jet down.
  local lift=p.heat*(p.contacted and 5 or 3)*(1+0.35*math.sin(t*0.73)*mix)
  local relativeVz=(p.vz-p.sourceVz-wz)*math.exp(-(p.contacted and 2.2 or 6)*dt)+wz+lift*dt
  p.vz=p.sourceVz+relativeVz
  p.x,p.y,p.z = p.x+p.vx*dt,p.y+p.vy*dt,p.z+p.vz*dt
  -- Mixing grows a narrow packet into a visibly open tongue downstream.
  -- Initial mouth radius is unchanged; later gas spreads rather than forming
  -- tiny bright dots. Retain faster high-speed cooling and bounded lifetime.
  local opening=math.min(1,math.max(0,(p.age-.018)/.12))
  opening=opening*opening*(3-2*opening)
  local expansion=(0.10+0.46*opening)*(0.55+0.45*p.heat)
  p.radius=math.min(p.hoodWake and .145 or .12,p.radius+expansion*dt)
  -- Orient detached volumes along the actual wake, rather than the old pipe
  -- axis. Include vertical vehicle velocity so climbs/jumps do not tilt them.
  local rx,ry,rz=p.vx-p.sourceVx,p.vy-p.sourceVy,relativeVz
  local length=math.sqrt(rx*rx+ry*ry+rz*rz)
  if length>0.001 then p.dx,p.dy,p.dz=rx/length,ry/length,rz/length end
  -- A tight young tongue opens into rolling sheets, conserving gas volume.
  local stretch=1.65+math.min(length,35)*0.045
  local roll=math.min(1,math.max(0,(p.age-.025)/.14))
  roll=roll*roll*(3-2*roll)
  local young=2.75+0.30*smoothNoise(p.age*13,p.seed+31)
  local mature=1.48+0.24*smoothNoise(p.age*17,p.seed+47)
  local aspect=young*(1-roll)+mature*roll
  local width=p.radius*(stretch/aspect)^(1/3)
  p.renderRadius=width
  p.halfLength=width*aspect
  return p.age < (p.hoodWake and .40 or .32) and p.heat > 0.055
end
return M
