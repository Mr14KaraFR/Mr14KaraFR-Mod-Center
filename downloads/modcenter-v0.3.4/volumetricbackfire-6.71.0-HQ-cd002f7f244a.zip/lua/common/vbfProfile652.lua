-- Uses the mounted JBeam parts, not a loudness threshold or the car's trim name.
local M={}
-- Verified vanilla free-flow side outlets; also works with localized labels.
local freeOutlets={bluebuck_exhaust_i6_side=true,bluebuck_exhaust_v8_side=true,
  fullsize_exhaust_limo_side=true,fullsize_exhaust_side=true,
  moonhawk_exhaust_v8_side=true,racetruck_v8_exhaust=true}
local function text(value)
  if type(value)=='string' then return value:lower() end
  if type(value)~='table' then return '' end
  local out={}; for _,v in pairs(value) do out[#out+1]=text(v) end
  return table.concat(out,' ')
end
function M.exhaustClass(data,pipes)
  local result=0
  local hasExhaust,hasTurbo=false,false
  for _,name in pairs(data and data.activeParts or {}) do
    local part=data.activePartsData and data.activePartsData[name] or {}
    local slot=text(part.slotType)
    local id=text(name)
    local label=text(part.information and part.information.name)
    local identity=id..' '..label
    if id:find('turbo',1,true) and (slot:find('intake',1,true) or slot:find('turbo',1,true)) then hasTurbo=true end
    local exhaust=slot:find('exhaust',1,true) or slot:find('muffler',1,true)
      or id:find('exhaust',1,true) or id:find('muffler',1,true)
    local cosmetic=slot:find('tip',1,true) or id:find('exhausttip',1,true)
    if exhaust and not cosmetic then
      hasExhaust=true
      if identity:find('race',1,true) or identity:find('racing',1,true) then result=2
      elseif identity:find('sport',1,true) or identity:find('performance',1,true) or identity:find('adjustable',1,true) or identity:find('reglable',1,true) or identity:find('réglable',1,true) then result=math.max(result,1) end
    end
    local outlet=exhaust or slot:find('header',1,true) or slot:find('downpipe',1,true)
    -- Explicit free-flow outlets; cosmetic straight-cut tips and short stock
    -- mufflers are not an open exhaust. Direction comes from the actual nodes.
    local words=identity:gsub('[_%-]',' ')
    local freeFlow=freeOutlets[id]==true
    for _,tag in ipairs({'straight pipe','straightpipe','full tube','fulltube',
      'side pipe','sidepipe','side exhaust','side exit','sideexit','lateral exhaust',
      'open exhaust','open header','zoomie','unmuffled','muffler delete','mufflerdelete',
      'no muffler','short exhaust','short pipe','exhaust cutout'}) do
      if words:find(tag,1,true) then freeFlow=true;break end
    end
    if outlet and not cosmetic and (freeFlow or id:find('straight',1,true)) then result=2 end
    if outlet and not cosmetic and (identity:find('hood exit',1,true) or identity:find('hoodexit',1,true)
      or identity:find('hood_exit',1,true) or label=='turbo exhaust'
      or id=='autobello_exhaust_turbo' or identity:find('stinger',1,true)) then result=2 end
  end
  -- With the downstream pipe removed, BeamNG exposes the turbine outlet itself.
  -- Do not treat a broken ordinary exhaust or an intake upgrade as an open turbo.
  if not hasExhaust and hasTurbo then
    for _,pipe in ipairs(pipes or {}) do
      local node=data and data.nodes and data.nodes[pipe.finish]
      local id=text(node and (node.name or node.id))
      if id:find('trb',1,true)==1 or id:find('turbo',1,true)==1 then result=2 end
    end
  end
  return result
end
function M.character(engine,raceParts)
  engine=engine or {}
  local prep=math.max(0,math.min(4,raceParts or 0))
  local boosted=(engine.turbocharger and engine.turbocharger.isExisting==true)
    or (engine.supercharger and engine.supercharger.isExisting==true)
  local revs=math.max(0,math.min(1,((engine.maxRPM or 8000)-5500)/4500))
  return {gain=math.min(1.15,0.76+prep*0.065+(boosted and 0.09 or 0)+revs*0.07),
    duration=math.min(1.25,0.78+prep*0.085+(boosted and 0.09 or 0)),
    tone=1.02-revs*0.025-prep*0.012-(boosted and 0.018 or 0)}
end
function M.strength(rpm,maxRPM,class,serial,assisted,character)
  local ratio=math.max(0,math.min(1,(tonumber(rpm) or 0)/math.max(1,maxRPM or 8000)))
  local variation=0.88+0.12*(0.5+0.5*math.sin(serial*2.399963))
  local base=(class==2 and 0.38 or 0.28)+ratio*0.56
  return math.max(0.2,math.min(1,base*variation*(assisted and 0.85 or 1)*(character and character.gain or 1)))
end
function M.raceEngineParts(data)
  local count,seen=0,{}
  for _,name in pairs(data and data.activeParts or {}) do
    local part=data.activePartsData and data.activePartsData[name] or {}
    local slot=text(part.slotType)..' '..text(name)
    local identity=text(name)..' '..text(part.information and part.information.name)
    local engine=slot:find('ecu',1,true) or slot:find('intake',1,true)
      or slot:find('internals',1,true) or slot:find('longblock',1,true)
      or slot:find('turbo',1,true) or slot:find('supercharg',1,true)
    local race=identity:find('race',1,true) or identity:find('racing',1,true)
      or identity:find('stage 3',1,true) or identity:find('stage3',1,true)
    local exhaust=slot:find('exhaust',1,true) or slot:find('muffler',1,true)
    if engine and race and not exhaust and not seen[name] then
      seen[name]=true; count=count+1
    end
  end
  return count
end
function M.preparedEngineParts(data)
  local count,seen=0,{}
  for _,name in pairs(data and data.activeParts or {}) do
    local part=data.activePartsData and data.activePartsData[name] or {}
    local slot=text(part.slotType)..' '..text(name)
    local identity=text(name)..' '..text(part.information and part.information.name)
    local engine=slot:find('ecu',1,true) or slot:find('intake',1,true)
      or slot:find('internals',1,true) or slot:find('longblock',1,true)
      or slot:find('turbo',1,true) or slot:find('supercharg',1,true)
    local prepared=identity:find('race',1,true) or identity:find('racing',1,true)
      or identity:find('sport',1,true) or identity:find('performance',1,true)
      or identity:find('stage',1,true) or identity:find('adjustable',1,true)
    local exhaust=slot:find('exhaust',1,true) or slot:find('muffler',1,true)
    if engine and prepared and not exhaust and not seen[name] then seen[name]=true; count=count+1 end
  end
  return count
end
-- Diameter is optional: never infer an extra physical outlet from a cosmetic mesh.
function M.tipScale(data,finish)
 local function diameter(value)
  value=tonumber(value)
  if not value or value~=value then return nil end
  if value>=20 and value<=250 then value=value/1000 end
  if value<.02 or value>.25 then return nil end
  return math.max(.65,math.min(1.45,value/.08))
 end
 local node=data and data.nodes and data.nodes[finish] or {}
 for _,key in ipairs({'exhaustTipDiameter','exhaustDiameter','tipDiameter'}) do
  local scale=diameter(node[key]);if scale then return scale end
 end
 local fallback=1
 for _,name in pairs(data and data.activeParts or {}) do
  local part=data.activePartsData and data.activePartsData[name] or {}
  local identity=text(name)..' '..text(part.slotType)..' '..text(part.information and part.information.name)
  if identity:find('exhaust',1,true) or identity:find('muffler',1,true) then
   for _,key in ipairs({'exhaustTipDiameter','exhaustDiameter','tipDiameter'})do
    local scale=diameter(part[key]);if scale then return scale end
   end
   if identity:find('tip',1,true) then
    if identity:find('large',1,true) or identity:find('megaphone',1,true) or identity:find('flared',1,true) then fallback=1.18
    elseif identity:find('small',1,true) or identity:find('narrow',1,true) then fallback=.85 end
   end
  end
 end
 for key,value in pairs(data and data.variables or {})do
  local id=text(key)
  if (id:find('exhaust',1,true) or id:find('tip',1,true)) and id:find('diameter',1,true) then
   local scale=diameter(type(value)=='table' and value.val or value);if scale then return scale end
  end
 end
 return fallback
end
return M
