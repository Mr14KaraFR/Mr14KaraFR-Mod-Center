-- Smooth configured night window, including windows crossing midnight.
local M={}
local function smooth(x)x=math.max(0,math.min(1,x));return x*x*(3-2*x)end
function M.factor(state)
 if type(state)~='table' then return 0 end
 local time=tonumber(state.time)
 if not time or time~=time then return state.isNight==true and 1 or 0 end
 local first,last=tonumber(state.nightStart) or .25,tonumber(state.nightEnd) or .75
 local span=(last-first)%1;if span<.0001 then return 0 end
 local phase=(time-first)%1;if phase>=span then return 0 end
 local edge=math.min(.06,span*.2)
 return smooth(phase/edge)*smooth((span-phase)/edge)
end
return M
