-- Recorded pop-pressure transients, isolated from held-flame and terminal audio.
local M={};local sources,serial,last={},0,0
function M.reset() sources,serial,last={},0,0 end
function M.play(obj,node,strength,count,rate,interior,scale)
 serial=serial+1
 local index=1+math.floor((math.sin(serial*2.399963+node*.173)*.5+.5)*6)
 if index==last then index=index%6+1 end;last=index
 local path='art/sound/vbf650/'..(interior and 'cabin/' or '')..'pop_'..index..'.wav'
 local level=(.28+.82*math.max(0,math.min(1,strength)))*(scale or 1)
  /math.sqrt(math.max(1,count or 1))*math.max(.55,math.min(1,math.sqrt(8/math.max(1,rate or 5))))
 local pitch=.975+.025*math.sin(serial*1.754877)
 return pcall(function()
  local key=node..':'..path;local id=sources[key]
  if not id then id=obj:createSFXSource2(path,'AudioDefault3D','vbf650_pop_'..node..'_'..serial,node,0);assert(type(id)=='number' and id>=0);sources[key]=id end
  obj:setVolumePitchCT(id,level,pitch,0,0);obj:playSFX(id)
 end)
end
return M
