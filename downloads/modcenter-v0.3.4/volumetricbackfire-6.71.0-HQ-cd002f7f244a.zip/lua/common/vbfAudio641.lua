-- Approved recorded GTR pressure transients, attached to physical exhaust nodes.
-- Volume and pitch retain vehicle-specific muffler and event parameters.
local M = {}
-- Output gain only; original recordings and visual timing are unchanged.
local IMPACT_GAIN=1.80 -- +5.11 dB
local BREATH_GAIN=1.65 -- +4.35 dB
local END_GAIN=1.20 -- terminal impact: +6.69 dB including impact gain
local serial = 0
local sources={}
local customSerial=0
local heavyTimes={}
local flameTimes, crackleTimes, active={},{},{}
local breathSerial=0
local interior=false
local function acousticPath(path)
  return interior and path:gsub("^art/sound/","art/sound/vbf630/cabin/") or path
end
function M.isInterior() return interior end
function M.setInterior(value,obj)
  value=value==true
  if interior==value then return end
  interior=value
  -- Retire overlapping breath tails; new camera profile starts on the next update.
  for _,a in pairs(active) do
    if obj then for id in pairs(a.voices) do pcall(obj.setVolumePitchCT,obj,id,0,1,0,0) end end
    a.voices={};a.next=0
  end
end
function M.reset() interior=false; sources={}; customSerial=0; heavyTimes={}; flameTimes={}; crackleTimes={}; active={}; breathSerial=0 end
local function clamp(x,a,b) return math.max(a,math.min(b,x)) end

function M.play(obj,event,node,volume,pitch,color,texture,strength,rpm,massive)
  serial=serial+1
  strength=clamp(tonumber(strength) or 0.5,0,1)
  rpm=clamp((tonumber(rpm) or 0)/9000,0,1)
  local variation=math.sin(serial*2.399963+node*0.173)
  -- Stronger pressure pulses sound slightly deeper; small crackles are lighter.
  local gain=0.82+strength*0.28
  local tone=0.97+rpm*0.05-strength*0.065+variation*0.025
  return pcall(function()
    if obj.createSFXSource2 and obj.setVolumePitchCT and obj.playSFX then
      customSerial=customSerial+1
      local kind=strength>=.65 and 'bang' or (strength>=.3 and 'pop' or 'crackle')
      local path=kind=='bang' and ('art/sound/vbf625/bang_'..(1+(customSerial-1)%6)..'.wav') or ('art/sound/vbf619/'..kind..'_'..(1+(customSerial-1)%3)..'.wav')
      if massive then path='art/sound/vbf629/mega_'..(1+(customSerial-1)%3)..'.wav' end
      path=acousticPath(path)
      local key=tostring(node)..':'..path
      local source=sources[key]
      if source==nil then
        source=obj:createSFXSource2(path,'AudioDefault3D','vbf619_'..node..'_'..customSerial,node,0)
        assert(type(source)=='number' and source>=0,'custom exhaust sound source unavailable')
        sources[key]=source
      end
      obj:setVolumePitchCT(source,math.max(0,volume)*gain*IMPACT_GAIN,clamp(1+(((pitch or 1)*tone)-1)*0.25,.95,1.05),color or 0,texture or 0)
      obj:playSFX(source)
      return
    end
    obj:playSFXOnceCT(event,node,math.max(0,volume)*gain*IMPACT_GAIN*(interior and .78 or 1),
      clamp((pitch or 1)*tone,0.8,1.15),color or 0,texture or 0)
  end)
end

function M.flame(obj,event,node,volume,pitch,color,texture,strength,rpm,time,count,scale,force)
  strength=clamp(strength or 0,0,1)
  local now=time or 0
  local continuous=now-(flameTimes[node] or -100)<.20
  flameTimes[node]=now
  local heavy=strength>=.65 and (force or not continuous) and now-(heavyTimes[node] or -100)>=.28
  if heavy then
    -- A visible pressure burst must not inherit the tiny native pop coefficient.
    local level=math.max(volume or 0,(1.25+.65*strength)*clamp(scale or 1,0,1.3)
      /math.sqrt(math.max(1,count or 1)))
    local ok=M.play(obj,event,node,level,pitch,color,texture,strength,rpm)
    if ok then heavyTimes[node]=time or 0 end
    return ok
  end
  if strength>=.65 then volume=math.min(volume or 0,.24); strength=.25 end
  return M.play(obj,event,node,volume,pitch,color,texture,strength,rpm)
end

function M.detonation(obj,event,node,volume,pitch,color,texture,strength,rpm)
  -- Shape the existing vehicle event, preserving its exhaust-specific timbre.
  return M.play(obj,event,node,volume*1.55,(pitch or 1)*0.90,color,texture,
    math.max(0.7,strength or 0),rpm)
end

-- Driven by actual accepted flame pulses, independently of explosion cadence.
function M.touch(node,strength,time,count,scale,duration)
  -- Repeated short pops (rev limiter/shift) do not constitute held combustion.
  -- They must neither arm nor extend the breath/terminal-impact state.
  if (tonumber(duration) or 0)<=.10 then return end
  local a=active[node]
  if not a or time-a.last>.18 then a={start=time,born=time,next=time,voices={}}; active[node]=a end
  if (duration or 0)>.10 then a.start=math.min(a.start,time-.16) end
  a.last=time; a.strength=clamp(strength or 0,0,1)
  a.level=clamp(scale or 1,0,1.3)/math.sqrt(math.max(1,count or 1))
end
function M.update(obj,time,onEnd)
  for node,a in pairs(active) do
    if time-a.last>.18 then
      for id in pairs(a.voices) do pcall(obj.setVolumePitchCT,obj,id,0,1,0,0) end
      active[node]=nil
      -- One terminal impact only after a genuinely sustained source.
      -- Remove state first: the terminal visual pulse must not re-arm it.
      if onEnd and a.last-a.born>=.35 then onEnd(node,a.strength) end
    elseif time-a.start>.14 and a.strength>=.30 and time>=a.next then
      breathSerial=breathSerial+1
      local path='art/sound/vbf626/breath_'..(1+(breathSerial-1)%6)..'.wav'
      path=acousticPath(path)
      local key=tostring(node)..':'..path
      local ok=pcall(function()
        local id=sources[key]
        if id==nil then
          id=obj:createSFXSource2(path,'AudioDefault3D','vbf626_breath_'..node..'_'..breathSerial,node,0)
          assert(type(id)=='number' and id>=0,'breath source unavailable'); sources[key]=id
        end
        -- Short overlapping recorded tails; no endless loop or extra bangs.
        local gain=(.55+.55*a.strength)*a.level*BREATH_GAIN
        obj:setVolumePitchCT(id,gain,1,0,0);obj:playSFX(id);a.voices[id]=true
      end)
      a.next=time+.26+.025*(.5+.5*math.sin(breathSerial*2.4))
      a.ok=ok
    end
  end
end

function M.finish(obj,node,strength,time,count,scale,massive,exhaustClass)
  local level=(1.45+.5*clamp(strength or 0,0,1))*clamp(scale or 1,0,1.3)
    /math.sqrt(math.max(1,count or 1))
  -- Extra output gain only for the final pressure impact on an upgraded exhaust.
  -- Class 1: sport/performance +8dB; class 2: race/open turbo +10dB.
  local outletGain=exhaustClass==2 and 3.16227766 or (exhaustClass==1 and 2.51188643 or 1)
  level=level*END_GAIN*outletGain
  if massive then level=level*2.2 end
  heavyTimes[node]=time or 0
  return M.play(obj,'event:>Vehicle>Afterfire>01_Single_EQ1',node,level,.96,0,0,.96,0,massive)
end

function M.assisted(obj,pipe,rpm,first,count,mode,character,soundVolume,flameStrength,time)
  local volume=clamp(tonumber(pipe.afterFireVolumeCoef) or 1,0,2)
  if mode=='hold' then
    local now=time or 0
    if now-(crackleTimes[pipe.finish] or -100)<.34 then return true end
    crackleTimes[pipe.finish]=now
    return M.play(obj,'event:>Vehicle>Afterfire>01_Single_EQ1',pipe.finish,
      .14*volume*clamp(soundVolume or 1,0,1.3)/math.sqrt(math.max(1,count or 1)),1,0,0,.2,rpm)
  end
  local muffling=clamp(tonumber(pipe.afterFireMufflingCoef) or 1,0,1)
  local strength=clamp(((rpm or 0)-2000)/6500,0,1)
  -- Split the acoustic energy over multiple outlets, avoiding a loudness jump.
  local variation=math.sin((serial+1)*1.754877+pipe.finish*0.31)
  local level=first and 0.52 or 0.24
  if mode=='shift' then level=0.46 elseif mode=='hold' then level=0.17+0.06*(0.5+0.5*variation) end
  if mode=='detonation' then level=1.0 end
  local gain=level*(0.92+0.08*(0.5+0.5*variation))
    *clamp(soundVolume or 1,0,1.3)/math.sqrt(math.max(1,count or 1))
  local tone=(first and 1 or 1.035)*(character and character.tone or 1)
  if mode=='shift' then tone=tone*0.975 elseif mode=='hold' then tone=tone*(1.025+variation*0.025) end
  if mode=='detonation' then tone=tone*0.88 end
  if flameStrength~=nil then
    return M.flame(obj,'event:>Vehicle>Afterfire>01_Single_EQ1',pipe.finish,
      volume*gain,tone,1-muffling,0,flameStrength,rpm,time,count,soundVolume,mode=='detonation' or mode=='shift')
  end
  return M.play(obj,'event:>Vehicle>Afterfire>01_Single_EQ1',pipe.finish,
    volume*gain,tone,1-muffling,0,
    first and strength or strength*0.35,rpm)
end
return M
