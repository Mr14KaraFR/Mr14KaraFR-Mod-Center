-- Local contact with finite mounted JBeam panel triangles, refreshed from live
-- node positions. It is not a full moving-mesh fluid/collision solver.
local M={}
local function dot(a,b)return a[1]*b[1]+a[2]*b[2]+a[3]*b[3]end
local function sub(a,b)return {a[1]-b[1],a[2]-b[2],a[3]-b[3]}end
local function cross(a,b)return {a[2]*b[3]-a[3]*b[2],a[3]*b[1]-a[1]*b[3],a[1]*b[2]-a[2]*b[1]}end
local function xyz(p)return {p.x,p.y,p.z}end
function M.triangle(a,b,c,up)
 local ab,ac=sub(b,a),sub(c,a);local n=cross(ab,ac);local len=math.sqrt(dot(n,n))
 if len<.00001 then return nil end
 for i=1,3 do n[i]=n[i]/len end
 if math.abs(dot(n,up))<.30 then return nil end
 if dot(n,up)<0 then b,c=c,b;ab,ac=ac,ab;for i=1,3 do n[i]=-n[i]end end
 local aa,bb,cc=dot(ab,ab),dot(ab,ac),dot(ac,ac);local den=aa*cc-bb*bb
 if den<1e-10 then return nil end
 return {a=a,b=b,c=c,n=n,ab=ab,ac=ac,aa=aa,bb=bb,cc=cc,den=den}
end
function M.project(tri,x,y,z)
 local p={x-tri.a[1],y-tri.a[2],z-tri.a[3]};local d,e=dot(p,tri.ab),dot(p,tri.ac)
 local u=(tri.cc*d-tri.bb*e)/tri.den;local v=(tri.aa*e-tri.bb*d)/tri.den
 return u>=0 and v>=0 and u+v<=1,dot(p,tri.n)
end
function M.new(getData)
 local cache,frame={},{};local contacts=0
 local api={}
 function api.beginFrame()frame={};contacts=0 end
 function api.clear(id)if id then cache[id]=nil;frame[id]=nil else cache={};frame={}end end
 function api.stats()return {contacts=contacts}end
 function api.triangles(veh)
  local id=veh:getID();if frame[id]then return frame[id]end
  local d=getData(id);d=d and(d.vdata or d)
  if not d then return {}end
  local ids=cache[id]
  if not ids or ids.data~=d then
   ids={data=d,list={}}
   for _,t in pairs(d.triangles or {})do
    local part=tostring(t.partOrigin or ''):lower()
    if (part:find('hood',1,true)or part:find('bonnet',1,true)or part:find('enginecover',1,true)or part:find('tailgate',1,true)or part:find('cowl',1,true)or part:find('windshield',1,true)or part:find('fender',1,true))
     and not part:find('exhaust',1,true)and not part:find('header',1,true)and t.id1 and t.id2 and t.id3 then ids.list[#ids.list+1]=t end
   end
   cache[id]=ids
  end
  local points={};local origin=veh:getPosition();local up=xyz(veh:getDirectionVectorUp())
  local function point(id)
   if not points[id]then points[id]=xyz(origin+veh:getNodePosition(id))end;return points[id]
  end
  local tris={}
  for _,t in ipairs(ids.list)do
   local tri=M.triangle(point(t.id1),point(t.id2),point(t.id3),up)
   if tri then tris[#tris+1]=tri end
  end
  frame[id]=tris;return tris
 end
 function api.query(veh,x,y,z)
  local best,score
  for _,tri in ipairs(api.triangles(veh))do
   local inside,h=M.project(tri,x,y,z)
   if inside and h>-.35 and h<.60 and(not score or math.abs(h)<score)then best=tri;score=math.abs(h)end
  end
  return best
 end
 function api.root(p,pose,veh)
  p.bodyTriangle=nil;p.hoodStandOff=0;if not p.hood then return end
  local dx,dy,dz=pose[4],pose[5],pose[6]
  local ax=(p.wx or 0)*dx+(p.wy or 0)*dy+(p.wz or 0)*dz
  local cross={ (p.wx or 0)-dx*ax,(p.wy or 0)-dy*ax,(p.wz or 0)-dz*ax }
  local bend=math.min(.012,.50/math.max(.001,math.sqrt(dot(cross,cross))))
  local tri=api.query(veh,pose[1]+cross[1]*bend,pose[2]+cross[2]*bend,pose[3]+.08+cross[3]*bend)
  p.bodyTriangle=tri or api.query(veh,pose[1],pose[2],pose[3]+.03)
  local t=p.bodyTriangle
  if t then
   local toward=dx*t.n[1]+dy*t.n[2]+dz*t.n[3]
   local _,h=M.project(t,pose[1],pose[2],pose[3])
   if toward>.25 then p.hoodStandOff=math.max(0,math.min(.25,-h/toward))end
  end
 end
 function api.parcel(p,veh,dt)
  p.bodyTriangle=nil;p.inNozzleHole=false;if not p.hood then return false end
  local tri=api.query(veh,p.x,p.y,p.z);p.bodyTriangle=tri
  if not tri then return false end
  if p.apertureFinish and p.apertureStart then
   local origin=veh:getPosition();local mouth=origin+veh:getNodePosition(p.apertureFinish)
   local axis=veh:getNodePosition(p.apertureFinish)-veh:getNodePosition(p.apertureStart)
   local length=math.sqrt(axis.x^2+axis.y^2+axis.z^2)
   if length>.001 then
    local dx,dy,dz=axis.x/length,axis.y/length,axis.z/length
    local rx,ry,rz=p.x-mouth.x,p.y-mouth.y,p.z-mouth.z;local along=rx*dx+ry*dy+rz*dz
    local radial=rx*rx+ry*ry+rz*rz-along*along
    local toward=dx*tri.n[1]+dy*tri.n[2]+dz*tri.n[3];local _,h=M.project(tri,mouth.x,mouth.y,mouth.z)
    local stand=toward>.25 and math.max(0,math.min(.25,-h/toward))or 0
    if along>=-.02 and along<=stand+.04 and radial<(p.apertureRadius or .06)^2 then p.bodyTriangle=nil;p.inNozzleHole=true;return false end
   end
  end
  local _,h=M.project(tri,p.x,p.y,p.z);local n=tri.n
  local axis=p.dx*n[1]+p.dy*n[2]+p.dz*n[3]
  local r=p.renderRadius or p.radius
  local support=math.sqrt(math.max(0,r*r+(p.halfLength^2-r*r)*axis*axis))
  local gap=h-support-.006;if gap>=0 then return false end
  local lift=-gap;p.x=p.x+n[1]*lift;p.y=p.y+n[2]*lift;p.z=p.z+n[3]*lift
  local vel=veh:getVelocity();local vn=(p.vx-vel.x)*n[1]+(p.vy-vel.y)*n[2]+(p.vz-vel.z)*n[3]
  if vn<0 then p.vx=p.vx-vn*n[1];p.vy=p.vy-vn*n[2];p.vz=p.vz-vn*n[3]end
  local rise=.7*math.max(0,p.heat)*math.max(0,dt or 0)
  p.vx=p.vx+n[1]*rise;p.vy=p.vy+n[2]*rise;p.vz=p.vz+n[3]*rise
  p.heat=p.heat*math.exp(-3*math.max(0,dt or 0));p.renderHeat=p.heat*(p.visibility or 1)
  p.bodyContacted=true;contacts=contacts+1;return true
 end
 return api
end
return M
