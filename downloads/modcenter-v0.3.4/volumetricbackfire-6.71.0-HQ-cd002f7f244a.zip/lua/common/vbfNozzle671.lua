-- Small short returns: advancing pressure front and irregular quenching.
local base=require('common/vbfNozzle670');local M={pose=base.pose}
local function smooth(a,b,x)local t=math.max(0,math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)end
local function pick(s)local n=math.sin(s*127.1+19.3)*43758.5453;return n-math.floor(n)end
function M.anchor(p,pose,remaining)
 base.anchor(p,pose,remaining)
 if not p.popVariant or p.hood then return end
 local tiny=1-smooth(.07,.16,p.halfLength);if tiny<=0 then return end
 local age=p.popAge or 0;local seed=p.seed or 0;local v=pick(seed)
 local front=smooth(.002,.032+.010*v,age)
 local quench=smooth(.050+.008*v,.088+.012*v,age)
 local length=(.65+.48*front)*(1-.22*quench)
 local width=(.78+.22*smooth(0,.014,age))*(1-.30*quench)
 p.halfLength=p.halfLength*(1+(length-1)*tiny)
 p.radius=p.radius*(1+(width-1)*tiny)
 local burn=(.22+.78*smooth(0,.008+.004*v,age))*(1-.65*quench)
 p.heat=p.heat*(1+(burn-1)*tiny)
 -- Hold the real pipe origin: motion is downstream, never camera-relative.
 p.x=pose[1]+p.dx*p.halfLength;p.y=pose[2]+p.dy*p.halfLength;p.z=pose[3]+p.dz*p.halfLength
end
return M
