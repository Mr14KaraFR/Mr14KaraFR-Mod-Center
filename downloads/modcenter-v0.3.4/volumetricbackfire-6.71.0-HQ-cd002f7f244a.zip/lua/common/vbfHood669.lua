-- Only an actual exposed header/hood/turbine outlet receives this treatment.
local M={}
function M.exposed(data,finish,start)
 local n=data and data.nodes and data.nodes[finish]or {}
 local id=tostring(n.name or n.id or ''):lower()
 local part=tostring(n.partOrigin or ''):lower()
 if id:find('trb',1,true)==1 or id:find('turbo',1,true)==1 then return true end
 if part:find('hoodexit',1,true)or part:find('hood_exit',1,true)or part:find('header_derby',1,true)or part:find('exhaust_turbo',1,true)then return true end
 return false
end
function M.compress(p)
 if not p.hood then return end
 local axial=(p.wx or 0)*p.dx+(p.wy or 0)*p.dy+(p.wz or 0)*p.dz
 local speed2=(p.wx or 0)^2+(p.wy or 0)^2+(p.wz or 0)^2
 local cross=math.sqrt(math.max(0,speed2-axial*axial))
 -- Preserve the mouth and first centimetres; only the downstream jet folds.
 p.halfLength=math.max(.018*math.min(1,p.flameScale or 1),p.halfLength*math.max(.34,1/(1+cross*.045)),((p.hoodStandOff or 0)>0 and ((p.hoodStandOff or 0)+.065)/1.2 or 0))
end
return M
