-- Recent heavy load proxy; not an ECU or fuel simulation.
local M={}
local function clamp(v,a,b) return math.max(a,math.min(b,tonumber(v) or 0)) end
function M.new() return {energy=0,recent=0} end
function M.update(s,dt,throttle,load,rpm,maxRPM)
  dt=clamp(dt,0,.1);throttle=clamp(throttle,0,1);load=clamp(load,0,1)
  local ratio=clamp((tonumber(rpm) or 0)/math.max(1,maxRPM or 8000),0,1)
  local demand=clamp((throttle-.30)/.70,0,1)*clamp((load-.35)/.65,0,1)*clamp((ratio-.22)/.50,0,1)
  s.recent=math.max(demand,s.recent*math.exp(-dt*1.2))
  if demand>.12 then s.energy=math.min(1,s.energy+dt*demand*.9)
  else s.energy=math.max(0,s.energy-dt*.2) end
end
function M.allowed(s,throttle,rpm,maxRPM,limiter,held)
  if held then return true end
  local ratio=(tonumber(rpm) or 0)/math.max(1,maxRPM or 8000)
  if limiter and (tonumber(throttle) or 0)>.6 and ratio>.85 then return true end
  return s.energy>=.065 and s.recent>.22
end
return M
