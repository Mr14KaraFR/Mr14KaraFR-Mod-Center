-- Preserve approved geometry except the aspect of centimetre-scale pops.
local base=require('common/vbfNozzle669');local M={pose=base.pose}
function M.anchor(p,pose,remaining)
 base.anchor(p,pose,remaining)
 if not p.popVariant or p.hood then return end
 local t=math.max(0,math.min(1,(p.halfLength-.065)/.090));local tiny=1-t*t*(3-2*t)
 local stretch=1+.22*tiny
 -- Reallocate the same body volume along the tube; preserve lip coverage.
 p.halfLength=p.halfLength*stretch;p.radius=p.radius/math.sqrt(stretch)
 p.x=pose[1]+p.dx*p.halfLength;p.y=pose[2]+p.dy*p.halfLength;p.z=pose[3]+p.dz*p.halfLength
end
return M
