-- User settings. Quality: 'balanced', 'high', or 'ultra'.
-- Intensity and soundVolume are independent, bounded controls.
local M={quality='ultra',intensity=1,soundVolume=1}
local presets={balanced={384,48,60},high={576,72,75},ultra={768,96,90}}
function M.resolve(options)
  options=options or M
  local p=presets[options.quality] or presets.ultra
  local function bounded(v,default,lo,hi)
    v=tonumber(v)
    if not v or v~=v then v=default end
    return math.max(lo,math.min(hi,v))
  end
  return {maxSim=p[1],maxRender=p[2],range=p[3],
    intensity=bounded(options.intensity,1,0.5,1.3),
    soundVolume=bounded(options.soundVolume,1,0,1.3)}
end
return M
