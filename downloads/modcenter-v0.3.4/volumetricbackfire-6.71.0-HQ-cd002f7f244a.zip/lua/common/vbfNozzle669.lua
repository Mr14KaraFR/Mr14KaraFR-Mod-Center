local base=require('common/vbfNozzle668');local hood=require('common/vbfHood669')
local M={pose=base.pose}
function M.anchor(p,pose,remaining)
 base.anchor(p,pose,remaining);hood.compress(p)
 if p.hood then p.x=pose[1]+p.dx*p.halfLength;p.y=pose[2]+p.dy*p.halfLength;p.z=pose[3]+p.dz*p.halfLength end
end
return M
