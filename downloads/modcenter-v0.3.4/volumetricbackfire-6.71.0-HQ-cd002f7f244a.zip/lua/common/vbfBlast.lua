local M={}
function M.new(seed) return {rng=(math.floor(seed or 1)%2147483646)+1,last=-100,choiceTime=-100,choice=false} end
function M.pick(s,time,energy,prepared)
  -- All outlets in the same event share a decision, without multiplying odds.
  if time-s.choiceTime<=.12 then return s.choice end
  s.choiceTime=time;s.choice=false
  s.rng=(s.rng*48271)%2147483647
  local chance=prepared and (.14+.08*math.max(0,math.min(1,energy or 0))) or .08
  if time-s.last>=8 and s.rng/2147483647<chance then s.choice=true;s.last=time end
  return s.choice
end
return M
