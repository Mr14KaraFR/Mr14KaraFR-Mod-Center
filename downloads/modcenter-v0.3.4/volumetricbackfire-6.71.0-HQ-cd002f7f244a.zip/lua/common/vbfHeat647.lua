-- Visual thermal response from BeamNG exhaustTemperature (Celsius).
-- Not a combustion-spectrum solver. Existing appearance is the safe fallback.
local M={neutral=.65}
function M.new()return {value=M.neutral,initialized=false}end
function M.target(celsius)
  local t=tonumber(celsius)
  if not t or t~=t or math.abs(t)>10000 then return nil end
  return math.max(0,math.min(1,(t-120)/530))
end
function M.update(s,dt,celsius)
  local target=M.target(celsius)
  if target==nil then return s.value end
  if not s.initialized then s.value=target;s.initialized=true end
  local step=math.max(0,math.min(.1,tonumber(dt)or 0))
  s.value=s.value+(target-s.value)*(1-math.exp(-step/1.2))
  return s.value
end
function M.gain(v)
  v=math.max(0,math.min(1,tonumber(v)or M.neutral))
  local cold=math.max(0,(.65-v)/.65)
  local hot=math.max(0,(v-.65)/.35)
  return 1-.28*cold+.18*hot
end
return M
