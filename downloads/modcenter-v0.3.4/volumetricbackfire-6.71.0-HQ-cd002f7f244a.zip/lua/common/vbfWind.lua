-- Samples physical ground wind, not cloud animation speed.
local M={}
local function bounded(v)
  return type(v)=='number' and v==v and math.max(-40,math.min(40,v)) or 0
end
function M.sample(engine,x,y,z,vector,environment)
  local ok,w
  if engine and type(engine.getWindAt)=='function' then
    ok,w=pcall(engine.getWindAt,engine,vector(x,y,z))
    if ok and w then return bounded(w.x),bounded(w.y),bounded(w.z),true end
  end
  -- BeamNG 0.39 core_environment applies this exact vector to vehicle physics.
  if environment and type(environment.getGroundWind)=='function' then
    ok,w=pcall(environment.getGroundWind)
    if ok and w then return bounded(w.x),bounded(w.y),bounded(w.z),true end
  end
  return 0,0,0,false
end
function M.relative(p,wx,wy,wz,vx,vy,vz)
  p.wx,p.wy,p.wz=wx-vx,wy-vy,wz-vz
  local speed=math.sqrt(p.wx*p.wx+p.wy*p.wy+p.wz*p.wz)
  p.turbulence=math.min(2.8,0.65+speed*0.060)
  p.flowRate=1+math.min(1.8,speed*0.035)
end
return M
