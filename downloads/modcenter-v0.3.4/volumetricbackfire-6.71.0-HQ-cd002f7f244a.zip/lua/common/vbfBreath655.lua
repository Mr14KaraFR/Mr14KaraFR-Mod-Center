-- ECU-owned held-flame breath; existing recorded tails, no terminal timer.
local M={};local sources,active,serial,lastVariant={},{},0,0
local function volume(obj,id,gain,pitch) return pcall(obj.setVolumePitchCT,obj,id,gain,pitch or 1,0,0) end
local function silence(obj,a)
 if obj then for id in pairs(a.voices) do volume(obj,id,0,1) end end
 a.voices={}
end
function M.reset(obj)
 for _,a in pairs(active) do silence(obj,a) end
 sources,active,serial,lastVariant={},{},0,0
end
function M.update(obj,time)
 for node,a in pairs(active) do
  if time-a.last>.18 then silence(obj,a);active[node]=nil
  else
   local pressure=1+.10*math.sin(time*9+node*.173)+.04*math.sin(time*23+node*.31)
   local gain=(.55+.55*a.strength)*a.scale/math.sqrt(a.count)*1.65*pressure
   for id,born in pairs(a.voices) do
    if time-born>=.40 then volume(obj,id,0,1);a.voices[id]=nil else volume(obj,id,gain,1) end
   end
   if time>=a.next then
    serial=serial+1
    local index=1+math.floor((math.sin(serial*2.399963+node*.173)*.5+.5)*6)
    if index==lastVariant then index=index%6+1 end;lastVariant=index
    local path='art/sound/vbf626/breath_'..index..'.wav'
    if a.inside then path=path:gsub('^art/sound/','art/sound/vbf630/cabin/') end
    local key=node..':'..path
    local ok=pcall(function()
     local id=sources[key]
     if id==nil then id=obj:createSFXSource2(path,'AudioDefault3D','vbf655_breath_'..node..'_'..serial,node,0);assert(type(id)=='number' and id>=0);sources[key]=id end
     assert(volume(obj,id,gain,1));obj:playSFX(id);a.voices[id]=time
    end)
    a.ok=ok;a.next=time+.26+.025*(.5+.5*math.sin(serial*2.399963))
   end
  end
 end
end
function M.touch(obj,node,strength,time,count,scale,inside)
 local a=active[node]
 if not a then a={voices={},next=time};active[node]=a end
 if a.inside~=(inside==true) then silence(obj,a);a.next=time end
 a.last=time;a.strength=math.max(0,math.min(1,strength or 0))
 a.count=math.max(1,count or 1);a.scale=math.max(0,math.min(1.3,scale or 1));a.inside=inside==true
 M.update(obj,time)
 return a.ok==true
end
return M
