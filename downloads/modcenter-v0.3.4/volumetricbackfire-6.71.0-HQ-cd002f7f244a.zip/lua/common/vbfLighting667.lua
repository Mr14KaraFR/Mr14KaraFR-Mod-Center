-- Bounded pool of actual scene lights; simulation pause freezes flicker too.
local M={}
function M.new(create,vector,ray)
  local pool,disabled={},false
  local enabled={}
  local blockedCount=0
  local api={}
  function api.clear()
    for _,light in ipairs(pool) do pcall(function() light:delete() end) end
    pool={};enabled={}
  end
  local function cabinBlocked(p,camera,insideVehicle)
    if insideVehicle==nil or p.vehicle~=insideVehicle then return false end
    -- View-dependent fallback for vehicle meshes not occluding local lights.
    -- No ray work in exterior views; open cabin path retains diffuse light.
    if type(ray)~='function' then return true end
    local offset=p.halfLength*.7
    local source=vector(p.x-p.dx*offset,p.y-p.dy*offset,p.z-p.dz*offset)
    local ok,hit=pcall(ray,camera,source,true,true)
    if not ok then return true end
    if not hit then return false end
    if not hit.pt then return true end
    local x,y,z=hit.pt.x-source.x,hit.pt.y-source.y,hit.pt.z-source.z
    -- Ignore a hit on the mouth itself at the very end of the segment.
    return x*x+y*y+z*z>.0004
  end
  function api.stats()
    local count=0;for _,value in pairs(enabled) do if value then count=count+1 end end
    return {enabled=count,blocked=blockedCount,pooled=#pool}
  end
  function api.update(roots,camera,insideVehicle,night)
    night=math.max(0,math.min(1,tonumber(night) or 0));blockedCount=0
    if disabled then return end
    local near={}
    for _,p in ipairs(roots) do
      local x,y,z=p.x-camera.x,p.y-camera.y,p.z-camera.z
      if x*x+y*y+z*z<1600 and p.heat>0 then
        -- Fail closed for the owner's night cockpit: glass/body shadow support
        -- differs across vehicles. Other vehicles still illuminate the scene.
        local ownNight=night>.05 and insideVehicle~=nil and p.vehicle==insideVehicle
        if ownNight or cabinBlocked(p,camera,insideVehicle) then blockedCount=blockedCount+1
        else near[#near+1]=p end
      end
    end
    table.sort(near,function(a,b)
      local function d(p) return (p.x-camera.x)^2+(p.y-camera.y)^2+(p.z-camera.z)^2 end
      return d(a)<d(b)
    end)
    local ok,err=pcall(function()
      for i=1,math.min(8,#near) do
        local p=near[i]
        local l=pool[i]
        if not l then
          l=create('PointLight'); pool[i]=l
          l.canSave=false; l.castShadows=true
          -- Let opaque body panels block the fire illumination at night.
          -- Use engine shadow maps; do not dim or recolour the flame lights.
          l:setField('castShadows',0,'true')
          l:setField('texSize',0,'1024')
          l:setField('color',0,'1 0.32 0.09 1')
          l:registerObject('VBFExhaustLight'..i)
        end
        local thermal=math.max(0,math.min(1,p.exhaustHeat or .65))
        local cold=math.max(0,(.65-thermal)/.65)
        local hot=math.max(0,(thermal-.65)/.35)
        local thermalGain=1-.28*cold+.18*hot
        local s=p.strength or 1
        local fast=0.86+0.14*math.sin(p.age*61+p.seed)
        local slow=.86+.10*math.sin(p.age*11+p.seed)+.04*math.sin(p.age*23+p.seed*1.7)
        local flicker=fast+(slow-fast)*night
        l.radius=(1.4+2.4*s)*(1-.24*night)
        l.intensity=(180+2100*s*s)*p.heat*flicker*thermalGain*(1-.40*night)
        l:setField('color',0,string.format('1 %.5f %.5f 1',.32+night*(-.05+.10*thermal),.09+night*(-.04+.035*thermal)))
        l.isEnabled=true;enabled[i]=true
        -- A few centimetres outside the mouth, not inside the vehicle body.
        local original=p.halfLength*.30
        local outside=math.max(.045,math.min(.16,original+(p.mouthRadius or 0)*.40))
        local offset=p.halfLength-(original+(outside-original)*night)
        l:setPosition(vector(p.x-p.dx*offset,p.y-p.dy*offset,p.z-p.dz*offset))
        l:postApply()
      end
      for i=math.min(8,#near)+1,#pool do
        if enabled[i] then pool[i].isEnabled=false;pool[i]:postApply();enabled[i]=false end
      end
    end)
    if not ok then api.clear(); disabled=true; return false,tostring(err) end
    return true
  end
  return api
end
return M
