-- Numerical lip diameters measured from vanilla 0.40 meshes; no game mesh assets included.
return {
 ["bx_exhaust_i4_fartcan"]={["ex7r"]=0.09},
 ["bx_exhaust_v8_fartcan"]={["ex7r"]=0.09},
 ["sunburst2_exhaust_na_race"]={["ex8"]=0.0871},
 ["sunburst2_exhaust_turbo_race"]={["ex8"]=0.0871},
 ["sunburst2_exhaust_turbo_stock_race"]={["ex8"]=0.0871},
 ["vivace_exhaust_race"]={["ex8l"]=0.0968},
}
