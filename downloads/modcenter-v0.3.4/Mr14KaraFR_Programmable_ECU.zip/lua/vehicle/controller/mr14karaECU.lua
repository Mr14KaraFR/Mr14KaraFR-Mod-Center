-- Mr14KaraFR programmable ECU. Additive controller, BeamNG 0.39.

local M = {type = 'auxiliary', defaultOrder = 90}
local overrunMap=require('mr14karaECUOverrunMap')

local engine, originalUpdate, wrappedUpdate, tune, baseline

local clock, revision = 0, 0

local sample = {}

local flamesOK, flames = pcall(require, "mr14karaECUFlames")

if not flamesOK then flames=nil end

local nativeLimiter
local transmissionRetryAt=0
local transmissionOK,transmission=pcall(require,"mr14karaECUTransmission")
if not transmissionOK then transmission=nil end
local transbrakeOK,transbrake=pcall(require,"mr14karaECUTransbrake")
if not transbrakeOK then transbrake=nil end
-- Flat shift uses the actual manual gearbox clutch; never requests a gear.
local flatShift={armed=false,active=false,elapsed=0,count=0,gear=0,supported=false}
function flatShift.defaults() return {enabled=false,method='ignition',duration=.12,minRPM=3000,minPedal=90} end
function flatShift.reset() flatShift.armed=false;flatShift.active=false;flatShift.elapsed=0;flatShift.gear=0;flatShift.count=0 end
function flatShift.validate(c)
  if type(c)~='table' or type(c.enabled)~='boolean' or c.method~='ignition' and c.method~='torque' then return false,'Flat shift invalide.' end
  for k,r in pairs({duration={.03,.4},minRPM={1500,10000},minPedal={50,100}}) do if type(c[k])~='number' or c[k]~=c[k] or c[k]<r[1] or c[k]>r[2] then return false,'Flat shift hors limites : '..k end end
  return true
end
function flatShift.step(e,c,dt,blocked)
  local gb=flatShift.box
  if not gb or gb.type~='manualGearbox' then flatShift.active=false;flatShift.armed=false;return 1 end
  local ratio=gb.parent and gb.parent.clutchRatio
  flatShift.supported=type(ratio)=='number' and ratio==ratio and ratio>=0 and ratio<=1 and e.requiredEnergyType=='gasoline' and type(e.cutIgnition)=='function'
  local pedal=electrics.values.throttle_input
  local speed=electrics.values.wheelspeed or electrics.values.airspeed
  local valid=flatShift.supported and c and c.enabled and not blocked and playerInfo and playerInfo.anyPlayerSeated and e.hasFuel~=false and not e.isDisabled and not e.isStalled and (e.ignitionCoef or 1)>0 and type(pedal)=='number' and pedal*100>=c.minPedal and type(speed)=='number' and math.abs(speed)>1.4
  local gear=gb.gearIndex or 0
  if not valid or gear<0 then flatShift.active=false;flatShift.armed=false;return 1 end
  if ratio>=.8 then
    flatShift.active=false;flatShift.elapsed=0
    flatShift.armed=gear>0;flatShift.gear=gear
    return 1
  end
  if flatShift.active and gear>0 and gear<flatShift.gear then flatShift.active=false end
  if flatShift.armed and ratio<=.5 then
    flatShift.armed=false
    if flatShift.gear>0 and (gear==0 or gear>=flatShift.gear) and (e.outputAV1 or 0)*30/math.pi>=c.minRPM then
      flatShift.active=true;flatShift.elapsed=0;flatShift.count=flatShift.count+1
    end
  end
  if not flatShift.active then return 1 end
  if flatShift.elapsed>=c.duration then flatShift.active=false;return 1 end
  local remaining=c.duration-flatShift.elapsed
  flatShift.elapsed=flatShift.elapsed+dt
  if c.method=='ignition' then e:cutIgnition(math.max(e.ignitionCutTime or 0,math.min(remaining,dt*1.1))) end
  return c.method=='torque' and 0 or 1
end
local temperatureAxis={-20,0,20,40,60,80,90,100,110,120,130}
local function temperatureDefaults()
  local t={fuelEnabled=false,advanceEnabled=false,axis=deepcopy(temperatureAxis),fuel={},advance={}}
  for i=1,#temperatureAxis do t.fuel[i]=0;t.advance[i]=0 end
  return t
end
local function transbrakeDefaults() return {enabled=false,maxHold=8} end
local speedLimiter=require("mr14karaECUSpeedLimiter")
local traction=require("mr14karaECUTraction")
local tractionSample={}
local idleModel=require("mr14karaECUIdle")
local idleState
local rpmModelOK,rpmModel=pcall(require,"mr14karaECURPM")
if not rpmModelOK then rpmModel=nil end

local syncNativeLimiter

local dieselSmokeTick=0

local lastECUIgnitionCut=-100
local lastRollingIgnitionCut=-100
local limiterLatched=false
local limiterRuntime={elapsed=0,count=0}

local faultHistory,faultStates={},{}

local faultSession=1

local hardwareKey=""
local tuneKey=""
local multiplayerRemote,multiplayerFrame,multiplayerAge,multiplayerRevision=false,nil,0,nil
local multiplayerSession
local multiplayerSampleTime
local mpProtocolOK,mpProtocol=pcall(require,'common/mr14karaECUMPProtocol')
local mpNativeOK,mpNative=pcall(require,'mr14karaECUMPNative')
local mpPlaybackOK,mpPlayback=pcall(require,'mr14karaECUMPPlayback')
local dieselVolumeOK,dieselVolume=pcall(require,'mr14karaECUDieselSmoke')
local diagnosticOK,diagnostic=pcall(require,'mr14karaECUDiagnostics')
local mpNativeError
-- Use the game's native Start/ESP control widget. No replacement UI files.
local modeButtonKey,transbrakeButtonKey,speedButtonKey
local modeLabels={eco='Éco',route='Route',sport='Sport'}
local modeColors={eco='70D68B',route='67B7FF',sport='FF4C55'}
local function updateSimpleControlButtons(force)
  local api=extensions and extensions.ui_simplePowertrainControl
  if not api or type(api.setButton)~='function' then return end
  local remote=multiplayerRemote or v and v.mpVehicleType=='R'
  local mode=tune and tune.activeMode or 'route'
  local available=engine~=nil and tune~=nil
  local key=(available and mode or 'absent')..(remote and ':remote' or ':owner')
  local ts=transbrake and transbrake.status() or {}
  local tbVisible=available and ts.supported and tune.transbrake and tune.transbrake.enabled and not remote
  local tbKey=(tbVisible and 'visible' or 'hidden')..(ts.active and ':active' or ':off')
  if force==true or transbrakeButtonKey~=tbKey then
    transbrakeButtonKey=tbKey
    local name=M.name or 'mr14karaECU'
    if tbVisible then api.setButton('mr14kara_ecu_transbrake','Transbrake : '..(ts.active and 'actif' or 'prêt'),'powertrain_gearbox_automatic',ts.active and 'FF6600' or 'FFFFFF',ts.active and 1 or 0,string.format('local c=controller.getController(%q);if c and c.toggleTransbrake then c.toggleTransbrake() end',name))
    else api.setButton('mr14kara_ecu_transbrake',nil,nil,nil,nil,nil,true) end
  end
  local ss=speedLimiter.status()
  local visible=available and tune.speedLimiter and tune.speedLimiter.enabled and not remote
  local sk=tostring(visible)..':'..tostring(ss.armed)..':'..tostring(ss.active)..':'..tostring(visible and tune.speedLimiter.speed)
  if force==true or speedButtonKey~=sk then
    speedButtonKey=sk
    if visible then api.setButton('mr14kara_ecu_speed','Limiteur '..tune.speedLimiter.speed..' km/h : '..(ss.armed and 'activé' or 'désactivé'),'cruise-control_lim-enable',ss.active and 'FF6600' or ss.armed and '70D68B' or 'FFFFFF',ss.armed and 1 or 0,string.format('local c=controller.getController(%q);if c and c.toggleSpeedLimiter then c.toggleSpeedLimiter() end',M.name or 'mr14karaECU'))
    else api.setButton('mr14kara_ecu_speed',nil,nil,nil,nil,nil,true) end
  end
  if force~=true and modeButtonKey==key then return end
  modeButtonKey=key
  local id='mr14kara_ecu_mode'
  if not available then api.setButton(id,nil,nil,nil,nil,nil,true);return end
  local name=M.name or 'mr14karaECU'
  local tooltip=(remote and 'ECU distant : ' or 'ECU : ')..(modeLabels[mode] or mode)
  local click=string.format('local c=controller.getController(%q);if c and c.cycleMode then c.cycleMode() end',name)
  api.setButton(id,tooltip,'tech_bngmicrochip',remote and '777777' or modeColors[mode],mode=='eco' and 1/3 or mode=='sport' and 1 or 2/3,click)
end

local function rememberTune()
  if multiplayerRemote then return end
  if not tune or not obj.queueGameEngineLua then return end
  obj:queueGameEngineLua('if not extensions.mr14karaECUStorage then extensions.load("mr14karaECUStorage") end; if extensions.mr14karaECUStorage then extensions.mr14karaECUStorage.rememberActive('..obj:getID()..','..string.format('%q',tuneKey)..','..string.format('%q',jsonEncode(tune))..') end')
end

local function configKey(t)

  if type(t)~='table' then return type(t)..':'..tostring(t) end

  local keys={};for k in pairs(t) do keys[#keys+1]=k end;table.sort(keys,function(a,b) return tostring(a)<tostring(b) end)

  local values={};for _,k in ipairs(keys) do local value=configKey(t[k]);values[#values+1]=tostring(k)..'='..#value..':'..value end

  return table.concat(values,';')

end

local overrunElapsed, antiLagElapsed = 0, 0

local turbo, turboOriginal, turboWrapped, antiLagOwned

local antiLagPhysicsAge=0

local launchBlocked,launchCut,launchElapsed=false,false,0
local rollingInput,rollingBlocked,rollingElapsed=false,false,0
local function detonationDefaults() return {scaleVersion=2,shift={enabled=false,volume=25,flame=50,maxTime=.30,minPedal=60,minRPM=2500},limiter={enabled=false,volume=25,flame=50,hz=5}} end
local function rollingBangDefaults() return {enabled=true,volume=80,flame=60,hz=6} end
local function rollingDefaults() return {detonations=rollingBangDefaults(),enabled=false,rpm=4000,hysteresis=150,minThrottle=50,minSpeed=20,maxSpeed=200,maxHold=8,turboPrep=true,intensity=40,fuel=25,retard=30} end

local function launchDefaults() return {enabled=false,rpm=3500,hysteresis=150,minThrottle=80,maxSpeed=5,maxHold=10,turboPrep=true,intensity=40,fuel=25,retard=30} end

local function antiLagDefaults() return {enabled=false,intensity=50,fuel=25,retard=30,minRPM=3000,maxRPM=8000,maxThrottle=5,duration=3} end

local function overrunDefaults() return {mode="off",fuel=15,retard=20,minRPM=2500,maxRPM=8000,maxThrottle=5,duration=3,popHz=5,popControl=require("mr14karaECUPopControl").defaults(5),rpmMap=overrunMap.defaults(15,20)} end

local function emit(event,data)

  guihooks.trigger(event,data)

  if obj.queueGameEngineLua and jsonEncode then

    obj:queueGameEngineLua('if extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.publish('..string.format('%q',event)..','..string.format('%q',jsonEncode(data))..') end')

  end

end

local rpmAxis = {600,1000,1500,2000,2500,3000,4000,5000,6000,7500,9000,12000}

local loadAxis = {0,10,20,35,50,65,80,100}
local dieselBoostAxis={0,2,5,10,15,20,30,40}

local limits = {fuel={25,300}, advance={-30,70}, lambda={0.4,4}, boost={-15,40}}

local dieselLimits={dieselTorque={25,500},dieselSmoke={0.2,4},dieselAirFuel={25,500}}
local dieselMapLimits={fuel={25,500},lambda={0.2,4}}

local function dieselTable(value) local grid={} for y=1,#loadAxis do grid[y]={} for x=1,#rpmAxis do grid[y][x]=value end end return grid end
local function dieselAirTable()
  local values={100,110,130,160,200,250,350,500};local grid={}
  for y=1,#dieselBoostAxis do grid[y]={};for x=1,#rpmAxis do grid[y][x]=values[y] end end
  return grid
end
local function pedalMapDefaults()
  local rows={};for y,p in ipairs(loadAxis) do rows[y]={};for x=1,#rpmAxis do rows[y][x]=p end end
  return {enabled=true,axis=deepcopy(loadAxis),values=rows}
end
local function finite(x) return type(x)=='number' and x==x and math.abs(x)<1e20 end
local function boostTargetDefaults()
  local rows={};for y=1,#loadAxis do rows[y]={};for x=1,#rpmAxis do rows[y][x]=15 end end
  return {enabled=false,values=rows}
end
-- Mirror the native turbo configuration, never infer its target from measured pressure.
local function nativeBoostTarget(gear)
  local data=v and v.data
  if not data or not engine then return nil end
  local config={}
  for _,row in pairs(data.powertrain or {}) do if type(row)=='table' and row.name==engine.name then for k,n in pairs(row) do config[k]=n end end end
  for k,n in pairs(data[engine.name] or {}) do config[k]=n end
  if config.turbochargerLuaFileName and config.turbochargerLuaFileName~='powertrain/turbocharger' then return nil end
  local turbo=type(config.turbocharger)=='string' and data[config.turbocharger]
  if type(turbo)~='table' then return nil end
  local starts,limits,ranges={}, {}, {};local maxStart,maxLimit,maxRange=0,1/6894.757,1/6894.757
  if type(turbo.wastegateStart)=='table' then
    for k,n in pairs(turbo.wastegateStart) do if not finite(n) then return nil end;starts[k]=n;maxStart=n end
  else starts[1]=turbo.wastegateStart or 0;if not finite(starts[1]) then return nil end;maxStart=starts[1] end
  if type(turbo.wastegateLimit)=='table' then
    for k,n in pairs(turbo.wastegateLimit) do if not finite(n) then return nil end;limits[k]=n;maxLimit=n end
  elseif type(turbo.wastegateLimit)=='number' then limits[1]=turbo.wastegateLimit;maxLimit=limits[1]
  else for k,n in pairs(starts) do limits[k]=n+.01;maxLimit=limits[k] end end
  for k,n in pairs(starts) do ranges[k]=(limits[k] or maxLimit)-n;maxRange=ranges[k] end
  local base=(starts[gear] or maxStart)+(ranges[gear] or maxRange)*.5
  return finite(base) and base or nil
end
local function gearBoostDefaults()
  local axis,values={},{};for gear=-1,18 do axis[#axis+1]=gear;values[#values+1]=0 end
  return {enabled=false,axis=axis,values=values}
end

local function clamp(x,a,b) return math.min(b,math.max(a,x)) end



-- Preserve the installed engine's electronic limiter independently from its

-- physical over-rev damage threshold; raised torque curves are owned/restorable.

local function restoreNativeLimiter()
  if idleState and engine then idleModel.restore(engine,idleState);idleState=nil end

  if nativeLimiter then

    local d=nativeLimiter.engine
    if rpmModel then rpmModel.restore(d,nativeLimiter.rpmModel) end

    if d.revLimiterAV==nativeLimiter.ownedAV then

      d.revLimiterRPM=nativeLimiter.originalRPM;d.revLimiterAV=nativeLimiter.originalAV

    end

    nativeLimiter=nil

  end

end

syncNativeLimiter=function()

  if not nativeLimiter or nativeLimiter.engine~=engine then return end

  local rpm=tune and tune.limiter or 0

  local raised=rpm>nativeLimiter.rpm

  local target=raised and rpm or nativeLimiter.originalRPM

  local av=raised and rpm*(2*math.pi/60) or nativeLimiter.originalAV

  if engine.revLimiterAV~=av then

    engine.revLimiterActive=false;engine.revLimiterActiveTimer=0

    engine.revLimiterWasActiveTimer=999

  end

  engine.revLimiterRPM=target;engine.revLimiterAV=av;nativeLimiter.ownedAV=av
  if rpmModel then rpmModel.apply(engine,nativeLimiter.rpmModel,raised and rpm or 0) end

end

local function diesel() return engine and engine.requiredEnergyType=='diesel' end

local function referenceAdvance(rpm,load) return clamp(10+rpm*0.004-load*0.10,5,42) end

local function referenceLambda(load)

  if diesel() then return 3-1.5*load/100 end

  return 1-0.12*clamp((load-35)/65,0,1)

end

local function protectionDefaults() return {enabled=false,coolantStart=110,coolantEnd=125,oilStart=130,oilEnd=150,minTorque=35} end

local function revLimiterDefaults() return {style='hard',cutMethod='fuel',hysteresis=150,softRange=500,ignitionAggression=0,torqueCutTime=0} end

local modes={eco=true,route=true,sport=true}

local function payload(t) local c=deepcopy(t);c.modeMaps=nil;c.activeMode=nil;c.profileMeta=nil;return c end

local function defaults()

  local t={version=1, fuelType=diesel() and 'diesel' or 'gasoline', rpmAxis=deepcopy(rpmAxis), loadAxis=deepcopy(loadAxis), limiter=0, revLimiter=revLimiterDefaults(), throttleResponse={enabled=false,gamma=1}, overrun=overrunDefaults(), antiLag=antiLagDefaults(), launchControl=launchDefaults(), tables={fuel={},advance={},lambda={},boost={}}}

  for key,grid in pairs(t.tables) do

    for y,load in ipairs(loadAxis) do

      grid[y]={}

      for x,rpm in ipairs(rpmAxis) do

        grid[y][x]=key=='fuel' and 100 or key=='advance' and referenceAdvance(rpm,load) or key=='lambda' and referenceLambda(load) or 0

        grid[y][x]=math.floor(grid[y][x]*100+0.5)/100

      end

    end

  end

  if diesel() then t.tables.dieselTorque=dieselTable(130);t.tables.dieselSmoke=dieselTable(1.15);t.tables.dieselAirFuel=dieselAirTable();t.dieselBoostAxis=deepcopy(dieselBoostAxis);t.dieselAirLimiterEnabled=false end

  t.dieselFlame={enabled=true,start=850,full=1100};t.flatShift=flatShift.defaults();t.temperatureCorrection=temperatureDefaults();t.transbrake=transbrakeDefaults();t.tractionControl=traction.defaults();t.speedLimiter=speedLimiter.defaults();t.detonations=detonationDefaults();t.transmission=transmission and transmission.defaults(engine) or nil;t.rollingLaunch=rollingDefaults();t.boostTarget=boostTargetDefaults();t.pedalMap=pedalMapDefaults();t.boostByGear=gearBoostDefaults();t.idleControl=idleModel.defaults({idleRPM=idleState and idleState.rpm or engine and engine.idleRPM});t.protection=protectionDefaults();t.activeMode='route';t.modeMaps={};for mode in pairs(modes) do t.modeMaps[mode]=payload(t) end

  return t

end

local function bracket(axis,v)

  if v<=axis[1] then return 1,1,0 end

  for i=2,#axis do if v<=axis[i] then return i-1,i,(v-axis[i-1])/(axis[i]-axis[i-1]) end end

  return #axis,#axis,0

end

local function interpolate(grid,rpm,load,rowAxis,columnAxis)

  local a,b,u=bracket(columnAxis or tune and tune.rpmAxis or rpmAxis,rpm)

  local c,d,v=bracket(rowAxis or loadAxis,load)

  return (grid[c][a]*(1-u)+grid[c][b]*u)*(1-v)+(grid[d][a]*(1-u)+grid[d][b]*u)*v,a,c

end
local function mappedPedal(value,rpm)
  if tune and tune.pedalMap and tune.pedalMap.enabled then return clamp(interpolate(tune.pedalMap.values,rpm,value*100,tune.pedalMap.axis)/100,0,1) end
  local response=tune and tune.throttleResponse
  return response and response.enabled and value^response.gamma or value
end

local function status(message,ok)

  emit('Mr14ECUNotice',{message=message,ok=ok,vehicleId=obj:getID()})

end

local function migrateDetonations(det)
  if type(det)~='table' or det.scaleVersion~=nil then return end
  for _,kind in ipairs({'shift','limiter'}) do
    local cfg=det[kind]
    if type(cfg)=='table' then
      if finite(cfg.volume) then cfg.volume=cfg.volume/10 end
      if finite(cfg.flame) then cfg.flame=cfg.flame/2 end
    end
  end
  det.scaleVersion=2
end
local function temperatureCorrection(cfg,thermals)
  local sensor=thermals and thermals.coolantTemperature
  local definition=v and v.data and engine and v.data[engine.name] or {}
  if not finite(sensor) or sensor< -100 or sensor>250 or definition.thermalsEnabled==false or nop and thermals.updateGFX==nop then return 0,0,false,0 end
  local i,j,m=bracket(temperatureAxis,sensor)
  local fuel=cfg.fuelEnabled and (cfg.fuel[i]+(cfg.fuel[j]-cfg.fuel[i])*m) or 0
  local advance=cfg.advanceEnabled and (cfg.advance[i]+(cfg.advance[j]-cfg.advance[i])*m) or 0
  return fuel,advance,true,i
end
local function applyTune(data,validateOnly)

  if type(data)~='table' or data.version~=1 or type(data.tables)~='table' then return false,'Format de cartographie invalide.' end

  data=deepcopy(data);migrateDetonations(data.detonations)
  if type(data.modeMaps)=='table' then for _,bank in pairs(data.modeMaps) do if type(bank)=='table' then migrateDetonations(bank.detonations) end end end

  if data.fuelType~=(diesel() and 'diesel' or 'gasoline') then return false,'Carburant incompatible avec ce moteur.' end
  local dc=data.dieselFlame or {enabled=true,start=850,full=1100}
  if type(dc)~='table' or type(dc.enabled)~='boolean' or not finite(dc.start) or not finite(dc.full) or dc.start<600 or dc.full>1400 or dc.full<dc.start+50 then return false,'Seuils EGT diesel invalides (600–1400 °C, écart minimum 50 °C).' end
  local fc=data.flatShift or flatShift.defaults();local flatOK,flatMessage=flatShift.validate(fc);if not flatOK then return false,flatMessage end
  local temperature=data.temperatureCorrection or temperatureDefaults()
  if type(temperature)~='table' or type(temperature.fuelEnabled)~='boolean' or type(temperature.advanceEnabled)~='boolean' or type(temperature.axis)~='table' or #temperature.axis~=#temperatureAxis then return false,'Corrections de température invalides.' end
  for _,key in ipairs({'fuel','advance'}) do
    if type(temperature[key])~='table' or #temperature[key]~=#temperatureAxis then return false,'Dimensions de correction température invalides.' end
    for i,value in ipairs(temperatureAxis) do
      local n=temperature[key][i];local lo=key=='fuel' and -50 or -20;local hi=key=='fuel' and 100 or 20
      if temperature.axis[i]~=value or not finite(n) or n<lo or n>hi then return false,'Correction température hors limites : '..key end
    end
  end
  local tb=data.transbrake or transbrakeDefaults()
  if type(tb)~='table' or type(tb.enabled)~='boolean' or not finite(tb.maxHold) or tb.maxHold<1 or tb.maxHold>20 then return false,'Réglages transbrake invalides.' end
  local speedConfig=data.speedLimiter or speedLimiter.defaults()
  if not speedLimiter.valid(speedConfig) then return false,'Réglages du limiteur de vitesse invalides.' end
  local tractionConfig=data.tractionControl or traction.defaults()
  if not traction.valid(tractionConfig) then return false,'Réglages antipatinage invalides.' end
  local pm=data.pedalMap or pedalMapDefaults()
  if type(pm)~='table' or type(pm.enabled)~='boolean' or type(pm.axis)~='table' or #pm.axis~=#loadAxis or type(pm.values)~='table' or #pm.values~=#loadAxis then return false,'Table de pedale invalide.' end
  for y,p in ipairs(loadAxis) do
    if pm.axis[y]~=p or type(pm.values[y])~='table' or #pm.values[y]~=#rpmAxis then return false,'Axes de pedale incompatibles.' end
    for x=1,#rpmAxis do local n=pm.values[y][x];if not finite(n) or n<0 or n>100 or y==1 and n~=0 then return false,'Pedale hors limites ou commande non nulle a 0 %.' end end
  end
  local bt=data.boostTarget or boostTargetDefaults()
  if type(bt)~='table' or type(bt.enabled)~='boolean' or type(bt.values)~='table' or #bt.values~=#loadAxis then return false,'Table cible turbo invalide.' end
  for y=1,#loadAxis do
    if type(bt.values[y])~='table' or #bt.values[y]~=#rpmAxis then return false,'Dimensions cible turbo invalides.' end
    for x=1,#rpmAxis do local n=bt.values[y][x];if not finite(n) or n<0 or n>80 then return false,'Cible turbo hors limites : 0 a 80 psi.' end end
  end
  local gb=data.boostByGear or gearBoostDefaults()
  if type(gb)~='table' or type(gb.enabled)~='boolean' or type(gb.axis)~='table' or #gb.axis~=20 or type(gb.values)~='table' or #gb.values~=20 then return false,'Consigne turbo par rapport invalide.' end
  for i=1,20 do if gb.axis[i]~=i-2 or not finite(gb.values[i]) or gb.values[i]<-15 or gb.values[i]>40 then return false,'Rapport ou correction turbo invalide.' end end
  if data.dieselAirLimiterEnabled~=nil and type(data.dieselAirLimiterEnabled)~='boolean' then return false,'Activation du limiteur de fumee invalide.' end
  if data.dieselBoostAxis~=nil then
    if type(data.dieselBoostAxis)~='table' or #data.dieselBoostAxis~=#dieselBoostAxis then return false,'Axe pression diesel invalide.' end
    for i,n in ipairs(dieselBoostAxis) do if data.dieselBoostAxis[i]~=n then return false,'Axe pression diesel incompatible.' end end
  end

  for key,range in pairs(limits) do
    range=diesel() and dieselMapLimits[key] or range

    local grid=data.tables[key]

    if type(grid)~='table' or #grid~=#loadAxis then return false,'Dimensions invalides : '..key end

    for y=1,#loadAxis do

      if type(grid[y])~='table' or #grid[y]~=#rpmAxis then return false,'Dimensions invalides : '..key end

      for x=1,#rpmAxis do

        local n=grid[y][x]

        if not finite(n) or n<range[1] or n>range[2] then return false,'Valeur hors limites : '..key end

      end

    end

  end

  -- Optional for old profiles. Missing diesel limits retain the historical defaults.

  if diesel() then

    for key,range in pairs(dieselLimits) do

      local grid=data.tables[key]

      if grid~=nil then

        if type(grid)~='table' or #grid~=#loadAxis then return false,'Dimensions diesel invalides : '..key end

        for y=1,#loadAxis do

          if type(grid[y])~='table' or #grid[y]~=#rpmAxis then return false,'Dimensions diesel invalides : '..key end

          for x=1,#rpmAxis do local n=grid[y][x];if not finite(n) or n<range[1] or n>range[2] then return false,'Valeur diesel hors limites : '..key end end

        end

      end

    end

  end

  for key,axis in pairs({rpmAxis=rpmAxis,loadAxis=loadAxis}) do

    if type(data[key])~='table' or #data[key]~=#axis then return false,'Axes incompatibles.' end

    if key=='rpmAxis' then
      for i,n in ipairs(data[key]) do if not finite(n) or n<0 or n>12000 or n%1~=0 or i>1 and n<data[key][i-1]+25 then return false,'Axe régime : 12 valeurs croissantes de 0 à 12000, écart minimum 25 tr/min.' end end
    else for i,n in ipairs(axis) do if data[key][i]~=n then return false,'Axes incompatibles.' end end end

  end

  if not finite(data.limiter) or (data.limiter~=0 and (data.limiter<1000 or data.limiter>12000)) then return false,'Limiteur invalide.' end

  local tr=data.throttleResponse or {enabled=false,gamma=1}

  if type(tr)~='table' or type(tr.enabled)~='boolean' or not finite(tr.gamma) or tr.gamma<.5 or tr.gamma>2 then return false,'Reponse accelerateur invalide.' end

  if tr.enabled and type(engine.electricsThrottleName)~='string' then return false,'Commande accelerateur native indisponible.' end

  local idle=data.idleControl or idleModel.defaults({idleRPM=idleState and idleState.rpm or engine and engine.idleRPM})
  if not idleModel.valid(idle) then return false,"Cartographie ralenti invalide." end
  local rl=deepcopy(data.revLimiter or revLimiterDefaults())
  if type(rl)~="table" then return false,"Reglage limiteur invalide." end
  if rl.torqueCutTime==nil then rl.torqueCutTime=0 end
  if not finite(rl.torqueCutTime) or rl.torqueCutTime<0 or rl.torqueCutTime>.4 then return false,'Durée de coupure de couple : 0 à 0,4 seconde.' end
  if rl.ignitionAggression==nil then rl.ignitionAggression=0 end
  if not finite(rl.ignitionAggression) or rl.ignitionAggression<0 or rl.ignitionAggression>100 then return false,"Agressivite coupure allumage invalide." end

  if type(rl)~='table' or (rl.style~='hard' and rl.style~='soft') or (rl.cutMethod~='fuel' and rl.cutMethod~='ignition' and rl.cutMethod~='torque')

    or not finite(rl.hysteresis) or rl.hysteresis<50 or rl.hysteresis>1000 or not finite(rl.softRange) or rl.softRange<100 or rl.softRange>2000 then return false,'Reglage limiteur invalide.' end

  if data.limiter>0 and data.limiter-rl.hysteresis<500 then return false,'Regime de reprise trop bas.' end

  if data.limiter>0 and rl.style=='soft' and data.limiter-rl.softRange<500 then return false,'Zone progressive trop large pour ce regime.' end

  if rl.cutMethod=='ignition' and (diesel() or type(engine.cutIgnition)~='function') then return false,'Coupure allumage indisponible sur ce moteur.' end

  local o=data.overrun or overrunDefaults()

  if type(o)~='table' or (o.mode~='off' and o.mode~='pops' and o.mode~='continuous') then return false,'Mode deceleration invalide.' end

  for key,range in pairs({fuel={0,40},retard={0,40},minRPM={1200,12000},maxRPM={1200,12000},maxThrottle={0,10},duration={0,20},popHz={1,12}}) do

    if not finite(o[key]) or o[key]<range[1] or o[key]>range[2] then return false,'Reglage deceleration invalide : '..key end

  end

  if o.maxRPM<=o.minRPM then return false,'Plage de regime deceleration invalide.' end
  do local ok,message=overrunMap.validate(o);if not ok then return false,message end end

  local a=data.antiLag or antiLagDefaults()

  if type(a)~='table' or type(a.enabled)~='boolean' then return false,'Activation anti-lag invalide.' end

  for key,range in pairs({intensity={0,100},fuel={0,40},retard={0,40},minRPM={1200,12000},maxRPM={1200,12000},maxThrottle={0,10},duration={0,10}}) do

    if not finite(a[key]) or a[key]<range[1] or a[key]>range[2] then return false,'Reglage anti-lag invalide : '..key end

  end

  if a.maxRPM<=a.minRPM then return false,'Plage de regime anti-lag invalide.' end

  local lc=data.launchControl or launchDefaults()

  if type(lc)~='table' or type(lc.enabled)~='boolean' or type(lc.turboPrep)~='boolean' then return false,'Activation launch control invalide.' end

  for key,range in pairs({rpm={1500,8000},hysteresis={50,500},minThrottle={50,100},maxSpeed={1,10},maxHold={1,20},intensity={0,100},fuel={0,40},retard={0,40}}) do

    if not finite(lc[key]) or lc[key]<range[1] or lc[key]>range[2] then return false,'Reglage launch control invalide : '..key end

  end

  local tc=transmission and deepcopy(data.transmission or transmission.defaults(engine)) or data.transmission
  if transmission and transmission.migrate then transmission.migrate(tc) end
  if transmission then local ok,message=transmission.validate(tc);if not ok then return false,message end end
  local det=data.detonations or detonationDefaults()
  if type(det)~='table' or det.scaleVersion~=2 or type(det.shift)~='table' or type(det.limiter)~='table' then return false,'Detonations invalides.' end
  for _,kind in ipairs({'shift','limiter'}) do
    local cfg=det[kind]
    if type(cfg.enabled)~='boolean' then return false,'Activation detonations invalide.' end
    for key,r in pairs(kind=='shift' and {volume={0,100},flame={0,100},maxTime={.05,1},minPedal={10,100},minRPM={1000,10000}} or {volume={0,100},flame={0,100},hz={1,15}}) do
      if not finite(cfg[key]) or cfg[key]<r[1] or cfg[key]>r[2] then return false,'Detonation '..kind..' : '..key..' hors limites.' end
    end
  end
  local rc=deepcopy(data.rollingLaunch or rollingDefaults())
  if type(rc)~='table' or type(rc.enabled)~='boolean' or type(rc.turboPrep)~='boolean' then return false,'Activation rolling launch invalide.' end
  for key,range in pairs({rpm={1500,8000},hysteresis={50,500},minThrottle={10,100},minSpeed={5,250},maxSpeed={10,300},maxHold={1,20},intensity={0,100},fuel={0,40},retard={0,40}}) do
    if not finite(rc[key]) or rc[key]<range[1] or rc[key]>range[2] then return false,'Reglage rolling launch invalide : '..key end
  end
  if rc.maxSpeed<=rc.minSpeed then return false,'Plage de vitesse rolling launch invalide.' end
  rc.detonations=rc.detonations or rollingBangDefaults()
  local rd=rc.detonations
  if type(rd)~='table' or type(rd.enabled)~='boolean' then return false,'Activation detonations rolling invalide.' end
  for key,range in pairs({volume={0,100},flame={0,100},hz={1,12}}) do if not finite(rd[key]) or rd[key]<range[1] or rd[key]>range[2] then return false,'Detonation rolling : '..key..' hors limites.' end end

  local protection=data.protection or protectionDefaults()

  if type(protection)~='table' or type(protection.enabled)~='boolean' then return false,'Protection thermique invalide.' end

  for key,range in pairs({coolantStart={70,160},coolantEnd={75,180},oilStart={80,180},oilEnd={85,200},minTorque={10,100}}) do

    if not finite(protection[key]) or protection[key]<range[1] or protection[key]>range[2] then return false,'Seuil thermique invalide : '..key end

  end

  if protection.coolantEnd<=protection.coolantStart or protection.oilEnd<=protection.oilStart then return false,'Les seuils thermiques maximum doivent dÃƒÂ©passer les seuils de dÃƒÂ©but.' end

  if data.activeMode~=nil and not modes[data.activeMode] then return false,'Mode inconnu.' end

  if data.modeMaps~=nil then

    if type(data.modeMaps)~='table' then return false,'Modes invalides.' end

    for mode in pairs(modes) do

      local bank=data.modeMaps[mode]

      if type(bank)~='table' or bank.modeMaps~=nil or bank.activeMode~=nil then return false,'Cartographie manquante ou imbriquÃƒÂ©e : '..mode end

      local ok,message=applyTune(bank,true);if not ok then return false,mode..' : '..message end

    end

  end

  if validateOnly then return true end

  tune=deepcopy(data);tune.dieselSmokeGain=nil;if diesel() then tune.tables.dieselTorque=tune.tables.dieselTorque or dieselTable(130);tune.tables.dieselSmoke=tune.tables.dieselSmoke or dieselTable(1.15);tune.tables.dieselAirFuel=tune.tables.dieselAirFuel or dieselAirTable();tune.dieselBoostAxis=deepcopy(dieselBoostAxis);tune.dieselAirLimiterEnabled=data.dieselAirLimiterEnabled==true end;tune.launchControl=deepcopy(lc);launchBlocked=false;launchCut=false;launchElapsed=0;rollingInput=false;rollingBlocked=false;rollingElapsed=0;tune.antiLag=deepcopy(a);tune.overrun=deepcopy(o);tune.overrun.rpmMap=tune.overrun.rpmMap or overrunMap.defaults(o.fuel,o.retard);tune.overrun.popControl=tune.overrun.popControl or require("mr14karaECUPopControl").defaults(o.popHz);overrunElapsed=0;antiLagElapsed=0;sample={};revision=revision+1

  tune.idleControl=deepcopy(idle);limiterLatched=false;lastECUIgnitionCut=-100;lastRollingIgnitionCut=-100;tune.throttleResponse=deepcopy(tr);tune.revLimiter=deepcopy(rl)
  if transbrake then transbrake.reset() end;tune.transbrake=deepcopy(tb)
  if transmission and transmission.cancelShiftCut then transmission.cancelShiftCut() end
  tune.dieselFlame=deepcopy(dc);flatShift.reset();tune.flatShift=deepcopy(fc)
  tune.temperatureCorrection=deepcopy(temperature)
  speedLimiter.reset();tune.speedLimiter=deepcopy(speedConfig)
  tune.tractionControl=deepcopy(tractionConfig);traction.reset();tractionSample={}
  tune.boostTarget=deepcopy(bt);tune.detonations=deepcopy(det);tune.transmission=deepcopy(tc);tune.rollingLaunch=deepcopy(rc);rollingInput=false;rollingBlocked=false;rollingElapsed=0;tune.pedalMap=deepcopy(pm);tune.boostByGear=deepcopy(gb)

  tune.protection=deepcopy(protection);tune.activeMode=data.activeMode or 'route';tune.modeMaps=tune.modeMaps or {};for mode in pairs(modes) do tune.modeMaps[mode]=tune.modeMaps[mode] or payload(tune) end;tune.modeMaps[tune.activeMode]=payload(tune)

  syncNativeLimiter()

  updateSimpleControlButtons(true)
  rememberTune()
  return true,'Cartographie appliquee.'

end

local function setTuneJSON(json)
  if multiplayerRemote then status('Cartographie controlee par le proprietaire BeamMP.',false);return false end

  local ok,data=pcall(jsonDecode,json)

  if not ok then status('Fichier JSON invalide.',false);return false end

  local accepted,message=applyTune(data)

  status(message,accepted)

  return accepted

end

local function selectMode(mode)
  if multiplayerRemote then status('Mode controle par le proprietaire BeamMP.',false);return false end

  if not tune or not modes[mode] then status('Mode inconnu.',false);return false end

  local nextTune=deepcopy(tune.modeMaps[mode]);nextTune.modeMaps=deepcopy(tune.modeMaps);nextTune.activeMode=mode;nextTune.profileMeta=tune.profileMeta

  local ok,message=applyTune(nextTune);status(ok and ('Mode actif : '..mode) or message,ok);return ok

end

local function limiterFactor(rpm,dt)

  if not tune or tune.limiter<=0 or not engine or engine.hasFuel==false or engine.isDisabled or (engine.ignitionCoef or 1)<=0 then limiterLatched=false;lastECUIgnitionCut=-100;return 1 end

  local rl=tune.revLimiter or revLimiterDefaults()

  if not limiterLatched and rpm>=tune.limiter then limiterLatched=true;limiterRuntime.elapsed=0;limiterRuntime.count=limiterRuntime.count+1 end
  if limiterLatched then
    limiterRuntime.elapsed=limiterRuntime.elapsed+math.max(0,dt or 0)
    local hold=rl.cutMethod=='torque' and (rl.torqueCutTime or 0) or 0
    if rpm<=tune.limiter-rl.hysteresis and limiterRuntime.elapsed>=hold then limiterLatched=false end
  end

  if limiterLatched then return 0 end

  return rl.style=='soft' and clamp((tune.limiter-rpm)/rl.softRange,0,1) or 1

end

local function requestFaults()

  local active={};for _,record in ipairs(faultHistory) do if record.active then active[#active+1]=deepcopy(record) end end

  emit('Mr14ECUFaults',{vehicleId=obj:getID(),session=faultSession,history=deepcopy(faultHistory),active=active})

end

local function clearFaults()

  local keep={};for _,record in ipairs(faultHistory) do if record.active then keep[#keep+1]=record end end;faultHistory=keep;requestFaults()

end

local function resetFaultRuntime()

  for _,state in pairs(faultStates) do if state.record and state.record.active then state.record.active=false;state.record.recoveredTime=clock;state.record.endReason='reset' end end

  faultStates={};faultSession=faultSession+1

end

local function updateFaults(dt)

  local p=tune.protection or protectionDefaults()

  local definitions={

    {code='coolant_hot',message='Temperature eau elevee',condition=sample.thermalSensorsAvailable and sample.coolant>=p.coolantStart,recovered=sample.coolant<p.coolantStart-3,delay=.5},

    {code='oil_hot',message='Temperature huile elevee',condition=sample.thermalSensorsAvailable and sample.oil>=p.oilStart,recovered=sample.oil<p.oilStart-3,delay=.5},

    {code='thermal_protection',message='Protection thermique declenchee',condition=sample.protectionActive,recovered=not sample.protectionActive,delay=.2},

    {code='diesel_limited',message='Injection diesel limitee',condition=sample.diesel and sample.dieselLimited and sample.pedal>5 and sample.load>15,recovered=not sample.dieselLimited or sample.pedal<=5 or sample.load<=15,delay=.5},

    {code='thermal_sensors',message='Temperatures moteur indisponibles',condition=sample.engineRunning and not sample.thermalSensorsAvailable,recovered=sample.thermalSensorsAvailable or not sample.engineRunning,delay=2}

  }

  local changed=false;local count=0

  for _,d in ipairs(definitions) do

    local state=faultStates[d.code] or {elapsed=0};faultStates[d.code]=state

    if state.record and state.record.active then

      if d.recovered then state.record.active=false;state.record.recoveredTime=clock;state.record.endReason='recovered';state.elapsed=0;changed=true else count=count+1 end

    elseif d.condition then

      state.elapsed=state.elapsed+math.max(0,dt)

      if state.elapsed>=d.delay then

        local record={code=d.code,message=d.message,time=clock,session=faultSession,active=true,rpm=sample.rpm,load=sample.load,mode=sample.activeMode,revision=revision,coolant=sample.coolant,oil=sample.oil,protectionFactor=sample.protectionFactor,dieselTorqueLimit=sample.dieselTorqueLimit,dieselSmokeLimit=sample.dieselSmokeLimit}

        faultHistory[#faultHistory+1]=record;state.record=record;count=count+1;changed=true

        if #faultHistory>100 then local remove=1;for i,r in ipairs(faultHistory) do if not r.active then remove=i;break end end;table.remove(faultHistory,remove) end

      end

    else state.elapsed=0 end

  end

  sample.activeFaultCount=count;sample.faultSession=faultSession

  if changed then requestFaults() end

end

local function requestState()

  local t=engine and engine.turbocharger

  local present=t and t.isExisting or false

  emit('Mr14ECUState',{runtimeVersion='0.16.23',transmission=transmission and transmission.update() or {supported=false},throttleControlSupported=engine and type(engine.electricsThrottleName)=='string' or false,ignitionCutSupported=engine and type(engine.cutIgnition)=='function' and not diesel() or false,installed=engine~=nil,multiplayerRemote=multiplayerRemote,vehicleId=obj:getID(),vehicleModel=v and v.config and v.config.mainPartName or 'unknown',engineName=engine and engine.name,hardwareKey=hardwareKey,tuneKey=tuneKey,hasTurbo=present,turboControlSupported=present and type(t.setWastegateOffset)=='function' or false,antiLagSupported=present and type(t.setAntilagCoef)=='function' and t.updateFixedStep==turboWrapped and not diesel() or false,tune=tune,revision=revision})

end

local function transmissionSample()
  local ss=speedLimiter.status()
  sample.speedLimiterArmed=ss.armed;sample.speedLimiterActive=ss.active;sample.speedLimiterFactor=ss.factor;sample.speedLimiterReason=ss.reason;sample.speedLimiterTarget=tune and tune.speedLimiter and tune.speedLimiter.speed
  sample.limiterCutElapsed=limiterRuntime.elapsed;sample.limiterCutCount=limiterRuntime.count
  sample.flatShiftSupported=flatShift.supported;sample.flatShiftActive=flatShift.active;sample.flatShiftCount=flatShift.count;sample.flatShiftElapsed=flatShift.elapsed
  if not transmission or multiplayerRemote then return end
  local d=transmission.update()
  if not d.supported and engine and clock>=transmissionRetryAt then
    transmissionRetryAt=clock+2
    if transmission.bind(engine,function() return tune and tune.transmission end,function() return multiplayerRemote end,function() return sample.rollingActive or sample.launchActive end) then requestState();d=transmission.update() end
  end
  sample.shiftCutSupported=d.shiftCutSupported or false;sample.shiftCutActive=d.shiftCutActive or false;sample.shiftCutCount=d.shiftCutCount or 0;sample.shiftCutFactor=d.shiftCutFactor or 1;sample.shiftCutElapsed=d.shiftCutElapsed or 0;sample.shiftCutReason=d.shiftCutReason;sample.blipActive=d.blipActive or false;sample.blipTargetRPM=d.blipTargetRPM or 0;sample.blipCount=d.blipCount or 0;sample.transmissionSupported=d.supported;sample.transmissionActive=d.active or false;sample.shiftUpRPM=d.upRPM;sample.shiftDownRPM=d.downRPM;sample.gearChangeTime=d.shiftTime;sample.lockupRatio=d.lockupRatio
end
local function requestSample()
  transmissionSample()

  local s=deepcopy(sample)
  if diagnosticOK then s.diagnostic=diagnostic.build(s,multiplayerRemote) end

  s.engineName=engine and engine.name;s.hardwareKey=hardwareKey

  s.installed=engine~=nil;s.vehicleId=obj:getID();s.revision=revision

  emit('Mr14ECUSample',s)

end

local function resetTune() if not multiplayerRemote then speedLimiter.reset() end;flatShift.reset();if multiplayerRemote then status('Cartographie controlee par le proprietaire BeamMP.',false);return false end;if transmission and transmission.cancelShiftCut then transmission.cancelShiftCut() end;if transbrake then transbrake.reset() end;if flames then flames.reset() end;limiterLatched=false;lastECUIgnitionCut=-100;lastRollingIgnitionCut=-100;if antiLagOwned and turbo then turbo.setAntilagCoef(0) end;antiLagOwned=false;launchBlocked=false;launchCut=false;launchElapsed=0;rollingInput=false;rollingBlocked=false;rollingElapsed=0;traction.reset();tractionSample={};tune=defaults();syncNativeLimiter();overrunElapsed=0;antiLagElapsed=0;sample={};if engine then engine.mr14karaOverrun=nil end;revision=revision+1;dieselSmokeTick=0;rememberTune();requestState() end

local function launchHeld()

  local lc=tune and tune.launchControl

  local ev=electrics.values

  local pedal=tonumber(ev.throttle_input) or engine.requestedThrottle or 0

  local hold=math.max(tonumber(ev.brake_input) or tonumber(ev.brake) or 0,tonumber(ev.parkingbrake) or 0,tonumber(ev.clutch_input) or tonumber(ev.clutch) or 0)

  local speed=math.abs(tonumber(ev.wheelspeed) or tonumber(ev.airspeed) or 0)*3.6

  return lc and lc.enabled and not diesel() and pedal*100>=lc.minThrottle and (hold>=.5 or transbrake and transbrake.active()) and speed<=lc.maxSpeed

    and (engine.ignitionCoef or 1)>0 and engine.hasFuel~=false and not engine.isDisabled

    and engine.outputTorqueState~=0 and (engine.revLimiterWasActiveTimer or 999)>.1

    and not (tune.limiter>0 and engine.outputAV1*9.549296586>=tune.limiter)

end

local function rollingHeld()
  local rc=tune and tune.rollingLaunch
  if not rc or not rc.enabled or not rollingInput or rollingBlocked or multiplayerRemote or not engine or diesel() or type(engine.cutIgnition)~='function' then return false end
  local ev=electrics.values
  local pedal=tonumber(ev.throttle_input) or engine.requestedThrottle or 0
  local speed=math.abs(tonumber(ev.wheelspeed) or tonumber(ev.airspeed) or 0)*3.6
  return pedal*100>=rc.minThrottle and speed>=rc.minSpeed and speed<=rc.maxSpeed and (tonumber(ev.gearIndex) or 0)>0
    and (engine.ignitionCoef or 1)>0 and engine.hasFuel~=false and not engine.isDisabled and engine.outputTorqueState~=0
    and not (tune.limiter>0 and engine.outputAV1*9.549296586>=tune.limiter)
end
local function holdPreparation()
  if sample.rollingPrepActive then return tune.rollingLaunch,rollingHeld() end
  if sample.launchPrepActive then return tune.launchControl,launchHeld() end
  return nil,false
end
local function setRollingLaunchInput(value)
  if multiplayerRemote then return false end
  local wasRolling=sample.rollingActive or sample.rollingPrepActive
  rollingInput=value==true or type(value)=='number' and value>.5
  if not rollingInput then
    rollingBlocked=false;rollingElapsed=0;lastRollingIgnitionCut=-100;launchCut=false;sample.rollingActive=false;sample.rollingPrepActive=false
    if wasRolling then
      if antiLagOwned and turbo and turbo.setAntilagCoef then turbo.setAntilagCoef(0);antiLagOwned=false end
      if engine and engine.mr14karaOverrun then engine.mr14karaOverrun.active=false;engine.mr14karaOverrun.demand=0;if engine.mr14karaOverrun.rolling then engine.mr14karaOverrun.rolling[1],engine.mr14karaOverrun.rolling[2]=false,false end end
      if flames then flames.reset() end
      sample.overrunActive=false;sample.flameDemand=0;sample.overrunFuel=0
    end
  end
  return true
end
local function compatibleEngine(d)
  if type(d)~='table' then return false end
  if d.type=='combustionEngine' then return true end
  -- Native-derived factories keep this interface but have their own JBeam type.
  return type(d.deviceCategories)=='table' and d.deviceCategories.engine==true
    and (d.requiredEnergyType=='gasoline' or d.requiredEnergyType=='diesel')
    and type(d.torqueUpdate)=='function' and type(d.torqueCurve)=='table'
    and finite(d.outputAV1) and finite(d.intakeAirDensityCoef) and finite(d.invBurnEfficiencyCoef)
end

local function attach()

  restoreNativeLimiter()

  engine=powertrain.getDevice('mainEngine')

  if not compatibleEngine(engine) then

    engine=nil

    for _,d in pairs(powertrain.getDevices() or {}) do if compatibleEngine(d) then engine=d;break end end

  end

  if not engine then return end

  -- The browser connects straight to BeamNG: no Windows companion or user path.

  if obj.queueGameEngineLua then

    obj:queueGameEngineLua('if not extensions.mr14karaECUExternal then extensions.load("mr14karaECUExternal") end; if extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.start() end')

  end

  if finite(engine.maxRPM) or (finite(engine.revLimiterRPM) and finite(engine.revLimiterAV)) then

    nativeLimiter={engine=engine,rpm=engine.revLimiterRPM or engine.maxRPM,av=engine.revLimiterAV or engine.maxAV,originalRPM=engine.revLimiterRPM,originalAV=engine.revLimiterAV,ownedAV=engine.revLimiterAV,rpmModel=rpmModel and rpmModel.capture(engine,v and v.data and v.data[engine.name])}

  end

  local config=v and v.config or {}

  hardwareKey=configKey({model=config.mainPartName,parts=config.parts,partsTree=config.partsTree,vars=config.vars,engine=engine.name})
  -- Calibration identity excludes bodywork, wheels and unrelated tuning variables.
  local definition=v and v.data and v.data[engine.name] or {}
  local enginePart=definition.partOrigin or definition.partName
  if not enginePart then
    local selected={}
    for slot,part in pairs(config.parts or {}) do
      if type(slot)=='string' and (slot=='engine' or slot:match('_engine$')) then selected[slot]=part end
    end
    enginePart=selected
  end
  tuneKey=configKey({model=config.mainPartName,engine=engine.name,fuel=engine.requiredEnergyType,part=enginePart})

  idleState=idleModel.capture(engine)
  flatShift.reset();flatShift.box=nil;flatShift.supported=false
  for _,gb in pairs(powertrain.getDevices and powertrain.getDevices() or {}) do if gb.type=='manualGearbox' then flatShift.box=gb;flatShift.supported=gb.parent and type(gb.parent.clutchRatio)=='number' and not diesel() and type(engine.cutIgnition)=='function';break end end
  if transmission then transmission.bind(engine,function() return tune and tune.transmission end,function() return multiplayerRemote end,function() return sample.rollingActive or sample.launchActive end) end
  baseline=defaults()

  tune=tune or defaults()

  syncNativeLimiter()

  if engine.torqueUpdate==wrappedUpdate then return end

  originalUpdate=engine.torqueUpdate

  wrappedUpdate=function(device,dt)
    if multiplayerRemote then return originalUpdate(device,dt) end

    -- Only temporary coefficients: retain the engine's native damage, storage,

    -- traction/ignition cuts and thermal processing. Restore after every step.

    local density,efficiency=device.intakeAirDensityCoef,device.invBurnEfficiencyCoef

    local torqueState,nitrous=device.outputTorqueState,device.nitrousOxideTorque

    tractionSample=traction.update(dt,tune.tractionControl,device,rollingHeld() or launchHeld())
    local speedFactor=speedLimiter.update(dt,tune.speedLimiter,device,multiplayerRemote or v and v.mpVehicleType=='R')
    local tractionFactor=(tractionSample.factor or 1)*speedFactor
    local factor=limiterFactor(math.max(0,device.outputAV1*9.549296586),dt)

    device.intakeAirDensityCoef=density*(sample.baseTorqueFactor or sample.torqueFactor or 1)

    device.invBurnEfficiencyCoef=efficiency*(sample.baseFuelFactor or sample.fuelFactor or 1)/math.max(sample.baseTorqueFactor or sample.torqueFactor or 1,0.01)

    if factor<1 then

      if factor==0 and tune.revLimiter.cutMethod=='ignition' and not diesel() and device.cutIgnition then
        local aggression=tune.revLimiter.ignitionAggression or 0
        local hold=aggression>0 and (.02+.23*aggression/100) or 0
        device:cutIgnition(math.max(device.ignitionCutTime or 0,dt*1.5,hold));lastECUIgnitionCut=clock
      end

      -- Suppress combustion work and its native tank energy; also cover nitrous.

      -- Intermediate soft reduction is a native combustion-torque multiplier.

      device.outputTorqueState=(torqueState or 1)*factor

      if nitrous and factor==0 then device.nitrousOxideTorque=0 end

    end

    sample.limiterActive=factor<1;sample.limiterFactor=factor;sample.limiterCut=factor==0

    sample.torqueFactor=(sample.baseTorqueFactor or 1)*factor*tractionFactor;sample.fuelFactor=(sample.baseFuelFactor or 1)*factor*tractionFactor

    local lc=tune and (sample.rollingActive and tune.rollingLaunch or tune.launchControl)

    if factor==1 and antiLagPhysicsAge<.25 and (sample.launchActive or sample.rollingActive) and (sample.rollingActive and rollingHeld() or not sample.rollingActive and launchHeld()) then

      local rpm=device.outputAV1*9.549296586

      if rpm>=lc.rpm then launchCut=true elseif rpm<=lc.rpm-lc.hysteresis then launchCut=false end

      if launchCut and device.cutIgnition then device:cutIgnition(math.max(device.ignitionCutTime or 0,dt*1.5));if sample.rollingActive then lastRollingIgnitionCut=clock end end

    else launchCut=false end
    sample.rollingCut=sample.rollingActive and launchCut or false

    local throttleName=device.electricsThrottleName

    local nativeThrottle=throttleName and electrics.values[throttleName]

    local response=tune.throttleResponse or {enabled=false,gamma=1}

    if finite(nativeThrottle) and nativeThrottle>=0 and nativeThrottle<=1 then
      local command=mappedPedal(nativeThrottle,math.max(0,device.outputAV1*9.549296586))
      if transmission and transmission.blipThrottle then command=transmission.blipThrottle(command,dt,(sample.thermalSeverity or 0)>0 or factor<1) end
      if transmission and transmission.shiftCutThrottle then command=transmission.shiftCutThrottle(command,dt,(sample.thermalSeverity or 0)>0 or factor<1 or tractionFactor<.995 or transbrake and transbrake.active()) end
      electrics.values[throttleName]=command
    end

    -- Multiply the current native output state; never overwrite a native cut.
    device.outputTorqueState=(device.outputTorqueState or 1)*tractionFactor*flatShift.step(device,tune.flatShift,dt,multiplayerRemote or (sample.thermalSeverity or 0)>0 or factor<1 or tractionFactor<.995 or sample.launchActive or sample.rollingActive or transbrake and transbrake.active())
    if nitrous and speedFactor==0 then device.nitrousOxideTorque=0 end
    originalUpdate(device,dt)

    if throttleName then electrics.values[throttleName]=nativeThrottle end

    device.intakeAirDensityCoef=density

    device.invBurnEfficiencyCoef=efficiency

    device.outputTorqueState=torqueState;device.nitrousOxideTorque=nitrous

    -- Unburned overrun fuel consumes tank energy without adding crankshaft torque.

    local pedal=tonumber(electrics.values.throttle_input) or device.requestedThrottle or device.throttle or 0

    local prep,prepHeld=holdPreparation()
    local o=tune and (prep or sample.antiLagActive and tune.antiLag or tune.overrun)

    local rpm=math.max(0,device.outputAV1*9.549296586)

    if factor==1 and sample.overrunActive and o and ((prep and prepHeld and rpm>=o.rpm-o.hysteresis*2) or (not prep and pedal*100<=o.maxThrottle and rpm>=o.minRPM and rpm<=o.maxRPM))

      and (device.ignitionCoef or 1)>0 and not device.isDisabled and device.hasFuel~=false

      and device.outputTorqueState~=0 and (device.revLimiterWasActiveTimer or 999)>.1 then

      local curve=device.torqueCurve or {}

      local fullTorque=math.max(0,curve[math.floor(device.outputAV1*9.549296586)] or 100)

      -- Evaluate fuel at the physics RPM, rather than reusing the previous
      -- graphics-frame cell after crossing a map boundary.
      local injectedFuel=sample.overrunFuel
      if not prep and not sample.antiLagActive then injectedFuel=overrunMap.values(o,rpm) end
      local energy=fullTorque*math.max(0,device.outputAV1)*injectedFuel/100*3*dt

      device.spentEnergy=(device.spentEnergy or 0)+energy

    end

  end

  engine.torqueUpdate=wrappedUpdate

  turbo=engine.turbocharger

  if turbo and turbo.isExisting and turbo.setAntilagCoef and turbo.updateFixedStep then

    if turbo.updateFixedStep~=turboWrapped then

      turboOriginal=turbo.updateFixedStep

      turboWrapped=function(dt)

        antiLagPhysicsAge=antiLagPhysicsAge+math.max(0,dt)

        local a=tune and tune.antiLag

        local rpm=engine.outputAV1*9.549296586

        local pedal=tonumber(electrics.values.throttle_input) or engine.requestedThrottle or 0

        local prep,prepHeld=holdPreparation()
        local launchEligible=prep and prepHeld and rpm>=prep.rpm-prep.hysteresis*2

        local eligible=not limiterLatched and (sample.limiterFactor or 1)>=1 and antiLagPhysicsAge<.25 and ((launchEligible) or (sample.antiLagActive and a and pedal*100<=a.maxThrottle and rpm>=a.minRPM and rpm<=a.maxRPM))

          and (engine.ignitionCoef or 1)>0 and not engine.isDisabled and engine.hasFuel~=false

          and engine.outputTorqueState~=0 and (engine.revLimiterWasActiveTimer or 999)>.1

          and not (tune.limiter>0 and rpm>=tune.limiter)

        local coefficient=eligible and (launchEligible and (sample.rollingPrepCoef or sample.launchPrepCoef) or sample.antiLagCoef or 0) or 0

        if coefficient>0 or antiLagOwned then turbo.setAntilagCoef(coefficient);antiLagOwned=coefficient>0 end

        local requested=engine.requestedThrottle

        -- Exhaust energy surrogate only during the turbine calculation. Native

        -- curves, inertia, wastegate, BOV and damage remain in control. This is

        -- not an intake throttle opening and adds no crankshaft torque.

        if coefficient>0 then engine.requestedThrottle=math.max(requested or 0,math.sqrt(coefficient)) end

        turboOriginal(dt)

        engine.requestedThrottle=requested

      end

      turbo.updateFixedStep=turboWrapped

    end

  end

  if revision==0 and obj.queueGameEngineLua then
    obj:queueGameEngineLua('if not extensions.mr14karaECUStorage then extensions.load("mr14karaECUStorage") end; if extensions.mr14karaECUStorage then extensions.mr14karaECUStorage.restoreActive('..obj:getID()..','..string.format('%q',tuneKey)..') end')
  end
end

-- Additional tuning smoke; retain native diesel/oil/steam particles unchanged.

local function emitDieselSmoke(dt)

  local receivedFlame=multiplayerRemote and sample.dieselFlameDemand;local receivedEGT=multiplayerRemote and sample.dieselEGT
  sample.dieselFlameDemand=0;sample.dieselEGT=nil;sample.dieselHotSupported=false
  local receivedGain=multiplayerRemote and sample.dieselSmokeGain
  local receivedDemand=multiplayerRemote and sample.dieselSmokeDemand
  sample.dieselSmokeDemand=0;sample.dieselSmokeEmitting=false;sample.dieselSmokeLambda=0
  if not diesel() then return end
  local running=sample.engineRunning and not sample.ignitionCut and sample.rpm>650 and sample.pedal>5 and sample.load>15
  if not multiplayerRemote then running=running and not engine.isStalled and (engine.combustionTorque or 0)>0 end
  local demand,computedDensity=0,1
  if running then
    if multiplayerRemote then
      demand=finite(receivedDemand) and clamp(receivedDemand,0,1) or 0
    else
      local boostPsi=engine.turbocharger and engine.turbocharger.isExisting and math.max(tonumber(electrics.values.turboBoost) or 0,0) or 0
      local smokeLambda=sample.lambda*(1+boostPsi/14.7)
      sample.dieselSmokeLambda=smokeLambda
      local enrichment=math.max(0,((sample.fuelFactor or 1)-1)/0.3)
      local oxygenDeficit=clamp((1.65-smokeLambda)/0.65,0,1)
      local soot=clamp(enrichment*oxygenDeficit*clamp((sample.load-15)/85,0,1),0,8)
      demand=math.min(soot,1);computedDensity=math.max(soot,1)
    end
  end
  sample.dieselSmokeDemand=demand
  sample.dieselSmokeGain=multiplayerRemote and (receivedGain or 1) or computedDensity
  if dieselVolumeOK then
    local state=dieselVolume.update(engine,{running=running==true,engineRunning=sample.engineRunning==true and not sample.ignitionCut,
      pedal=(sample.pedal or 0)/100,demand=demand,rpm=sample.rpm,gain=sample.dieselSmokeGain,flameConfig=tune.dieselFlame,load=(sample.load or 0)/100,fuelFactor=sample.fuelFactor,lambda=sample.dieselSmokeLambda>0 and sample.dieselSmokeLambda or sample.lambda,remote=multiplayerRemote,remoteDemand=receivedFlame,remoteEGT=receivedEGT},dt)
    sample.dieselFlameDemand=state.flameDemand or 0;sample.dieselEGT=state.egt;sample.dieselHotSupported=state.hotSupported or false
    sample.dieselVolumetricAvailable=state.available;sample.dieselVolumetricReady=state.ready
    if state.ready then dieselSmokeTick=0;sample.dieselSmokeEmitting=demand>.0001;return end
  end
  if not running or type(obj.addParticleByNodesRelative)~='function' then dieselSmokeTick=0;return end

  if demand<0.015 then dieselSmokeTick=0;return end

  dieselSmokeTick=dieselSmokeTick+math.min(math.max(dt,0),0.1)*30*demand

  local count=math.min(math.floor(dieselSmokeTick+1e-9),3)

  if count<1 then return end

  dieselSmokeTick=math.max(0,dieselSmokeTick-count)

  local fast=math.abs(tonumber(electrics.values.airspeed) or tonumber(electrics.values.wheelspeed) or 0)>=10

  local particle=demand>=0.3 and (fast and 43 or 42) or (fast and 41 or 40)

  local seen={}

  local outlets=0

  for _,pipe in pairs(engine.thermals and engine.thermals.exhaustEndNodes or {}) do

    if pipe.finish~=nil and pipe.start~=nil then

      local key=tostring(pipe.finish)..':'..tostring(pipe.start)

      if not seen[key] and outlets<8 then

        seen[key]=true;outlets=outlets+1

        if not obj.inWater or not obj:inWater(pipe.finish) then

          for i=1,count do obj:addParticleByNodesRelative(pipe.finish,pipe.start,-3-sample.rpm*0.0004,particle,0,1) end

          sample.dieselSmokeEmitting=true

        end

      end

    end

  end

end

local function updateGFX(dt)
  updateSimpleControlButtons()

  if not engine or not tune then return end

  if multiplayerSession~=false and mpNativeOK and (multiplayerRemote or v and v.mpVehicleType=='R') then M.setMultiplayerRole(true);mpNative.receive(M) end
  if multiplayerRemote then
    multiplayerAge=multiplayerAge+dt
    local command={managed=true,active=false,demand=0,mode='off',style='off',maxThrottle=100}
    if multiplayerFrame and multiplayerAge<=.5 then
      command=deepcopy(multiplayerFrame.command);command.time=clock
      sample=deepcopy(multiplayerFrame.sample)
    else sample={rpm=0,load=0,pedal=0,lambda=1,fuelFactor=1,engineRunning=false,ignitionCut=false} end
    command.remote=true;command.engineRunning=sample.engineRunning==true
    if mpPlaybackOK then mpPlayback.update(engine,sample,multiplayerFrame~=nil and multiplayerAge<=.5) end
    clock=clock+dt;engine.mr14karaOverrun=command
    local bridge=rawget(_G,'volumetricBackfireBridge')
    if flames and not (bridge and bridge.ecuCompatible) then flames.update(dt,engine,command) end
    emitDieselSmoke(dt)
    return
  end

  if transbrake then transbrake.update(dt,tune.transbrake,engine,false) end
  antiLagPhysicsAge=0

  clock=clock+dt

  local rpm=math.max(0,engine.outputAV1*9.549296586)

  local load=clamp((engine.engineLoad or 0)*100,0,100)

  local fuel,x,y=interpolate(tune.tables.fuel,rpm,load)

  local target=interpolate(tune.tables.lambda,rpm,load)

  local advance=interpolate(tune.tables.advance,rpm,load)

  local boost=interpolate(tune.tables.boost,rpm,load)
  local boostByGearActive=false
  local selectedGear=tonumber(electrics.values.gearIndex)
  if tune.boostByGear and tune.boostByGear.enabled and selectedGear and selectedGear%1==0 and selectedGear>=-1 and selectedGear<=18 then
    boost=tune.boostByGear.values[selectedGear+2];boostByGearActive=true
  end

  local nativeBoostBase=nativeBoostTarget(selectedGear or 1)
  local boostTargetSupported=engine.turbocharger and engine.turbocharger.isExisting and type(engine.turbocharger.setWastegateOffset)=='function' and nativeBoostBase~=nil or false
  local boostTargetActive=tune.boostTarget.enabled and boostTargetSupported or false
  local boostTargetPsi,boostTargetCommanded
  if boostTargetActive then
    boostTargetPsi=clamp(interpolate(tune.boostTarget.values,rpm,load)+(boostByGearActive and boost or 0),0,80)
    boost=boostTargetPsi-nativeBoostBase
  end
  local temperatureBaseFuel,temperatureBaseAdvance=fuel,advance
  local temperatureFuel,temperatureAdvance,temperatureSupported,temperatureIndex=temperatureCorrection(tune.temperatureCorrection or temperatureDefaults(),engine.thermals or {})
  if diesel() then temperatureAdvance=0 end
  fuel=fuel*(1+temperatureFuel/100);advance=advance+temperatureAdvance
  local lambda=target/(fuel/100)

  local baseLambda=interpolate(baseline.tables.lambda,rpm,load,nil,baseline.rpmAxis)

  local requestedFuelFactor=baseLambda/lambda
  local fuelFactor=clamp(requestedFuelFactor,0.25,5)
  local boostRequested=boost

  local torqueFactor,risk

  local dieselTorqueLimit,dieselSmokeLimit,dieselRequestedFuel,dieselLimited=0,0,0,false
  local dieselAirLimit,dieselAirLimited=500,false

  if diesel() then

    dieselTorqueLimit=interpolate(tune.tables.dieselTorque,rpm,load)

    dieselSmokeLimit=interpolate(tune.tables.dieselSmoke,rpm,load)

    dieselRequestedFuel=fuelFactor
    if tune.dieselAirLimiterEnabled then
      local pressure=math.max(tonumber(electrics.values.turboBoost) or 0,0)
      dieselAirLimit=interpolate(tune.tables.dieselAirFuel,rpm,pressure,dieselBoostAxis)
      dieselAirLimited=dieselAirLimit/100<math.min(dieselRequestedFuel,dieselTorqueLimit/100,baseLambda/dieselSmokeLimit)-0.000001
    end

    -- Normalized air reserve, not a measured oxygen mass or exhaust smoke sensor.

    -- Both limiters reduce injected fuel and torque; no artificial fuel burning.

    fuelFactor=math.min(dieselRequestedFuel,dieselTorqueLimit/100,baseLambda/dieselSmokeLimit,dieselAirLimit/100)

    fuelFactor=math.max(fuelFactor,0.01)

    dieselLimited=fuelFactor<dieselRequestedFuel-0.000001

    lambda=baseLambda/fuelFactor

    torqueFactor=fuelFactor

    risk=clamp((1.3-lambda)/0.5,0,1)

  else

    local highLoad=clamp((load-35)/65,0,1)

    local delta=advance-interpolate(baseline.tables.advance,rpm,load,nil,baseline.rpmAxis)

    local margin=4*highLoad

    local timing=clamp(1-0.003*(delta-margin)^2,0.20,1)/math.max(1-0.003*margin^2,0.8)

    local bestLambda=baseLambda-0.02*highLoad

    local mixture=clamp(1-3*(lambda-bestLambda)^2,0.15,1)/math.max(1-3*(baseLambda-bestLambda)^2,0.8)

    torqueFactor=clamp(timing*mixture,0.10,1.08)

    risk=clamp((math.max(delta-margin-2,0)/12+math.max(lambda-0.98,0)*2)*highLoad,0,1)

  end

  local thermals=engine.thermals or {}

  local p=tune.protection or protectionDefaults()

  local function severity(value,startValue,endValue) return finite(value) and clamp((value-startValue)/(endValue-startValue),0,1) or 0 end

  local thermalSeverity=p.enabled and math.max(severity(thermals.coolantTemperature,p.coolantStart,p.coolantEnd),severity(thermals.oilTemperature,p.oilStart,p.oilEnd)) or 0

  local mapFuelFactor,mapTorqueFactor=fuelFactor,torqueFactor
  local protectionFactor=1-thermalSeverity*(1-p.minTorque/100)

  torqueFactor=torqueFactor*protectionFactor;fuelFactor=fuelFactor*protectionFactor

  if diesel() then lambda=baseLambda/math.max(fuelFactor,0.01) end

  if boostTargetActive then
    boostTargetCommanded=boostTargetPsi*protectionFactor
    boost=boostTargetCommanded-nativeBoostBase
  else boost=boost>0 and boost*protectionFactor or boost end

  local baseTorqueFactor,baseFuelFactor=torqueFactor,fuelFactor
  torqueFactor=torqueFactor*(tractionSample.factor or 1);fuelFactor=fuelFactor*(tractionSample.factor or 1)

  local limiterCoef=limiterFactor(rpm)

  torqueFactor=torqueFactor*limiterCoef;fuelFactor=fuelFactor*limiterCoef

  if diesel() then lambda=clamp(baseLambda/math.max(fuelFactor,.01),0,100) end

  if engine.turbocharger and engine.turbocharger.isExisting and engine.turbocharger.setWastegateOffset then engine.turbocharger.setWastegateOffset(boost) end

  local lc=tune.launchControl or launchDefaults()
  local rc=tune.rollingLaunch or rollingDefaults()
  local rollingActive=rollingHeld()
  if sample.rollingActive and not rollingActive and rollingInput then rollingBlocked=true end
  rollingElapsed=rollingActive and rollingElapsed+math.max(0,dt) or rollingElapsed
  if rollingElapsed>=rc.maxHold then rollingActive=false;rollingBlocked=true end

  local pedal=tonumber(electrics.values.throttle_input) or engine.requestedThrottle or 0

  if pedal*100<lc.minThrottle then launchBlocked=false;launchElapsed=0 end

  local held=launchHeld()

  if sample.launchActive and not held then launchBlocked=true end

  local launchActive=held and not launchBlocked and not rollingActive or false

  launchElapsed=launchActive and launchElapsed+math.max(0,dt) or launchElapsed

  if launchElapsed>=lc.maxHold then launchActive=false;launchBlocked=true end

  local o=tune.overrun or overrunDefaults()
  local overrunFuel,overrunRetard=require("mr14karaECUOverrunMap").values(o,rpm)

  local a=tune.antiLag or antiLagDefaults()

  local throttle=tonumber(electrics.values.throttle_input) or engine.requestedThrottle or engine.throttle or 0

  local eligible=o.mode~='off' and not diesel() and throttle*100<=o.maxThrottle

    and rpm>=o.minRPM and rpm<=o.maxRPM and (engine.ignitionCoef or 1)>0

    and not engine.isDisabled and engine.hasFuel~=false and engine.outputTorqueState~=0

    and (engine.revLimiterWasActiveTimer or 999)>.1

    and not (tune.limiter>0 and rpm>=tune.limiter)

  overrunElapsed=require("mr14karaECUOverrunMap").elapsed(o,sample.rpm,rpm,eligible,overrunElapsed,dt)

  local active=eligible and overrunFuel>0 and (o.duration==0 or overrunElapsed<=o.duration)

  local antiLagSupported=turbo and turbo.isExisting and turbo.updateFixedStep==turboWrapped and not diesel() or false

  local alsEligible=a.enabled and antiLagSupported and throttle*100<=a.maxThrottle

    and rpm>=a.minRPM and rpm<=a.maxRPM and (engine.ignitionCoef or 1)>0 and not engine.isDisabled

    and engine.hasFuel~=false and engine.outputTorqueState~=0 and (engine.revLimiterWasActiveTimer or 999)>.1

    and not (tune.limiter>0 and rpm>=tune.limiter)

  antiLagElapsed=alsEligible and antiLagElapsed+math.max(0,dt) or 0

  local alsActive=alsEligible and a.intensity>0 and a.fuel>0 and a.retard>0 and (a.duration==0 or antiLagElapsed<=a.duration)

  local warmth=clamp(((thermals.exhaustTemperature or 200)-40)/160,0,1)

  if alsActive then o=a;active=true end

  local alsCoef=alsActive and clamp(a.intensity/100*a.fuel/25*a.retard/30*warmth,0,1) or 0

  local holdConfig=rollingActive and rc or lc
  local launchPrep=(launchActive or rollingActive) and holdConfig.turboPrep and antiLagSupported and rpm>=holdConfig.rpm-holdConfig.hysteresis*2 and holdConfig.intensity>0 and holdConfig.fuel>0 and holdConfig.retard>0

  local launchPrepCoef=launchPrep and clamp(holdConfig.intensity/100*holdConfig.fuel/25*holdConfig.retard/30*warmth,0,1) or 0

  if launchPrep then o=holdConfig;active=true;alsActive=false;alsCoef=0 end
  local commandFuel=(launchPrep or alsActive) and o.fuel or overrunFuel
  local commandRetard=(launchPrep or alsActive) and o.retard or overrunRetard

  if thermalSeverity>0 or limiterCoef<1 then active=false;alsActive=false;alsCoef=0;launchActive=false;rollingActive=false;launchPrep=false;launchPrepCoef=0 end

  -- Normalize against slider maxima: each slider remains effective across its

  -- entire range instead of clipping at the historical 25% / 30-degree preset.

  local intensity=(launchPrep or alsActive) and o.intensity/100 or 1

  local demand=active and clamp(commandFuel/40*commandRetard/40*warmth*intensity,0,1) or 0

  local shiftKind,shiftBusy=nil,false
  for _,device in pairs(powertrain.getDevices() or {}) do
    if device.type=='automaticGearbox' or device.type=='dctGearbox' or device.type=='sequentialGearbox' then
      shiftKind=device.type;shiftBusy=device.isShifting==true or electrics.values.isShifting==true or (tonumber(electrics.values.isShifting) or 0)>0;break
    end
  end
  local rd=rc.detonations or rollingBangDefaults()
  local rollingEffects=rollingActive and rd.enabled and rc.intensity>0 and rc.fuel>0 and rc.retard>0 and rpm>=rc.rpm-rc.hysteresis*2 and warmth>0 and thermalSeverity<=0 and limiterCoef>=1 or false
  local det=tune.detonations or detonationDefaults()
  local limiterBang=det.limiter.enabled and not diesel() and tune.revLimiter.cutMethod=='ignition' and clock-lastECUIgnitionCut<=.15 and pedal*100>=det.shift.minPedal and thermalSeverity<=0 or false
  engine.mr14karaOverrun={rolling=rollingEffects and {true,clock-lastRollingIgnitionCut<=.12,rd.volume,rd.flame,rd.hz} or nil,bangs={det.shift.enabled,det.shift.volume*10,det.shift.flame*2,det.shift.maxTime,det.shift.minPedal,det.shift.minRPM,limiterBang,det.limiter.volume*10,det.limiter.flame*2,det.limiter.hz},time=clock,managed=(det.shift.enabled or det.limiter.enabled or rollingActive and rd.enabled or launchPrep or tune.overrun.mode~='off' or a.enabled and antiLagSupported) and not diesel(),active=active,

    demand=demand,mode=(launchPrep or alsActive) and 'continuous' or tune.overrun.mode,popHz=tune.overrun.popHz,maxThrottle=launchPrep and 100 or o.maxThrottle,rpm=rpm,
    style=launchPrep and 'launch' or alsActive and 'antilag' or tune.overrun.mode,lambda=lambda,extraFuel=commandFuel,
    advance=advance,baseAdvance=interpolate(baseline.tables.advance,rpm,load,nil,baseline.rpmAxis),retard=commandRetard,exhaustTemperature=thermals.exhaustTemperature,
    shiftKind=shiftKind,shiftGear=tonumber(electrics.values.gearIndex),shiftBusy=shiftBusy,shiftCut=(engine.ignitionCutTime or 0)>0,
    shiftPedal=pedal,shiftLoad=load/100,shiftFuel=det.shift.enabled and 40 or tune.overrun.fuel,shiftRetard=det.shift.enabled and 40 or tune.overrun.retard,shiftMaxRPM=engine.maxRPM,
    shiftAllowed=warmth>0 and thermalSeverity<=0 and limiterCoef>=1}
  require('mr14karaECUPopControl').apply(engine.mr14karaOverrun,tune.overrun,rpm)

  local bridge=rawget(_G,'volumetricBackfireBridge')

  local flameStatus=bridge and bridge.getECUStatus and bridge.getECUStatus() or {}

  if flames and not (bridge and bridge.ecuCompatible) then flameStatus=flames.update(dt,engine,engine.mr14karaOverrun) end



  local throttleCommand=engine.electricsThrottleName and tonumber(electrics.values[engine.electricsThrottleName]) or 0

  throttleCommand=clamp(throttleCommand or 0,0,1)

  local response=tune.throttleResponse or {enabled=false,gamma=1}

  local idleTarget,idleActive,idleVarying=idleModel.update(engine,idleState,tune.idleControl or idleModel.defaults({idleRPM=idleState and idleState.rpm or engine and engine.idleRPM}),dt,thermals.coolantTemperature,throttleCommand,math.abs(tonumber(electrics.values.wheelspeed) or 0),tune.limiter)
  sample={temperatureSupported=temperatureSupported,temperatureIndex=temperatureIndex,temperatureFuelCorrection=temperatureFuel,temperatureAdvanceCorrection=temperatureAdvance,temperatureBaseFuel=temperatureBaseFuel,temperatureBaseAdvance=temperatureBaseAdvance,temperatureCorrectionActive=temperatureFuel~=0 or temperatureAdvance~=0,transbrakeActive=transbrake and transbrake.active() or false,transbrakeSupported=transbrake and transbrake.status().supported or false,transbrakeReason=transbrake and transbrake.status().reason or "Module indisponible",transbrakeElapsed=transbrake and transbrake.status().elapsed or 0,tractionSupported=tractionSample.supported,tractionActive=tractionSample.active,tractionSlip=tractionSample.slip or 0,tractionReduction=(1-(tractionSample.factor or 1))*100,tractionReason=tractionSample.reason,rollingActive=rollingActive,rollingHeld=rollingInput,rollingBlocked=rollingBlocked,rollingElapsed=rollingElapsed,rollingTargetRPM=rc.rpm,rollingCut=rollingActive and launchCut or false,rollingPrepActive=rollingActive and launchPrep or false,rollingPrepCoef=rollingActive and launchPrepCoef or nil,boostTargetSupported=boostTargetSupported,boostTargetActive=boostTargetActive,boostTargetPsi=boostTargetPsi,boostTargetCommanded=boostTargetCommanded,nativeBoostBase=nativeBoostBase,idleTargetRPM=idleTarget,idleMapActive=idleActive,idleVariationActive=idleVarying,nativeIdleRPM=idleState and idleState.rpm or 0,nativeLimiterRPM=nativeLimiter and nativeLimiter.rpm or 0,physicalRedlineRPM=(engine.maxPhysicalAV or 0)*9.549296586,limiterTorqueExtended=nativeLimiter and nativeLimiter.rpmModel and nativeLimiter.rpmModel.target~=nil or false,commandedThrottle=throttleCommand*100,mappedThrottle=mappedPedal(throttleCommand,rpm)*100,throttleResponseActive=response.enabled or tune.pedalMap.enabled,pedalMapActive=tune.pedalMap.enabled,boostByGearActive=boostByGearActive,baseTorqueFactor=baseTorqueFactor,baseFuelFactor=baseFuelFactor,limiterActive=limiterCoef<1,limiterCut=limiterCoef==0,limiterFactor=limiterCoef,limiterMethod=tune.revLimiter.cutMethod,activeMode=tune.activeMode,modeIndex=tune.activeMode=='eco' and 1 or tune.activeMode=='sport' and 3 or 2,protectionActive=thermalSeverity>0,protectionFactor=protectionFactor,thermalSeverity=thermalSeverity,thermalSensorsAvailable=finite(thermals.coolantTemperature) or finite(thermals.oilTemperature),pedal=clamp(tonumber(electrics.values.throttle_input) or engine.requestedThrottle or engine.throttle or 0,0,1)*100,

    speedKmh=math.abs(tonumber(electrics.values.wheelspeed) or tonumber(electrics.values.airspeed) or 0)*3.6,

    gear=tonumber(electrics.values.gearIndex) or 0,ignitionCut=(engine.ignitionCutTime or 0)>0,

    engineRunning=(engine.ignitionCoef or 1)>0 and engine.hasFuel~=false and not engine.isDisabled and engine.outputTorqueState~=0,

    powerKW=(engine.combustionTorque or 0)*rpm*(2*math.pi/60)/1000,

    powerPS=(engine.combustionTorque or 0)*rpm*(2*math.pi/60)/735.49875,

    launchActive=launchActive,launchCut=launchActive and launchCut or false,launchPrepActive=launchActive and launchPrep or false,launchPrepCoef=launchPrepCoef,launchTargetRPM=lc.rpm,launchBlocked=launchBlocked,antiLagSupported=antiLagSupported,antiLagActive=alsActive,antiLagCoef=alsCoef,turboRPM=turbo and (turbo.turboAV or 0)*9.549296586 or 0,overrunActive=active,overrunFuel=active and commandFuel or 0,overrunRetard=active and commandRetard or 0,overrunMapActive=not launchPrep and not alsActive and tune.overrun.rpmMap and tune.overrun.rpmMap.enabled or false,flameDemand=demand,flameBridge=(bridge and bridge.ecuCompatible==true or flameStatus.supported==true),detonationLimiterReason=not det.limiter.enabled and 'Détonations rupteur désactivées' or tune.limiter<=0 and 'Régime ECU non défini : seul le limiteur du véhicule agit' or tune.revLimiter.cutMethod~='ignition' and 'Choisir la coupure Allumage dans Limiteur' or pedal*100<det.shift.minPedal and 'Accélérateur sous le seuil' or thermalSeverity>0 and 'Protection thermique active' or clock-lastECUIgnitionCut>.15 and 'En attente de coupure allumage ECU' or 'Coupure allumage détectée',detonationRollingCount=flameStatus.detonationRollingCount or 0,detonationTestCount=flameStatus.detonationTestCount or 0,detonationAudioError=flameStatus.detonationAudioError,detonationShiftCount=flameStatus.detonationShiftCount or 0,detonationLimiterCount=flameStatus.detonationLimiterCount or 0,detonationReason=not det.shift.enabled and 'Détonations de passage désactivées' or warmth<=0 and 'Échappement froid : attendre la montée en température' or thermalSeverity>0 and 'Protection thermique active' or limiterCoef<1 and 'Passages suspendus pendant le rupteur ECU' or flameStatus.detonationReason,detonationAudioReady=flameStatus.detonationAudioReady or false,flameRendererReady=flameStatus.ready,flameEmittedStrength=flameStatus.strength or 0,flamePulseCount=flameStatus.pulses or 0,overrunMode=launchPrep and 'launch' or alsActive and 'antilag' or tune.overrun.mode,time=clock,rpm=rpm,load=load,throttle=(engine.throttle or 0)*100,boostPsi=electrics.values.turboBoost or 0,

    dieselTorqueLimit=dieselTorqueLimit,dieselSmokeLimit=dieselSmokeLimit,dieselRequestedFuel=dieselRequestedFuel,dieselLimited=dieselLimited,dieselAirLimit=dieselAirLimit,dieselAirLimited=dieselAirLimited,

    lambda=lambda,afr=lambda*(diesel() and 14.5 or 14.7),targetLambda=target,fuelPercent=fuel,advance=diesel() and 0 or active and -commandRetard or advance,

    torque=engine.combustionTorque or 0,torqueFactor=torqueFactor,fuelFactor=fuelFactor,risk=risk,requestedFuelFactor=requestedFuelFactor,mapFuelFactor=mapFuelFactor,mapTorqueFactor=mapTorqueFactor,dieselSmokeFuelLimit=diesel() and baseLambda/dieselSmokeLimit or nil,dieselAirLimiterEnabled=tune.dieselAirLimiterEnabled==true,boostRequested=boostRequested,boostCommanded=boost,boostSupported=engine.turbocharger and engine.turbocharger.isExisting and type(engine.turbocharger.setWastegateOffset)=='function' or false,

    coolant=thermals.coolantTemperature or 0,oil=thermals.oilTemperature or 0,x=x,y=y,diesel=diesel(),torqueChangePercent=(torqueFactor-1)*100}

  transmissionSample()
  emitDieselSmoke(dt)

  updateFaults(dt)
  if multiplayerSession~=false and mpNativeOK and v and v.mpVehicleType=='L' then
    local ok,message=mpNative.publish(dt,tuneKey,revision,tune,engine.mr14karaOverrun,sample,engine.ignitionCutTime)
    if not ok and message~=mpNativeError then status(message,false);mpNativeError=message end
  end

end

local function init() speedLimiter.reset();speedButtonKey=nil;flatShift.reset();flatShift.box=nil;flatShift.supported=false;if transbrake then transbrake.reset() end;modeButtonKey=nil;traction.reset();tractionSample={};if transmission then transmission.reset() end;if dieselVolumeOK then dieselVolume.reset() end;if mpPlaybackOK then mpPlayback.reset() end;if mpNativeOK then mpNative.reset() end;mpNativeError=nil;multiplayerRemote=false;multiplayerFrame=nil;multiplayerAge=0;multiplayerRevision=nil;multiplayerSampleTime=nil;if flames then flames.reset() end;restoreNativeLimiter();limiterLatched=false;lastECUIgnitionCut=-100;lastRollingIgnitionCut=-100;faultHistory={};faultStates={};faultSession=1;if antiLagOwned and turbo then turbo.setAntilagCoef(0) end;antiLagOwned=false;if engine then engine.mr14karaOverrun=nil end;overrunElapsed=0;antiLagElapsed=0;launchBlocked=false;launchCut=false;launchElapsed=0;rollingInput=false;rollingBlocked=false;rollingElapsed=0;engine=nil;turbo=nil;tune=nil;clock=0;revision=0;sample={};dieselSmokeTick=0 end

local function reset() speedLimiter.reset();speedButtonKey=nil;flatShift.reset();if transbrake then transbrake.reset() end;modeButtonKey=nil;traction.reset();tractionSample={};if transmission then transmission.reset() end;if flames then flames.reset() end;limiterLatched=false;lastECUIgnitionCut=-100;lastRollingIgnitionCut=-100;resetFaultRuntime();if antiLagOwned and turbo then turbo.setAntilagCoef(0) end;antiLagOwned=false;if engine then engine.mr14karaOverrun=nil end;overrunElapsed=0;antiLagElapsed=0;clock=0;sample={};dieselSmokeTick=0;launchBlocked=false;launchCut=false;launchElapsed=0;rollingInput=false;rollingBlocked=false;rollingElapsed=0;attach() end

M.onExtensionUnloaded=function() speedLimiter.reset(); if flames then flames.reset() end;restoreNativeLimiter() end

M.init=init

M.initLastStage=attach

M.reset=function() speedLimiter.reset() end -- Keep the active tune across a vehicle reset.

M.resetLastStage=reset

M.updateGFX=updateGFX

M.testDetonation=function()
  if multiplayerRemote then status('Teste sur ta propre voiture.',false);return false end
  if not engine or not tune then status('Calculateur absent.',false);return false end
  if (sample.thermalSeverity or 0)>0 then status('Essai bloqué par la protection thermique.',false);return false end
  if not flames or not flames.test then status('Module ECU de flammes indisponible : redémarre BeamNG avec le nouveau ZIP.',false);return false end
  local ok,message=flames.test(engine,tune.detonations and tune.detonations.shift or detonationDefaults().shift)
  status(message,ok);return ok
end
M.requestState=requestState

M.requestSample=requestSample

M.getLimiterStatus=function() return sample.limiterFactor or 1,sample.limiterCut==true end

M.requestFaults=requestFaults

M.clearFaults=clearFaults

M.setTuneJSON=setTuneJSON
M.setMultiplayerRole=function(remote)
  if remote then speedLimiter.reset();flatShift.reset();if transmission and transmission.cancelShiftCut then transmission.cancelShiftCut() end;if transbrake then transbrake.reset() end;rollingInput=false;rollingBlocked=false;rollingElapsed=0 end
  if multiplayerRemote and not remote then
    if mpPlaybackOK then mpPlayback.reset() end
    if flames then flames.reset() end
    if engine then engine.mr14karaOverrun=nil end;sample={};multiplayerFrame=nil
  end
  multiplayerRemote=remote==true
end
M.setMultiplayerSession=function(active,remote) multiplayerSession=active==true;M.setMultiplayerRole(active and remote or false) end
M.requestMultiplayerStatus=function()
  local d=mpNativeOK and mpNative.status() or {error='Module de transport ECU absent'}
  d.installed=engine~=nil;d.remote=multiplayerRemote;d.frameAge=multiplayerAge;d.effectActive=multiplayerFrame and multiplayerAge<=.5 and multiplayerFrame.command.active or false
  if mpPlaybackOK then d.playback=mpPlayback.status() end
  if obj.queueGameEngineLua then obj:queueGameEngineLua('if extensions.mr14karaECUMultiplayer then extensions.mr14karaECUMultiplayer.reportVehicle('..obj:getID()..','..string.format('%q',jsonEncode(d))..') end') end
end
M.receiveMultiplayerJSON=function(kind,json)
  if not mpProtocolOK or not engine or type(json)~='string' or #json>65000 then return false,'Calculateur ou protocole indisponible' end
  local ok,d=pcall(jsonDecode,json);if not ok or not mpProtocol.header(d) then return false,'En-tete ECU invalide' end
  if d.key~=tuneKey then return false,'Identite moteur differente' end
  if kind=='tune' and mpProtocol.tune(d) then
    M.setMultiplayerRole(true)
    return applyTune(d.tune)
  elseif kind=='frame' and mpProtocol.frame(d) then
    M.setMultiplayerRole(true);multiplayerFrame=d;multiplayerAge=0
    if engine.cutIgnition and d.sample.ignitionCutTime>0 then engine:cutIgnition(d.sample.ignitionCutTime) end
    return true
  end
  return false,'Valeurs des effets invalides'
end
M.restoreActiveJSON=function(key,json)
  if key~=tuneKey or revision~=0 then return false end
  local ok=setTuneJSON(json);if ok then requestState() end;return ok
end

M.toggleSpeedLimiter=function()
  local active=speedLimiter.toggle(tune and tune.speedLimiter,engine,multiplayerRemote or v and v.mpVehicleType=='R')
  updateSimpleControlButtons(true);requestSample();return active
end
M.setRollingLaunchInput=setRollingLaunchInput
M.setTransbrakeInput=function(value)
  if not transbrake then return false end
  if value and (multiplayerRemote or v and v.mpVehicleType=='R') then return false end
  transbrake.setInput(value)
  transbrake.update(0,tune and tune.transbrake,engine,multiplayerRemote)
  updateSimpleControlButtons(true)
  return transbrake.active()
end
M.toggleTransbrake=function() return M.setTransbrakeInput(not (transbrake and transbrake.held())) end
M.selectMode=selectMode
M.updateSimpleControlButtons=function() updateSimpleControlButtons(true) end
M.cycleMode=function()
  if multiplayerRemote or v and v.mpVehicleType=='R' then status('Mode contrôlé par le propriétaire BeamMP.',false);return false end
  if not engine or not tune then return false end
  local nextMode=({eco='route',route='sport',sport='eco'})[tune.activeMode] or 'route'
  local ok=selectMode(nextMode)
  if ok then
    requestState()
    if type(guihooks.message)=='function' then guihooks.message('ECU : '..modeLabels[nextMode],3,'mr14karaECUMode') end
  end
  return ok
end

M.resetTune=resetTune

return M





