# ECU Studio By Mr14KaraFR
## Version 0.13.0 : cartographie de ralenti

Onglet Ralenti : régime cible à -10, 0, 20, 40, 60, 80 et 100 °C d’eau. Interpolation linéaire, cibles 500–2500 tr/min. Désactivé par défaut, commandes natives du moteur conservées. Chaque mode Éco/Route/Sport et profil conserve ses valeurs. Sans sonde d’eau, retour à la consigne d’origine. Désactiver restaure idleRPM/idleAV d’origine.

Variation optionnelle : amplitude de 0 à 300 tr/min, période 0,3 à 5 secondes, active à l’arrêt avec accélérateur relâché et moteur alimenté/allumé. La régulation native détermine le régime réel, qui peut différer de la consigne ; un réglage trop bas peut faire caler. Le ralenti élevé demandé par une autre commande du véhicule reste prioritaire. La consigne reste sous le limiteur ECU. Cible et état acquis dans les logs. Les anciens profils sont acceptés avec ralenti désactivé. Aucun fichier de flammes modifié.

Validation LuaJIT : application au véritable contrôleur ECU, interpolation, modes, oscillation, reprise des gaz, déplacement, absence de sonde, profils anciens, reset et restitution, priorité du ralenti élevé natif. Syntaxe JavaScript vérifiée. Essai dans BeamNG en conduite restant à confirmer.

## Version 0.14.0 : agressivité de coupure d’allumage

Limiteur → Coupure Allumage : curseur Agressivité 0–100 %. 0 conserve le comportement antérieur. Une valeur positive demande à la fonction native cutIgnition un maintien minimum de 20 + 2,3 × pourcentage millisecondes, soit 250 ms à 100 %. Le maintien se renouvelle tant que le rupteur ECU est déclenché ; après reprise sous l’hystérésis, le temps déjà demandé se termine normalement. Une coupure native plus longue n’est pas raccourcie. Le régime retombe davantage avant de reprendre, sans ajout de couple ou de carburant artificiel.

Essence avec cutIgnition native uniquement ; sans effet en coupure carburant, pas de coupure d’allumage diesel. Réglage propre à chaque mode et conservé dans les profils ; ancien profil : 0 %. Aucune modification des flammes ou de l’anti-lag/launch, aucun effet de flamme ajouté au rupteur.

Tests du vrai contrôleur ECU et de la fonction cutIgnition du jeu : anciennes cartographies, durées 25/50/100 %, priorité d’une coupure native plus longue, reprise sous hystérésis, bornes invalides, carburant/diesel, modes. Régressions ralenti et migration UI passées, syntaxe JavaScript valide. Ressenti dans le jeu à confirmer.

## Version 0.14.1 : correction du curseur de coupure

Conversion de la valeur texte du curseur AngularJS en nombre avant validation et application. Corrige le message « Réglages du limiteur invalides » après modification de l’agressivité. Conversion également lors du chargement des anciennes cartographies ; les valeurs hors limites restent refusées. Aucun changement des effets moteur ni du mod de flammes volumétriques.

## Version 0.14.3 : cartographies après changement de pièces

Les nouveaux profils sont identifiés par modèle, moteur, pièce moteur et carburant, indépendamment de la carrosserie, des roues et des variables de configuration. Les anciens profils restent chargeables sur le même modèle/moteur après validation des tables et du carburant ; leur ancien format ne permet pas de vérifier la pièce moteur exacte. Les références et le filtrage des profils suivent cette compatibilité. La comparaison des logs et le banc conservent leur vérification complète de configuration.

La cartographie appliquée est mémorisée dans la session de jeu pour le véhicule courant puis restaurée après sa reconstruction par le gestionnaire de pièces, si l’identité moteur reste compatible. Une seconde vérification dans le véhicule empêche de restaurer une commande retardée sur un autre moteur ou après une nouvelle application. Le bouton de remise à zéro met également à jour la mémoire. Les modifications encore présentes seulement dans l’éditeur ne sont pas appliquées automatiquement ; les profils enregistrés sur disque restent disponibles après redémarrage du jeu.

Validation : vrai contrôleur et cache LuaJIT avec reconstruction simulée, changement de carrosserie/roues/variables, conservation des réglages de ralenti et de coupure, remise à zéro, refus d’un autre moteur ou de données invalides ; anciens profils et noms stables dans l’éditeur. Régressions ralenti, coupure et curseur passées. Essai visuel en jeu restant à confirmer. Aucun fichier du mod de flammes modifié.

## Version 0.15.0 bêta : liaison BeamMP

Relais serveur séparé et extension client facultative pour partager les cartographies appliquées et les demandes d’effets du propriétaire. Environ 10 états par seconde, arrêt des demandes après 0,5 seconde sans données récentes, réception après reconstruction et arrivée tardive. Validation de propriété, de format et de limites. Aucune modification du mod de flammes. Le propriétaire garde la simulation physique ; les copies distantes reproduisent les effets. Voir INSTALLATION_FR.md dans le paquet serveur pour l’installation et les limites. Tests de contrôleur/client/relais passés ; validation en vraie session à deux PC encore nécessaire.

## Version 0.15.1 bêta : BeamMP sans plugin serveur

Remplace le transport 0.15.0 : les champs électriques personnalisés sont distribués par BeamMP. Cartographies à chaque changement et toutes les cinq secondes, états d’effets jusqu’à dix fois par seconde, copies distantes validées et extinction après 0,5 seconde sans nouvel état. Aucun relais Lua côté serveur requis, aucun fichier BeamMP ou flammes modifié. Voir INSTALLATION_BEAMMP_NATIVE_FR.md pour remplacer uniquement le ZIP ECU dans Resources/Client. Transport vérifié avec le code BeamMP installé ; essai réel à deux PC encore nécessaire.

## Version 0.15.2 : interface web intégrée

L’interface web est également intégrée dans un module Lua chargé avec le serveur HTTP. Les pages, scripts et styles restent disponibles pour cette session même si le ZIP est ensuite démonté par le gestionnaire de mods. Le serveur HTTP démarre dès l’activation du mod, même avant d’installer la pièce ECU. Les actions moteur nécessitent toujours un ECU présent. Démarrage Windows inchangé. Après mise à jour, redémarrer BeamNG ; en BeamMP, remplacer le ZIP ECU distribué par l’hébergeur. Aucune modification des flammes ou du protocole natif BeamMP. Tests HTTP du véritable module Lua avec fichiers virtuels absents et contrôle d’accès passés.

## Version 0.15.3 : cartographie BeamMP fractionnée

La cartographie est envoyée par fragments Base64 de 384 caractères dans un seul champ électrique remplacé à chaque envoi. La copie distante vérifie le transfert complet et son checksum avant application. Les fragments reçus dans le désordre ou lors de répétitions sont réunis sans appliquer une cartographie incomplète. Les états des effets continuent en parallèle et leur JSON est limité à 1 200 octets. Le journal fourni ne confirme pas la cause de la déconnexion ; cette correction supprime le risque du gros champ de cartographie. Le nom distribué reste exactement Mr14KaraFR_Programmable_ECU.zip. Aucun fichier du mod de flammes ni de BeamMP n’est modifié. Remplacer le ZIP chez l’hébergeur, redémarrer le serveur et reconnecter les joueurs. Validation à deux joueurs encore nécessaire.

## Version 0.15.4 : encodage compatible avec le Launcher BeamMP

Le code public du Launcher ferme volontairement le processus si un message de plus de 500 caractères contient la suite Zp, même au milieu d’un champ électrique. Les messages ECU précédents déclenchaient cette condition dans le test de transport. Le nouvel alphabet privé remplace Z par _ et utilise les en-têtes C2/F2 pour distinguer les données précédentes. Les tables, effets et leur synchronisation sont conservés. Tests : condition de fermeture reproduite avec l’ancien encodage, absente des nouveaux messages, décodage indépendant et transfert distant vérifiés. La validation sur le serveur réel reste nécessaire. Mettre à jour le ZIP distribué et reconnecter tous les joueurs. Aucun changement du Launcher ni du mod de flammes. Le ZIP garde le nom Mr14KaraFR_Programmable_ECU.zip sans version.

## Version 0.15.5 : réception ECU et effets distants

Chaque fragment est explicitement envoyé via MPElectricsGE.sendElectrics, qui vérifie la propriété du véhicule. Le polling électrique normal reste compatible ; les doublons sont ignorés. Le rôle distant connu par GE suffit pour lancer la réception sans attendre la mise à jour du type VE. Les effets de la copie distante utilisent l’état moteur transmis par le propriétaire, avec arrêt sur expiration ou moteur propriétaire arrêté. La physique du propriétaire reste inchangée. Le bandeau affiche les compteurs d’émission, états et cartographies reçus, fragments en attente, ECU absent et motifs de refus ; une session connectée seule ne signifie plus une réception réussie. Tests des vrais modules BeamMP GE/VE, sans polling, et du vrai rendu adaptateur ECU avec moteur distant arrêté. Remplacer le ZIP serveur, redémarrer et reconnecter tous les joueurs ; vérifier les compteurs sur le PC observateur et les effets réels. Aucun fichier BeamMP ou du mod de flammes modifié.

## Version 0.15.6 : régime et son de la voiture distante

Le compte-tours et la routine sonore native du moteur et de l’échappement utilisent le régime reçu du propriétaire. Cela reproduit les variations de ralenti et le régime du limiteur au lieu du régime simulé par la copie locale. Les valeurs mécaniques temporaires utilisées par la routine sonore sont restaurées après chaque appel ; la simulation et le déplacement du véhicule restent gérés par BeamMP. Les données périmées après 0,5 seconde ne sont plus utilisées. Les pops et les flammes restent inchangés. Tests de la vraie routine audio native et du vrai contrôleur : ralenti variable, limiteur, affichage, timeout, retour au rôle local. Le nom du ZIP reste Mr14KaraFR_Programmable_ECU.zip. Essai réel à deux joueurs encore nécessaire.

## Version 0.15.7 : ECU dans Modifications supplémentaires

Installation recommandée : garder le calculateur d’origine dans le moteur, puis sélectionner Calculateur reprogrammable By Mr14KaraFR — universel dans Modifications supplémentaires. Le contrôleur ECU se raccorde au moteur thermique présent sans remplacer sa définition JBeam. Les pièces ECU historiques dans le moteur restent disponibles. Choisir un seul accès au calculateur Mr14KaraFR pour éviter des contrôleurs en double. Un emplacement de modification supplémentaire accepte une pièce à la fois.

Le paquet couvre les types d’emplacement détectés dans les véhicules vanilla et les mods installés sur ce PC, avec des définitions distinctes compatibles avec les anciens slots et les slots2. Les futurs véhicules moddés ayant un autre emplacement peuvent demander une nouvelle définition. Un moteur moddé qui utilise combustionEngine est détecté même avec un nom interne personnalisé ; les moteurs utilisant un modèle entièrement personnalisé, les moteurs électriques et les systèmes de contrôle tiers ne sont pas universellement compatibles. Le calculateur conserve les dispositifs natifs et applique ses réglages d’injection, avance, limiteur, ralenti et suralimentation lorsque ces fonctions sont disponibles. Tests du vrai sélecteur de pièces et du vrai contrôleur avec moteur moddé. ZIP de nom fixe ; aucun changement des flammes.

## Version 0.15.8 : plages diesel et turbo élargies

Injection diesel et plafond de couple : 25 à 300 %. Lambda cible diesel et minimum de richesse : 0,4 à 4. Correction de consigne turbo : −15 à +40 psi (environ −1 à +2,76 bar), ajoutée à la consigne native, pour essence et diesel compatibles. Le plafonnement interne de la demande carburant diesel passe de 2 à 5 ; les limites de couple et de richesse conservent la priorité, donc le carburant effectivement appliqué peut rester inférieur à la demande. Les anciennes cartographies et les valeurs par défaut restent inchangées. Les plages essence d’injection et de lambda restent inchangées.

Éditeur, collage, import, contrôleur et validation multijoueur alignés. Le protocole accepte aussi le lambda estimé très élevé d’une coupure carburant diesel, sans perdre les états synchronisés. La pression réellement obtenue reste limitée par le turbo natif, et les protections/dégâts natifs restent actifs. Tests : 300 % effectivement appliqués à pleine charge, réduction par plafond de couple, bornes, rejet atomique, collage diesel et essence. Aucune intégration ni modification du mod de fumée volumétrique : attente de l’essai et de l’avis de l’utilisateur. ZIP fixe, version visible 0.15.8.

## Version 0.15.9 : plages essence élargies

Injection essence de 25 à 300 %, lambda cible de 0,4 à 4 et avance modélisée de −30 à +70 degrés. Correction turbo commune de −15 à +40 psi, ajoutée à la consigne native. Le plafond de demande carburant essence est relevé de 2 à 5 ; le modèle de rendement du mélange et de l’avance reste actif. Une forte injection n’est pas une multiplication identique de la puissance. Le turbo installé et les dégâts/protections natifs restent déterminants. Éditeur, collage et validation Lua alignés ; profils antérieurs conservés. Tests des bornes et du vrai passage moteur : 300 % de coefficient carburant, restauration des coefficients après la simulation native et baisse du rendement pour mélange/avance excessifs. Aucun changement des flammes ou de la fumée volumétrique. Version visible 0.15.9, nom du ZIP inchangé.

## Version 0.15.10 : moteurs thermiques dérivés du moteur natif

La détection ne dépend plus uniquement du type exact combustionEngine. Un moteur utilisant un type personnalisé (par exemple combustionEngine_fixed) est aussi accepté lorsqu’il conserve la catégorie engine, un carburant gasoline/diesel, une fonction torqueUpdate, une courbe de couple et les coefficients temporaires de densité/carburant nécessaires à l’ECU. Les moteurs électriques et interfaces incompatibles restent exclus. Tests : chargement du Lua fourni, catégorie réelle de sa factory, contrôleur sous type/nom personnalisés, limiteur relevé et cas incompatibles refusés. La voiture complète et son JBeam n’ont pas encore été testés. Aucun fichier du mod moteur d’origine n’est modifié.

## Version 0.15.11 : liaison fumée volumétrique diesel

Compatible avec Mr14KaraFR_Diesel_Volumetric.zip installé séparément. L’adaptateur ECU pilote son modèle de densité pour le moteur contrôlé par l’ECU, sans modifier le ZIP de fumée. Injection et richesse appliquées, charge et air turbo déterminent la demande : propre donne peu/pas de fumée additionnelle, riche sous charge donne davantage de fumée. Les plafonds de couple/richesse continuent de limiter le carburant réellement appliqué. L’interface indique mod disponible, rendu prêt et demande en %. Les autres moteurs conservent le modèle de fumée d’origine. Quand le rendu est prêt, les particules de suie supplémentaires de l’ECU sont remplacées par les volumes ; sans le mod ou sans rendu prêt, les particules supplémentaires restent le secours.

La demande est transmise via BeamMP et reproduite sur les voitures distantes, avec arrêt sur état périmé ou moteur propriétaire arrêté. Tests avec le vrai module de densité du ZIP installé : propre/riche, air turbo, rendu prêt sans doublons de suie ECU, copie distante et expiration, restauration du modèle d’origine. Le rendu graphique en jeu reste à confirmer par l’utilisateur. Les ZIP du mod de fumée et des flammes restent inchangés.

## Version 0.15.12 : diesel riche et densité volumétrique réglable

Tables diesel : injection et plafond de couple de 25 à 500 %, lambda cible et minimum de richesse de 0,2 à 4. Demande carburant interne jusqu’à 5 fois la base ; limites de couple/richesse restent réglables. Nouveau réglage Densité volumétrique diesel de ×0 à ×8, par mode, à appliquer comme la cartographie. Il multiplie la densité optique réelle après la simulation du mod de fumée, sans multiplier les volumes ni toucher leurs dimensions. Une demande de fumée nulle reste nulle ; pour beaucoup de fumée, demander un enrichissement réel sous charge, ouvrir les plafonds couple/richesse, puis augmenter la densité vers ×4/×8. La correction d’air turbo continue d’agir.

Gain transmis avec les états BeamMP et limité à 0..8. L’adaptateur GE ECU n’affecte que les voitures ECU enregistrées, expire après absence de mise à jour et restaure le modèle d’origine. Tests du vrai modèle de fumée : densité ×8/×0, absence d’accumulation exponentielle, autres véhicules inchangés ; contrôleur à 500 % et gain distant vérifiés. Aucune modification des ZIP indépendants de fumée/flammes. Version interface 0.15.12, ZIP de nom fixe.

## Version 0.15.13 : densité de suie automatique

Le curseur multiplicateur de fumée est supprimé et ignoré dans les profils de la version précédente. La densité dépend uniquement de la quantité de carburant réellement appliquée, du lambda/AFR estimé, de la charge et de la correction d’air turbo. L’enrichissement n’est plus saturé dès 130 % de carburant : une cartographie réellement plus riche continue d’augmenter la densité optique volumétrique. La limite numérique interne de suie est conservée pour borner le rendu, sans réglage artificiel à choisir. Les tables diesel restent à 500 % et lambda minimum 0,2. Les plafonds de couple/richesse restent pris en compte. Une forte demande non appliquée ne produit pas une fumée fictive.

La densité calculée est transmise aux voitures distantes. Tests : cartographie 300 % plus dense que 150 %, ancienne valeur multiplicateur ignorée, air turbo réduisant la suie, arrêt/expiration, modèle volumétrique réel. Aucun changement des ZIP indépendants de fumée ou de flammes. Version interface 0.15.13 ; nom du ZIP fixe.


## Version 0.15.14 — transitions de fumée diesel

Avec le mod diesel volumétrique 0.6.1, la demande de suie effective de l’ECU passe par une réponse commune : montée rapide, courte bouffée liée à la hausse de pédale et décroissance plus rapide au relâchement. Le gain optique est conservé par chaque volume déjà émis ; une baisse de carburant ne rend donc plus tout le panache existant transparent d’un coup. Les limites de couple/richesse et l’estimation d’air continuent de déterminer la demande de suie. Sans cette version du mod diesel, l’adaptateur conserve son ancienne réponse.

Les tests hors jeu incluent l’ECU réel, les variations de demande, l’expiration et les états distants. La validation en jeu reste nécessaire. Cette modification ne change pas les cartographies enregistrées.

## Version 0.15.15 : diagnostic des limites

Nouvelle page Diagnostic, avec résumé sous les cartographies : demande calculée injection/lambda, plafond après les limites, coefficient après protection thermique, coefficient appliqué par l’ECU au carburant principal. Le diagnostic indique les plafonds actuellement déterminants (modèle, couple diesel, richesse diesel et table fumée/air), rapporte les égalités entre limites et affiche les réductions successives de protection thermique / limiteur de régime. Ce sont des coefficients relatifs, pas une mesure d’injection en mg/coup ; les états natifs du moteur et le carburant additionnel des pops/launch restent séparés. Les moteurs arrêtés sont signalés sans prétendre injecter réellement ce coefficient.

Turbo : correction demandée et envoyée comparées à part de la pression mesurée, car l’offset est ajouté à la consigne native. Essence : rendement couple estimé du mélange/avance affiché. Le diagnostic détaillé est calculé à la lecture des mesures pour suivre le dernier passage physique, sans changer le comportement du moteur. Disponible sur le véhicule du propriétaire ; les états réseau ne contiennent pas toutes les étapes et ne sont pas présentés comme un diagnostic complet. Tests du vrai contrôleur : limite d’air, richesse, égalités couple/air, réduction thermique, dernière coupure régime et données incomplètes/distantes. ZIP de nom fixe, interface 0.15.15.

## Version 0.15.16 : table de pédale et turbo par rapport

Page Pédale : table régime × commande native d’accélérateur, sortie de 0 à 100 % interpolée. La ligne 0 % reste à zéro ; table désactivée par défaut et linéaire. Activée, elle prend la priorité sur la courbe simple historique, qui reste sauvegardée. Application temporaire avant le calcul de couple natif, puis restauration de la commande pour préserver les autres consommateurs. Régulation de ralenti et facteurs de réduction natifs conservés.

Page Turbo / rapport : corrections −15 à +40 psi par rapport, marche arrière, point mort et rapports 1..18. Activée, la correction sélectionnée remplace celle de la table turbo, en restant ajoutée à la consigne native (pas une pression absolue). Rapport inconnu/hors table : retour à la table turbo. Nécessite turbo et wastegate compatibles. Protection thermique prioritaire. Désactivée par défaut pour préserver les profils. Les deux configurations sont sauvegardées par mode, comparées par cellules/rapports et transmises avec la cartographie BeamMP ; états de pédale/rapport transmis aux copies distantes.

Tests du vrai contrôleur : interpolation pédale entre régime/commande, priorité sur gamma, commande nulle, restauration après calcul natif, corrections rapport/R/N/fallback, thermique, anciennes cartographies et validation. Tests éditeur : migration, comparaison et rejet des données invalides. Version visible 0.15.16, ZIP de nom fixe.

## Version 0.15.17 : réglages de départ des nouvelles tables

La table de pédale est activée par défaut, avec une réponse linéaire : chaque ligne conserve le pourcentage de pédale à tous les régimes. Le turbo par rapport reste désactivé et ses corrections initiales restent à 0 psi. Les nouveaux profils et les anciennes cartographies sans ces champs reçoivent ces valeurs ; un choix explicite déjà sauvegardé est conservé.

## Version 0.15.18 : courbes A/B et table de pression turbo cible

Acquisition : conserver deux logs en A/B affiche huit courbes superposées par mesure (régime, vitesse, turbo mesuré, cible envoyée, lambda estimé, facteur injection, protection thermique et limiteur). Chaque log commence à zéro ; les interruptions de plus d’une seconde et valeurs absentes ne sont pas reliées. Les courbes conservent les passages sous limiteur, contrairement aux moyennes du tableau à forte charge. Une configuration différente refuse la comparaison. Les CSV ont désormais un en-tête complet correspondant aux colonnes et incluent vitesse, pédale, état moteur et cible turbo.

Cible turbo : nouvelle table charge × régime, 0 à 80 psi relatifs à l’atmosphère, désactivée par défaut et initialisée à 15 psi. Lorsqu’elle est active, elle remplace la correction globale ; la correction par rapport s’ajoute à la cible, bornée à 0–80 psi. La protection thermique réduit ensuite cette cible. La commande est convertie en offset par rapport à la consigne native wastegate de la configuration du moteur, y compris ses réglages par rapport. Une consigne native absente ou un module turbo personnalisé conserve le fonctionnement par correction, sans déduire la consigne de la pression mesurée. Les cartographies Éco/Route/Sport, profils et transport BeamMP incluent la table. La pression réelle dépend de la capacité du turbo et de la charge. Aucun fichier des mods de flammes ou fumée n’est modifié.

## Version 0.15.19 : une seule table Turbo dans l’interface

Cartographies → Turbo propose un choix Correction / Pression cible. La grille et ses bornes suivent le mode sélectionné : correction −15 à +40 psi, cible 0 à 80 psi. Les valeurs des deux modes sont conservées indépendamment, y compris dans les profils et les modes Éco/Route/Sport. Le choix ne change la commande moteur qu’après Appliquer. Le sélecteur désactive l’accès à une nouvelle cible lorsque la consigne native est indisponible. Copier/coller, modifications par bloc, lissage et annuler/rétablir fonctionnent dans les deux modes. La page Cible turbo séparée est supprimée. La relecture utilise la table cible lorsque l’échantillon indique qu’elle était active. Le calcul moteur et la compatibilité des profils 0.15.18 sont conservés.

## Version 0.15.20 : rolling launch

Nouvelle page Rolling launch et commande native assignable « ECU Mr14KaraFR : Rolling launch (maintenir) » dans Options → Contrôles, catégorie Véhicule. Aucun raccourci existant n’est remplacé. Fonction désactivée par défaut, essence uniquement avec coupure d’allumage native. Valeurs de départ : 4000 tr/min, hystérésis 150 tr/min, 20–200 km/h, accélérateur ≥50 %, maintien maximal 8 s. Le bouton limite le régime et prépare le turbo si compatible ; relâcher supprime les commandes de maintien/préparation sans attendre la prochaine mise à jour graphique. Le système ne freine pas la voiture, ne gère pas la boîte et ne remonte pas un régime trop bas. Utiliser un rapport adapté.

La préparation reprend l’adaptateur anti-lag ECU et ses réglages intensité/injection/retard. Les protections et le limiteur principal restent prioritaires. Durée maximale et perte des conditions interrompent le maintien ; relâcher le bouton pour réarmer. Les entrées sont transitoires et ne sont pas enregistrées : appliquer une cartographie, changer de mode ou réinitialiser demande une nouvelle pression. Profils Éco/Route/Sport, logs CSV, transport BeamMP et affichage de la copie distante incluent les états rolling. Les comparaisons de couple à forte charge excluent les phases de rolling launch ; les courbes conservent ces phases. Aucun fichier du mod de flammes ou de fumée n’est modifié. Tests avec la fonction native cutIgnition et les modules BeamMP ; essai de conduite réel encore nécessaire.

## Version 0.15.21 : cartographies de boîtes automatiques classiques

Nouvel onglet Boîte automatique dans les interfaces jeu et web, désactivé par défaut. Tables rapport actuel × pédale pour montée et rétrogradage. Choix régime ou vitesse, avec valeurs conservées séparément ; à moins de 1 km/h, le mode vitesse utilise les seuils natifs. Jusqu’à 18 rapports, seules les lignes de la boîte installée sont affichées. Durées de montée et rétrogradage selon la pédale : 0,05 à 2 s, transition native du rapport sans modifier la résistance de la boîte. Kickdown par seuil de pédale et pourcentage du régime maximal moteur. Verrouillage configurable uniquement si le convertisseur possède déjà cette fonction native ; restauration à la désactivation.

Adaptateur pour la logique automatique vanilla vérifiée : contrôle de l’identité moteur/boîte et des références internes, refus des DCT/CVT et contrôleurs personnalisés incompatibles. Les décisions restent natives avec protections de surrégime, freinage, patinage et délais. P/R/N et mode manuel restent natifs. Rolling launch : maintien des seuils ordinaires, protection native du régime conservée. Aucune commande de boîte sur la copie distante BeamMP. Profils et Éco/Route/Sport incluent les tables ; logs ajoutent état, seuils, durée commandée et verrouillage. Tests avec la logique automatique installée : passage effectif 2→3, refus du rétrogradage en surrégime, fonction native setGearIndex, conversion vitesse et restauration. Intégration ECU, profils et tailles diesel/essence vérifiées. Essai de conduite réel encore nécessaire. Aucun fichier des mods de flammes/fumée modifié.

## Version 0.15.22 : sélection du mode Turbo compatible Angular 1.5

Le choix Correction / Pression cible utilise ng-options avec des valeurs booléennes. Les options ng-value pouvaient fournir les chaînes true/false au lieu des booléens sur Angular 1.5.8, déclenchant « Table cible turbo invalide » même pour des cellules valides. La migration convertit uniquement ces deux chaînes dans le mode actif et les profils Éco/Route/Sport ; les valeurs et le mode choisi sont conservés. Les booléens et nombres invalides restent refusés. Aucun réglage moteur ni mod de flammes/fumée modifié.

## Version 0.15.23 : détection et cartographies DCT

L’adaptateur reconnaît maintenant les doubles embrayages vanilla dctGearbox, dont la Vivace 7DCT diesel, en plus des automatiques classiques. Les tables régime/vitesse et kickdown utilisent la sélection native des seuils. La durée règle le transfert d’embrayage DCT, compensé selon l’agressivité native ; les délais de pré-engagement, la synchronisation et les protections restent natifs. Aucun convertisseur affiché pour les DCT. Le rapport utilisé est celui de l’embrayage primaire, même avant la première mise à jour graphique ou pendant la présélection. Détection classique/DCT réessayée après initialisation si les références natives étaient encore indisponibles ; l’interface reçoit l’état compatible mis à jour. CVT et logiques personnalisées incompatibles restent refusées. Tests avec le vrai module DCT installé, sept rapports, durée pour plusieurs agressivités natives et restauration en distant/désactivation/reset. Aucun mod de flammes ou fumée modifié.

## Version 0.15.24 : validation des cellules et affichage cohérent

Les durées de boîte ont un pas libre : les valeurs de départ 0,44/0,38/0,32/0,26 s sont acceptées, comme le prévoit la plage 0,05–2 s du calculateur. Le contrôle DOM ne refuse plus les valeurs valides pour une simple incompatibilité de pas HTML ; il conserve les contrôles de nombre et de plage, ainsi que la validation des cartographies. Une erreur DOM identifie le champ concerné. Les grilles Pédale et Boîte disposent désormais des mêmes cellules colorées et de la largeur disponible que les autres cartographies. Aucune valeur de profil modifiée.

## Version 0.15.25 : états BeamMP trop volumineux

Les états fréquents sont limités aux champs utilisés par les effets distants, y compris les événements de changement de rapport, et leurs nombres sont arrondis à trois décimales pour le transport uniquement. Les cartographies et calculs locaux conservent leur précision. La limite de 1200 octets JSON et les fragments de cartographie de 384 caractères sont conservés, ainsi que l’alphabet privé sans Z. Les données temporaires internes et champs inutilisés ne sont plus envoyés. Une erreur de taille ne réémet plus un ancien état ; elle remonte un échec explicite et disparaît après un nouvel état valide. Le diagnostic interne expose taille et limite du dernier état. Test de reproduction avec toutes les options et nombres à longue précision : 1094 octets après correction ; protocole, précision, conservation des données locales et reprise vérifiés. Transport BeamMP natif, lecture audio et rendu distant testés. Aucun fichier du mod de flammes ou fumée modifié. Tous les clients et le ZIP serveur doivent être mis à jour.

## Version 0.15.26 : détonation finale du mode continu

Une flamme continue suffisamment maintenue déclenche de nouveau sa salve visuelle et sa détonation finale lorsque l’échappement est d’origine ou non reconnu par la classification VBF. Le type de séquence est mémorisé dans l’adaptateur ECU ; les autres profils conservent leur classification et la variation des impacts massifs reste inchangée. Une salve finale ne se réarme pas elle-même. La fin de prise de contrôle utilise désormais l’état courant du propriétaire pour éviter une détonation sur arrêt moteur distant. Tests du vrai adaptateur : émission finale unique, absence après une impulsion courte ou moteur coupé, état propriétaire distant et arrêt distant. Modification de l’adaptateur ECU uniquement, aucun fichier du mod de flammes volumétriques modifié.

## Version 0.15.27 : grosses détonations de passage et de rupteur

Nouvel onglet Grosses détonations, avec réglages distincts pour changements de rapport rapides et rupteur à coupure d’allumage. Son 0–500 %, flamme 0–200 %, son et visuel désactivables séparément à 0. À partir de 200 % de son, utilisation des échantillons mega du mod déjà installé ; le gain continue de croître jusqu’à 500 %, sans modifier les fichiers VBF. Le visuel règle la force, le boost et l’échelle de sortie jusqu’aux limites réelles du rendu existant. Valeurs de départ activées : son 250 %, flamme 200 %. Essence uniquement.

Passages auto/DCT/séquentielle : détection du changement réel sous charge, régime et pédale minimaux configurables, durée maximale du passage 0,05–1 s (0,30 s au départ). Fonction indépendante du mode Pops/Flammes. Ne force ni changement de rapport ni coupure d’allumage. Rupteur : salves cadencées de 1 à 15 bangs/s (5 au départ), uniquement lors de la vraie coupure ECU à l’allumage ; la coupure carburant n’en produit pas. La vitesse de la boîte et l’agressivité physique du limiteur gardent leurs réglages distincts. Les protections thermiques et l’état moteur restent prioritaires.

Paramètres enregistrés en profils et Éco/Route/Sport, migration des anciens profils, validation JS/Lua et transmission compacte BeamMP à dix valeurs. État toutes options testé à 1145 octets sous le plafond de 1200. Tests du vrai adaptateur ECU : échelle maximale, gain 100/200/500, échantillon mega, silence et visuel nuls, rejet des passages lents, cadence du rupteur, arrêt, diesel, vrai cutIgnition, profils, DCT, fin du mode continu et transport distant. Essai audio/visuel en conduite encore nécessaire. Aucun fichier des mods de flammes/fumée modifié.

## Version 0.15.28 : audio dédié aux grosses détonations ECU

À partir de 200 % de son, l’adaptateur joue des WAV propres à l’ECU, dérivés de la banque enregistrée existante : transitoire accentué, composante grave ralentie et retombée courte. Trois variantes extérieures et trois variantes habitacle, attachées au véritable nœud d’échappement. Aucun son synthétique de l’essai rejeté n’est utilisé. La lecture native évite le multiplicateur de gain VBF : progression (volume/500)^0,75, limitée à 1, avec normalisation multi-sorties et respect du volume global du rendu. Les réglages inférieurs à 200 % gardent le bang habituel avec gain borné. Repli sur l’audio VBF si la source dédiée échoue. Indication Audio dédié ECU chargé dans la page et télémétrie locale.

Tests des véritables chemins PCM et appels createSFXSource2/setVolumePitchCT/playSFX, gain 200/300/400/500 strictement croissant, habitacle, plusieurs sorties, silence et arrêt des voix ; test du véritable adaptateur au passage de rapport confirmant le choix du fichier ECU et le gain maximal. L’effet perceptif reste à confirmer en jeu. Les WAV et le code sont dans le ZIP ECU uniquement ; aucun fichier du mod de flammes ou fumée n’est modifié. Tous les joueurs doivent mettre à jour le ZIP serveur pour disposer des nouveaux fichiers sonores.

## Version 0.15.29 : déclenchement des grosses détonations

Les grosses détonations explicitement activées ne sont plus annulées par un petit événement natif récent. Le détecteur garde la charge/pédale/régime d’avant coupure sur 0,4 s : la chute de couple pendant le passage ne supprime plus son éligibilité. Le temps de transfert mécanique reste limité par le réglage, mais la fin de coupure peut attendre une fenêtre supplémentaire de 0,7 s sans être considérée comme un passage lent. Un neutre transitoire sous signal de passage/coupure ne fait plus perdre le rapport précédent. La vraie coupure ECU au rupteur est mémorisée en physique pendant 0,15 s, au lieu de dépendre d’un timer natif déjà expiré au prochain rendu. Aucune nouvelle coupure ni commande de rapport n’est ajoutée.

La page Grosses détonations affiche la raison d’attente et les compteurs des déclenchements de passage/rupteur ; le rendu VBF déconnecté est signalé. Tests des cas reproduits : bang natif récent, charge retombée avant changement de rapport, coupure prolongée après passage rapide, neutre transitoire, vrai passage lent refusé et vraie coupure native très courte déjà terminée à la prochaine mise à jour graphique. Son dédié, mode continu et transport BeamMP conservés ; aucun mod de flammes/fumée modifié. Confirmation en conduite encore nécessaire.

## Version 0.15.30 : diagnostic des détonations

Retour à la banque VBF précédemment utilisée pour les grosses détonations ; audio dédié seulement en secours après un échec. Erreurs audio isolées du rendu visuel. Essai unitaire de détonation à l’arrêt, moteur essence démarré, véhicule propriétaire uniquement, sans modification de cartographie. Affichage de la version réellement exécutée et du motif d’attente au rupteur. Remplacer le ZIP jeu fermé ; actualiser aussi le ZIP serveur BeamMP. Essais automatisés réussis ; résultat sonore et visuel en jeu restant à confirmer. Aucun fichier du mod de flammes modifié.

## Version 0.15.31 : son 1 000 % et flammes plus fines

Plage sonore 0–1 000 % pour les passages et le rupteur, validée dans le contrôleur, les profils et BeamMP. Le gain à 1 000 % vaut deux fois celui à 500 %, pour la banque principale et le secours. Flammes réduites avec une courbe progressive, sans plancher à 55 % de force : intensité, largeur et durée sont séparées du volume sonore. Nouveaux profils : flamme 50 % ; réglages existants conservés. Mod VBF intact. Vérifications automatisées ; résultat sonore réel à confirmer dans le jeu.

## Version 0.15.32 : détonations désactivées par défaut

Les détonations de passage et de rupteur sont décochées sur les nouvelles cartographies, dans les trois modes. Les profils existants conservent leurs activations explicites.

## Version 0.15.33 : différence sonore réelle entre 500 et 1 000 %

Au-dessus de 500 %, lecture ECU de six banques progressivement renforcées issues des mêmes enregistrements VBF, en cabine et à l’extérieur. Fondu entre banques adjacentes, gains des sources limités à 1, sans dépendre d’un gain natif supérieur à 1. Mesure des fichiers : +7,39 dB RMS entre 500 et 1 000 % pour la première variante extérieure ; vérification avec saturation du gain simulée. À 500 % et moins, chemin VBF existant conservé. Aucune modification des flammes ni du ZIP VBF. Test en jeu encore nécessaire pour confirmer le volume perçu.

## Version 0.15.34 : commandes son et flamme de 0 à 100 %

Les deux commandes vont de 0 à 100 %. Son 100 % utilise la banque renforcée maximale ; flamme 100 % retrouve la pleine amplitude du rendu. Les faibles réglages restent disponibles et le son reste indépendant de la flamme. Conversion automatique des anciens profils et de chaque mode, sans double conversion. Les détonations restent décochées par défaut. Le protocole réseau conserve son échelle interne pour la compatibilité. Aucun fichier VBF modifié.

## Version 0.15.38 : interface Motorsport

Interface graphite et rouge avec navigation latérale Moteur, Turbo, Boîte, Effets, Diagnostic, Banc & logs, sous-rubriques, et accès direct Profils & références et Guide. Toutes les fonctions de la 0.15.34 sont conservées : tables essence/diesel, modes, ralenti, pédale, limiteur, turbo global/par rapport, TCU, effets, launch/rolling, protections, alertes, banc, acquisitions, relecture/comparaison, références et import/export. Les outils de lissage et l’aide sont repliables ; application et état des modifications restent visibles. Adaptation au redimensionnement réel du panneau dans le jeu et à la fenêtre web. Vérification dans Chromium avec Angular 1.5 du jeu et adaptateur externe réel, transport simulé : 18 pages accessibles, édition/appliquer avec tous les champs, profils, diesel, liens d’alertes, panneau natif et ouverture externe. Moteur, réseau et son de la 0.15.34 conservés ; version d’exécution seule actualisée. ZIP de nom inchangé.

## Version 0.16.0 BÊTA

La refonte Motorsport passe en version mineure 0.16.0, désormais identifiée BÊTA dans l’interface et les métadonnées. Les fonctionnalités et le comportement de la 0.15.38 sont conservés. Le nom de distribution reste Mr14KaraFR_Programmable_ECU.zip.

## Version 0.16.1 BÊTA : détonations propres au rolling launch

Ajout de réglages indépendants de bangs renforcés du rolling : activation, volume 0–100 %, flamme 0–100 %, cadence maximale 1–12/s. Réglages de départ : 80 %, 60 %, 6/s ; le rolling reste désactivé par défaut. Les événements sont liés aux coupures réellement commandées par le maintien, pas uniquement à un temporisateur. Disponibles sur moteurs essence compatibles sans obligation de turbo ; la préparation de pression reste réservée au turbo. Arrêt au relâchement, moteur arrêté, protections et sortie des conditions. Les autres modes conservent leur comportement. Paramètres inclus dans profils et trois modes, avec migration des anciens profils. Signal compact et validé pour BeamMP ; télémétrie diesel inutile omise pour les moteurs essence, sans mutation des mesures locales. Aucun fichier VBF ni banque sonore modifié. Vérifications Lua, adaptateur, API de coupure native, migration, interface Angular et taille de trame ; rendu réel et comparaison à la référence vidéo restant à valider.

## 0.16.2 BÊTA — Antipatinage ECU

Moteur → Antipatinage : activation indépendante par mode, patinage autorisé 0–100 %, réduction maximale 0–100 %, rapidité d’intervention 1–30 et restitution 0,1–10. Désactivé par défaut et pour les anciens profils. Compare la vitesse longitudinale réelle aux roues motrices les plus rapides, avec référence minimale de 3 m/s ; fonctionne aussi en AWD et marche arrière. Réduction progressive du couple combustion et du nitrous, cumulée aux aides natives sans modifier leurs réglages. Le maintien launch/rolling est prioritaire. Sans roue motrice valide ou capteur, aucune réduction ECU. Mesures et réduction dans l’interface, le diagnostic et les CSV locaux ; physique calculée seulement chez le propriétaire BeamMP. Tests automatisés moteur/interface ; comportement routier à valider en jeu.

## 0.16.3 BÊTA — Bouton de cartographie en jeu

Un bouton avec une icône de calculateur apparaît dans l’application native des commandes Start / ESP (Simple Powertrain Control) si l’ECU est installé. Un clic fait défiler Éco → Route → Sport → Éco. Couleurs verte / bleue / rouge et anneau 1/3, 2/3, plein ; le survol et le message de confirmation donnent le nom du mode. Utilise les trois cartographies appliquées et leurs réglages, sans ouvrir l’éditeur. Les changements passent par la sélection de mode existante, donc sauvegarde de configuration et transport BeamMP identiques. Véhicule distant : gris, sélection bloquée. Aucun fichier du jeu ni des mods de flammes remplacé. Si les trois cartographies sont identiques, le mode change mais le comportement reste identique.

## 0.16.4 BÊTA — Coup de gaz réglable au rétrogradage

Dans Boîte automatique : activation indépendante des tables de passage, ouverture 0–100 % et durée maximale 0,05–0,6 s. Désactivé par défaut et dans les profils anciens. Sur convertisseur compatible, impulsion temporaire lors d’une demande native de rétrogradage avant, arrêt au régime cible, au délai, sous 5 km/h, au launch/rolling, à distance, moteur arrêté ou cible trop proche du limiteur. La pédale et le coup de gaz sport natif restent prioritaires. Sur DCT, règle directement le rev-matching natif et son délai maximal, sans deuxième impulsion ; paramètres originaux restaurés à la désactivation/déconnexion/reset. Aucun rapport forcé. Inclut modes, profils et mesures CSV locales. Le ressenti dépend de la boîte et doit être vérifié en jeu.

## 0.16.5 BÊTA — Transbrake ECU

Boîte automatique → Transbrake : activation et durée maximale 1–20 secondes, défaut désactivé / 8 secondes. Automatiques classiques avec setLock natif uniquement (pas DCT/CVT). En première et à moins de 2 km/h : touche « ECU Mr14KaraFR : Transbrake (maintenir) » à attribuer dans les commandes, ou bouton natif près du Start au clic pour activer/libérer. Reconnu comme maintien par le launch control essence si activé. Libération immédiate au relâchement, timeout, changement de boîte, mode/profil/reset, moteur arrêté, véhicule quitté ou rôle distant. Un verrou déjà détenu par une autre commande n’est jamais acquis/libéré par l’ECU. Le verrouillage et le départ restent soumis à la physique du jeu. Réglages par mode et profil, état et durée dans les mesures locales. La capacité de cartographie BeamMP passe à 32 Kio / 114 fragments ; chaque fragment reste limité à 384 caractères, mêmes paquets bornés et alphabet privé évitant le crash launcher. Tous les joueurs doivent utiliser le même ZIP. Tests natifs automatisés ; départ réel à confirmer en jeu.

## 0.16.6 BÊTA — Brap naturel et reprise du couple

Boîte automatique → Brap naturel à la montée des rapports. Essence uniquement, automatiques natives compatibles à convertisseur et DCT avec commande d’accélérateur et coupure allumage. Option indépendante des tables de boîte, désactivée par défaut et dans les profils anciens. Types Progressif (baisse de commande puis reprise) et Haché (impulsions réelles d’allumage) ; durée 0,05–1 s, reprise 0–0,5 s, intensité 0–100 %, seuil RPM 1500–8000 et pédale 10–100 %. Le couple peut rester réduit après le passage ; aucune promesse de volume ou de timbre identique entre moteurs. Aucun son ajouté. Le contrôleur adapte uniquement les demandes de coupure des fonctions natives de changement de rapport, identifiées par leur fonction Lua ; il préserve les demandes du limiteur, du launch et des autres contrôleurs. Arrêt à la levée de pied, au rétrogradage, moteur arrêté, en rôle distant, sur intervention des protections/antipatinage ECU ou changement de mode/profil. Restauration des commandes temporaires après chaque pas moteur et des hooks au reset. Réglages par mode/profil, compteurs et mesures CSV locaux ; lecture distante via les états moteur BeamMP existants, sans reproduire la physique sur une voiture distante. Les impulsions rapides peuvent être moins détaillées chez l’observateur, selon le transport natif. Aucun fichier des mods de flammes/fumée modifié.

## 0.16.7 BÊTA — Corrections de température

Moteur → Température : deux tables selon le liquide de refroidissement, de −20 à 130 °C. Injection relative de −50 à +100 % ; avance du modèle ECU essence de −20 à +20°. Interpolation linéaire entre colonnes et maintien de la valeur du bord au-delà de l’axe. Chaque table démarre désactivée et à zéro, y compris dans les anciens profils. Zéro reste neutre. L’avance ne règle pas le début d’injection diesel. Sans température de liquide valide ou avec thermique désactivée, les corrections sont neutralisées.

Les écarts sont appliqués à la cartographie existante avant les limites de carburant, les limites diesel et les protections thermiques. Le fonctionnement thermique natif reste présent. Réglages conservés dans les trois modes et profils, comparaison par cellule et corrections incluses dans les CSV locaux. Aucun fichier des mods de fumée ou flammes modifié. Tests du contrôleur réel avec interpolation, neutralité, capteur absent, moteur essence/diesel, protections, coefficients temporaires, validation et migration ; interface Angular, transport BeamMP et régressions boîte vérifiés. Essai en conduite restant à confirmer.

## 0.16.8 BÊTA — Flat shift manuel

Boîte → Flat shift manuel : accélérateur maintenu et ouverture réelle de l’embrayage d’une boîte manualGearbox essence. Désactivé par défaut ; durée maximale 0,03–0,4 s (défaut 0,12), régime minimum 1500–10000 tr/min (3000), pédale minimum 50–100 % (90). Deux méthodes : allumage natif ou réduction temporaire à zéro de l’état de couple. Pas de son ajouté, pas de rapport forcé ni de synchroniseur contourné. La sonorité dépend du moteur et de l’échappement.

Armement uniquement après embrayage fermé sur un rapport avant, au-delà de 5 km/h. Une coupure par débrayage, sans répétition si l’embrayage reste ouvert ; fin au délai, réembrayage, levée de pied, arrêt, rétrogradage détecté, launch/rolling ou intervention des protections/antipatinage ECU. Le futur rapport ne peut être connu avant sa sélection : la coupure initiale peut donc précéder un rétrogradage. Une coupure native plus longue reste prioritaire. Modes, profils, comparaison et acquisition CSV inclus ; anciens profils migrés désactivés. Aucun mod de flammes/fumée modifié. Tests automatisés du contrôleur et de son wrapper physique, neutralité et restitution, gardes, validation, profils, interface Angular et transfert BeamMP ; ressenti en conduite à confirmer.

## 0.16.9 BÊTA — Flamme diesel concentrée

Effets → Flamme diesel : rendu rouge orangé court et fin aux sorties réelles, dans Fumée diesel volumétrique 0.9.20. Option automatique activée par défaut, seuils EGT estimée 850 / 1100 °C, réglables de 600 à 1400 °C avec au moins 50 °C d’écart. Estimation visuelle à inertie selon charge, régime, carburant effectif et richesse après estimation d’air ; ce n’est pas une mesure native de température des gaz ni un modèle thermodynamique. Aucun carburant ou couple ajouté pour l’effet. La chaleur seule ne suffit pas : enrichissement, charge et pédale requis. Arrêt à la levée de pied, moteur arrêté, sortie sous l’eau, désactivation ou expiration des données.

Le nouveau shader émissif du mod diesel est séparé du rendu de suie, avec profondeur opaque, jet de 12 à 55 cm et rayon de 1,8 à 4 cm suivant la demande. Huit sorties visibles maximum, sélectionnées par distance. Aucun fichier du mod de flammes volumétriques essence modifié. Modes, profils, comparaison et logs CSV conservent les réglages. BeamMP transmet la demande et l’EGT estimée du propriétaire, avec expiration ; les événements essence inutiles sont omis des trames diesel pour conserver les limites existantes. Les deux ZIP doivent être mis à jour chez tous les joueurs et sur le serveur. Tests automatisés des vraies liaisons ECU/VE/GE, gardes et profondeur shader compilé avec les en-têtes du jeu ; résultat visuel à vérifier en jeu.

Essai local 0.40.1 Direct3D12 : ETK 854 190d, cartographie de démonstration à 400 % et seuils 600/800 °C. Demande ECU observée avec EGT estimée 854 °C, jet inspecté au niveau des nœuds réels ; contrôle isolé du rendu maximal pour régler l’ordre après la fumée. À la levée de pied et restauration, zéro jet restant. Les seuils distribués restent 850/1100 °C. Validation réelle BeamMP à deux PC restant à effectuer.

## 0.16.10 BÊTA — Axes de régime libres et rupteur par couple

Cartographies → Précision des colonnes de régime : 12 colonnes repositionnables par mode (0–12000 tr/min entiers, ordre croissant, écart minimum 25 tr/min). Préréglages historique, diesel détaillé (250 tr/min dans la zone basse) et zone de dix points espacés de 100 tr/min autour d’un régime choisi, avec extrêmes 0/12000. Les colonnes restent au nombre de 12 pour conserver le format des tables et des profils. Les limites de transport BeamMP existantes restent applicables.

Le bouton de rééchantillonnage recalcule toutes les tables indexées par régime du mode courant, notamment pédale, cible turbo et limites diesel, par interpolation des anciennes valeurs ; aucun changement moteur avant Appliquer. Les autres modes gardent leurs axes. Les valeurs en bord sont prolongées hors axe. Déplacer les points peut lisser des détails de l’ancienne courbe ; l’annulation restaure axe et grilles ensemble. Import/export, comparaison (réalignement des références par interpolation), relecture des logs et profils acceptent les axes personnalisés. Les courbes de référence du modèle ECU conservent leur axe propre, pour éviter de déplacer la base moteur lorsque l’utilisateur déplace ses colonnes.

Moteur → Limiteur → Couple : coupure du multiplicateur natif outputTorqueState, sur essence et diesel. Durée minimale 0–0,4 s (défaut zéro pour compatibilité), avec hystérésis existante de 50–1000 tr/min ; réglage du régime par pas de 10 tr/min. Le temps avance au pas physique, sans double comptage à l’affichage. La reprise exige le temps minimum ET un régime sous le seuil. Les demandes natives plus restrictives et les dégâts restent actifs ; coefficients temporaires restaurés après le pas moteur. Le nitrous est couvert par la coupure. Aucun appel d’allumage pour ce mode et aucune injection imbrûlée imposée : la dépense native suit le travail moteur. Anciens profils et méthodes Carburant/Allumage conservés. Ce n’est pas une nouvelle table d’avance d’injection diesel.

Tests du contrôleur réel : interpolation à 100 tr/min, référence indépendante, pédale physique, axes par mode, validation, durée et reprise de couple diesel, restitution et migration ; éditeur Angular réel avec boutons, application et annulation ; cartographie diesel complète rééchantillonnée sur trois modes transmise sans perte en 113 fragments BeamMP bornés. Régressions température, flat shift, boîte auto/DCT, antipatinage, diagnostic, fumée et réception MP passées. Ressenti du nouveau rupteur en conduite et synchronisation sur deux PC restant à confirmer. ZIP stable : Mr14KaraFR_Programmable_ECU.zip. Aucun fichier des mods de fumée ou flammes modifié dans cette version.

## 0.16.13 BÊTA — Réarmement des zones pied levé et table simplifiée

Corrige le cas où une séquence à 6000 tr/min consommait la durée disponible et empêchait la reprise à 3000 tr/min sur la même décélération. Une zone sans injection remet le compteur à zéro ; le franchissement d’une colonne sans injection ou sans retard permet de démarrer une nouvelle zone de flammes. Les colonnes traversées sont inspectées même lorsque le régime chute assez vite pour sauter toute la zone intermédiaire entre deux mesures. La durée reste limitée dans une seule zone continue, et le comportement des profils historiques à valeurs fixes est conservé. Les conditions de pédale, régime, moteur, protections et limiteur restent prioritaires. Aucun fichier des mods de flammes ou de fumée modifié.

Onglet Pops / Flammes recentré sur le mode et la table pied levé : en-têtes RPM modifiables, lignes injection/retard, dégradé par valeur, zéros atténués et colonne moteur active encadrée. Suppression des entrées fixes en doublon et des mesures répétées sous la table. Conditions RPM, pédale, durée et cadence conservées dans un volet replié. Les anciens réglages fixes sont reportés à l’identique dans la table de l’éditeur lors de l’ouverture de cette page ; l’application au moteur exige toujours Appliquer. Mise en page vérifiée en fenêtre large et panneau compact avec défilement interne à la table.

Validation : vrai contrôleur ECU avec durée expirée à 6000 puis reprise à 3000, zones zéro injection/retard, saut direct entre deux régimes, durée dans une zone unique, durée illimitée, reprise des gaz et moteur arrêté ; interface Angular réelle, édition et application des deux zones ; régressions couple diesel, flat shift, température, fin de flamme continue et réception BeamMP. Ressenti en conduite restant à confirmer. Métadonnées, version d’exécution et en-tête alignés sur 0.16.13. Le packaging ne remplace plus les numéros de version des dépendances.

## Version 0.16.22 BÊTA : limiteur de vitesse

Moteur → Limiteur de vitesse : consigne 10–400 km/h, mode doux ou coupure de couple avec hystérésis de 1 km/h. Fonction désactivée par défaut. L'activation est transitoire par bouton ECU Studio, bouton natif à côté des commandes véhicule ou touche assignable sans raccourci imposé. Désactivation au freinage cochée par défaut, configurable. Après freinage, réinitialisation, changement de mode ou application de cartographie, une nouvelle activation manuelle est nécessaire. Les profils et modes conservent uniquement la configuration.

Essence et diesel : réduction temporaire du couple natif, sans commande de frein ou d'allumage ajoutée. Les coupures natives restent prioritaires ; nitrous neutralisé pendant une coupure complète puis restauré. Vitesse mesurée sur le déplacement du véhicule, indépendante du patinage. Arrêt moteur, perte du conducteur, capteur manquant et rôle distant désarment. Une descente peut dépasser la consigne : aucun freinage automatique. État et réduction visibles, données dans les CSV.

BeamMP : la banque du mode actif est omise du transport uniquement lorsqu'elle est strictement identique au contenu principal, puis reconstruite à réception. Aucun réglage perdu, limites et alphabet du transport inchangés. Ceci garde les cartographies diesel complètes sous le plafond réseau malgré les nouveaux contrôles des pops. Aucun fichier BeamMP, fumée ou flammes indépendant modifié.

## 0.16.23 — Température vers le rendu EGT

Le pont diesel fournit son EGT estimée au moteur en plus de la demande. Fumée 0.9.22 l’utilise pour réserver les jets longs aux températures extrêmes. Aucune modification des tables, seuils, calcul thermique ni protocole réseau.
