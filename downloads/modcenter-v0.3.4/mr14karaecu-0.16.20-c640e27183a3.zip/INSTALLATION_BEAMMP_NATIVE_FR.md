# ECU Studio By Mr14KaraFR 0.16.13 bêta — synchronisation native BeamMP

Cette version remplace la proposition 0.15.0 avec relais Lua serveur. Elle utilise le transport existant des valeurs électriques personnalisées de BeamMP. Aucun plugin serveur ni modification de BeamMP n’est requis.

## Installation chez l’hébergeur

1. Arrêter le serveur dans le panneau de l’hébergeur.
2. Dans `Resources/Client`, remplacer les anciens ZIP ECU par `Mr14KaraFR_Programmable_ECU.zip`, sans extraire ce ZIP. Ne pas retirer les autres mods ni les profils ECU.
3. Si le relais 0.15.0 a déjà été installé, retirer uniquement `Resources/Server/Mr14KaraECU`. Il n’est plus utilisé. S’il n’a pas été installé, aucune opération dans Server n’est nécessaire.
4. Relancer le serveur et reconnecter tous les joueurs. BeamMP distribue le ZIP automatiquement. Utiliser la même version du mod de flammes pour tous afin de voir ses effets ; ce paquet ne change aucun fichier de ce mod.

Le bandeau distingue la session BeamMP connectée de la réception réelle. Chaque voiture affiche émission ou réception, ECU absent, nombres d’états et de cartographies reçus, fragments en attente et erreurs de validation. Sur le PC observateur, les états reçus doivent augmenter, puis au moins une cartographie doit être reçue. Les compteurs d’émission du propriétaire ne sont pas un accusé de réception distant.

## Vérification à deux joueurs

Installer la pièce ECU, appliquer une cartographie et comparer les effets désactivés/activés chez un observateur : pops, flammes continues, différentes intensités, anti-lag avec turbo. Tester ensuite le changement de pièces, la remise à zéro, un joueur rejoignant plus tard et la disparition des effets après arrêt ou déconnexion. Attendre la réception complète de la cartographie : les fragments sont répétés après cinq secondes de pause et un transfert peut prendre plusieurs secondes supplémentaires.

## Fonctionnement

Les cartographies appliquées sont fractionnées lors d’un changement, puis le transfert est répété après cinq secondes de pause pour les arrivées tardives et reconstructions. Chaque fragment remplace le précédent dans le même champ, sans accumulation de champs. Les états d’effets sont publiés au maximum dix fois par seconde via les champs électriques personnalisés `mr14ecu_tune` et `mr14ecu_frame`. BeamMP ne les exclut pas dans la version installée utilisée pour les tests. Un encodage dérivé du Base64 remplace Z par _ pour éviter la suite Zp que le Launcher refuse dans les messages de plus de 500 caractères. Les en-têtes de transfert sont C2/F2 ; tous les joueurs doivent recevoir cette mise à jour.

Les copies distantes vérifient l’identité du moteur et les bornes des tables avant application, puis affichent les demandes d’effets du propriétaire au lieu de recalculer ses déclenchements. Le propriétaire garde sa simulation ; le mouvement et les informations moteur habituelles restent transmis par BeamMP. Les commandes locales de modification d’un ECU distant sont refusées. Les demandes de flammes sont arrêtées après 0,5 seconde sans état nouveau. Les métadonnées de profil, profils non appliqués et logs ne sont pas envoyés.

La cartographie sérialisée est limitée à 30 000 octets, transportée en fragments Base64 de 384 caractères (champ inférieur à 430 caractères, en-tête compris). Les états sont limités à 1 200 octets JSON. La cartographie ne s’applique qu’après réception complète et vérification du checksum. Les tables ECU normales passent cette limite. Un message explicite signale une cartographie trop volumineuse. La latence et la phase des pulses peuvent différer entre les PC : ce n’est pas une synchronisation de chaque particule ni une simulation du moteur sur le serveur.

## Validation

Test sous LuaJIT du vrai contrôleur et des fonctions de transport `check` et d’affectation des champs reçus de la version BeamMP installée : valeurs personnalisées transportées, cartographie restaurée sur une copie distante, répétition pour une arrivée tardive, états temporaires, délai d’arrêt, encodage vérifié indépendamment, données invalides et autre moteur refusés. Régressions ralenti, limiteur, profils et curseur vérifiées. Aucun essai à deux PC ni installation sur l’hébergeur n’a été effectué ici ; cette version reste bêta.

Le nom du ZIP reste fixe : `Mr14KaraFR_Programmable_ECU.zip`, même si sa version interne est maintenant 0.16.13. Le journal du lanceur ne fournit pas la raison de la déconnexion. Tests supplémentaires : taille des messages ECU bornée, transfert incomplet, fragments dans le désordre, doublons, checksum indépendant et charge maximale.

## Correction du crash Launcher

Windows a signalé une fermeture de BeamMP-Launcher.exe 2.8.1 (0xc0000409). Le prédicat de fermeture volontaire du code public est reproduit avec les anciens messages ECU et évité avec le nouvel alphabet privé, sans supprimer la synchronisation. Source : https://github.com/BeamMP/BeamMP-Launcher/blob/master/src/Network/GlobalHandler.cpp#L61-L66 . Vérifier sur le serveur : installer/retirer la pièce ECU, actualiser la voiture, changer de cartographie et comparer les effets chez un observateur. Les tests automatisés ne remplacent pas cet essai réel.

## Envoi explicite et effets distants (0.15.5)

Chaque fragment ECU est envoyé explicitement via le transport MPElectricsGE.sendElectrics du véhicule propriétaire, au lieu de dépendre uniquement de la prochaine collecte électrique. La réception utilise également le rôle distant attribué par GE. L’adaptateur ECU rend les effets selon l’état moteur reçu du propriétaire ; un état arrêté ou périmé arrête les effets. Tests exécutés via les fonctions GE d’envoi/routage et la réception VE installées, sans polling électrique, ainsi que le vrai adaptateur de flammes ECU. Aucun essai sur deux PC ne peut être certifié par ces tests ; vérifier le serveur réel après mise à jour.

## Régime distant (0.15.6)

Chez l’observateur, le son moteur et échappement natif ainsi que les valeurs électriques du compte-tours utilisent le régime reçu du propriétaire. Vérifier une variation de ralenti puis un limiteur de régime différent de l’origine. Le régime est publié au maximum dix fois par seconde ; la latence réseau et le lissage audio natif restent présents, les oscillations très rapides ne sont pas reproduites à l’échantillon près. Les mouvements sont toujours synchronisés par BeamMP ; cette fonction reproduit le régime visible et audible, pas une nouvelle simulation de couple distante. Les pops et flammes ne sont pas modifiés dans cette version.

## Installation ECU dans les modifications supplémentaires

Dans Pièces, conserver le calculateur d’origine du moteur et sélectionner Calculateur reprogrammable By Mr14KaraFR — universel dans Modifications supplémentaires. Utiliser soit cet accès, soit la pièce ECU Mr14KaraFR dans le moteur, pas les deux. L’emplacement ne permet qu’une modification supplémentaire à la fois ; l’accès moteur historique reste disponible. Les types d’emplacement vanilla et ceux des mods installés ont été détectés à la construction du ZIP ; un futur véhicule avec un autre slot nécessitera une adaptation. Moteurs thermiques standard, y compris moddés : le contrôleur détecte le moteur présent. Moteurs entièrement personnalisés : compatibilité à vérifier. Les pièces et les cartographies appliquées continuent d’être synchronisées par BeamMP après mise à jour de tous les joueurs.

## Fumée volumétrique pilotée par l’ECU

Pour utiliser le rendu volumétrique, distribuer aussi Mr14KaraFR_Diesel_Volumetric.zip via Resources/Client. Le ZIP ECU contient uniquement son adaptateur, pas le mod de rendu. Tous les joueurs doivent activer la même version du rendu. L’ECU transmet sa demande de suie, calculée avec le carburant effectivement appliqué et l’air disponible ; la copie distante la reproduit sans utiliser son propre état moteur pour estimer la densité. Régler les tables d’injection, lambda, plafond de couple et limite de richesse, puis comparer propre/riche sous la même charge. La pression turbo réduit le déficit d’air du modèle. L’interface affiche la demande et la disponibilité du rendu. Les tests du modèle Lua ne certifient pas le rendu graphique sur deux PC.
