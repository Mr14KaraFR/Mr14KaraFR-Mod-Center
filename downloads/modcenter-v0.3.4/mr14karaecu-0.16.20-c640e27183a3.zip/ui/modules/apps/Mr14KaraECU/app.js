function Mr14ECUValidRPM(a){return Array.isArray(a)&&a.length===12&&a.every(function(n,i){return Number.isFinite(n)&&Number.isInteger(n)&&n>=0&&n<=12000&&(!i||n>=a[i-1]+25);});}
function Mr14ECUResampleRPM(t,axis){
  if(!t||!Mr14ECUValidRPM(t.rpmAxis)||!Mr14ECUValidRPM(axis))throw Error('Axe régime invalide : 12 régimes croissants, écart minimum 25 tr/min.');
  var out=JSON.parse(JSON.stringify(t)),old=t.rpmAxis;
  function grid(g){return g.map(function(row){if(!Array.isArray(row)||row.length!==12)throw Error('Dimensions de table incompatibles.');return axis.map(function(n){if(n<=old[0])return row[0];if(n>=old[11])return row[11];for(var i=1;i<12;i++)if(n<=old[i])return Math.round((row[i-1]+(row[i]-row[i-1])*(n-old[i-1])/(old[i]-old[i-1]))*10000)/10000;});});}
  Object.keys(out.tables).forEach(function(k){out.tables[k]=grid(t.tables[k]);});
  if(out.pedalMap)out.pedalMap.values=grid(t.pedalMap.values);
  if(out.boostTarget)out.boostTarget.values=grid(t.boostTarget.values);
  out.rpmAxis=axis.slice();return out;
}
function Mr14ECUFlatShiftDefaults(){return {enabled:false,method:'ignition',duration:.12,minRPM:3000,minPedal:90};}
function Mr14ECUTemperatureDefaults(){return {fuelEnabled:false,advanceEnabled:false,axis:[-20,0,20,40,60,80,90,100,110,120,130],fuel:[0,0,0,0,0,0,0,0,0,0,0],advance:[0,0,0,0,0,0,0,0,0,0,0]};}
function Mr14ECUShiftCutDefaults(){return {enabled:false,style:'pulsed',duration:.17,recovery:.10,strength:100,minRPM:2500,minPedal:40};}
function Mr14ECUTractionDefaults(){return {enabled:false,slip:12,strength:70,response:10,recovery:3};}
function Mr14ECUInvalidCell(root){
  var fields=root.querySelectorAll('.gridwrap input');
  for(var i=0;i<fields.length;i++){
    var f=fields[i],v=f.validity;
    if(!f.disabled&&v&&(v.badInput||v.rangeUnderflow||v.rangeOverflow||v.valueMissing))return f.getAttribute('aria-label')||'cellule de cartographie';
  }
  return null;
}
function Mr14ECUHeat(n,min,max){return {'background-color':Number.isFinite(n)?'hsl(354,'+(10+30*Math.max(0,Math.min(1,(n-min)/(max-min))))+'%,'+(18+20*Math.max(0,Math.min(1,(n-min)/(max-min))))+'%)':'#23272d'};}
function Mr14ECUTurboBoolean(value){return value==='true'?true:value==='false'?false:value;}
function Mr14ECUGrid(t,key){return key==='boostTarget'?t.boostTarget.values:t.tables[key];}
function Mr14ECUTableKey(t,key){return key==='boost'&&t&&t.boostTarget&&t.boostTarget.enabled?'boostTarget':key;}
function Mr14ECURollingBangDefaults(){return {enabled:true,volume:80,flame:60,hz:6};}
function Mr14ECURollingDefaults(){return {detonations:Mr14ECURollingBangDefaults(),enabled:false,rpm:4000,hysteresis:150,minThrottle:50,minSpeed:20,maxSpeed:200,maxHold:8,turboPrep:true,intensity:40,fuel:25,retard:30};}
function Mr14ECUTransmissionDefaults(t){
  var diesel=t&&t.fuelType==='diesel',max=diesel?4500:6500,x={shiftCut:Mr14ECUShiftCutDefaults(),blip:false,blipPct:50,blipTime:.2,enabled:false,unit:'rpm',pedalAxis:[0,20,40,60,80,100],rpmUp:[],rpmDown:[],speedUp:[],speedDown:[],upTime:[],downTime:[],kickdown:true,kickdownPedal:90,kickdownPercent:65,lockup:{enabled:false,rpm:1800,range:300,minGear:2}};
  for(var g=1;g<=18;g++){x.rpmUp.push(x.pedalAxis.map(function(p){return Math.floor(1800+(max*.9-1800)*p/100);}));x.rpmDown.push(x.pedalAxis.map(function(p){return Math.floor(900+(max*.45-900)*p/100);}));x.speedUp.push(x.pedalAxis.map(function(p){return Math.min(15*g+p*.65,400);}));x.speedDown.push(x.pedalAxis.map(function(p){return Math.min(10*(g-1)+p*.2,395);}));}
  for(var i=0;i<6;i++){x.upTime.push(Math.round((.5-i*.06)*100)/100);x.downTime.push(Math.round((.45-i*.05)*100)/100);}return x;
}
function Mr14ECUValidateTransmission(t){
  var c=t.transmission;if(!c||typeof c.enabled!=='boolean'||!['rpm','speed'].includes(c.unit)||JSON.stringify(c.pedalAxis)!==JSON.stringify([0,20,40,60,80,100]))throw Error('Cartographie boîte invalide.');
  var ranges={rpmUp:[800,12000],rpmDown:[500,11000],speedUp:[5,400],speedDown:[0,395]};Object.keys(ranges).forEach(function(k){if(!Array.isArray(c[k])||c[k].length!==18||c[k].some(function(row){return !Array.isArray(row)||row.length!==6||row.some(function(v){return !Number.isFinite(v)||v<ranges[k][0]||v>ranges[k][1];});}))throw Error('Seuil boîte invalide : '+k);});
  for(var g=0;g<18;g++)for(var i=0;i<6;i++)if(c.rpmUp[g][i]<c.rpmDown[g][i]+200||c.speedUp[g][i]<c.speedDown[g][i]+2)throw Error('Montée et rétrogradage trop proches.');
  ['upTime','downTime'].forEach(function(k){if(!Array.isArray(c[k])||c[k].length!==6||c[k].some(function(v){return !Number.isFinite(v)||v<.05||v>2;}))throw Error('Durée boîte : 0,05 à 2 secondes.');});
  function range(n,a,b){return Number.isFinite(n)&&n>=a&&n<=b;}var l=c.lockup;
  var sc=c.shiftCut;if(!sc||typeof sc.enabled!=='boolean'||!['progressive','pulsed'].includes(sc.style)||!range(sc.duration,.05,1)||!range(sc.recovery,0,.5)||!range(sc.strength,0,100)||!range(sc.minRPM,1500,8000)||!range(sc.minPedal,10,100))throw Error('Coupure de passage invalide.');
  if(typeof c.blip!=='boolean'||!range(c.blipPct,0,100)||!range(c.blipTime,.05,.6))throw Error('Coup de gaz invalide.');
  if(typeof c.kickdown!=='boolean'||!range(c.kickdownPedal,50,100)||!range(c.kickdownPercent,40,90)||!l||typeof l.enabled!=='boolean'||!range(l.rpm,500,6000)||!range(l.range,100,2000)||!range(l.minGear,1,18)||!Number.isInteger(l.minGear))throw Error('Kickdown ou convertisseur invalide.');
}
function Mr14ECUDetonationDefaults(){return {scaleVersion:2,shift:{enabled:false,volume:25,flame:50,maxTime:.30,minPedal:60,minRPM:2500},limiter:{enabled:false,volume:25,flame:50,hz:5}};}
function Mr14ECUOverrunMapDefaults(o){var axis=[1200,2000,3000,4000,5000,6000,7000,8000,9000,10000,12000];return {enabled:false,axis:axis,fuel:axis.map(function(){return o.fuel;}),retard:axis.map(function(){return o.retard;})};}
function Mr14ECUValidateOverrunMap(o){var c=o&&o.rpmMap;if(c===undefined)return true;if(!c||typeof c.enabled!=='boolean')throw Error('Activation de la table pied levé invalide.');['axis','fuel','retard'].forEach(function(k){if(!Array.isArray(c[k])||c[k].length!==11)throw Error('Table pied levé : 11 colonnes requises.');for(var i=0;i<11;i++){var v=c[k][i];if(!Number.isFinite(v)||(k==='axis'?(!Number.isInteger(v)||v<1200||v>12000||i>0&&v<c.axis[i-1]+25):(v<0||v>40)))throw Error('Cellule pied levé invalide : '+k+' / '+(i+1));}});return true;}
function Mr14ECUControlDefaults(t){if(!t||!Array.isArray(t.rpmAxis)||!Array.isArray(t.loadAxis))return;if(t.overrun&&t.overrun.rpmMap===undefined)t.overrun.rpmMap=Mr14ECUOverrunMapDefaults(t.overrun);if(t.revLimiter&&t.revLimiter.torqueCutTime===undefined)t.revLimiter.torqueCutTime=0;if(!t.dieselFlame)t.dieselFlame={enabled:true,start:850,full:1100};if(!t.flatShift)t.flatShift=Mr14ECUFlatShiftDefaults();if(!t.temperatureCorrection)t.temperatureCorrection=Mr14ECUTemperatureDefaults();if(!t.transbrake)t.transbrake={enabled:false,maxHold:8};if(!t.tractionControl)t.tractionControl=Mr14ECUTractionDefaults();if(!t.detonations)t.detonations=Mr14ECUDetonationDefaults();else if(t.detonations.scaleVersion===undefined){['shift','limiter'].forEach(function(k){var d=t.detonations[k];if(d){if(Number.isFinite(d.volume))d.volume/=10;if(Number.isFinite(d.flame))d.flame/=2;}});t.detonations.scaleVersion=2;}if(!t.transmission)t.transmission=Mr14ECUTransmissionDefaults(t);if(!t.transmission.shiftCut)t.transmission.shiftCut=Mr14ECUShiftCutDefaults();if(t.transmission.blip===undefined)t.transmission.blip=false;if(t.transmission.blipPct===undefined)t.transmission.blipPct=50;if(t.transmission.blipTime===undefined)t.transmission.blipTime=.2;if(!t.rollingLaunch)t.rollingLaunch=Mr14ECURollingDefaults();if(!t.rollingLaunch.detonations)t.rollingLaunch.detonations=Mr14ECURollingBangDefaults();if(!t.boostTarget)t.boostTarget={enabled:false,values:t.loadAxis.map(function(){return t.rpmAxis.map(function(){return 15;});})};t.boostTarget.enabled=Mr14ECUTurboBoolean(t.boostTarget.enabled);if(!t.pedalMap)t.pedalMap={enabled:true,axis:t.loadAxis.slice(),values:t.loadAxis.map(function(p){return t.rpmAxis.map(function(){return p;});})};if(!t.boostByGear){var axis=[],values=[];for(var g=-1;g<=18;g++){axis.push(g);values.push(0);}t.boostByGear={enabled:false,axis:axis,values:values};}}
function Mr14ECURowAxis(t,key){return key==='dieselAirFuel'?(t.dieselBoostAxis||[0,2,5,10,15,20,30,40]):t.loadAxis;}
function Mr14ECUDieselAirDefaults(t){if(!t||t.fuelType!=='diesel')return;if(t.dieselAirLimiterEnabled===undefined)t.dieselAirLimiterEnabled=false;if(t.dieselBoostAxis===undefined)t.dieselBoostAxis=[0,2,5,10,15,20,30,40];if(t.tables&&!t.tables.dieselAirFuel)t.tables.dieselAirFuel=[100,110,130,160,200,250,350,500].map(function(n){return t.rpmAxis.map(function(){return n;});});}
function Mr14ECUMapRange(t,key){var ranges={fuel:[25,300],advance:[-30,70],lambda:[0.4,4],boost:[-15,40],dieselTorque:[25,500],dieselSmoke:[0.2,4],dieselAirFuel:[25,500]};if(t&&t.fuelType==='diesel'){ranges.fuel=[25,500];ranges.lambda=[0.2,4];}return key==='boostTarget'?[0,80]:ranges[key];}
function Mr14ECULogCells(t,row,key){
  if(!t||!row||!Number.isFinite(row.rpm)||!Number.isFinite(row.load)||!t.tables||!t.rpmAxis||!t.loadAxis||!Mr14ECUGrid(t,key))return [];
  function bracket(axis,n){if(n<=axis[0])return [0,0,0];for(var i=1;i<axis.length;i++)if(n<=axis[i])return [i-1,i,(n-axis[i-1])/(axis[i]-axis[i-1])];return [axis.length-1,axis.length-1,0];}
  var x=bracket(t.rpmAxis,row.rpm),y=bracket(Mr14ECURowAxis(t,key),key==='dieselAirFuel'?(row.boostPsi||0):row.load),cells={};
  [[x[0],1-x[2]],[x[1],x[2]]].forEach(function(a){[[y[0],1-y[2]],[y[1],y[2]]].forEach(function(b){var w=a[1]*b[1];if(w<=0)return;var id=b[0]+':'+a[0];if(!cells[id])cells[id]={x:a[0],y:b[0],rpm:t.rpmAxis[a[0]],load:Mr14ECURowAxis(t,key)[b[0]],value:Mr14ECUGrid(t,key)[b[0]][a[0]],weight:0};cells[id].weight+=w;});});return Object.keys(cells).map(function(k){return cells[k];});
}
function Mr14ECULogComparison(){
  var c={slots:{A:null,B:null},metrics:['torque','lambda','boostPsi','coolant','oil'],result:{rows:[],message:'Conserve deux acquisitions en A et B.'}};
  c.save=function(slot,rows,meta){if(['A','B'].indexOf(slot)<0||!Array.isArray(rows)||!rows.length)throw Error('Acquisition vide.');c.slots[slot]={rows:JSON.parse(JSON.stringify(rows.slice(0,6000))),meta:JSON.parse(JSON.stringify(meta))};return c.compare();};
  function bins(log){var groups={};log.rows.forEach(function(r){if(!Number.isFinite(r.time)||!Number.isFinite(r.rpm)||!Number.isFinite(r.load)||!Number.isFinite(r.gear)||r.gear<1||!Number.isFinite(r.pedal)||!Number.isFinite(r.speedKmh)||r.pedal<90||r.load<70||r.speedKmh<5||!r.engineRunning||r.ignitionCut||r.launchActive||r.rollingActive||r.antiLagActive||r.limiterActive)return;
    if(c.metrics.some(function(k){return !Number.isFinite(r[k]);}))return;
    var rpm=Math.round(r.rpm/100)*100,load=Math.round(r.load/10)*10,key=r.gear+':'+rpm+':'+load;
    var b=groups[key]||(groups[key]={rpm:rpm,load:load,gear:r.gear,count:0,modes:{},revisions:{}});b.count++;b.time=(b.time||0)+r.time;c.metrics.forEach(function(k){b[k]=(b[k]||0)+r[k];});b.modes[r.activeMode||'unknown']=true;b.revisions[r.revision]=true;
  });Object.keys(groups).forEach(function(k){groups[k].time/=groups[k].count;c.metrics.forEach(function(metric){groups[k][metric]/=groups[k].count;});});return groups;}
  c.compare=function(){var a=c.slots.A,b=c.slots.B;if(!a||!b)return c.result={rows:[],message:'Conserve deux acquisitions en A et B.',compatible:false};
    var same=['model','engine','hardwareKey','fuelType'].every(function(k){return a.meta[k]!==undefined&&a.meta[k]===b.meta[k];});
    if(!same)return c.result={rows:[],compatible:false,message:'Moteur, carburant ou configuration différents : comparaison refusée.'};
    var aa=bins(a),bb=bins(b),out=[];Object.keys(aa).forEach(function(k){if(!bb[k])return;var x=aa[k],y=bb[k],d={};c.metrics.forEach(function(metric){d[metric]=y[metric]-x[metric];});out.push({rpm:x.rpm,load:x.load,gear:x.gear,a:x,b:y,delta:d,conditions:Math.abs(d.coolant)<=5&&Math.abs(d.oil)<=10,mixed:Object.keys(x.modes).length>1||Object.keys(y.modes).length>1||Object.keys(x.revisions).length>1||Object.keys(y.revisions).length>1});});out.sort(function(x,y){return x.gear-y.gear||x.rpm-y.rpm||x.load-y.load;});
    return c.result={rows:out,compatible:true,message:out.length?out.length+' zones communes : même rapport, zones de 100 tr/min et 10 % de charge. Écarts B − A.':'Aucune zone commune sous forte charge : enregistre des passages comparables.',conditions:out.every(function(r){return r.conditions&&!r.mixed;})};
  };
  c.csv=function(){var lines=['time_s,time_B_s,rpm,load_bin_pct,gear,count_A,count_B,torque_A_Nm,torque_B_Nm,delta_torque_Nm,lambda_A_est,lambda_B_est,delta_lambda_est,boost_A_psi,boost_B_psi,delta_boost_psi,coolant_A_C,coolant_B_C,oil_A_C,oil_B_C,conditions_close,mixed_maps'];c.result.rows.forEach(function(r){lines.push([r.a.time,r.b.time,r.rpm,r.load,r.gear,r.a.count,r.b.count,r.a.torque,r.b.torque,r.delta.torque,r.a.lambda,r.b.lambda,r.delta.lambda,r.a.boostPsi,r.b.boostPsi,r.delta.boostPsi,r.a.coolant,r.b.coolant,r.a.oil,r.b.oil,r.conditions?1:0,r.mixed?1:0].join(','));});return lines.join('\n');};return c;
}
/* Raw time-aligned A/B curves: retain limits, missing values and acquisition gaps. */
function Mr14ECULogSeries(log,key){
  if(!log||!Array.isArray(log.rows))return [];
  var origin=log.rows.find(function(r){return Number.isFinite(r.time);});if(!origin)return [];
  return log.rows.map(function(r){var value=r[key];if((key==='boostTargetCommanded'||key==='boostTargetPsi')&&!r.boostTargetActive)value=null;return {time:Number.isFinite(r.time)?r.time-origin.time:null,value:typeof value==='number'&&Number.isFinite(value)?value:null};});
}
function Mr14ECUDrawLogComparison(canvas,comparison){
  var ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);
  if(!comparison.result.compatible)return;
  var specs=[['rpm','Régime · tr/min'],['speedKmh','Vitesse · km/h'],['boostPsi','Turbo mesuré · psi'],['boostTargetCommanded','Cible envoyée · psi'],['lambda','Lambda estimé'],['fuelFactor','Injection · facteur'],['protectionFactor','Protection · facteur'],['limiterFactor','Limiteur · facteur']];
  var colors=['#76b9ff','#ffbf75'],left=180,right=w-25,duration=0;
  ['A','B'].forEach(function(slot){Mr14ECULogSeries(comparison.slots[slot],'rpm').forEach(function(p){if(p.time!==null)duration=Math.max(duration,p.time);});});
  ctx.font='14px Segoe UI';ctx.fillStyle=colors[0];ctx.fillText('A',left,20);ctx.fillStyle=colors[1];ctx.fillText('B',left+45,20);
  specs.forEach(function(spec,lane){
    var series=['A','B'].map(function(slot){return Mr14ECULogSeries(comparison.slots[slot],spec[0]);}),min=Infinity,max=-Infinity;
    series.forEach(function(points){points.forEach(function(p){if(p.value!==null){min=Math.min(min,p.value);max=Math.max(max,p.value);}});});
    var top=40+lane*(h-72)/specs.length,bottom=top+(h-72)/specs.length-22;
    ctx.fillStyle='#e6edf4';ctx.fillText(spec[1],8,top+18);
    if(min===Infinity){ctx.fillStyle='#a1a8b3';ctx.fillText('Données absentes',left,top+18);return;}
    if(max===min){min-=.5;max+=.5;}else{var pad=(max-min)*.08;min-=pad;max+=pad;}
    ctx.fillStyle='#a1a8b3';ctx.fillText(min.toFixed(2)+' / '+max.toFixed(2),8,top+39);
    ctx.strokeStyle='#344150';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(left,bottom);ctx.lineTo(right,bottom);ctx.stroke();
    series.forEach(function(points,i){ctx.strokeStyle=colors[i];ctx.lineWidth=2;ctx.setLineDash(spec[0]==='boostTargetCommanded'?[7,4]:[]);ctx.beginPath();var previous=null;
      points.forEach(function(p){if(p.time===null||p.value===null){previous=null;return;}var x=left+p.time/Math.max(duration,.1)*(right-left),y=bottom-(p.value-min)/(max-min)*(bottom-top);if(previous===null||p.time-previous>1||p.time<previous)ctx.moveTo(x,y);else ctx.lineTo(x,y);previous=p.time;});ctx.stroke();
    });ctx.setLineDash([]);
  });
  ctx.fillStyle='#a1a8b3';for(var i=0;i<=4;i++){var seconds=duration*i/4;ctx.fillText(seconds.toFixed(1)+' s',left+(right-left)*i/4-(i===4?40:0),h-7);}
}
function Mr14ECUProfileCompatible(saved,current){
  if(!saved)return true;
  if(saved.model!==current.model||saved.engine!==current.engine||saved.fuelType&&saved.fuelType!==current.fuelType)return false;
  return !saved.tuneKey||saved.tuneKey===current.tuneKey;
}
function Mr14ECUIgnitionNumber(value){if(typeof value==='string'&&/^\d+(?:\.\d+)?$/.test(value.trim()))return Number(value);return value;}
function Mr14ECURevLimiterDefaults(){return {style:'hard',cutMethod:'fuel',hysteresis:150,softRange:500,ignitionAggression:0,torqueCutTime:0};}
function Mr14ECUProtectionDefaults(){return {enabled:false,coolantStart:110,coolantEnd:125,oilStart:130,oilEnd:150,minTorque:35};}
function Mr14ECUModePayload(t){var c=JSON.parse(JSON.stringify(t));delete c.modeMaps;delete c.activeMode;delete c.profileMeta;return c;}
function Mr14ECUIdleDefaults(){return {enabled:false,rpm:[1100,1050,1000,950,900,850,850],amplitude:0,period:1};}
function Mr14ECUMigrateModes(t){if(!t)return t;Mr14ECUControlDefaults(t);if(t.modeMaps)['eco','route','sport'].forEach(function(k){Mr14ECUControlDefaults(t.modeMaps[k]);});Mr14ECUDieselAirDefaults(t);if(t.modeMaps)['eco','route','sport'].forEach(function(k){Mr14ECUDieselAirDefaults(t.modeMaps[k]);});delete t.dieselSmokeGain;if(t.modeMaps)['eco','route','sport'].forEach(function(k){if(t.modeMaps[k])delete t.modeMaps[k].dieselSmokeGain;});t.idleControl=t.idleControl||Mr14ECUIdleDefaults();if(t.modeMaps)['eco','route','sport'].forEach(function(k){if(t.modeMaps[k])t.modeMaps[k].idleControl=t.modeMaps[k].idleControl||Mr14ECUIdleDefaults();});t.throttleResponse=t.throttleResponse||{enabled:false,gamma:1};if(t.modeMaps)['eco','route','sport'].forEach(function(k){if(t.modeMaps[k])t.modeMaps[k].throttleResponse=t.modeMaps[k].throttleResponse||{enabled:false,gamma:1};});t.revLimiter=t.revLimiter||Mr14ECURevLimiterDefaults();if(t.revLimiter.ignitionAggression===undefined)t.revLimiter.ignitionAggression=0;t.revLimiter.ignitionAggression=Mr14ECUIgnitionNumber(t.revLimiter.ignitionAggression);if(t.modeMaps)['eco','route','sport'].forEach(function(k){if(t.modeMaps[k]){t.modeMaps[k].revLimiter=t.modeMaps[k].revLimiter||Mr14ECURevLimiterDefaults();if(t.modeMaps[k].revLimiter.ignitionAggression===undefined)t.modeMaps[k].revLimiter.ignitionAggression=0;t.modeMaps[k].revLimiter.ignitionAggression=Mr14ECUIgnitionNumber(t.modeMaps[k].revLimiter.ignitionAggression);}});t.protection=t.protection||Mr14ECUProtectionDefaults();t.activeMode=t.activeMode||'route';if(!t.modeMaps){t.modeMaps={};['eco','route','sport'].forEach(function(k){t.modeMaps[k]=Mr14ECUModePayload(t);});}return t;}
/* Shared table editor: mutations are atomic and never apply to the engine automatically. */
function Mr14ECUEditor() {
  var e={selection:null,undo:[],redo:[],last:null};
  e.ranges={fuel:[25,300],advance:[-30,70],lambda:[0.4,4],boost:[-15,40],dieselTorque:[25,500],dieselSmoke:[0.2,4],dieselAirFuel:[25,500]};
  e.range=function(t,key){return Mr14ECUMapRange(t,key);};
  e.keys=function(t){return Object.keys(e.ranges).filter(function(k){return k.indexOf('diesel')!==0||t.fuelType==='diesel';});};
  e.clone=function(t){return JSON.parse(JSON.stringify(t));};
  function canonical(value){if(Array.isArray(value))return value.map(canonical);if(value&&typeof value==='object'){var result={};Object.keys(value).sort().forEach(function(k){result[k]=canonical(value[k]);});return result;}return value;}
  e.equal=function(a,b){return JSON.stringify(canonical(e.content(a)))===JSON.stringify(canonical(e.content(b)));};
  e.content=function(t){if(!t)return null;var c=e.clone(t);delete c.profileMeta;return c;};
  e.reset=function(t){e.last=e.clone(t);e.undo=[];e.redo=[];e.selection=null;};
  e.commit=function(t){if(!e.equal(e.last,t)){if(e.last)e.undo.push(e.clone(e.last));if(e.undo.length>30)e.undo.shift();e.redo=[];e.last=e.clone(t);return true;}return false;};
  e.travel=function(t,back){var from=back?e.undo:e.redo,to=back?e.redo:e.undo;if(!from.length)return t;to.push(e.clone(t));var next=from.pop();e.last=e.clone(next);return next;};
  e.select=function(key,y,x,extend){var a=extend&&e.selection&&e.selection.key===key?e.selection.anchor:{y:y,x:x};e.selection={key:key,anchor:a,y0:Math.min(a.y,y),y1:Math.max(a.y,y),x0:Math.min(a.x,x),x1:Math.max(a.x,x)};};
  e.contains=function(key,y,x){var r=e.selection;return !!r&&r.key===key&&y>=r.y0&&y<=r.y1&&x>=r.x0&&x<=r.x1;};
  e.copy=function(t,key){var r=e.selection;if(!r||r.key!==key)throw Error('Sélectionne des cellules.');return Mr14ECUGrid(t,key).slice(r.y0,r.y1+1).map(function(row){return row.slice(r.x0,r.x1+1).join('\t');}).join('\n');};
  function numeric(text){if(!/^[+-]?(?:\d+(?:[.,]\d*)?|[.,]\d+)(?:e[+-]?\d+)?$/i.test(text))throw Error('Valeur non numérique.');return Number(text.replace(',','.'));}
  e.paste=function(t,key,text){
    var r=e.selection;if(!r||r.key!==key)throw Error('Sélectionne la cellule de départ.');
    if(typeof text!=='string'||text.length>20000||!text.trim())throw Error('Bloc vide ou trop volumineux.');
    var rows=text.trim().split(/\r?\n/).map(function(line){return line.trim().split(/\t|;| +/).map(function(n){return numeric(n.trim());});});
    var width=rows[0].length;if(rows.some(function(row){return row.length!==width;}))throw Error('Le bloc doit être rectangulaire.');
    if(r.y0+rows.length>t.loadAxis.length||r.x0+width>t.rpmAxis.length)throw Error('Le bloc dépasse la table.');
    var range=e.range(t,key);if(rows.some(function(row){return row.some(function(n){return !Number.isFinite(n)||n<range[0]||n>range[1];});}))throw Error('Valeur hors limites : '+range.join(' à ')+'. Aucun collage effectué.');
    rows.forEach(function(row,y){row.forEach(function(n,x){Mr14ECUGrid(t,key)[r.y0+y][r.x0+x]=n;});});
    e.select(key,r.y0,r.x0,false);e.select(key,r.y0+rows.length-1,r.x0+width-1,true);return rows.length*width;
  };
  e.modify=function(t,key,mode,value){
    var r=e.selection;if(!r||r.key!==key)throw Error('Sélectionne des cellules.');
    if(!Number.isFinite(value)||['add','percent','set'].indexOf(mode)<0)throw Error('Modification invalide.');
    var range=e.range(t,key),changes=[],clipped=0;
    for(var y=r.y0;y<=r.y1;y++)for(var x=r.x0;x<=r.x1;x++){
      var v=Mr14ECUGrid(t,key)[y][x];if(!Number.isFinite(v))throw Error('Corrige les cellules invalides de la sélection.');
      var n=mode==='set'?value:mode==='percent'?v*(1+value/100):v+value;if(!Number.isFinite(n))throw Error('Résultat invalide.');
      var bounded=Math.max(range[0],Math.min(range[1],n));if(bounded!==n)clipped++;changes.push([y,x,Math.round(bounded*10000)/10000]);
    }
    changes.forEach(function(c){Mr14ECUGrid(t,key)[c[0]][c[1]]=c[2];});return {count:changes.length,clipped:clipped};
  };
  e.smooth=function(t,key,strength){
    var r=e.selection;if(!r||r.key!==key)throw Error('Sélectionne les cellules à lisser.');if(!Number.isFinite(strength)||strength<0||strength>100)throw Error('Intensité de lissage invalide.');
    var grid=Mr14ECUGrid(t,key),range=e.range(t,key),changes=[];
    for(var y=r.y0;y<=r.y1;y++)for(var x=r.x0;x<=r.x1;x++){
      var sum=0,total=0;for(var dy=-1;dy<=1;dy++)for(var dx=-1;dx<=1;dx++){var yy=y+dy,xx=x+dx;if(yy<r.y0||yy>r.y1||xx<r.x0||xx>r.x1)continue;var n=grid[yy][xx];if(!Number.isFinite(n)||n<range[0]||n>range[1])throw Error('Corrige les cellules invalides avant lissage.');var w=dx===0&&dy===0?2:1;sum+=n*w;total+=w;}
      var before=grid[y][x],after=Math.round((before+(sum/total-before)*strength/100)*10000)/10000;changes.push({x:x,y:y,before:before,after:after});
    }return {key:key,changes:changes};
  };
  e.validate=function(t,base){
    if(!t||t.version!==1||!t.tables||!base||t.fuelType!==base.fuelType)throw Error('Format ou carburant incompatible.');
    if(!Mr14ECUValidRPM(t.rpmAxis))throw Error('Axe régime invalide : 12 valeurs croissantes, écart minimum 25 tr/min.');
    if(JSON.stringify(t.loadAxis)!==JSON.stringify(base.loadAxis))throw Error('Axes de charge incompatibles.');
    if(t.fuelType==='diesel'&&(typeof t.dieselAirLimiterEnabled!=='boolean'||JSON.stringify(t.dieselBoostAxis)!==JSON.stringify([0,2,5,10,15,20,30,40])))throw Error('Limiteur de fumée ou axe pression invalide.');
    e.keys(t).forEach(function(k){var rows=t.tables[k],range=e.range(t,k);if(!Array.isArray(rows)||rows.length!==base.loadAxis.length)throw Error('Dimensions invalides : '+k);rows.forEach(function(row){if(!Array.isArray(row)||row.length!==base.rpmAxis.length||row.some(function(n){return !Number.isFinite(n)||n<range[0]||n>range[1];}))throw Error('Cellules invalides : '+k);});});
    function within(n,a,b){return Number.isFinite(n)&&n>=a&&n<=b;}
    if(t.limiter!==0&&!within(t.limiter,1000,12000))throw Error('Limiteur invalide.');
    if(t.throttleResponse&&(typeof t.throttleResponse.enabled!=='boolean'||!within(t.throttleResponse.gamma,.5,2)))throw Error('Réponse accélérateur invalide.');
    if(!t.revLimiter||!within(t.revLimiter.torqueCutTime,0,.4))throw Error('Durée de coupure de couple : 0 à 0,4 seconde.');
    var dh=t.dieselFlame;if(!dh||typeof dh.enabled!=='boolean'||!within(dh.start,600,1350)||!within(dh.full,650,1400)||dh.full<dh.start+50)throw Error('Seuils EGT diesel invalides : 600–1400 °C, écart minimum 50 °C.');
    var fs=t.flatShift;if(!fs||typeof fs.enabled!=='boolean'||!['ignition','torque'].includes(fs.method)||!within(fs.duration,.03,.4)||!within(fs.minRPM,1500,10000)||!within(fs.minPedal,50,100))throw Error('Réglages flat shift invalides.');
    var temp=t.temperatureCorrection;if(!temp||typeof temp.fuelEnabled!=='boolean'||typeof temp.advanceEnabled!=='boolean'||JSON.stringify(temp.axis)!==JSON.stringify(Mr14ECUTemperatureDefaults().axis))throw Error('Axes de température invalides.');
    ['fuel','advance'].forEach(function(k){var lo=k==='fuel'?-50:-20,hi=k==='fuel'?100:20;if(!Array.isArray(temp[k])||temp[k].length!==11||temp[k].some(function(n){return !within(n,lo,hi);}))throw Error('Correction de température invalide : '+k);});
    var tb=t.transbrake;if(!tb||typeof tb.enabled!=='boolean'||!within(tb.maxHold,1,20))throw Error('Réglages transbrake invalides.');
    var tr=t.tractionControl;if(!tr||typeof tr.enabled!=='boolean'||!within(tr.slip,0,100)||!within(tr.strength,0,100)||!within(tr.response,1,30)||!within(tr.recovery,.1,10))throw Error('Réglages antipatinage invalides.');
    var pm=t.pedalMap;if(!pm||typeof pm.enabled!=='boolean'||JSON.stringify(pm.axis)!==JSON.stringify(t.loadAxis)||!Array.isArray(pm.values)||pm.values.length!==t.loadAxis.length)throw Error('Table de pédale invalide.');
    pm.values.forEach(function(row,y){if(!Array.isArray(row)||row.length!==t.rpmAxis.length||row.some(function(n){return !within(n,0,100)||y===0&&n!==0;}))throw Error('Pédale hors limites ou non nulle à 0 %.');});
    var bt=t.boostTarget;if(!bt||typeof bt.enabled!=='boolean'||!Array.isArray(bt.values)||bt.values.length!==t.loadAxis.length||bt.values.some(function(row){return !Array.isArray(row)||row.length!==t.rpmAxis.length||row.some(function(n){return !within(n,0,80);});}))throw Error('Table cible turbo invalide (0 à 80 psi).');
    var gb=t.boostByGear;if(!gb||typeof gb.enabled!=='boolean'||!Array.isArray(gb.axis)||gb.axis.length!==20||!Array.isArray(gb.values)||gb.values.length!==20||gb.axis.some(function(g,i){return g!==i-1||!within(gb.values[i],-15,40);}))throw Error('Turbo par rapport invalide.');

    if(t.idleControl){var id=t.idleControl;if(typeof id.enabled!=='boolean'||!Array.isArray(id.rpm)||id.rpm.length!==7||id.rpm.some(function(r){return !within(r,500,2500);})||!within(id.amplitude,0,300)||!within(id.period,.3,5))throw Error('Cartographie ralenti invalide.');}
    if(t.revLimiter){var rl=t.revLimiter;if(['hard','soft'].indexOf(rl.style)<0||['fuel','ignition','torque'].indexOf(rl.cutMethod)<0||!within(rl.ignitionAggression===undefined?0:rl.ignitionAggression,0,100)||!within(rl.hysteresis,50,1000)||!within(rl.softRange,100,2000)||t.limiter>0&&t.limiter-rl.hysteresis<500||t.limiter>0&&rl.style==='soft'&&t.limiter-rl.softRange<500||t.fuelType==='diesel'&&rl.cutMethod==='ignition')throw Error('Réglages du limiteur invalides.');}
    Mr14ECUValidateOverrunMap(t.overrun);
    var specs={overrun:{fuel:[0,40],retard:[0,40],minRPM:[1200,12000],maxRPM:[1200,12000],maxThrottle:[0,10],duration:[0,20],popHz:[1,12]},antiLag:{intensity:[0,100],fuel:[0,40],retard:[0,40],minRPM:[1200,12000],maxRPM:[1200,12000],maxThrottle:[0,10],duration:[0,10]},launchControl:{rpm:[1500,8000],hysteresis:[50,500],minThrottle:[50,100],maxSpeed:[1,10],maxHold:[1,20],intensity:[0,100],fuel:[0,40],retard:[0,40]}};
    Object.keys(specs).forEach(function(k){var o=t[k];if(!o||typeof o!=='object')throw Error('Réglages absents : '+k);Object.keys(specs[k]).forEach(function(n){var limits=specs[k][n];if(!within(o[n],limits[0],limits[1]))throw Error('Réglage invalide : '+k+'.'+n);});if(k!=='launchControl'&&o.maxRPM<=o.minRPM)throw Error('Plage RPM invalide : '+k);});
    if(!t.detonations)throw Error('Réglages détonations absents.');
    ['shift','limiter'].forEach(function(k){var d=t.detonations[k],r=k==='shift'?{volume:[0,100],flame:[0,100],maxTime:[.05,1],minPedal:[10,100],minRPM:[1000,10000]}:{volume:[0,100],flame:[0,100],hz:[1,15]};if(!d||typeof d.enabled!=='boolean')throw Error('Activation détonations invalide.');Object.keys(r).forEach(function(n){if(!within(d[n],r[n][0],r[n][1]))throw Error('Détonation '+k+' : '+n+' hors limites.');});});
    Mr14ECUValidateTransmission(t);
    var rc=t.rollingLaunch;if(!rc||typeof rc.enabled!=='boolean'||typeof rc.turboPrep!=='boolean')throw Error('Options rolling launch invalides.');
    var rr={rpm:[1500,8000],hysteresis:[50,500],minThrottle:[10,100],minSpeed:[5,250],maxSpeed:[10,300],maxHold:[1,20],intensity:[0,100],fuel:[0,40],retard:[0,40]};Object.keys(rr).forEach(function(k){if(!within(rc[k],rr[k][0],rr[k][1]))throw Error('Réglage rolling launch invalide : '+k);});if(rc.maxSpeed<=rc.minSpeed)throw Error('Plage de vitesse rolling launch invalide.');
    if(t.protection){var p=t.protection;if(typeof p.enabled!=='boolean'||!within(p.coolantStart,70,160)||!within(p.coolantEnd,75,180)||!within(p.oilStart,80,180)||!within(p.oilEnd,85,200)||!within(p.minTorque,10,100)||p.coolantEnd<=p.coolantStart||p.oilEnd<=p.oilStart)throw Error('Seuils de protection thermique invalides.');}
    var rd=rc.detonations;if(!rd||typeof rd.enabled!=='boolean'||!within(rd.volume,0,100)||!within(rd.flame,0,100)||!within(rd.hz,1,12))throw Error('Détonations rolling invalides.');
    if(t.activeMode&&['eco','route','sport'].indexOf(t.activeMode)<0)throw Error('Mode invalide.');
    if(t.modeMaps){['eco','route','sport'].forEach(function(k){var bank=t.modeMaps[k];if(!bank||bank.modeMaps||bank.activeMode)throw Error('Mode manquant ou imbriqué : '+k);e.validate(bank,base);});}
    if(['off','pops','continuous'].indexOf(t.overrun.mode)<0||typeof t.antiLag.enabled!=='boolean'||typeof t.launchControl.enabled!=='boolean'||typeof t.launchControl.turboPrep!=='boolean')throw Error('Options invalides.');return true;
  };
  e.diff=function(a,b){
    if(!a||!b)return [];
    var out=[];if(JSON.stringify(a.rpmAxis)!==JSON.stringify(b.rpmAxis)){a.rpmAxis.forEach(function(n,i){if(n!==b.rpmAxis[i])out.push({label:'Régime colonne '+(i+1),before:n,after:b.rpmAxis[i]});});b=Mr14ECUResampleRPM(b,a.rpmAxis);}
    e.keys(a).forEach(function(k){a.tables[k].forEach(function(row,y){row.forEach(function(n,x){if(n!==b.tables[k][y][x])out.push({label:k+' · '+Mr14ECURowAxis(a,k)[y]+(k==='dieselAirFuel'?' psi / ':' % / ')+a.rpmAxis[x]+' tr/min',before:n,after:b.tables[k][y][x],delta:Math.round((b.tables[k][y][x]-n)*10000)/10000});});});});
    ['limiter','overrun','antiLag','launchControl','protection','revLimiter','throttleResponse','idleControl','rollingLaunch','tractionControl','transbrake','flatShift','dieselFlame'].forEach(function(k){if(k==='limiter'){if(a[k]!==b[k])out.push({label:'Plafond RPM',before:a[k],after:b[k]});return;}Object.keys(a[k]||{}).forEach(function(n){if(k==='overrun'&&n==='rpmMap')return;if(k==='rollingLaunch'&&n==='detonations'){if(a[k][n]&&b[k]&&b[k][n])Object.keys(a[k][n]).forEach(function(v){if(a[k][n][v]!==b[k][n][v])out.push({label:'Détonations rolling · '+v,before:a[k][n][v],after:b[k][n][v]});});return;}if(b[k]&&a[k][n]!==b[k][n])out.push({label:k+'.'+n,before:a[k][n],after:b[k][n]});});});
    if(a.overrun&&b.overrun){var oa=a.overrun.rpmMap||Mr14ECUOverrunMapDefaults(a.overrun),ob=b.overrun.rpmMap||Mr14ECUOverrunMapDefaults(b.overrun);if(oa.enabled!==ob.enabled)out.push({label:'Table pied levé active',before:oa.enabled,after:ob.enabled});['axis','fuel','retard'].forEach(function(k){oa[k].forEach(function(v,i){if(v!==ob[k][i])out.push({label:'Pied levé · '+(k==='axis'?'régime '+(i+1):oa.axis[i]+' tr/min · '+(k==='fuel'?'injection %':'retard °')),before:v,after:ob[k][i]});});});}
    if(a.temperatureCorrection&&b.temperatureCorrection){var ta=a.temperatureCorrection,tb=b.temperatureCorrection;['fuelEnabled','advanceEnabled'].forEach(function(k){if(ta[k]!==tb[k])out.push({label:'Température · '+k,before:ta[k],after:tb[k]});});['fuel','advance'].forEach(function(k){ta[k].forEach(function(n,i){if(n!==tb[k][i])out.push({label:'Température '+ta.axis[i]+' °C · '+(k==='fuel'?'injection %':'avance °'),before:n,after:tb[k][i],delta:tb[k][i]-n});});});}
    ['pedalMap','boostByGear','boostTarget'].forEach(function(k){if(a[k]&&b[k]&&a[k].enabled!==b[k].enabled)out.push({label:k+' actif',before:a[k].enabled,after:b[k].enabled});});
    if(a.detonations&&b.detonations)['shift','limiter'].forEach(function(k){Object.keys(a.detonations[k]).forEach(function(n){if(a.detonations[k][n]!==b.detonations[k][n])out.push({label:'Détonation '+k+' · '+n,before:a.detonations[k][n],after:b.detonations[k][n]});});});
    if(a.transmission&&b.transmission&&JSON.stringify(a.transmission)!==JSON.stringify(b.transmission))out.push({label:'Cartographie boîte automatique',before:JSON.stringify(a.transmission),after:JSON.stringify(b.transmission)});
    if(a.boostTarget&&b.boostTarget)a.boostTarget.values.forEach(function(row,y){row.forEach(function(n,x){var next=b.boostTarget.values[y][x];if(n!==next)out.push({label:'Cible turbo '+a.loadAxis[y]+' % / '+a.rpmAxis[x]+' tr/min',before:n,after:next,delta:next-n});});});
    if(a.pedalMap&&b.pedalMap)a.pedalMap.values.forEach(function(row,y){row.forEach(function(n,x){var next=b.pedalMap.values[y][x];if(n!==next)out.push({label:'Pédale '+a.pedalMap.axis[y]+' % / '+a.rpmAxis[x]+' tr/min',before:n,after:next,delta:next-n});});});
    if(a.boostByGear&&b.boostByGear)a.boostByGear.values.forEach(function(n,i){var next=b.boostByGear.values[i];if(n!==next)out.push({label:'Turbo rapport '+a.boostByGear.axis[i],before:n,after:next,delta:next-n});});return out;
  };
  return e;
}

/* Engine-side road dyno. Power uses native net crank torque, not wheel power. */
function Mr14ECUDyno() {
  var d={phase:'idle',slot:'A',minRPM:2000,maxRPM:6500,runs:{A:null,B:null},message:'Choisis A ou B, arme le passage, puis accélère à fond sur un rapport fixe.',current:null};
  function finite(n){return typeof n==='number' && Number.isFinite(n);}
  function points(r){return Object.keys(r.bins).map(Number).sort(function(a,b){return a-b;}).map(function(k){var b=r.bins[k];return {rpm:k,torque:b.torque/b.n,power:b.power/b.n,n:b.n};});}
  d.arm=function(slot,state){
    if(d.phase==='armed'||d.phase==='running')return false;
    if(!state.installed || !state.tune || state.dirty || ['gasoline','diesel'].indexOf(state.tune.fuelType)<0){d.message='Calculateur essence ou diesel requis, avec cartographie appliquée.';return false;}
    if(!finite(d.minRPM)||!finite(d.maxRPM)||d.minRPM<1000||d.maxRPM>12000||d.maxRPM-d.minRPM<500){d.message='Plage invalide : 1 000–12 000 tr/min, au moins 500 tr/min entre les bornes.';return false;}
    d.slot=slot;d.phase='armed';d.current={vehicleId:state.vehicleId,engineName:state.engineName,hardwareKey:state.hardwareKey,revision:state.revision,tune:JSON.parse(JSON.stringify(state.tune)),bins:{},min:d.minRPM,max:d.maxRPM,lastTime:null,lastRPM:null,elapsed:0,gear:null,start:null,end:null};
    d.message='Passage '+slot+' armé : accélère à fond près du régime minimum, sur un rapport fixe.';return true;
  };
  d.stop=function(reason){
    if(d.phase==='idle')return;
    var r=d.current;
    if(d.phase==='running'){
      r.points=points(r);r.reason=reason;r.finished=d.phase==='running' && reason==='Régime maximum atteint';
      r.valid=r.points.length>=8 && r.points[r.points.length-1].rpm-r.points[0].rpm>=500;
      if(r.valid){r.peakPower=Math.max.apply(null,r.points.map(function(p){return p.power;}));r.peakTorque=Math.max.apply(null,r.points.map(function(p){return p.torque;}));d.runs[d.slot]=r;d.message='Passage '+d.slot+' conservé'+(r.finished?'':' (partiel)')+' : '+reason+'.';}
      else d.message='Passage rejeté : couverture trop courte. '+reason+'.';
    }else d.message='Passage annulé : '+reason+'.';
    d.phase='idle';d.current=null;
  };
  d.invalidate=function(reason){if(d.phase!=='idle'){d.phase='idle';d.current=null;d.message='Passage rejeté : '+reason+'. Les passages précédents sont conservés.';}};
  d.accept=function(s){
    if(d.phase==='idle')return;
    var r=d.current;
    if(!s.installed || s.vehicleId!==r.vehicleId || s.engineName!==r.engineName || s.hardwareKey!==r.hardwareKey || s.revision!==r.revision){d.invalidate('voiture, moteur ou cartographie modifiés');return;}
    if(!finite(s.time)||!finite(s.rpm))return;
    if(r.lastTime!==null && s.time<=r.lastTime){if(s.time<r.lastTime)d.invalidate('véhicule réinitialisé');return;}
    var delta=r.lastTime===null?0:s.time-r.lastTime;r.lastTime=s.time;r.elapsed+=delta;
    if(delta>1){d.invalidate('mesures interrompues');return;}
    if(r.elapsed>60){d.stop('Délai de 60 secondes écoulé');return;}
    var eligible=finite(s.torque) && s.torque>0 && s.pedal>=90 && s.load>=70 && s.speedKmh>=5 && s.gear>=1 && !s.launchActive && !s.antiLagActive && !s.ignitionCut && s.engineRunning;
    if(d.phase==='armed'){
      var rising=r.armedRPM===undefined||s.rpm>=r.armedRPM;r.armedRPM=s.rpm;
      if(!rising||!eligible || s.rpm<r.min || s.rpm>r.min+300)return;
      d.phase='running';r.gear=s.gear;r.start={time:s.time,coolant:s.coolant,oil:s.oil,boost:s.boostPsi};d.message='Passage '+d.slot+' en cours : garde le rapport '+r.gear+' et l’accélérateur à fond.';
    }
    if(s.gear!==r.gear){d.stop('Changement de rapport');return;}
    if(s.rpm>=r.max){r.end={time:s.time,coolant:s.coolant,oil:s.oil,boost:s.boostPsi};d.stop('Régime maximum atteint');return;}
    if(!eligible){d.stop('Accélérateur relâché, charge insuffisante ou coupure moteur');return;}
    if(r.lastRPM!==null && s.rpm<r.lastRPM-200){d.stop('Régime en baisse');return;}
    if(s.rpm<r.min)return;
    r.lastRPM=s.rpm;r.end={time:s.time,coolant:s.coolant,oil:s.oil,boost:s.boostPsi};
    var k=Math.round(s.rpm/100)*100,b=r.bins[k]||(r.bins[k]={n:0,torque:0,power:0});b.n++;b.torque+=s.torque;b.power+=s.torque*s.rpm*(2*Math.PI/60)/735.49875;
  };
  d.curve=function(slot){return d.current && d.phase==='running' && d.slot===slot?points(d.current):(d.runs[slot]?d.runs[slot].points:[]);};
  d.comparison=function(){
    var a=d.runs.A,b=d.runs.B;if(!a||!b)return null;
    var same=a.vehicleId===b.vehicleId && a.engineName===b.engineName && a.hardwareKey===b.hardwareKey && a.gear===b.gear;
    var amap={};a.points.forEach(function(p){amap[p.rpm]=p;});var overlap=b.points.filter(function(p){return amap[p.rpm];});
    var conditions=Math.abs(a.start.coolant-b.start.coolant)<=5 && Math.abs(a.start.oil-b.start.oil)<=10;
    var result={comparable:same&&overlap.length>=8,conditions:conditions,bins:overlap.length,rows:overlap.map(function(p){var q=amap[p.rpm];return {rpm:p.rpm,a:q,b:p,deltaPower:p.power-q.power,deltaTorque:p.torque-q.torque};})};
    result.message=!same?'Voiture, moteur ou rapport différents : comparaison indicative.':overlap.length<8?'Trop peu de régimes communs pour comparer.':!conditions?'Températures de départ différentes : comparaison indicative.':'Même voiture, moteur et rapport ; températures proches. Compare les mêmes régimes.';
    return result;
  };
  d.csv=function(){
    var lines=['time_s,run,rpm,torque_engine_Nm,power_engine_ch,bin_samples,vehicle_id,engine,gear,tune_revision,start_coolant_C,start_oil_C,complete'];
    ['A','B'].forEach(function(slot){var r=d.runs[slot];if(!r)return;r.points.forEach(function(p){lines.push([r.start.time,slot,p.rpm,p.torque.toFixed(3),p.power.toFixed(3),p.n,r.vehicleId,'"'+String(r.engineName).replace(/"/g,'""')+'"',r.gear,r.revision,r.start.coolant,r.start.oil,r.finished?1:0].join(','));});});return lines.join('\n');
  };
  return d;
}

/* global angular, bngApi */
angular.module('beamng.apps').directive('mr14KaraEcu', function () {
  return {
    restrict: 'EA', replace: true, scope: true,
    templateUrl: '/ui/modules/apps/Mr14KaraECU/app.html',
    controller: ['$scope', '$interval', '$element', function (s, $interval, $element) {
      var logTunes={},logContext=null;var faultPoll=0;var polling, pending = false, lastVehicle = null, rows = [], history = [], lastTime = -1;
      s.isExternal=!!window.ECU_SESSION; s.tab = 'fuel'; s.page = 'maps'; s.live = {}; s.profiles = []; s.profile = {name:'Ma_cartographie',selected:''};
      s.navigation=[
        {id:'engine',label:'Moteur',items:[{label:'Cartographies',page:'maps',map:'engine'},{label:'Ralenti',page:'idle'},{label:'Pédale',page:'throttle'},{label:'Antipatinage',page:'traction'},{label:'Température',page:'temperature'},{label:'Limiteur',page:'limiter'}]},
        {id:'turbo',label:'Turbo',items:[{label:'Cartographie turbo',page:'maps',map:'boost'},{label:'Par rapport',page:'boostgear'},{label:'Anti-lag',page:'als'}]},
        {id:'transmission',label:'Boîte',items:[{label:'Boîte automatique',page:'transmission'},{label:'Flat shift manuel',page:'flatshift'}]},
        {id:'effects',label:'Effets',items:[{label:'Pops / flammes',page:'overrun'},{label:'Flamme diesel',page:'dieselheat'},{label:'Détonations',page:'detonations'},{label:'Launch control',page:'launch'},{label:'Rolling launch',page:'rolling'}]},
        {id:'diagnostic',label:'Diagnostic',items:[{label:'Diagnostic',page:'diagnostic'},{label:'Alertes',page:'faults'},{label:'Protections',page:'protection'}]},
        {id:'measurements',label:'Banc & logs',items:[{label:'Banc de puissance',page:'dyno'},{label:'Acquisition / logs',page:'logs'}]}
      ];
      var auxiliaryGroup={id:'auxiliary',items:[]};
      s.currentGroup=function(){if(s.page==='profiles'||s.page==='help')return auxiliaryGroup;if(s.page==='maps')return s.navigation[s.tab==='boost'?1:0];for(var i=0;i<s.navigation.length;i++)for(var j=0;j<s.navigation[i].items.length;j++)if(s.navigation[i].items[j].page===s.page)return s.navigation[i];return s.navigation[0];};
      s.zeroTemperature=function(key){if(!s.tune||!s.tune.temperatureCorrection||!['fuel','advance'].includes(key))return;s.tune.temperatureCorrection[key]=s.tune.temperatureCorrection[key].map(function(){return 0;});s.edit();};
      s.openPage=function(item){if(item.page==='dyno'){s.showDyno();return;}s.page=item.page;if(item.page==='overrun')s.prepareOverrunTable();if(item.map==='boost')s.selectMap('boost');else if(item.map==='engine'&&s.tab==='boost')s.selectMap('fuel');};
      s.openGroup=function(group){s.openPage(group.items[0]);};
      function sizeInterface(){var node=$element[0];if(node.classList)node.classList.toggle('ecu-compact',node.clientWidth<760);}
      var interfaceObserver=window.ResizeObserver?new window.ResizeObserver(sizeInterface):null;
      if(interfaceObserver)interfaceObserver.observe($element[0]);else window.addEventListener('resize',sizeInterface);
      s.$evalAsync(sizeInterface);
      s.$on('$destroy',function(){if(interfaceObserver)interfaceObserver.disconnect();else window.removeEventListener('resize',sizeInterface);});
      s.notice = 'Connexion au véhicule…'; s.installed = false; s.recording = false; s.rowCount = 0;
      s.editor=Mr14ECUEditor();s.bulk={mode:'add',value:1,text:''};s.transfer={text:'',open:false};s.profileIndex=[];s.compareRows=[];s.compareLabel='';s.profileMode='load';s.profile.showAll=false;
      s.review={active:false,index:0,playing:false};s.inspected={};s.logCompare=Mr14ECULogComparison();s.smoothing={strength:50};s.traceKey='fuel';s.traceCells=[];s.dyno=Mr14ECUDyno();
      s.maps = [
        {key:'fuel',label:'Injection',unit:'Correction carburant (%)',min:25,max:300,step:1},
        {key:'advance',label:'Allumage',unit:'Avance modélisée (° avant PMH)',min:-30,max:70,step:0.5},
        {key:'lambda',label:'Richesse',unit:'Lambda cible',min:0.4,max:4,step:0.01},
        {key:'boost',label:'Turbo',unit:'Correction de consigne wastegate (psi)',min:-15,max:40,step:0.5},
        {key:'dieselTorque',label:'Limite couple',unit:'Plafond de couple relatif à la base (%)',min:25,max:500,step:1},
        {key:'dieselAirFuel',label:'Limiteur fumée / air',unit:'Carburant maximum selon pression turbo (%)',min:25,max:500,step:1},
        {key:'dieselSmoke',label:'Limite richesse',unit:'Lambda minimum estimé — limite d’enrichissement',min:0.2,max:4,step:0.05}
      ];
      function overrunDefaults(t){if(t&&t.fuelType==='diesel'&&t.tables&&Array.isArray(t.loadAxis)&&Array.isArray(t.rpmAxis)){['dieselTorque','dieselSmoke'].forEach(function(k){if(!t.tables[k])t.tables[k]=t.loadAxis.map(function(){return t.rpmAxis.map(function(){return k==='dieselTorque'?130:1.15;});});});}if(t&&!t.overrun)t.overrun={mode:'off',fuel:15,retard:20,minRPM:2500,maxRPM:8000,maxThrottle:5,duration:3,popHz:5};if(t&&!t.antiLag)t.antiLag={enabled:false,intensity:50,fuel:25,retard:30,minRPM:3000,maxRPM:8000,maxThrottle:5,duration:3};if(t&&!t.launchControl)t.launchControl={enabled:false,rpm:3500,hysteresis:150,minThrottle:80,maxSpeed:5,maxHold:10,turboPrep:true,intensity:40,fuel:25,retard:30};return Mr14ECUMigrateModes(t);}
      s.rowAxis=function(){return s.tune?Mr14ECURowAxis(s.tune,s.tab):[];};
      s.activeCell=function(y,x){if(s.tab!=='dieselAirFuel')return s.live.x===x+1&&s.live.y===y+1;function index(axis,n){if(n<=axis[0])return 0;for(var i=1;i<axis.length;i++)if(n<=axis[i])return i-1;return axis.length-1;}return index(s.tune.rpmAxis,s.live.rpm||0)===x&&index(s.rowAxis(),Math.max(s.live.boostPsi||0,0))===y;};
      s.visibleMaps=function(){return s.maps.filter(function(m){return s.tune&&s.tune.fuelType==='diesel'?m.key!=='advance':m.key.indexOf('diesel')!==0;});};
      s.rpmEdit={text:'',center:4500};
      s.readRPMAxis=function(){if(s.tune)s.rpmEdit.text=s.tune.rpmAxis.join(' ');};
      s.rpmPreset=function(kind){var a;if(kind==='diesel')a=[500,750,1000,1250,1500,1750,2000,2500,3000,3500,4000,5000];else if(kind==='limiter'){var n=Number(s.rpmEdit.center);if(!Number.isInteger(n)||n<1000||n>11000){s.notice='Centre de précision : 1000 à 11000 tr/min.';return;}a=[0];for(var i=0;i<10;i++)a.push(n-500+i*100);a.push(12000);}else a=[600,1000,1500,2000,2500,3000,4000,5000,6000,7500,9000,12000];s.rpmEdit.text=a.join(' ');};
      s.applyRPMAxis=function(){try{var a=s.rpmEdit.text.trim().split(/[\s,;]+/).map(Number);var next=Mr14ECUResampleRPM(s.tune,a);s.cancelSmooth();s.tune=next;s.editor.selection=null;s.bulk.text='';s.edit();s.notice='Axes et toutes les tables du mode courant rééchantillonnés dans l’éditeur. Appliquer pour activer. Annuler reste disponible.';}catch(e){s.notice=e.message;}};
      s.mapLabel=function(m){return s.tune&&s.tune.fuelType==='diesel'?(m.key==='fuel'?'Quantité injectée':m.key==='lambda'?'Lambda demandé':m.label):m.label;};
      s.transmissionRows=function(key){return s.tune?s.tune.transmission[key].slice(0,s.transmission&&s.transmission.gearCount||0):[];};
      s.tableKey=function(){return Mr14ECUTableKey(s.tune,s.tab);};
      s.mapGrid=function(){return s.tune?Mr14ECUGrid(s.tune,s.tableKey()):[];};
      s.turboModes=[{value:false,label:'Correction'},{value:true,label:'Pression cible'}];
      s.changeTurboMode=function(){s.tune.boostTarget.enabled=Mr14ECUTurboBoolean(s.tune.boostTarget.enabled);s.cancelSmooth();s.editor.selection=null;s.bulk.text='';s.edit();};
      s.mapInfo = function () { var m=s.maps.filter(function(m){return m.key===s.tab;})[0],r=Mr14ECUMapRange(s.tune,s.tableKey());return angular.extend({},m,{min:r[0],max:r[1],unit:s.tableKey()==='boostTarget'?'Pression turbo cible (psi relatifs à l’atmosphère)':m.unit}); };
      s.selectMap = function (key) { s.tab=key;s.smoothPreview=null;s.editor.selection=null; };
      function luaString(value) { return '"'+String(value).replace(/\\/g,'\\\\').replace(/"/g,'\\"').replace(/\r/g,'\\r').replace(/\n/g,'\\n')+'"'; }
      function vehicle(code, missing) {
        bngApi.activeObjectLua('local c=controller.getController("mr14karaECU"); if c and c.requestState then '+code+' else '+(missing||'')+' end');
      }
      function storage(code) {
        bngApi.engineLua('if not extensions.mr14karaECUStorage then extensions.load("mr14karaECUStorage") end; if extensions.mr14karaECUStorage then extensions.mr14karaECUStorage.'+code+' end');
      }
      s.closeExternal=function(){s.externalReady=false;};
      s.openExternal = function () {
        if(window.ECU_SESSION)return;
        s.externalReady=true;
        bngApi.engineLua('if not extensions.mr14karaECUExternal then extensions.load("mr14karaECUExternal") end; if extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.open() else guihooks.trigger("Mr14ECUFileNotice",{ok=false,message="Liaison externe indisponible."}) end');
      };
      s.refresh = function () {
        pending=false; s.dirty=false;
        vehicle('c.requestState()', 'guihooks.trigger("Mr14ECUState",{installed=false,vehicleId=obj:getID()})');
      };
      s.prepareOverrunTable=function(){if(!s.tune||!s.tune.overrun||s.tune.fuelType==='diesel')return;var o=s.tune.overrun;if(!o.rpmMap)o.rpmMap=Mr14ECUOverrunMapDefaults(o);if(!o.rpmMap.enabled){o.rpmMap.fuel=o.rpmMap.axis.map(function(){return o.fuel;});o.rpmMap.retard=o.rpmMap.axis.map(function(){return o.retard;});o.rpmMap.enabled=true;s.edit();}};
      s.editOverrunTable=function(){s.prepareOverrunTable();s.edit();};
      s.overrunColumn=function(i){var o=s.tune&&s.tune.overrun,m=o&&o.rpmMap,r=s.live.rpm;if(!m||!Number.isFinite(r))return false;return r<=m.axis[0]?i===0:r>=m.axis[m.axis.length-1]?i===m.axis.length-1:r>=m.axis[i]&&r<m.axis[i+1];};
      s.overrunHeat=function(n){var v=Math.max(0,Math.min(40,Number(n)||0))/40;return {background:v===0?'#15191e':'rgba(207,57,42,'+(.16+v*.62)+')'};};
      s.fillOverrunMap=function(){if(!s.tune||!s.tune.overrun)return;var o=s.tune.overrun;if(!o.rpmMap)o.rpmMap=Mr14ECUOverrunMapDefaults(o);o.rpmMap.fuel=o.rpmMap.axis.map(function(){return o.fuel;});o.rpmMap.retard=o.rpmMap.axis.map(function(){return o.retard;});s.edit();};
      s.edit = function () { if(s.tune){s.editor.commit(s.tune);s.dirty=!s.editor.equal(s.activeTune,s.tune);s.overwriteName=null;} };
      s.editIgnitionAggression=function(){if(!s.tune||!s.tune.revLimiter)return;s.tune.revLimiter.ignitionAggression=Mr14ECUIgnitionNumber(s.tune.revLimiter.ignitionAggression);s.edit();};
      s.apply = function () {
        if (!s.tune || !s.installed) return;
        try{s.editor.validate(s.tune,s.activeTune);}catch(e){s.notice=e.message;return;}
        var invalid=Mr14ECUInvalidCell($element[0]);if(invalid){s.notice='Corrige la valeur de « '+invalid+' » avant application.';return;}
        vehicle('if c.setTuneJSON('+luaString(JSON.stringify(s.tune))+') then c.requestState() end');
      };
      s.faultHistory=[];s.activeFaults=[];
      s.clearFaultHistory=function(){vehicle('c.clearFaults()');};
      s.exportFaults=function(){var keys=['time','session','code','message','active','recoveredTime','rpm','load','mode','revision','coolant','oil','protectionFactor'];var csv='time_s,session,code,message,active,recovered_time_s,rpm,load_pct,mode,tune_revision,coolant_C,oil_C,thermal_factor\n'+s.faultHistory.map(function(r){return keys.map(function(k){return r[k]===undefined?'':typeof r[k]==='string'?'"'+r[k].replace(/"/g,'""')+'"':r[k]===true?'1':r[k]===false?'0':r[k];}).join(',');}).join('\n');storage('exportLog('+luaString(csv)+')');};
      s.modeLabels={eco:'Éco',route:'Route',sport:'Sport'};s.copyModeTarget='sport';
      s.switchMode=function(mode){
        if(!s.installed||!s.activeTune)return;if(s.dirty){s.notice='Applique les modifications ou reviens au réglage actif avant de changer de mode.';return;}
        var next=angular.copy(s.activeTune.modeMaps[mode]);if(!next)return;next.activeMode=mode;next.modeMaps=angular.copy(s.activeTune.modeMaps);next.profileMeta=s.activeTune.profileMeta;
        try{s.editor.validate(next,s.activeTune);}catch(e){s.notice=e.message;return;}
        vehicle('if c.setTuneJSON('+luaString(JSON.stringify(next))+') then c.requestState() end');
      };
      s.copyToMode=function(){if(!s.tune||s.copyModeTarget===s.tune.activeMode)return;s.tune.modeMaps[s.copyModeTarget]=Mr14ECUModePayload(s.tune);s.edit();s.notice='Réglages copiés vers '+s.modeLabels[s.copyModeTarget]+'. Applique pour conserver les trois modes.';};
      s.testDetonation=function(){vehicle('if c.testDetonation then c.testDetonation() else guihooks.trigger("Mr14ECUNotice",{ok=false,message="Redémarre BeamNG avec le nouveau ZIP ECU."}) end');};
      s.reset = function () { vehicle('c.resetTune()'); };
      function context(){return {model:s.vehicleModel||'unknown',engine:s.engineName||'unknown',hardwareKey:s.hardwareKey||'',tuneKey:s.tuneKey||'',fuelType:s.tune&&s.tune.fuelType};}
      function enginePrefix(){var c=context(),text=JSON.stringify({model:c.model,engine:c.engine,tuneKey:c.tuneKey,fuelType:c.fuelType}),hash=2166136261;for(var i=0;i<text.length;i++)hash=Math.imul(hash^text.charCodeAt(i),16777619);return 'E'+(hash>>>0).toString(16)+'_';}
      function namedTune(name,role){var t=angular.copy(s.tune);t.modeMaps[t.activeMode]=Mr14ECUModePayload(t);var c=context();c.id=enginePrefix();t.profileMeta={displayName:name,role:role||'tune',context:c,savedAt:new Date().toISOString()};return t;}
      s.visibleProfiles=function(){return s.profile.showAll?s.profiles:s.profiles.filter(function(name){var p=s.profileIndex.filter(function(p){return p.name===name;})[0];return !p||!p.context||Mr14ECUProfileCompatible(p.context,context());});};
      s.profileLabel=function(name){var p=s.profileIndex.filter(function(p){return p.name===name;})[0];return p?p.displayName+' · '+p.context.model+(p.role==='reference'?' · Référence':''):name+' · ancien profil';};
      s.save=function(role){
        if(!s.tune)return;
        try{s.editor.validate(s.tune,s.activeTune);}catch(e){s.notice=e.message;return;}
        var label=role==='reference'?'Reference':(s.profile.name||'').trim();if(!label||label.length>40){s.notice='Choisis un nom de 1 à 40 caractères.';return;}
        var name=enginePrefix()+label.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Za-z0-9_-]/g,'_');
        if(s.profiles.indexOf(name)>=0&&s.overwriteName!==name){s.overwriteName=name;s.notice='Ce profil existe. Clique de nouveau sur le même bouton pour le remplacer.';return;}
        s.overwriteName=null;storage('saveTune('+luaString(name)+','+luaString(JSON.stringify(namedTune(label,role)))+')');s.profile.selected=name;
      };
      s.load=function(mode){if(s.profile.selected&&!s.profileLoading){s.profileLoading=true;s.profileMode=mode||'load';storage('loadTune('+luaString(s.profile.selected)+')');}};
      s.restoreReference=function(){if(s.profileLoading)return;var name=enginePrefix()+'Reference';if(s.profiles.indexOf(name)<0){var legacy=s.profileIndex.filter(function(p){return p.role==='reference'&&Mr14ECUProfileCompatible(p.context,context());})[0];if(legacy)name=legacy.name;}if(s.profiles.indexOf(name)<0){s.notice='Aucune référence sauvegardée pour ce moteur.';return;}s.profileLoading=true;s.profileMode='load';storage('loadTune('+luaString(name)+')');};
      s.compareActive=function(){s.compareRows=s.editor.diff(s.activeTune,s.tune);s.compareLabel='Moteur actif → éditeur';};
      s.restoreActive=function(){if(s.activeTune){s.tune=angular.copy(s.activeTune);s.edit();s.notice='Cartographie active restaurée dans l’éditeur.';}};
      s.undoEdit=function(back){s.tune=s.editor.travel(s.tune,back);s.dirty=!s.editor.equal(s.activeTune,s.tune);s.overwriteName=null;};
      s.pickCell=function(y,x,event){s.editor.select(s.tableKey(),y,x,!!event.shiftKey);};
      s.pickAll=function(){if(!s.tune)return;s.editor.select(s.tableKey(),0,0,false);s.editor.select(s.tableKey(),s.tune.loadAxis.length-1,s.tune.rpmAxis.length-1,true);};
      s.pickRow=function(y){s.editor.select(s.tableKey(),y,0,false);s.editor.select(s.tableKey(),y,s.tune.rpmAxis.length-1,true);};
      s.pickColumn=function(x){s.editor.select(s.tableKey(),0,x,false);s.editor.select(s.tableKey(),s.tune.loadAxis.length-1,x,true);};
      s.previewSmooth=function(){try{s.smoothPreview=s.editor.smooth(s.tune,s.tableKey(),s.smoothing.strength);s.smoothBase=angular.copy(s.tune);s.notice='Aperçu du lissage : aucune cellule modifiée.';}catch(e){s.notice=e.message;}};
      s.cancelSmooth=function(){s.smoothPreview=null;s.smoothBase=null;};
      s.acceptSmooth=function(){if(!s.smoothPreview)return;if(!s.editor.equal(s.smoothBase,s.tune)){s.cancelSmooth();s.notice='Éditeur modifié : recalcule un aperçu de lissage.';return;}s.smoothPreview.changes.forEach(function(c){Mr14ECUGrid(s.tune,s.smoothPreview.key)[c.y][c.x]=c.after;});s.cancelSmooth();s.edit();s.notice='Lissage validé dans l’éditeur. Appliquer pour modifier le moteur.';};
      s.smoothValue=function(y,x){if(!s.smoothPreview||s.smoothPreview.key!==s.tableKey())return null;var c=s.smoothPreview.changes.filter(function(c){return c.y===y&&c.x===x;})[0];return c?c.after:null;};
      s.selectionCount=function(){var r=s.editor.selection;return r?(r.y1-r.y0+1)*(r.x1-r.x0+1):0;};
      s.modifySelection=function(){try{var result=s.editor.modify(s.tune,s.tableKey(),s.bulk.mode,s.bulk.value);s.edit();s.notice=result.count+' cellules modifiées'+(result.clipped?' ; '+result.clipped+' limitées aux bornes de la table.':'.');}catch(e){s.notice=e.message;}};
      s.copySelection=function(){try{s.bulk.text=s.editor.copy(s.tune,s.tableKey());s.notice='Sélection copiée dans le bloc ci-dessous. Utilise Ctrl+C pour la transférer ailleurs.';}catch(e){s.notice=e.message;}};
      s.pasteSelection=function(){try{var n=s.editor.paste(s.tune,s.tableKey(),s.bulk.text);s.edit();s.notice=n+' cellules collées dans l’éditeur.';}catch(e){s.notice=e.message;}};
      s.exportProfile=function(){try{s.editor.validate(s.tune,s.activeTune);s.transfer.text=JSON.stringify(namedTune(s.profile.name||'Export'),null,2);s.transfer.open=true;s.notice='Profil JSON prêt : copie le texte pour le conserver ou le partager.';}catch(e){s.notice=e.message;}};
      s.importProfile=function(){try{if(s.transfer.text.length>60000)throw Error('Profil trop volumineux.');receiveProfile(JSON.parse(s.transfer.text),'load');}catch(e){s.notice=e.message;}};
      function receiveProfile(data,mode){
        try{data=overrunDefaults(angular.copy(data));s.editor.validate(data,s.activeTune);
          if(data.profileMeta&&!Mr14ECUProfileCompatible(data.profileMeta.context,context()))throw Error('Profil destiné à un autre modèle ou moteur.');
          if(mode==='compare'){s.compareRows=s.editor.diff(data,s.tune);s.compareLabel=(data.profileMeta?data.profileMeta.displayName:'Profil')+' → éditeur';s.notice='Comparaison affichée, éditeur conservé.';return;}
          s.tune=data;s.edit();s.profile.name=data.profileMeta?data.profileMeta.displayName:s.profile.name;s.notice='Profil chargé dans l’éditeur. Appliquer au moteur pour l’activer.';
        }catch(e){s.notice=e.message;}
      }
      s.toggleLog = function () {
        if (s.recording) {s.recording=false;return;}
        if (!s.installed) return;
        rows=[];logTunes={};logContext=context(); s.rowCount=0; lastTime=-1; s.recording=true; s.page='logs';s.review={active:false,index:0,playing:false};
      };
      s.exportLog = function () {
        if(!rows.length)return;
        var keys=['time','rpm','load','throttle','boostPsi','lambda','afr','targetLambda','fuelPercent','advance','torque','torqueFactor','fuelFactor','risk','coolant','oil','revision','overrunActive','overrunFuel','overrunRetard','flameDemand','flameBridge','antiLagActive','antiLagCoef','turboRPM','launchActive','launchCut','launchPrepActive','launchPrepCoef','launchTargetRPM','dieselTorqueLimit','dieselSmokeLimit','dieselRequestedFuel','dieselLimited','dieselSmokeDemand','dieselSmokeLambda','dieselSmokeEmitting','modeIndex','protectionActive','protectionFactor','thermalSeverity','limiterActive','limiterCut','limiterFactor','activeFaultCount','faultSession','commandedThrottle','mappedThrottle','throttleResponseActive','idleTargetRPM','idleMapActive','idleVariationActive','nativeIdleRPM','gear','pedalMapActive','boostByGearActive','boostRequested','boostCommanded','speedKmh','pedal','engineRunning','ignitionCut','boostTargetActive','boostTargetPsi','boostTargetCommanded','rollingActive','rollingHeld','rollingBlocked','rollingElapsed','rollingTargetRPM','rollingCut','rollingPrepActive','rollingPrepCoef','transmissionActive','shiftUpRPM','shiftDownRPM','gearChangeTime','lockupRatio','tractionSlip','tractionReduction','tractionActive','blipActive','blipTargetRPM','blipCount','transbrakeActive','transbrakeElapsed','shiftCutActive','shiftCutFactor','shiftCutElapsed','shiftCutCount','temperatureFuelCorrection','temperatureAdvanceCorrection','temperatureSupported','flatShiftActive','flatShiftCount','flatShiftElapsed','dieselEGT','dieselFlameDemand','limiterCutElapsed','limiterCutCount'];
        var csv='time_s,rpm,load_pct,throttle_pct,boost_psi,lambda_est,afr_est,lambda_target,fuel_pct,advance_model_deg,torque_Nm,torque_factor,fuel_factor,risk_model,coolant_C,oil_C,tune_revision,overrun_active,overrun_fuel_pct,overrun_retard_ATDC_deg,flame_demand,flame_bridge,antilag_active,antilag_coef,turbo_rpm,launch_active,launch_cut,launch_prep_active,launch_prep_coef,launch_target_rpm,diesel_torque_limit_pct,diesel_min_lambda_est,diesel_requested_fuel_factor,diesel_limited,diesel_smoke_demand,diesel_smoke_lambda_est,diesel_smoke_emitting,mode_index_1_eco_2_route_3_sport,thermal_protection_active,thermal_torque_factor,thermal_severity,ecu_limiter_active,ecu_limiter_cut,ecu_limiter_factor,active_fault_count,fault_session,commanded_throttle_pct,mapped_throttle_pct,throttle_response_active,idle_target_rpm,idle_map_active,idle_variation_active,native_idle_rpm,gear,pedal_map_active,boost_by_gear_active,boost_offset_requested_psi,boost_offset_commanded_psi,speed_kmh,pedal_pct,engine_running,ignition_cut,boost_target_active,boost_target_psi,boost_target_commanded_psi,rolling_active,rolling_held,rolling_blocked,rolling_elapsed_s,rolling_target_rpm,rolling_cut,rolling_prep_active,rolling_prep_coef,transmission_active,shift_up_rpm,shift_down_rpm,gear_change_time_s,lockup_ratio,traction_slip_pct,traction_reduction_pct,traction_active,blip_active,blip_target_rpm,blip_count,transbrake_active,transbrake_elapsed_s,shift_cut_active,shift_cut_factor,shift_cut_elapsed_s,shift_cut_count,temperature_fuel_correction_pct,temperature_advance_correction_deg,temperature_sensor_available,flat_shift_active,flat_shift_count,flat_shift_elapsed_s,diesel_egt_est_C,diesel_flame_demand,limiter_cut_elapsed_s,limiter_cut_count\n';
        csv+=rows.map(function(r){return keys.map(function(k){var v=typeof r[k]==='boolean'?Number(r[k]):r[k];return typeof v==='number'&&Number.isFinite(v)?v.toFixed(4):'';}).join(',');}).join('\n');
        storage('exportLog('+luaString(csv)+')');
      };
      s.tableHeat=Mr14ECUHeat;
      s.heat = function (n) { var m=s.mapInfo(); return Mr14ECUHeat(n,m.min,m.max); };
      s.bump = function (delta) {
        if(!s.tune)return;
        var m=s.mapInfo(); s.mapGrid().forEach(function(row){row.forEach(function(v,i){row[i]=Math.round(Math.max(m.min,Math.min(m.max,v+delta))*100)/100;});});s.edit();
      };
      function tableFocus(event){return event.target&&event.target.closest&&event.target.closest('.gridwrap')&&s.tune&&s.editor.selection;}
      function onCopy(event){if(!tableFocus(event)||!event.clipboardData)return;try{var text=s.editor.copy(s.tune,s.tableKey());event.clipboardData.setData('text/plain',text);event.preventDefault();s.$evalAsync(function(){s.bulk.text=text;s.notice='Sélection copiée dans le presse-papiers.';});}catch(e){s.$evalAsync(function(){s.notice=e.message;});}}
      function onPaste(event){if(!tableFocus(event)||!event.clipboardData)return;var text=event.clipboardData.getData('text/plain');event.preventDefault();s.$evalAsync(function(){s.bulk.text=text;s.pasteSelection();});}
      function onTableKey(event){if(!tableFocus(event)||!(event.ctrlKey||event.metaKey))return;if(event.key.toLowerCase()==='z'){event.preventDefault();s.$evalAsync(function(){s.undoEdit(!event.shiftKey);});}else if(event.key.toLowerCase()==='y'){event.preventDefault();s.$evalAsync(function(){s.undoEdit(false);});}}
      if($element[0].addEventListener){$element[0].addEventListener('copy',onCopy);$element[0].addEventListener('paste',onPaste);$element[0].addEventListener('keydown',onTableKey);}
      s.captureLog=function(slot){try{s.logCompare.save(slot,rows,logContext||context());s.notice='Acquisition conservée en '+slot+'.';s.drawLogComparison();}catch(e){s.notice=e.message;}};
      s.drawLogComparison=function(){var canvas=$element[0].querySelector('canvas.comparechart');if(canvas)Mr14ECUDrawLogComparison(canvas,s.logCompare);};
      s.exportLogComparison=function(){if(s.logCompare.result.rows.length)storage('exportLog('+luaString(s.logCompare.csv())+')');};
      function trace(){
        var row=s.inspected;var archived=s.review.active?logTunes[row.revision]:(row.revision===s.revision?s.activeTune:null);s.traceTune=archived||null;if(s.traceTune&&(s.traceTune.fuelType==='diesel'&&s.traceKey==='advance'||s.traceTune.fuelType!=='diesel'&&s.traceKey.indexOf('diesel')===0))s.traceKey='fuel';
        s.traceTableKey=s.traceKey==='boost'&&row.boostTargetActive?'boostTarget':s.traceKey;s.traceGrid=s.traceTune?Mr14ECUGrid(s.traceTune,s.traceTableKey):[];s.traceCells=Mr14ECULogCells(s.traceTune,row,s.traceTableKey);s.traceValue=s.traceCells.reduce(function(n,c){return n+c.value*c.weight;},0);
        s.traceMessage=s.traceTune?'Cartographie enregistrée · '+s.modeLabels[row.activeMode||s.traceTune.activeMode]+' · révision '+row.revision:'Cartographie de cet échantillon indisponible ; aucune valeur historique reconstruite.';
      }
      s.changeTraceMap=trace;
      s.traceCell=function(y,x){return s.traceCells.some(function(c){return c.y===y&&c.x===x;});};
      s.seekLog=function(event){if(!rows.length||s.recording||!s.review.active)return;var canvas=event.currentTarget,rect=canvas.getBoundingClientRect(),fraction=Math.max(0,Math.min(1,(event.clientX-rect.left-125*rect.width/canvas.width)/((canvas.width-137)*rect.width/canvas.width)));var start=s.review.active?Math.floor(s.review.index/300)*300:Math.max(0,rows.length-300);var end=s.review.active?Math.min(rows.length-1,start+299):rows.length-1;var target=rows[start].time+fraction*(rows[end].time-rows[start].time),best=start;for(var i=start;i<=end;i++)if(Math.abs(rows[i].time-target)<Math.abs(rows[best].time-target))best=i;s.review.active=true;s.review.playing=false;s.review.index=best;draw();};
      function draw() {
        s.inspected=s.review.active?(rows[s.review.index]||{}):s.live;trace();
        var canvas=$element[0].querySelector('canvas.logchart'); if(!canvas)return;
        var ctx=canvas.getContext('2d'), w=canvas.width, h=canvas.height;
        ctx.clearRect(0,0,w,h);
        var plotted=s.review.active?rows.slice(Math.floor(s.review.index/300)*300,Math.floor(s.review.index/300)*300+300):history;
        s.inspected=s.review.active?(rows[s.review.index]||{}):s.live;
        var specs=[['rpm',0,12000,'#ed4545','Régime · tr/min'],['lambda',0,4,'#ffc66d','Lambda estimé'],['boostPsi',-15,60,'#769aff','Turbo · psi'],['coolant',0,180,'#ff9270','Eau · °C'],['oil',0,200,'#dda0ff','Huile · °C']];
        var first=plotted.length?plotted[0].time:0,last=plotted.length?plotted[plotted.length-1].time:first;
        ctx.font='12px Segoe UI';specs.forEach(function(spec,lane){
          var top=lane*(h-25)/specs.length+20,bottom=(lane+1)*(h-25)/specs.length-7,left=125,right=w-12;
          ctx.fillStyle=spec[3];ctx.fillText(spec[4],6,top+12);ctx.fillText(spec[1]+' / '+spec[2],6,top+28);
          ctx.strokeStyle='#31363d';ctx.beginPath();ctx.moveTo(left,bottom);ctx.lineTo(right,bottom);ctx.stroke();
          ctx.strokeStyle=spec[3];ctx.lineWidth=2;ctx.beginPath();var previous=null;
          plotted.forEach(function(r){var v=r[spec[0]];if(!Number.isFinite(v)||!Number.isFinite(r.time)){previous=null;return;}
            var x=left+(r.time-first)/Math.max(last-first,.1)*(right-left),y=bottom-Math.max(0,Math.min(1,(v-spec[1])/(spec[2]-spec[1])))*(bottom-top);
            if(previous===null||r.time-previous>1)ctx.moveTo(x,y);else ctx.lineTo(x,y);previous=r.time;
          });ctx.stroke();
        });ctx.fillStyle='#a1a8b3';ctx.fillText(first.toFixed(1)+' s',125,h-4);ctx.fillText(last.toFixed(1)+' s',w-70,h-4);if(s.review.active&&plotted.length){ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.beginPath();var cursor=125+(s.inspected.time-first)/Math.max(last-first,.1)*(w-137);ctx.moveTo(cursor,0);ctx.lineTo(cursor,h-25);ctx.stroke();}
      }

      s.armDyno=function(slot){s.dyno.arm(slot,{installed:s.installed,tune:s.tune,dirty:s.dirty,vehicleId:lastVehicle,engineName:s.engineName,hardwareKey:s.hardwareKey,revision:s.revision});drawDyno();};
      s.stopDyno=function(){s.dyno.stop('Arrêt manuel');drawDyno();};
      s.exportDyno=function(){if(s.dyno.runs.A||s.dyno.runs.B)storage('exportLog('+luaString(s.dyno.csv())+')');};
      function drawDyno(){
        s.dynoCompare=s.dyno.comparison();
        var canvas=$element[0].querySelector('canvas.dynochart');if(!canvas)return;
        var ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height,left=58,right=w-58,top=24,bottom=h-34;
        var a=s.dyno.curve('A'),b=s.dyno.curve('B'),all=a.concat(b),xmin=all.length?Math.min.apply(null,all.map(function(p){return p.rpm;})):s.dyno.minRPM,xmax=all.length?Math.max.apply(null,all.map(function(p){return p.rpm;})):s.dyno.maxRPM;
        xmax=Math.max(xmin+500,xmax);var maxNm=Math.max(100,Math.ceil(Math.max.apply(null,[0].concat(all.map(function(p){return p.torque;})))/100)*100),maxPS=Math.max(100,Math.ceil(Math.max.apply(null,[0].concat(all.map(function(p){return p.power;})))/100)*100);
        ctx.clearRect(0,0,w,h);ctx.font='12px Segoe UI';ctx.fillStyle='#a1a8b3';ctx.fillText('Couple moteur (Nm)',left,15);ctx.fillText('Puissance moteur (ch)',right-140,15);
        for(var i=0;i<=4;i++){var y=bottom-i*(bottom-top)/4;ctx.strokeStyle='#31363d';ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();ctx.fillStyle='#a1a8b3';ctx.fillText(String(Math.round(i*maxNm/4)),5,y+4);ctx.fillText(String(Math.round(i*maxPS/4)),right+6,y+4);var x=left+i*(right-left)/4;ctx.fillText(String(Math.round(xmin+i*(xmax-xmin)/4)),x-15,h-12);}
        [[a,'#ed4545'],[b,'#ffc66d']].forEach(function(spec){[['torque',maxNm,[]],['power',maxPS,[6,4]]].forEach(function(metric){ctx.strokeStyle=spec[1];ctx.lineWidth=2;ctx.setLineDash(metric[2]);ctx.beginPath();spec[0].forEach(function(p,i){var x=left+(p.rpm-xmin)/(xmax-xmin)*(right-left),y=bottom-p[metric[0]]/metric[1]*(bottom-top);if(i===0||p.rpm-spec[0][i-1].rpm>200)ctx.moveTo(x,y);else ctx.lineTo(x,y);});ctx.stroke();ctx.setLineDash([]);});});
      }
      s.showDyno=function(){s.page='dyno';drawDyno();};
      s.drawReview=draw;
      s.replay=function(){if(!rows.length)return;s.recording=false;s.review.active=true;s.review.playing=!s.review.playing;if(s.review.index>=rows.length-1)s.review.index=0;draw();};
      s.$on('Mr14ECUMultiplayerStatus',function(_,d){s.$evalAsync(function(){s.multiplayer=d;});});
      s.$on('Mr14ECUState',function(_,d){s.$evalAsync(function(){
        if(s.dyno.current && (!d.installed || d.vehicleId!==s.dyno.current.vehicleId || d.revision!==s.dyno.current.revision || d.engineName!==s.dyno.current.engineName || d.hardwareKey!==s.dyno.current.hardwareKey))s.dyno.invalidate('voiture, moteur ou cartographie modifiés');
        if(s.recording&&d.installed&&(d.hardwareKey!==s.hardwareKey||d.engineName!==s.engineName||d.vehicleId!==lastVehicle)){s.recording=false;s.notice='Configuration changée : acquisition arrêtée.';}s.runtimeVersion=d.runtimeVersion||'ancienne version';s.installed=!!d.installed;pending=false;lastVehicle=d.vehicleId;s.cancelSmooth();
        if(d.installed){s.tune=overrunDefaults(angular.copy(d.tune));if(s.tune.fuelType==='diesel'&&s.tab==='advance'||s.tune.fuelType!=='diesel'&&s.tab.indexOf('diesel')===0)s.tab='fuel';s.throttleControlSupported=!!d.throttleControlSupported;s.ignitionCutSupported=d.ignitionCutSupported===undefined?s.tune.fuelType==='gasoline':d.ignitionCutSupported;s.transmission=d.transmission||{supported:false};s.hasTurbo=d.hasTurbo;s.turboControlSupported=d.turboControlSupported===undefined?d.hasTurbo:d.turboControlSupported;s.antiLagSupported=d.antiLagSupported===undefined?(d.hasTurbo && d.tune.fuelType!=='diesel'):d.antiLagSupported;s.multiplayerRemote=!!d.multiplayerRemote;s.engineName=d.engineName;s.vehicleModel=d.vehicleModel;s.hardwareKey=d.hardwareKey;s.tuneKey=d.tuneKey;s.activeTune=angular.copy(s.tune);s.editor.reset(s.tune);s.profileLoading=false;s.compareRows=[];s.compareLabel='';s.dirty=false;s.revision=d.revision;s.notice='Calculateur connecté — cartographie active.';if(s.page==='overrun')s.prepareOverrunTable();}
        else{s.faultHistory=[];s.activeFaults=[];s.tune=null;s.activeTune=null;s.editor.selection=null;s.live={};s.notice='Installe la pièce « Calculateur reprogrammable By Mr14KaraFR » dans Moteur → ECU / Allumage.';s.recording=false;}
      });});
      s.$on('Mr14ECUSample',function(_,d){s.$evalAsync(function(){
        s.dyno.accept(d);drawDyno();
        if(d.installed && d.vehicleId===lastVehicle && (d.engineName!==s.engineName || d.hardwareKey!==s.hardwareKey || d.revision!==s.revision) && !pending){s.refresh();pending=true;}
        if(d.vehicleId!==lastVehicle){s.recording=false;history=[];s.refresh();return;}
        if(!d.installed){if(s.installed)s.refresh();return;}
        s.live=d;
        if(!s.tune&&!pending){pending=true;s.refresh();}
        if(Number.isFinite(d.time)&&d.time!==lastTime){
          if(d.time<lastTime){s.recording=false;history=[];s.notice='Véhicule réinitialisé : acquisition arrêtée, log conservé.';}
          lastTime=d.time;history.push(d);if(history.length>300)history.shift();
          if(s.recording){if(s.activeTune&&d.revision===s.revision&&!logTunes[d.revision])logTunes[d.revision]=Mr14ECUModePayload(s.activeTune);rows.push(angular.copy(d));s.rowCount=rows.length;if(rows.length>=6000){s.recording=false;s.notice='Limite de 6 000 échantillons atteinte : exporte le CSV.';}}
        }
        draw();
      });});
      s.$on('Mr14ECUFaults',function(_,d){s.$evalAsync(function(){if(d.vehicleId!==lastVehicle)return;s.faultHistory=Array.isArray(d.history)?d.history:[];s.activeFaults=Array.isArray(d.active)?d.active:[];});});
      s.$on('Mr14ECUNotice',function(_,d){s.$evalAsync(function(){if(d.vehicleId===lastVehicle)s.notice=d.message;});});
      s.$on('Mr14ECUFileNotice',function(_,d){s.$evalAsync(function(){s.notice=d.message;if(d.ok===false)s.profileLoading=false;});});
      s.$on('Mr14ECUProfiles',function(_,d){s.$evalAsync(function(){s.profiles=Array.isArray(d)?d:[];});});
      s.$on('Mr14ECUProfileIndex',function(_,d){s.$evalAsync(function(){s.profileIndex=Array.isArray(d)?d:[];});});
      s.$on('Mr14ECULoadedTune',function(_,d){s.$evalAsync(function(){receiveProfile(d,s.profileMode);s.profileMode='load';s.profileLoading=false;});});
      s.$on('VehicleChange',function(){s.dyno.invalidate('voiture changée');history=[];s.recording=false;s.refresh();});
      polling=$interval(function(){
        if(s.review.active&&s.review.playing){s.review.index=Math.min(rows.length-1,s.review.index+1);if(s.review.index>=rows.length-1)s.review.playing=false;draw();}
        if(++faultPoll>=10){faultPoll=0;vehicle('c.requestFaults()');}
        vehicle('c.requestSample()','guihooks.trigger("Mr14ECUSample",{installed=false,vehicleId=obj:getID()})');
      },100);
      s.$on('$destroy',function(){$interval.cancel(polling);if($element[0].removeEventListener){$element[0].removeEventListener('copy',onCopy);$element[0].removeEventListener('paste',onPaste);$element[0].removeEventListener('keydown',onTableKey);}});
      if(!s.isExternal)bngApi.engineLua('if not extensions.mr14karaECUExternal then extensions.load("mr14karaECUExternal") end; if extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.start() end');
      s.refresh();storage('listTunes()');
    }]
  };
});

