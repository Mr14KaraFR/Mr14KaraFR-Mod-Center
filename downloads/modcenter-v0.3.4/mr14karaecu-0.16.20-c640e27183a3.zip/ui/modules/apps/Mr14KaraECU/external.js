/* Named-action adapter: never executes browser-supplied Lua. */
angular.module('beamng.apps',[]);
(function () {
  var cursor=0,busy=false,vehicleId=0;
  function emit(event,data){var injector=angular.element(document.body).injector();if(injector)injector.get('$rootScope').$broadcast(event,data);}
  function send(action){
    action.vehicleId=vehicleId;
    return fetch('/api/action',{method:'POST',headers:{'Content-Type':'application/json','X-ECU-Token':window.ECU_SESSION},body:JSON.stringify(action)})
      .then(function(r){if(!r.ok)throw Error('Connexion refusée');return r.json();})
      .then(function(r){if(!r.ok)emit('Mr14ECUFileNotice',{ok:false,message:r.error});})
      .catch(function(){emit('Mr14ECUFileNotice',{ok:false,message:'Connexion perdue. Vérifie que BeamNG et la liaison externe sont actifs.'});});
  }
  function strings(code){return (code.match(/"(?:\\.|[^"\\])*"/g)||[]).map(function(v){return JSON.parse(v);});}
  window.bngApi={
    activeObjectLua:function(code){
      if(code.includes('c.setTuneJSON(')){var args=strings(code);send({action:'applyTune',tune:JSON.parse(args[1])});}
      else if(code.includes('c.testDetonation()'))send({action:'testDetonation'});
      else if(code.includes('c.requestFaults()'))send({action:'getFaults'});
      else if(code.includes('c.clearFaults()'))send({action:'clearFaults'});
      else if(code.includes('c.resetTune()'))send({action:'resetTune'});
      else if(code.includes('c.requestState()'))send({action:'getState'});
      else if(code.includes('c.requestSample()'))send({action:'getSample'});
    },
    engineLua:function(code){
      var args=strings(code);
      if(code.includes('.saveTune('))send({action:'saveTune',name:args[1],tune:JSON.parse(args[2])});
      else if(code.includes('.loadTune('))send({action:'loadTune',name:args[1]});
      else if(code.includes('.exportLog('))send({action:'exportLog',csv:args[1]});
      else if(code.includes('.listTunes()'))send({action:'listTunes'});
    }
  };
  setInterval(function(){
    if(busy)return;busy=true;
    fetch('/api/events?after='+cursor,{headers:{'X-ECU-Token':window.ECU_SESSION}})
      .then(function(r){if(!r.ok)throw Error('Connexion refusée');return r.json();})
      .then(function(r){cursor=r.cursor;(Array.isArray(r.events)?r.events:[]).forEach(function(e){if(e.event==='Mr14ECUState')vehicleId=e.data.vehicleId;emit(e.event,e.data);});})
      .catch(function(){emit('Mr14ECUFileNotice',{ok:false,message:'BeamNG déconnecté — rouvre la fenêtre depuis le jeu.'});})
      .finally(function(){busy=false;});
  },100);
}());
