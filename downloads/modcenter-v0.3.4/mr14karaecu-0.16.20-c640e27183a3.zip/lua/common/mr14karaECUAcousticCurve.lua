local M={}
local function clamp(x,a,b)return math.max(a,math.min(b,tonumber(x)or 0))end
function M.blend(distance)
 local t=clamp((distance-12)/53,0,1);return t*t*(3-2*t)
end
function M.approach(value,target,dt)return value+(target-value)*(1-math.exp(-clamp(dt,0,.5)/.20))end
return M
