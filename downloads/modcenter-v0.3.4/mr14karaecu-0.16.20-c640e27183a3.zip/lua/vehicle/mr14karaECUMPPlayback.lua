-- Reproduce owner RPM in remote instruments/audio, without driving remote physics.
local M={}
local engine,original,wrapper,frame
function M.reset()
  if engine and engine.updateSounds==wrapper then engine.updateSounds=original end
  engine,original,wrapper,frame=nil,nil,nil,nil
end
function M.update(device,sample,fresh)
  if engine~=device then
    M.reset();engine=device;original=device and device.updateSounds
    if type(original)=='function' then
      local native=original
      wrapper=function(e,dt)
        if not frame then return native(e,dt) end
        local av,load=e.outputAV1,e.instantEngineLoad
        e.outputAV1=frame.rpm*math.pi/30;e.instantEngineLoad=frame.load/100
        local ok,err=pcall(native,e,dt)
        e.outputAV1,e.instantEngineLoad=av,load
        if not ok then error(err) end
      end
      device.updateSounds=wrapper
    end
  end
  frame=fresh and {rpm=sample.rpm,load=sample.load} or nil
  if frame then
    -- Native electrics computes these before controllers each frame.
    electrics.values.rpm=frame.rpm;electrics.values.rpmTacho=frame.rpm
  end
end
function M.status() return {active=frame~=nil,sound=frame~=nil and engine and engine.updateSounds==wrapper or false,rpm=frame and frame.rpm or nil} end
return M
