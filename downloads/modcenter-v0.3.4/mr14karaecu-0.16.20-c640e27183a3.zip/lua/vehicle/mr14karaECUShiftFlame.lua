-- Read-only shift events; no gear or ignition commands.
local M={}
local function clamp(n,a,b)return math.max(a,math.min(b,n))end
function M.new()return {gear=nil,rpm=0,pedal=0,load=0,cooldown=0,cutAge=100,pending=nil,history={},clock=0,reason='En attente de changement de rapport'}end
function M.update(s,dt,i,nativeAge)
 dt=clamp(tonumber(dt) or 0,0,.1);s.cooldown=math.max(0,s.cooldown-dt);s.cutAge=i.cut and 0 or s.cutAge+dt
 s.clock=(s.clock or 0)+dt;s.history=s.history or {}
 local gear=tonumber(i.gear);local rpm=tonumber(i.rpm)or 0;local pedal=tonumber(i.pedal)or 0;local load=tonumber(i.load)or 0
 local supported=i.kind=='automaticGearbox' or i.kind=='dctGearbox' or i.kind=='sequentialGearbox'
 local eligible=i.enabled and i.running and supported and (i.fuel or 0)>0 and (i.retard or 0)>0
 local peakPedal,peakLoad,peakRPM=pedal,load,rpm
 for n=#s.history,1,-1 do local h=s.history[n];if s.clock-h.time>.4 then table.remove(s.history,n) else peakPedal=math.max(peakPedal,h.pedal);peakLoad=math.max(peakLoad,h.load);peakRPM=math.max(peakRPM,h.rpm) end end
 s.history[#s.history+1]={time=s.clock,pedal=pedal,load=load,rpm=rpm}
 s.reason=not i.enabled and 'Détonations désactivées' or not i.running and 'Moteur arrêté' or not supported and 'Type de boîte non reconnu' or peakPedal<(i.minPedal or .45) and 'Accélérateur sous le seuil' or peakLoad<=.30 and 'Charge moteur insuffisante' or peakRPM<(i.minRPM or math.max(2000,(i.maxRPM or 8000)*.4)) and 'Régime sous le seuil' or 'En attente de changement de rapport'
 if not i.running then s.history={} end
 if not eligible or not gear or gear<=0 then s.pending=nil end
 if eligible and gear and s.gear and gear>0 and s.gear>0 and gear~=s.gear and s.cooldown<=0
  and peakPedal>=(i.minPedal or .45) and peakLoad>.30 and peakRPM>=(i.minRPM or math.max(2000,(i.maxRPM or 8000)*.4)) then
  s.pending={age=0,shiftAge=0,cut=s.cutAge<.18,gear=gear}
 end
 s.neutralAge=gear and gear>0 and 0 or (s.neutralAge or 0)+dt
 local observedGear=gear
 if (not gear or gear==0) and (i.shifting or i.cut) and s.neutralAge<.4 then observedGear=s.gear end
 s.gear,s.rpm,s.pedal,s.load=observedGear,rpm,pedal,load
 local p=s.pending;if not p then return nil end
 p.age=p.age+dt;p.cut=p.cut or i.cut==true
 if i.shifting then p.shiftAge=(p.shiftAge or 0)+dt end
 s.reason=i.shifting and 'Passage en cours' or i.cut and 'En attente de fin de coupure' or s.reason
 if not gear or gear<=0 or gear~=p.gear or not i.running or p.age>(i.maxTime or 2.5)+.7 or p.shiftAge>(i.maxTime or 2.5) then s.pending=nil;s.reason='Passage trop lent ou interrompu';return nil end
 if p.age>=.045 and not i.shifting and not i.cut then
  s.pending=nil;s.cooldown=.30
  if not i.force and (nativeAge or 100)<.18 then s.reason='Bang natif déjà joué';return nil end
  s.reason='Détonation de passage déclenchée'
  local lambda=clamp(tonumber(i.lambda)or 1,.45,2)
  local energy=clamp(i.fuel/40*i.retard/40*(1+(.95-lambda)*.5),0,1)
  return {strength=clamp(.30+.65*math.sqrt(energy),.30,.98),cut=p.cut}
 end
 return nil
end
return M
