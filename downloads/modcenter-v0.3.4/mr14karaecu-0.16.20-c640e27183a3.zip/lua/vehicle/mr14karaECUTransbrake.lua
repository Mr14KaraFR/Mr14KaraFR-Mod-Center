-- Native automatic gearbox transbrake; release only locks owned by this module.
local M={}
local owned,input,blocked=false,false,false
local device,elapsed=nil,0
local state={supported=false,active=false,held=false,reason='En attente de boîte'}
local function release(reason)
  if owned and device and device.lockCoef==0 then device:setLock(false) end
  owned=false;elapsed=0;state.active=false;state.elapsed=0
  if reason then state.reason=reason end
end
function M.reset()
  release('Relâché');input=false;blocked=false;device=nil
  state={supported=false,active=false,held=false,elapsed=0,reason='En attente de boîte'}
end
function M.setInput(value)
  input=value==true;state.held=input
  if not input then blocked=false;release('Relâché') end
end
function M.active() return owned end
function M.held() return input end
function M.status() return state end
function M.update(dt,cfg,engine,remote)
  local gb=powertrain and powertrain.getDevice and powertrain.getDevice('gearbox')
  if gb~=device then local old=device;release('Boîte changée');device=gb;if old and input then blocked=true end end
  state.supported=gb~=nil and gb.type=='automaticGearbox' and type(gb.setLock)=='function' and type(gb.lockCoef)=='number'
  state.active=owned;state.held=input
  local function reject(reason)
    if input then blocked=true end
    release(reason);return state
  end
  if playerInfo and playerInfo.anyPlayerSeated==false then return reject('Véhicule quitté : transbrake relâché') end
  if remote then return reject('Véhicule distant : commande bloquée') end
  if not state.supported then return reject('Boîte automatique à convertisseur compatible nécessaire') end
  if not cfg or not cfg.enabled then return reject('Désactivé') end
  if not engine or engine.hasFuel==false or engine.isDisabled or engine.isStalled or (engine.ignitionCoef or 1)<=0 then return reject('Moteur arrêté') end
  local ev=electrics and electrics.values or {}
  local speed=math.max(math.abs(tonumber(ev.airspeed) or 0),math.abs(tonumber(ev.wheelspeed) or 0))*3.6
  if speed>2 then return reject('Activation réservée à l’arrêt (2 km/h maximum)') end
  if gb.gearIndex~=1 or gb.isShifting then return reject('Engager le premier rapport avant') end
  if not input then release('Prêt · maintenir la commande');return state end
  if blocked then state.reason='Relâcher la commande avant de réarmer';return state end
  if owned and gb.lockCoef~=0 then return reject('Verrou libéré par une autre commande') end
  if not owned then
    if gb.lockCoef~=1 then return reject('Transmission déjà verrouillée par une autre commande') end
    gb:setLock(true);owned=true;elapsed=0
  end
  elapsed=elapsed+math.max(dt or 0,0)
  if elapsed>=(cfg.maxHold or 8) then return reject('Durée maximale atteinte · relâcher pour réarmer') end
  state.active=owned;state.elapsed=elapsed;state.reason='Transbrake actif · relâcher pour partir'
  return state
end
return M
