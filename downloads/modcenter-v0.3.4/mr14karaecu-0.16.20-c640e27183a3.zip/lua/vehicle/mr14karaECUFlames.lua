-- ECU-owned adapter for the installed VBF 6.48 renderer. No VBF files changed.
local M = {}
local shiftModel=require('mr14karaECUShiftFlame')
local shiftState=shiftModel.new()
local lastNative,shiftBlockUntil=-100,-100
local styleModel=require('mr14karaECUFlameStyle')
local burnModel=require('mr14karaECUOverrunFlame')
local burnState=burnModel.new(0)
local burnPhase,burnFactor='off',0
local releaseModel=require('mr14karaECUFlameRelease')
local releaseState=releaseModel.new()
local exhaustSound=require('mr14karaECUExhaustSound')
local distance=require('mr14karaECUAcousticDistance')
local gasResumed=false
local function soundCharacter(engine,node)return exhaustSound.character(v and v.data,node,engine and engine.thermals and engine.thermals.exhaustEndNodes or {})end
local bridge, originals, wrappers
local command, ready, pulseTime, audioTime = nil,false,0,0
local pulses, strength, active = 0,0,false
local audio
local megaAudio
local breathAudio
local popAudio
local shiftBangCount,limiterBangCount=0,0
local testCount,lastAudioOK,lastAudioError=0,nil,nil
local bangTime,rollingBangTime,rollingBangCount=0,0,0
local popSerial=0
local popOutlets=require('mr14karaECUPopOutlets')
local outletState=popOutlets.new(0)
local popState=styleModel.newPopState(0)
local lastPopKind,lastPopTrain=nil,false
local held, clock, endSerial = {},0,0
local finale=require('mr14karaECUFlameFinale')
local finalePhase,finaleCount,stutterCount,finaleStrength='idle',0,0,0
local function soundScale()
 local ok,settings=pcall(require,'common/vbfSettings')
 return ok and settings and settings.resolve and settings.resolve().soundVolume or 1
end
local function outletEvent(h,level,boost,gasScale,duration)
 local event={unpack(h.event)}
 local p=obj:getNodePosition(event[10]);local d=p-obj:getNodePosition(event[11])
 if d:length()<=.0001 then return nil end
 d:normalize();p=p+obj:getPosition();local v=obj:getNodeVelocityVector(event[10])
 event[1],event[2],event[3],event[4],event[5],event[6]=p.x,p.y,p.z,d.x,d.y,d.z
 event[7],event[8],event[9]=v.x,v.y,v.z
 event[12],event[13],event[14],event[18],event[20],event[26]=level,0,duration,boost,1,gasScale
 return event
end
local function sendEvent(event)
 if event then obj:queueGameEngineLua('if extensions.volumetricBackfireRenderer then extensions.volumetricBackfireRenderer.burst('..obj:getId()..','..serialize({event})..') end') end
end
local function dispatchPops(engine,items)
 for _,item in ipairs(items)do
  local e=item.event
  if not obj:inWater(e[10])then
   local event=outletEvent({event=e},e[12],e[18],e[26],e[14])
   if event then
    sendEvent(event)
    popOutlets.accept(outletState,item)
    local inside=audio and audio.isInterior and audio.isInterior()or false
    local played=popAudio and popAudio.play and popAudio.play(obj,e[10],e[12],item.count,1/item.period,inside,soundScale(),item.kind,soundCharacter(engine,e[10]))
    if not played and audio and audio.play then audio.play(obj,'event:>Vehicle>Afterfire>single',e[10],(.15+.65*(e[26]or 1)^2)/math.sqrt(item.count),1,0,0,e[12],command and command.rpm or 0)end
   end
  end
 end
end
local function finishHeld(engine,flush)
 for node,h in pairs(held) do
  local running
  if command and command.remote then running=command.engineRunning==true else running=engine and engine.hasFuel~=false and not engine.isDisabled and (engine.ignitionCoef or 1)>0 end
  local continuous=command and (command.style or command.mode)=='continuous'
  local holding=h.style==2 and command and command.managed and command.active and continuous
    and (command.demand or 0)>0 and (command.extraFuel or 0)>0 and (command.retard or 0)>0
  if holding then h.lastCommand=clock;h.releaseChecked=nil;h.silentEnd=nil
  elseif h.style==2 and not h.releaseChecked then
    h.releaseChecked=true;h.silentEnd=clock-h.last>.35
  end
  local gap=clock-(h.style==2 and h.lastCommand or h.last or clock)
  local duration=h.style==2 and (h.burnTime or 0) or h.last-h.born
  if flush or not running or not engine or obj:inWater(node) or h.silentEnd or gasResumed and h.style==2 then held[node]=nil
  elseif h.style==2 then
   if duration<.35 then
    if gap>.18 then held[node]=nil end
   elseif gap>.12 then
    if not h.ending then
     h.ending=finale.plan(duration,(h.energySum or 0)/math.max(1,h.samples or 1),(h.heatSum or 0)/math.max(1,h.samples or 1),endSerial+1)
    end
    local plan=h.ending;finalePhase='decay'
    if plan.stutter and not h.stuttered and gap>=plan.stutterDelay then
     h.stuttered=true;stutterCount=stutterCount+1;finalePhase='stutter'
     sendEvent(outletEvent(h,plan.stutterStrength,1,plan.stutterScale,.70))
     if popAudio and popAudio.play then popAudio.play(obj,node,plan.stutterStrength,h.count,4,audio and audio.isInterior and audio.isInterior() or false,soundScale(),'crackle',soundCharacter(engine,node)) end
    end
    if gap>=plan.delay then
     held[node]=nil -- remove before emission: neither flash can rearm the session
     endSerial=endSerial+1;finaleCount=finaleCount+1;finaleStrength=plan.strength;finalePhase='impact'
     sendEvent(outletEvent(h,plan.strength,plan.boost,plan.gasScale,plan.duration))
     if audio and audio.finish then
      local class=0;local ok,profile=pcall(require,'common/vbfProfile657')
      if ok and profile and profile.exhaustClass then class=profile.exhaustClass(v and v.data,engine.thermals and engine.thermals.exhaustEndNodes or {}) end
      exhaustSound.finish(obj,node,plan.strength,clock,h.count,soundScale()*plan.gain,plan.massive,class,audio and audio.isInterior and audio.isInterior()or false,soundCharacter(engine,node))
     end
    end
   end
  elseif gap>.18 then
   -- Preserve the existing launch/anti-lag finale; only continuous flames use
   -- the new pressure-release sequence.
   held[node]=nil
   if duration>=.35 and audio and audio.finish then
    local class=0;local ok,profile=pcall(require,'common/vbfProfile657')
    if ok and profile and profile.exhaustClass then class=profile.exhaustClass(v and v.data,engine.thermals and engine.thermals.exhaustEndNodes or {}) end
    if class>0 then
     endSerial=endSerial+1;local massive=duration>=1.2 and h.strength>.85 and endSerial%5==0
     sendEvent(outletEvent(h,massive and 1 or math.max(.85,h.strength),massive and 1.65 or 1.25,h.event[26] or 1,1))
     exhaustSound.finish(obj,node,h.strength,clock,h.count,soundScale(),massive,class,audio and audio.isInterior and audio.isInterior()or false,soundCharacter(engine,node))
    end
   end
  end
 end
end
local function ownsOverrun()
  if not command or not command.managed then return false end
  local pedal=tonumber(electrics.values.throttle_input) or 0
  return command.active or command.mode~='off' and pedal*100<=(command.maxThrottle or 5)
end
function M.reset()
  distance.reset(obj)
  releaseState=releaseModel.new();gasResumed=false;exhaustSound.reset()
  outletState=popOutlets.new(obj and obj.getId and obj:getId()or 0)
  if megaAudio then megaAudio.reset(obj) end
  shiftState=shiftModel.new();lastNative,shiftBlockUntil=-100,-100
  if breathAudio and breathAudio.reset then breathAudio.reset(obj) end
  burnState=burnModel.new(obj and obj.getId and obj:getId() or 0);burnPhase,burnFactor='off',0
  popState=styleModel.newPopState(obj and obj.getId and obj:getId() or 0);lastPopKind,lastPopTrain=nil,false
  popSerial=0;bangTime=0;rollingBangTime,rollingBangCount=0,0;shiftBangCount,limiterBangCount=0,0;testCount,lastAudioOK,lastAudioError=0,nil,nil
  if popAudio and popAudio.reset then popAudio.reset() end
  if bridge then
    for name,fn in pairs(originals or {}) do
      if bridge[name]==wrappers[name] then bridge[name]=fn end
    end
  end
  bridge,originals,wrappers,command=nil,nil,nil,nil
  held,clock,endSerial={},0,0
  finalePhase,finaleCount,stutterCount,finaleStrength='idle',0,0,0
  ready,pulseTime,audioTime,pulses,strength,active=false,0,0,0,0,false
end
local function bind(candidate)
  if bridge==candidate then return end
  M.reset()
  if not candidate or candidate.ecuCompatible or type(candidate.emit)~='function'
    or type(candidate.playNativeAudio)~='function' or type(candidate.setReady)~='function' then return end
  bridge=candidate;originals={};wrappers={}
  for _,name in ipairs({'emit','playNativeAudio'}) do
    local fn=candidate[name];originals[name]=fn
    wrappers[name]=function(...)
      -- Prevent the old lift/hold generator from adding an unrelated big flame.
      if clock<shiftBlockUntil or ownsOverrun() then return true end
      lastNative=clock
      return fn(...)
    end
    candidate[name]=wrappers[name]
  end
  originals.setReady=candidate.setReady
  wrappers.setReady=function(value) ready=value==true;return originals.setReady(value) end
  candidate.setReady=wrappers.setReady
  local megaOK,mega=pcall(require,'mr14karaECUDetonationAudio');megaAudio=megaOK and mega or nil
  local ok,result=pcall(require,'common/vbfAudio648');audio=ok and result or nil
  local breathOK,breathModule=pcall(require,'mr14karaECUBreath');breathAudio=breathOK and breathModule or nil
  local popOK,popModule=pcall(require,'mr14karaECUExhaustSound');popAudio=popOK and popModule or nil
  obj:queueGameEngineLua("extensions.load('volumetricBackfireRenderer'); if extensions.volumetricBackfireRenderer then extensions.volumetricBackfireRenderer.connect("..obj:getId()..") end")
end
function M.update(dt,engine,state)
  -- The real vehicle fuel type wins over remote or forced ECU flame requests.
  if engine and tostring(engine.requiredEnergyType or ''):lower()=='diesel' then
    local hadState=bridge~=nil or active
    M.reset()
    if hadState then obj:queueGameEngineLua('if extensions.volumetricBackfireRenderer then extensions.volumetricBackfireRenderer.removeVehicle('..obj:getId()..') end') end
    return M.status()
  end
  local delta=math.min(math.max(dt or 0,0),.1)
  clock=clock+delta
  if not state.managed then command=state;finishHeld(engine,true);M.reset();return M.status() end
  bind(rawget(_G,'volumetricBackfireBridge'))
  if bridge then distance.watch(obj,engine)end
  if command and (command.mode~=state.mode or command.style~=state.style) then burnModel.stop(burnState);burnPhase,burnFactor='off',0;styleModel.clearPopTrain(popState);lastPopKind,lastPopTrain=nil,false;pulseTime,audioTime=0,0;if breathAudio and breathAudio.reset then breathAudio.reset(obj) end end
  command=state
  local release=releaseModel.step(releaseState,clock,{
    managed=state.managed,continuous=(state.style or state.mode)=='continuous',
    running=state.remote and state.engineRunning==true or not state.remote and engine and engine.hasFuel~=false and not engine.isDisabled and (engine.ignitionCoef or 1)>0,
    blocked=state.rolling and state.rolling[1],
    pedal=tonumber(state.shiftPedal)or tonumber(electrics.values.throttle_input)or 0,maxThrottle=(tonumber(state.maxThrottle)or 5)/100})
  gasResumed=release.cancel
  if release.started and breathAudio and breathAudio.release then breathAudio.release(clock,.12)end
  if release.emit then
    for _,e in ipairs(release.events)do
      if not obj:inWater(e[10])then
        local event=outletEvent({event=e},e[12]*release.factor,1,e[26]*math.sqrt(release.factor),.7)
        if event then event[13]=.025;event[20]=e[20];sendEvent(event)end
      end
    end
  end
  if breathAudio and breathAudio.update then breathAudio.update(obj,clock,state.active and state.demand>0 and not gasResumed)end
  local bang=state.bangs
  local shiftPulse=shiftModel.update(shiftState,delta,{gear=state.shiftGear,kind=state.shiftKind,
    rpm=state.rpm,pedal=state.shiftPedal,load=state.shiftLoad,cut=state.shiftCut,shifting=state.shiftBusy,
    enabled=state.managed and (bang and bang[1] or not bang and state.mode~='off') and state.shiftAllowed~=false,running=state.remote and state.engineRunning==true or not state.remote and engine.hasFuel~=false and not engine.isDisabled and engine.outputTorqueState~=0 and (engine.ignitionCoef or 1)>0,
    fuel=state.shiftFuel,retard=state.shiftRetard,lambda=state.lambda,maxRPM=state.shiftMaxRPM,force=bang and bang[1],maxTime=bang and bang[4],minPedal=bang and bang[5]/100,minRPM=bang and bang[6]},clock-lastNative)
  if shiftState.pending or shiftPulse then
    for _,h in pairs(held) do if clock-h.last<.35 then h.last=clock end end
  end
  finishHeld(engine,false)
  local running
  if state.remote then running=state.engineRunning==true else running=engine.hasFuel~=false and not engine.isDisabled and (engine.ignitionCoef or 1)>0 end
  if not running and breathAudio and breathAudio.reset then breathAudio.reset(obj) end
  bangTime=math.max(0,bangTime-delta)
  local limiterPulse=bang and bang[7] and running and bangTime<=0
  if limiterPulse then bangTime=1/math.max(1,math.min(15,bang[10])) end
  local rolling=state.rolling
  local rollingOwned=rolling and rolling[1]==true
  rollingBangTime=math.max(0,rollingBangTime-delta)
  if not rollingOwned then rollingBangTime=0 end
  local rollingPulse=rollingOwned and rolling[2]==true and running and rollingBangTime<=0
  if rollingPulse then rollingBangTime=1/math.max(1,math.min(12,rolling[5])) end
  local bigPulse=rollingPulse or bang and (limiterPulse or shiftPulse~=nil)
  local bangVolume=rollingPulse and rolling[3]*10 or bigPulse and (limiterPulse and bang[8] or bang[2]) or 0
  local bangFlame=rollingPulse and rolling[4]*2 or bigPulse and (limiterPulse and bang[9] or bang[3]) or 0
  active=bridge~=nil and (state.active and state.demand>0 and not gasResumed or shiftPulse~=nil or limiterPulse or rollingPulse) and running
  if rollingOwned and not bigPulse then active=false end
  dispatchPops(engine,popOutlets.drain(outletState,clock,active and not bigPulse and not shiftPulse
    and (state.style or state.mode)=='pops'and (state.extraFuel or 0)>0 and (state.retard or 0)>0))
  if not active then burnModel.stop(burnState);burnPhase,burnFactor='off',0;styleModel.clearPopTrain(popState);lastPopKind,lastPopTrain=nil,false;pulseTime,audioTime,strength=0,0,0;return M.status() end
  local profile=styleModel.resolve(state)
  if limiterPulse or rollingPulse then profile.id,profile.demand,profile.hold,profile.period=1,1,0,.05;pulseTime,audioTime=0,0 end
  if shiftPulse then
    profile.id,profile.demand,profile.hold,profile.period=1,(shiftPulse.strength-.2)/.8,0,.05
    pulseTime,audioTime=0,0;shiftBlockUntil=clock+.30
  end
  if profile.demand<=0 then
    burnModel.stop(burnState);burnPhase,burnFactor='off',0
    styleModel.clearPopTrain(popState);lastPopKind,lastPopTrain=nil,false
    pulseTime,audioTime,strength=0,0,0;active=false;return M.status()
  end
  if profile.id==2 and not bigPulse and not shiftPulse then
    local burn=burnModel.step(burnState,delta,profile,state)
    burnPhase,burnFactor=burn.phase,burn.factor
    profile.demand,profile.hold=burn.demand,burn.hold
    if not burn.emit then strength=0;pulseTime=0;return M.status() end
  else burnModel.stop(burnState);burnPhase,burnFactor='off',0 end
  local continuous=profile.id~=1
  local period=profile.period
  pulseTime=pulseTime-delta;audioTime=audioTime-delta
  if pulseTime>1e-9 then return M.status() end
  local popPulse
  if profile.id==1 and not shiftPulse and not limiterPulse and not rollingPulse then
    popSerial=popSerial+1;popPulse=styleModel.pulse(profile,popSerial,popState);period=popPulse.period
    lastPopKind,lastPopTrain=popPulse.kind,popPulse.train
  end
  if not popPulse then styleModel.clearPopTrain(popState);lastPopKind,lastPopTrain=nil,false end
  pulseTime=period -- No accumulated burst storm after pause/frame stalls.
  -- VBF acknowledges readiness only after rendering its first real burst.
  -- Eligible bursts must bootstrap that callback; waiting here deadlocks it.
  if shiftPulse then popPulse={demand=profile.demand,period=.05,boost=1.10,kind='bang'} end
  local demand=popPulse and popPulse.demand or profile.demand
  strength=.2+.8*demand
  local gasScale=math.sqrt(math.max(.0025,math.min(1,demand)))
  local flameSize=math.max(0,math.min(1,bangFlame/200))
  if bigPulse then strength=.2+.8*flameSize;gasScale=math.sqrt(math.max(.0025,flameSize)) end
  local tipOK,tipProfile=pcall(require,'common/vbfProfile657')
  local events,seen={},{}
  local wx,wy,wz=0,0,0
  if obj.getWind then local ok,w=pcall(obj.getWind,obj);if ok and w then wx,wy,wz=w.x or 0,w.y or 0,w.z or 0 end end
  for _,pipe in pairs(engine.thermals and engine.thermals.exhaustEndNodes or {}) do
    local finish,start=pipe.finish,pipe.start
    local key=tostring(finish)..':'..tostring(start)
    if finish~=nil and start~=nil and not seen[key] and #events<8 and not obj:inWater(finish) then
      seen[key]=true
      local p=obj:getNodePosition(finish)
      local direction=p-obj:getNodePosition(start)
      if direction:length()>.0001 then
        direction:normalize();p=p+obj:getPosition()
        local velocity=obj:getNodeVelocityVector(finish)
        events[#events+1]={p.x,p.y,p.z,direction.x,direction.y,direction.z,velocity.x,velocity.y,velocity.z,finish,start,strength,
          profile.hold,popPulse and popPulse.duration or .7+.55*demand,wx,wy,wz,popPulse and popPulse.boost or 1,profile.heat,profile.id,profile.rich,profile.retard,tipOK and tipProfile.tipScale and tipProfile.tipScale(v and v.data,finish) or 1,tipOK and tipProfile.tipForm and tipProfile.tipForm(v and v.data,finish) or 0,1,gasScale}
      end
    end
  end
  if bigPulse then
    for _,event in ipairs(events) do
      event[14]=.7+.55*flameSize
      event[18]=1+.65*flameSize
      event[23]=math.max(.65,math.min(1.45,(event[23] or 1)*(.65+.8*flameSize)))
    end
  end
  if #events>0 then
    if bigPulse then if state.test then testCount=testCount+1 elseif rollingPulse then rollingBangCount=rollingBangCount+1 elseif limiterPulse then limiterBangCount=limiterBangCount+1 else shiftBangCount=shiftBangCount+1 end end
    if popPulse and profile.id==1 and not shiftPulse and not bigPulse then
      dispatchPops(engine,popOutlets.schedule(outletState,events,clock,popSerial,popPulse.kind,period))
      pulses=pulses+1;return M.status()
    end
    if profile.id==2 then releaseModel.capture(releaseState,events,clock)end
    -- Only accepted held-flame events count; discrete pops never arm the boom.
    if profile.id==2 or profile.id==3 or profile.id==4 then
      for _,event in ipairs(events) do
        local node=event[10]
        local h=held[node]
        if not h then h={born=clock};held[node]=h end
        if profile.id==2 then
          h.burnTime=(h.burnTime or 0)+math.min(.1,math.max(0,clock-(h.last or clock)))
          h.lastCommand=clock;h.releaseChecked=nil;h.silentEnd=nil
        else h.burnTime=nil;h.lastCommand=nil end
        h.last,h.strength,h.count,h.event,h.style=clock,strength,#events,event,profile.id
        h.samples=(h.samples or 0)+1
        h.energySum=(h.energySum or 0)+(event[26] or 1)^2
        h.heatSum=(h.heatSum or 0)+(event[19] or .65)
        h.ending,h.stuttered=nil,nil
        if profile.id==2 then finalePhase='burning' end
      end
    end
    local breathing=false
    if profile.id==2 and breathAudio and breathAudio.touch then
      local scale=1
      local settingsOK,settings=pcall(require,'common/vbfSettings')
      if settingsOK and settings and settings.resolve then scale=settings.resolve().soundVolume or 1 end
      for _,event in ipairs(events) do
        breathing=breathAudio.touch(obj,event[10],strength,clock,#events,scale*math.sqrt(math.min(1,demand/.4)),audio and audio.isInterior and audio.isInterior() or false,soundCharacter(engine,event[10])) or breathing
      end
    end
    pulses=pulses+1
    if not bigPulse or bangFlame>0 then obj:queueGameEngineLua('if extensions.volumetricBackfireRenderer then extensions.volumetricBackfireRenderer.burst('..obj:getId()..','..serialize(events)..') end') end
    if bigPulse then
      if bangVolume>0 and (megaAudio or audio and audio.play) then
        local scale=1;local ok,settings=pcall(require,'common/vbfSettings');if ok and settings and settings.resolve then scale=settings.resolve().soundVolume or 1 end
        for _,event in ipairs(events) do
          -- Up to 500 use the known VBF bank. Above 500 the ECU uses stronger
          -- recordings, because a native source gain above 1 may be clamped.
          local played=false
          if bangVolume>500 and megaAudio then
            local ok,result=pcall(megaAudio.play,obj,event[10],bangVolume,#events,audio and audio.isInterior and audio.isInterior() or false,scale)
            played=ok and result==true;if not played then lastAudioError=tostring(result) end
          end
          if not played and audio and audio.play then
            local ok,result=pcall(audio.play,obj,'event:>Vehicle>Afterfire>01_Single_EQ1',event[10],(math.min(bangVolume,500)/500)^.75*math.min(scale,1)/math.sqrt(#events),.96,0,0,1,state.rpm,bangVolume>=200)
            played=ok and result~=false
            if not played then lastAudioError=tostring(result) end
          end
          if not played and megaAudio then
            local ok,result=pcall(megaAudio.play,obj,event[10],bangVolume,#events,audio and audio.isInterior and audio.isInterior() or false,scale)
            played=ok and result==true
            if not played then lastAudioError=tostring(result) end
          end
          lastAudioOK=played;if played then lastAudioError=nil end
        end
      end
    elseif not breathing and audio and audio.play and (profile.id==1 or audioTime<=0) then
      audioTime=profile.id==2 and .2 or profile.id==3 and (.105+.04*(.5+.5*math.sin(pulses*2.399963))) or profile.id==4 and (.14+.055*(.5+.5*math.sin(pulses*1.754877))) or period
      for _,event in ipairs(events) do
        local played=false
        if profile.id==1 and popAudio and popAudio.play then
          local soundScale=1
          local settingsOK,settings=pcall(require,'common/vbfSettings')
          if settingsOK and settings and settings.resolve then soundScale=settings.resolve().soundVolume or 1 end
          played=popAudio.play(obj,event[10],strength,#events,1/period,audio.isInterior and audio.isInterior() or false,soundScale,popPulse and popPulse.kind or 'pop',soundCharacter(engine,event[10]))
        end
        if (profile.id==3 or profile.id==4) and popAudio and popAudio.play then
          local scale=1
          local settingsOK,settings=pcall(require,'common/vbfSettings')
          if settingsOK and settings and settings.resolve then scale=settings.resolve().soundVolume or 1 end
          played=popAudio.play(obj,event[10],strength*(profile.id==3 and .8 or .75),#events,
            profile.id==3 and 8 or 6,audio.isInterior and audio.isInterior() or false,scale,
            profile.id==3 and 'pop' or 'bang',soundCharacter(engine,event[10]))
        end
        if not played then audio.play(obj,'event:>Vehicle>Afterfire>single',event[10],(.15+.65*demand)/math.sqrt(#events),1,0,0,
          profile.id==2 and strength*.4 or profile.id==4 and strength*.65 or strength,state.rpm) end
      end
    end
  else strength=0 end
  return M.status()
end
-- Explicit stationary check, using exactly the same outlet/render/audio path.
function M.test(engine,settings)
  if not engine or tostring(engine.requiredEnergyType or ''):lower()=='diesel' then return false,'Essai disponible sur moteur essence uniquement.' end
  if engine.hasFuel==false or engine.isDisabled or (engine.ignitionCoef or 1)<=0 or (engine.outputAV1 or 0)*9.549296586<300 then return false,'Démarre le moteur avant le test.' end
  if math.abs(tonumber(electrics.values.wheelspeed) or 0)>.5 then return false,'Arrête la voiture avant le test.' end
  local before=pulses
  pulseTime,audioTime,bangTime=0,0,0
  M.update(0,engine,{managed=true,active=false,mode='off',style='off',demand=0,test=true,rpm=(engine.outputAV1 or 0)*9.549296586,
    bangs={false,0,0,.3,60,2500,true,settings.volume*10,settings.flame*2,5}})
  if not bridge then return false,'Mod de flammes non connecté à cette voiture.' end
  if pulses<=before then return false,'Aucune sortie échappement utilisable sur ce moteur.' end
  if lastAudioOK==false then return false,'Flamme envoyée ; échec de lecture audio : '..tostring(lastAudioError) end
  return true,'Essai envoyé : une détonation. Vérifie le son et la flamme à l’échappement.'
end
function M.status() return {supported=bridge~=nil,ready=ready,strength=strength,pulses=pulses,popKind=lastPopKind,popTrain=lastPopTrain,pendingPopOutlets=#outletState.pending,outletBalance=popOutlets.stats(outletState),listener=distance.stats(),combustionPhase=burnPhase,combustionFactor=burnFactor,releaseFactor=releaseState.factor,gasResumed=gasResumed,exhaustAudio=exhaustSound.stats(),finalePhase=finalePhase,finaleCount=finaleCount,finaleStutters=stutterCount,finaleStrength=finaleStrength,active=active,detonationAudioReady=audio~=nil or megaAudio~=nil,detonationTestCount=testCount,detonationAudioError=lastAudioError,detonationRollingCount=rollingBangCount,detonationShiftCount=shiftBangCount,detonationLimiterCount=limiterBangCount,detonationReason=bridge and shiftState.reason or 'Rendu VBF non connecté'} end
return M
