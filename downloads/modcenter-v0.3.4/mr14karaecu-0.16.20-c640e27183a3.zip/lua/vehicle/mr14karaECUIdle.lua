local M={}
local axes={-10,0,20,40,60,80,100}
function M.defaults(e)
 local rpm=math.max(500,math.min(2250,e and e.idleRPM or 800))
 return {enabled=false,rpm={rpm+250,rpm+200,rpm+150,rpm+100,rpm+50,rpm,rpm},amplitude=0,period=1}
end
local function finite(x) return type(x)=='number' and x==x and math.abs(x)<1e20 end
function M.valid(t)
 if type(t)~='table' or type(t.enabled)~='boolean' or type(t.rpm)~='table' or #t.rpm~=7 then return false end
 for i=1,7 do if not finite(t.rpm[i]) or t.rpm[i]<500 or t.rpm[i]>2500 then return false end end
 return finite(t.amplitude) and t.amplitude>=0 and t.amplitude<=300 and finite(t.period) and t.period>=.3 and t.period<=5
end
function M.restore(e,s)
 if not s then return end
 if e.idleAV==s.owned then e.idleAV=s.av;e.idleRPM=s.rpm end
 s.owned=nil;s.phase=0
end
function M.capture(e) return type(e.idleAV)=='number' and {av=e.idleAV,rpm=e.idleRPM,phase=0} or nil end
function M.update(e,s,t,dt,temperature,pedal,speed,limit)
 if not s then return 0,false,false end
 if not t.enabled or not finite(temperature) then M.restore(e,s);return s.rpm,false,false end
 local target=t.rpm[7]
 if temperature<=axes[1] then target=t.rpm[1] else
  for i=2,7 do if temperature<=axes[i] then local f=(temperature-axes[i-1])/(axes[i]-axes[i-1]);target=t.rpm[i-1]+(t.rpm[i]-t.rpm[i-1])*f;break end end
 end
 local varying=t.amplitude>0 and pedal<.02 and speed<1 and e.hasFuel~=false and not e.isDisabled and (e.ignitionCoef or 1)>0
 if varying then s.phase=(s.phase+math.max(0,dt or 0)/t.period) % 1;target=target+t.amplitude*math.sin(s.phase*2*math.pi) else s.phase=0 end
 target=math.max(500,math.min(2500,target,limit and limit>0 and math.max(500,limit-200) or 2500))
 e.idleRPM=target;e.idleAV=target*math.pi/30;s.owned=e.idleAV
 return math.max(target,(e.idleAVOverwrite or 0)*30/math.pi),true,varying
end
return M
