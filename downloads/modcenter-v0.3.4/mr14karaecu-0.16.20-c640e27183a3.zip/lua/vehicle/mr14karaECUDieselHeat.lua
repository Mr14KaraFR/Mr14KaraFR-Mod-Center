-- Visual heat estimate; not a measured EGT or a combustion solver.
local M={}
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<1e20 end
local function clamp(n,a,b) return math.max(a,math.min(b,n)) end
function M.defaults() return {enabled=true,start=850,full=1100} end
function M.validate(c)
  return type(c)=='table' and type(c.enabled)=='boolean' and finite(c.start) and finite(c.full)
    and c.start>=600 and c.full<=1400 and c.full>=c.start+50
end
function M.update(s,e,c,dt,input)
  dt=clamp(tonumber(dt) or 0,0,.25);c=c or M.defaults()
  local running=input.engineRunning==true and (input.rpm or 0)>650
  if input.remote then
    s.egt=finite(input.remoteEGT) and clamp(input.remoteEGT,0,1600) or 20
    s.demand=running and finite(input.remoteDemand) and clamp(input.remoteDemand,0,1) or 0
    return s.demand,s.egt
  end
  local load=clamp(input.load or 0,0,1);local fuel=clamp(input.fuelFactor or 1,0,10)
  local lambda=clamp(input.lambda or 2,.01,100);local target=20
  if running then
    target=180+load*(400+180*clamp((input.rpm or 0)/5000,0,1))
      +math.max(0,fuel-1)*330*load+clamp(1-lambda,0,1)*150*load
    target=clamp(target,180,1350)
  end
  s.egt=s.egt or 20
  s.egt=s.egt+(target-s.egt)*(1-math.exp(-dt/(target>s.egt and 2.2 or 3.5)))
  local heat=clamp((s.egt-c.start)/(c.full-c.start),0,1)
  local excess=clamp((fuel-1.1)/.9,0,1)*clamp((1.2-lambda)/.6,0,1)
  s.demand=running and c.enabled and (input.pedal or 0)>.2 and (input.rpm or 0)>1500
    and heat*excess*clamp((load-.35)/.65,0,1) or 0
  return s.demand,s.egt
end
return M
