-- Owner-only engine traction control. Native ESC/ABS remain authoritative.
local M={}
local factor=1
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<1e20 end
local function bound(n,a,b) return math.max(a,math.min(b,n)) end
function M.defaults() return {enabled=false,slip=12,strength=70,response=10,recovery=3} end
function M.valid(c)
  if type(c)~='table' or type(c.enabled)~='boolean' then return false end
  for k,r in pairs({slip={0,100},strength={0,100},response={1,30},recovery={.1,10}}) do if not finite(c[k]) or c[k]<r[1] or c[k]>r[2] then return false end end
  return true
end
function M.reset() factor=1 end
function M.update(dt,c,e,bypass)
  local s={supported=false,active=false,slip=0,factor=1}
  if not c or not c.enabled then factor=1;s.reason='Désactivé';return s end
  if bypass then factor=1;s.reason='Priorité au launch / rolling';return s end
  if not e or e.hasFuel==false or (e.ignitionCoef or 1)<=0 or (e.outputAV1 or 0)<30 then factor=1;s.reason='Moteur arrêté';return s end
  local ev=electrics and electrics.values or {}
  local gear=tonumber(ev.gearIndex)
  if not gear or gear==0 then factor=1;s.reason='Rapport non engagé';return s end
  if not wheels or type(wheels.wheels)~='table' or not obj or not obj.getVelocity or not obj.getDirectionVector then factor=1;s.reason='Capteurs de roues indisponibles';return s end
  local direction=gear<0 and -1 or 1
  local velocity=obj:getVelocity();local forward=obj:getDirectionVector()
  local speed=velocity:dot(forward)*direction
  if not finite(speed) then factor=1;s.reason='Vitesse véhicule indisponible';return s end
  speed=math.max(0,speed)
  local fastest,count=0,0
  for _,w in pairs(wheels.wheels) do
    if w.isPropulsed and not w.isBroken and finite(w.wheelSpeed) then fastest=math.max(fastest,w.wheelSpeed*direction);count=count+1 end
  end
  if count==0 then factor=1;s.reason='Aucune roue motrice mesurable';return s end
  s.supported=true
  local slip=math.max(0,(fastest-speed)/math.max(speed,3));s.slip=slip*100
  local pedal=tonumber(ev.throttle_input) or e.requestedThrottle or 0
  local demand=pedal>.02 and bound((slip-c.slip/100)/.30,0,1) or 0
  local target=1-demand*c.strength/100
  local rate=target<factor and c.response or c.recovery
  factor=bound(factor+(target-factor)*(1-math.exp(-rate*bound(dt or 0,0,.1))),0,1)
  if factor>.9999 then factor=1 end
  s.factor=factor;s.active=factor<.995;s.reason=s.active and 'Réduction de couple' or 'Adhérence suffisante'
  return s
end
return M
