-- ECU-owned integration with the installed diesel volumetric model.
-- Other engines keep the independent smoke model; hot jet requires smoke 0.9.20.
local M={}
local model,original,wrapper,engine,command
local age,lastGain=1,nil
local heatOK,heat=pcall(require,'mr14karaECUDieselHeat')
local heatState={}
function M.reset()
  if engine then engine.mr14karaDieselHot=nil end;heatState={}
  if model and model.update==wrapper then model.update=original end
  model,original,wrapper,engine,command=nil,nil,nil,nil,nil
  age,lastGain=1,nil
end
function M.update(device,state,dt)
  if engine~=device then M.reset();engine=device end
  command=state
  local flameDemand,egt=0,20
  if heatOK then flameDemand,egt=heat.update(heatState,device,state.flameConfig,dt,state) end
  device.mr14karaDieselHot={demand=flameDemand,lease=.35}
  age=age+math.max(0,dt or 0)
  local gain=state.gain or 1
  if model and (gain~=lastGain or age>=1) and obj.queueGameEngineLua then
    age=0;lastGain=gain
    obj:queueGameEngineLua('extensions.load("mr14karaECUDieselRenderer"); if extensions.mr14karaECUDieselRenderer then extensions.mr14karaECUDieselRenderer.setGain('..obj:getID()..','..gain..') end')
  end
  if not model then
    local ok,m=pcall(require,'common/mr14karaDieselModel')
    if ok and type(m)=='table' and type(m.update)=='function' then
      model=m;original=m.update
      local native=original
      wrapper=function(s,dt,e,throttle)
        if e~=engine or not command then return native(s,dt,e,throttle) end
        local target=command.running and math.max(0,math.min(1,command.demand or 0)) or 0
        if command.engineRunning==false or (command.engineRunning==nil and not command.running) then
          s.density,s.transient,s.throttle=0,0,0;return 0,command.rpm or 0
        end
        if type(model.response)=='function' then
          local density,pulse=model.response(s,dt,target,command.pedal or throttle)
          return density,command.rpm or 0,pulse
        end
        local delta=math.max(0,math.min(.1,tonumber(dt) or 0))
        s.density=(s.density or 0)+(target-(s.density or 0))*(1-math.exp(-delta/.12))
        return s.density,command.rpm or 0
      end
      model.update=wrapper
    end
  end
  local smoke=extensions and extensions.mr14karaDieselSmoke
  local status=smoke and smoke.getStatus and smoke.getStatus() or {}
  return {available=model~=nil and smoke~=nil,ready=model~=nil and status.ready==true,flameDemand=flameDemand,egt=egt,hotSupported=status.hotSupported==true}
end
return M
