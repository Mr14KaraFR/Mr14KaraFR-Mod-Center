-- Deceleration-only RPM curve. Values command the existing fuel/flame model.
local M={}
local axis={1200,2000,3000,4000,5000,6000,7000,8000,9000,10000,12000}
local function finite(v)return type(v)=='number' and v==v and math.abs(v)<math.huge end
function M.defaults(fuel,retard)
 local c={enabled=false,axis={},fuel={},retard={}}
 for i,n in ipairs(axis)do c.axis[i]=n;c.fuel[i]=fuel or 15;c.retard[i]=retard or 20 end
 return c
end
local function array(a,n)
 if type(a)~='table' then return false end
 local count=0
 for k in pairs(a)do if type(k)~='number' or k%1~=0 or k<1 or k>n then return false end;count=count+1 end
 return count==n
end
function M.validate(o)
 local c=o.rpmMap
 if c==nil then return true end -- older profiles keep the fixed settings
 if type(c)~='table' or type(c.enabled)~='boolean' then return false,'Activation de table pied leve invalide.' end
 if not array(c.axis,#axis) or not array(c.fuel,#axis) or not array(c.retard,#axis) then return false,'Table pied leve : 11 colonnes requises.' end
 for i=1,#axis do
  if not finite(c.axis[i]) or c.axis[i]%1~=0 or c.axis[i]<1200 or c.axis[i]>12000 or i>1 and c.axis[i]<c.axis[i-1]+25 then return false,'Regimes pied leve : valeurs croissantes de 1200 a 12000, ecart minimum 25 tr/min.' end
  for _,key in ipairs({'fuel','retard'})do if not finite(c[key][i]) or c[key][i]<0 or c[key][i]>40 then return false,'Table pied leve hors limites : '..key end end
 end
 return true
end
function M.values(o,rpm)
 local c=o and o.rpmMap
 if not c or not c.enabled then return o.fuel,o.retard end
 if rpm<=c.axis[1]then return c.fuel[1],c.retard[1]end
 for i=2,#c.axis do
  if rpm<=c.axis[i]then
   local t=(rpm-c.axis[i-1])/(c.axis[i]-c.axis[i-1])
   return c.fuel[i-1]+(c.fuel[i]-c.fuel[i-1])*t,c.retard[i-1]+(c.retard[i]-c.retard[i-1])*t
  end
 end
 return c.fuel[#c.axis],c.retard[#c.axis]
end
-- Time belongs to one contiguous combustion window, not the entire lift.
-- Inspect crossed knots too: a fast RPM drop can skip a narrow zero band.
function M.elapsed(o,previousRPM,rpm,eligible,elapsed,dt)
 if not eligible then return 0 end
 local c=o.rpmMap
 if c and c.enabled then
  local fuel,retard=M.values(o,rpm)
  if fuel<=0 then return 0 end
  if retard>0 and finite(previousRPM) then
   local low,high=math.min(previousRPM,rpm),math.max(previousRPM,rpm)
   for i,n in ipairs(c.axis)do
    if n>=low and n<=high and (c.fuel[i]<=0 or c.retard[i]<=0)then elapsed=0;break end
   end
  end
 end
 return (elapsed or 0)+math.max(0,dt or 0)
end
return M
