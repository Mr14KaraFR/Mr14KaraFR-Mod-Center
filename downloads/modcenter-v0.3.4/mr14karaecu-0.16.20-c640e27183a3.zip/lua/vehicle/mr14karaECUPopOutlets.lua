local M={}
local function pick(key,salt)local n=math.sin(key*127.1+salt*311.7)*43758.5453;return n-math.floor(n)end
function M.new(seed)return {seed=(tonumber(seed)or 0)%65521,pending={},counts={},energy={},target={}}end
function M.clear(s)s.pending={}end

local function record(s,item)
 local n=item.event[10];s.counts[n]=(s.counts[n]or 0)+1
 s.energy[n]=(s.energy[n]or 0)+(item.event[26]or 1)^2;s.target[n]=(s.target[n]or 0)+item.target
end
function M.accept(s,item)
 if not item.accepted then item.accepted=true;record(s,item)end
end
function M.stats(s)
 local out={};for node,count in pairs(s.counts)do out[#out+1]={node=node,count=count,energy=s.energy[node],target=s.target[node]}end;return out
end
function M.schedule(s,events,time,serial,kind,period)
 local count=#events;if count==0 then return {}end
 local gains,energy={},0
 for i,e in ipairs(events)do
  local n=e[10]or i
  local error=(s.energy[n]or 0)-(s.target[n]or 0)
  local feedback=math.max(.96,math.min(1.04,1-.10*error))
  local gain=count>1 and math.max(.90,math.min(1.10,(.94+.12*pick(serial+n*.317+s.seed*.137,3))*feedback))or 1
  gains[i]=gain;energy=energy+gain*gain
 end
 local normalize=math.sqrt(count/math.max(.001,energy))
 local lead=1+(serial%count);local least=s.counts[events[lead][10]]or 0
 local first=lead;for offset=1,count-1 do local i=1+((first-1+offset)%count);local n=s.counts[events[i][10]]or 0;if n<least then lead=i;least=n end end
 local stagger=count>1 and pick(serial+s.seed*.137,7)<.48
 local immediate={}
 for i,e in ipairs(events)do
  local event={unpack(e)};local gain=gains[i]*normalize
  event[26]=(e[26]or 1)*gain
  event[12]=.2+.8*math.min(1,event[26]^2)
  local delay=stagger and i~=lead and (.008+.014*pick(serial+(e[10]or i)*.317+s.seed*.137,11))or 0
  local item={event=event,due=time+delay,count=count,kind=kind,period=period,target=(e[26]or 1)^2}
  if delay==0 then immediate[#immediate+1]=item elseif #s.pending<32 then s.pending[#s.pending+1]=item end
 end
 return immediate
end
function M.drain(s,time,allowed)
 if not allowed then M.clear(s);return {}end
 local out={}
 for i=#s.pending,1,-1 do
  local p=s.pending[i]
  if time>=p.due then
   table.remove(s.pending,i)
   -- After a stall, retire stale requests instead of catching up with a storm.
   if time-p.due<=.065 then out[#out+1]=p end
  end
 end
 return out
end
return M
