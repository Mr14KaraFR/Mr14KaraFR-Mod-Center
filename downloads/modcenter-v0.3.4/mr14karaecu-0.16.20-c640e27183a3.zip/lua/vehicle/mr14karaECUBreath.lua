-- ECU-owned pressure decay preceding the independently scheduled final impact.
local M={};local sources,active,serial,lastVariant={},{},0,0
local timbre=require('mr14karaECUExhaustSound')
local distance=require('mr14karaECUAcousticDistance')
local function volume(obj,id,gain,pitch) return pcall(obj.setVolumePitchCT,obj,id,gain,pitch or 1,0,0) end
local function silence(obj,a)
 if obj then for id in pairs(a.voices) do volume(obj,id,0,1) end end
 a.voices={}
end
function M.reset(obj)
 for _,a in pairs(active) do silence(obj,a) end
 sources,active,serial,lastVariant={},{},0,0
end
function M.release(time,duration)
 for _,a in pairs(active)do if not a.releaseAt then a.releaseAt=time;a.releaseDuration=duration or .12 end end
end
function M.update(obj,time,allowStart)
 for node,a in pairs(active) do
  if time-a.last>.30 or a.releaseAt and time-a.releaseAt>=a.releaseDuration then silence(obj,a);active[node]=nil
  else
   local gap=math.max(0,time-a.last)
   local ending=math.max(0,math.min(1,(gap-.025)/.20))
   local pressure=1+.10*math.sin(time*9+node*.173)+.04*math.sin(time*23+node*.31)
   -- A short broken decay follows accepted flame cessation, never a free timer.
   pressure=pressure*(1-ending)^1.20*(1-ending*.65*(.5+.5*math.sin(time*91+node*.7)))
   local gain=(.55+.55*a.strength)*a.scale/math.sqrt(a.count)*1.65*pressure
   if a.releaseAt then gain=gain*math.max(0,1-(time-a.releaseAt)/a.releaseDuration)^1.5 end
   for id,voice in pairs(a.voices) do
    local mix=distance.mix(a.inside)
    if time-voice.born>=.40 then volume(obj,id,0,1);a.voices[id]=nil else volume(obj,id,gain*(voice.far and mix or 1-mix),a.pitch) end
   end
   if time>=a.next and gap<.07 and allowStart~=false and not a.releaseAt then
    serial=serial+1
    local index=1+math.floor((math.sin(serial*2.399963+node*.173)*.5+.5)*6)
    if index==lastVariant then index=index%6+1 end;lastVariant=index
    local ok=pcall(function()
     for _,far in ipairs(a.inside and {false}or {false,true})do
      local path=far and timbre.distantPath('breath',index,a.character)or timbre.path('breath',index,a.inside,a.character)
      local key=node..':'..path;local id=sources[key]
      if id==nil then id=obj:createSFXSource2(path,'AudioDefault3D','ecu1620_breath_'..node..'_'..serial,node,0);assert(type(id)=='number'and id>=0);sources[key]=id end
      local mix=distance.mix(a.inside);assert(volume(obj,id,gain*(far and mix or 1-mix),a.pitch));obj:playSFX(id);a.voices[id]={born=time,far=far}
     end
    end)
    a.ok=ok;a.next=time+.26+.025*(.5+.5*math.sin(serial*2.399963))
   end
  end
 end
end
function M.touch(obj,node,strength,time,count,scale,inside,character)
 local a=active[node]
 if not a then a={voices={},next=time};active[node]=a end
 if a.inside~=(inside==true) then silence(obj,a);a.next=time end
 a.releaseAt=nil;a.character=character;a.pitch=character and character.pitch or 1
 a.last=time;a.strength=math.max(0,math.min(1,strength or 0))
 a.count=math.max(1,count or 1);a.scale=math.max(0,math.min(1.3,scale or 1));a.inside=inside==true
 M.update(obj,time)
 return a.ok==true
end
return M
