-- ECU-owned gain staging: louder PCM banks, never relying on a source gain above 1.
local M={}
local sources,serial={},0
function M.play(obj,node,volume,count,interior,scale)
  if not obj.createSFXSource2 or not obj.setVolumePitchCT or not obj.playSFX then return false end
  local value=math.max(0,math.min(1000,volume or 0))
  if value<=0 then return true end
  local position=math.max(0,(value-500)/100)
  local bank=math.min(5,math.floor(position))
  local mix=position-bank
  local gain=math.min(1,(value/500)^.75)*math.max(0,math.min(1,scale or 1))/math.sqrt(math.max(1,count or 1))
  serial=serial+1;local variant=1+(serial-1)%3
  local function voice(index,weight)
    if weight<=0 then return end
    local path='art/sound/mr14karaecu/impact_'..index..'_'..variant..(interior and '_cabin' or '')..'.wav'
    local key=tostring(node)..':'..path
    local source=sources[key]
    if source==nil then
      source=obj:createSFXSource2(path,'AudioDefault3D','mr14kara_ecu_impact_'..node..'_'..serial..'_'..index,node,0)
      assert(type(source)=='number' and source>=0,'ECU audio source unavailable');sources[key]=source
    end
    obj:setVolumePitchCT(source,gain*weight,1,0,0)
    obj:playSFX(source)
  end
  -- Adjacent banks share the exact same recording and duration. Their convex
  -- crossfade stays within full scale while PCM energy rises across 500–1000.
  return pcall(function() voice(bank,1-mix);if mix>0 then voice(bank+1,mix) end end)
end
function M.reset(obj)
  if obj and obj.stopSFX then for _,source in pairs(sources) do pcall(obj.stopSFX,obj,source) end end
end
return M
