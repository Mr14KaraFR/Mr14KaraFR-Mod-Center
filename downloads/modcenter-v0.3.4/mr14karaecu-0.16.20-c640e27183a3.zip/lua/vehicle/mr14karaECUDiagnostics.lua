local M={}
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<math.huge end
function M.build(s,remote)
  if remote or not finite(s.requestedFuelFactor) or not finite(s.mapFuelFactor) then return {available=false,remote=remote==true} end
  local d={available=true,requested=s.requestedFuelFactor*100,capped=s.mapFuelFactor*100,
    afterThermal=s.mapFuelFactor*(s.protectionFactor or 1)*100,applied=(s.fuelFactor or 0)*100,rows={},reasons={},running=s.engineRunning==true,
    boostRequested=s.boostRequested,boostCommanded=s.boostCommanded,boostMeasured=s.boostPsi,boostSupported=s.boostSupported==true}
  local eps=.000001
  local function ceiling(code,label,value,hint,enabled)
    if not finite(value) or enabled==false then return end
    local binding=value<=s.mapFuelFactor+eps and value<s.requestedFuelFactor-eps
    d.rows[#d.rows+1]={code=code,label=label,value=value*100,binding=binding,hint=hint}
    if binding then d.reasons[#d.reasons+1]=label end
  end
  ceiling('model','Plafond du modèle ECU',5,'La demande combinée injection/lambda dépasse 500 %.')
  if s.requestedFuelFactor<.25-eps then d.reasons[#d.reasons+1]='Plancher du modèle ECU : 25 %' end
  if s.diesel then
    ceiling('torque','Limite de couple diesel',(s.dieselTorqueLimit or 500)/100,'Modifier la table Limite couple à ce régime et cette charge.')
    ceiling('richness','Limite de richesse diesel',s.dieselSmokeFuelLimit,'Un lambda minimum plus élevé autorise moins de carburant.')
    ceiling('air','Limiteur fumée / air',(s.dieselAirLimit or 500)/100,'La table dépend de la pression turbo mesurée, pas de la consigne.',s.dieselAirLimiterEnabled)
  end
  if (s.protectionFactor or 1)<1-eps then d.reasons[#d.reasons+1]='Protection thermique' end
  if (s.limiterFactor or 1)<1-eps then d.reasons[#d.reasons+1]='Limiteur de régime' end
  if s.tractionActive then d.reasons[#d.reasons+1]='Antipatinage ECU' end
  if s.shiftCutActive then d.reasons[#d.reasons+1]='Coupure de passage' end
  d.limited=#d.reasons>0
  d.thermalReduction=(1-(s.protectionFactor or 1))*100;d.limiterReduction=(1-(s.limiterFactor or 1))*100
  d.mixtureTorqueFactor=not s.diesel and s.mapTorqueFactor or nil
  return d
end
return M
