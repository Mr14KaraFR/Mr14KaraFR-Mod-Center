-- Bounded end-of-combustion envelope; actual accepted ECU flames only.
local M={}
local function clamp(x,a,b)return math.max(a,math.min(b,tonumber(x) or 0))end
function M.plan(duration,dose,heat,serial)
 duration=clamp(duration,0,30);dose=clamp(dose,0,1);heat=clamp(heat,0,1)
 local dwell=1-math.exp(-math.max(0,duration-.25)/.85)
 local energy=clamp(dose*(.35+.65*heat)*(.20+.80*dwell),0,1)
 local impact=clamp(.16+.84*math.sqrt(energy),.16,1)
 local r=math.sin((serial or 0)*127.1+19*311.7)*43758.5453;r=r-math.floor(r)
 local massive=duration>=1.5 and energy>.65 and r<.16
 return {energy=energy,strength=impact,gain=clamp(.15+1.15*energy,.15,1),
  gasScale=math.sqrt(math.max(.0025,energy)),boost=massive and 1.65 or 1+.25*energy,
  duration=.72+.40*energy,delay=.23+.045*dwell,stutterDelay=.135,
  stutter=energy>.055,stutterStrength=.20+.17*energy,
  stutterScale=math.sqrt(math.max(.0025,energy*.12)),massive=massive}
end
return M
