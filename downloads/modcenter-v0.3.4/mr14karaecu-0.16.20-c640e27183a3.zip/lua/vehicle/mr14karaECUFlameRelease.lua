-- A finite visual tail from accepted ECU combustion, never an extra bang.
local M={}
function M.new()return {last=-100,events={},factor=0,cancelled=false}end
function M.capture(s,events,time)
 s.events={};for _,event in ipairs(events)do s.events[#s.events+1]={unpack(event)}end
 s.last=time;s.start=nil;s.factor=0;s.next=0
end
function M.step(s,time,input)
 local enabled=input.managed and input.continuous and input.running and not input.blocked
 local gas=enabled and input.pedal>math.max(.001,input.maxThrottle)
 if not gas then
  s.start=nil;s.factor=0;s.cancelled=false
  if not enabled then s.events={};s.last=-100 end
  return {cancel=false,emit=false,factor=0}
 end
 local first=not s.cancelled;s.cancelled=true
 if first and time-s.last<=.14 and #s.events>0 then s.start=time;s.next=time end
 local age=s.start and math.max(0,time-s.start) or 1
 s.factor=math.max(0,1-age/.12)^1.5
 local emit=s.factor>.06 and time>=(s.next or 0)
 if emit then s.next=time+.04 end
 return {cancel=true,started=first,emit=emit,factor=s.factor,events=s.events}
end
return M
