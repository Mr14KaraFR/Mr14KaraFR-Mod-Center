-- ECU-only combustion envelope. It changes visible/sounding combustion,
-- never ECU injection, engine torque, pedal eligibility or native afterfire.
local M={}
local ignition=require('mr14karaECUFlameStart')
local function clamp(x,a,b)return math.max(a,math.min(b,tonumber(x) or 0))end
local function pick(s,salt)
 local n=math.sin((s.cycle+s.seed*.137)*127.1+salt*311.7)*43758.5453
 return n-math.floor(n)
end
function M.new(seed)return {seed=math.floor(tonumber(seed) or 0)%65521,cycle=0,phase='off',time=0,factor=0}end
function M.stop(s)s.phase='off';s.time=0;s.factor=0;s.untilTime=0;s.startRPM=nil;s.startup=nil end
local function segment(s,phase,support)
 s.cycle=s.cycle+1;s.phase=phase
 local r=pick(s,7)
 if phase=='gap' then
  s.target=0;s.untilTime=s.untilTime+.16+.30*(1-support)+.18*r
 elseif phase=='dip' then
  s.target=.10+.30*support;s.untilTime=s.untilTime+.07+.07*(1-support)+.04*r
 elseif phase=='recover' then
  s.target=.70+.30*r;s.untilTime=s.untilTime+.10+.22*pick(s,11)
 else
  s.target=.64+.18*support+.18*r;s.untilTime=s.untilTime+.16+.34*support+.18*pick(s,13)
 end
end
function M.step(s,dt,profile,input)
 dt=clamp(dt,0,.1);input=input or {}
 local pressure=clamp(profile and profile.demand,0,1)
 if pressure<=0 or input.active~=true then M.stop(s);return {emit=false,demand=0,factor=0,phase='off',hold=0}end
 local heat=clamp(profile.heat,0,1)
 local late=profile.retard==nil and 1 or clamp(profile.retard,0,1)
 local fuel=profile.fuel==nil and 1 or clamp(profile.fuel,0,1)
 local support=pressure*(.4+.6*heat)*(.55+.45*late)
 local fullness=.85+.15*fuel
 local rpm=math.max(0,tonumber(input.rpm) or 0)
 if s.phase=='off' then
  s.time=0;s.untilTime=0;s.factor=.80;s.startRPM=rpm
  segment(s,'burn',support)
  s.startup=ignition.plan(profile,s.seed,s.cycle)
 end
 s.time=s.time+dt
 local loops=0
 while s.time>=s.untilTime and loops<4 do
  loops=loops+1
  if s.phase=='gap' or s.phase=='dip' then segment(s,'recover',support)
  elseif s.phase=='recover' then segment(s,'burn',support)
  else
   local r=pick(s,19)
   local gapChance=.65*(1-support)^2
   if r<gapChance then segment(s,'gap',support)
   elseif r<gapChance+.10+.25*(1-support) then segment(s,'dip',support)
   else segment(s,'burn',support)end
  end
 end
 local drop=clamp(((s.startRPM or rpm)-rpm)/math.max(1,s.startRPM or rpm),0,1)
 local taper=1-drop*(.50-.35*support)
 local target=s.target*taper
 local tau=target<s.factor and .025 or .055
 s.factor=clamp(s.factor+(target-s.factor)*(1-math.exp(-dt/tau)),0,1)
 local gate,startPhase=ignition.factor(s.startup,s.time)
 local demand=pressure*s.factor*fullness*gate
 return {emit=s.factor*gate>.045 and demand>.0001,demand=demand,factor=s.factor*gate,phase=startPhase~='ready'and startPhase or s.phase,
  hold=math.min(s.phase=='burn'and(.085+.055*support)or .065+.035*support,startPhase~='ready'and(.035+.055*gate)or 1)}
end
return M
