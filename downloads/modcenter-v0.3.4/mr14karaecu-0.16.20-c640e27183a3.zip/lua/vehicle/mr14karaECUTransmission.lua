-- Adapter for the installed vanilla automatic shift logic. Never force a gear.
local M={}
local axis={0,20,40,60,80,100}
local gearbox,logic,shared,converter,originalSelect,selectWrapper,originalSet,setWrapper
local getTune,getRemote,getHold,converterBase
local engineRef,clutchHandling,clutchBlipBase,expiryTable,expiryBase
local blipLeft,blipGear,blipCount=0,0,0
local originalCut,cutWrapper,nativeCutCallers
local cutActive,cutElapsed,cutKey,cutTo,cutBlocked=false,0,nil,0,false
local dct,dctBase
local state={supported=false,reason='Boîte automatique classique nécessaire.'}
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<1e20 end
local function clamp(n,a,b) return math.min(b,math.max(a,n)) end
local function interpolate(row,p)
  p=clamp(p,0,100);local i=math.min(math.floor(p/20)+1,5);local a=(p-axis[i])/20
  return row[i]+(row[i+1]-row[i])*a
end
function M.shiftCutDefaults() return {enabled=false,style='pulsed',duration=.17,recovery=.10,strength=100,minRPM=2500,minPedal=40} end
function M.defaults(engine)
  local maxRPM=clamp(engine and (engine.revLimiterRPM or engine.maxRPM) or 6500,2500,12000)
  local t={shiftCut=M.shiftCutDefaults(),blip=false,blipPct=50,blipTime=.2,enabled=false,unit='rpm',pedalAxis={0,20,40,60,80,100},rpmUp={},rpmDown={},speedUp={},speedDown={},upTime={},downTime={},kickdown=true,kickdownPedal=90,kickdownPercent=65,lockup={enabled=false,rpm=1800,range=300,minGear=2}}
  for g=1,18 do
    t.rpmUp[g]={};t.rpmDown[g]={};t.speedUp[g]={};t.speedDown[g]={}
    for i,p in ipairs(axis) do
      t.rpmUp[g][i]=math.floor(1800+(maxRPM*.9-1800)*p/100)
      t.rpmDown[g][i]=math.floor(900+(maxRPM*.45-900)*p/100)
      t.speedUp[g][i]=math.min(15*g+p*.65,400)
      t.speedDown[g][i]=math.min(10*(g-1)+p*.2,395)
    end
  end
  for i=1,6 do t.upTime[i]=math.floor((.5-(i-1)*.06)*100+.5)/100;t.downTime[i]=math.floor((.45-(i-1)*.05)*100+.5)/100 end
  return t
end
function M.migrate(t)
  if type(t)=='table' then if t.shiftCut==nil then t.shiftCut=M.shiftCutDefaults() end;if t.blip==nil then t.blip=false end;if t.blipPct==nil then t.blipPct=50 end;if t.blipTime==nil then t.blipTime=.2 end end
  return t
end
function M.validate(t)
  if type(t)~='table' or type(t.enabled)~='boolean' or (t.unit~='rpm' and t.unit~='speed') or type(t.pedalAxis)~='table' or #t.pedalAxis~=6 then return false,'Cartographie de boîte invalide.' end
  for i,p in ipairs(axis) do if t.pedalAxis[i]~=p then return false,'Axe pédale boîte incompatible.' end end
  for key,r in pairs({rpmUp={800,12000},rpmDown={500,11000},speedUp={5,400},speedDown={0,395}}) do
    if type(t[key])~='table' or #t[key]~=18 then return false,'Dimensions boîte invalides : '..key end
    for g=1,18 do
      if type(t[key][g])~='table' or #t[key][g]~=6 then return false,'Ligne boîte invalide.' end
      for i=1,6 do if not finite(t[key][g][i]) or t[key][g][i]<r[1] or t[key][g][i]>r[2] then return false,'Seuil boîte hors limites : '..key end end
    end
  end
  for g=1,18 do for i=1,6 do
    if t.rpmUp[g][i]<t.rpmDown[g][i]+200 or t.speedUp[g][i]<t.speedDown[g][i]+2 then return false,'Montée et rétrogradage trop proches.' end
  end end
  for _,key in ipairs({'upTime','downTime'}) do
    if type(t[key])~='table' or #t[key]~=6 then return false,'Durée de passage invalide.' end
    for i=1,6 do if not finite(t[key][i]) or t[key][i]<.05 or t[key][i]>2 then return false,'Durée boîte : 0,05 à 2 secondes.' end end
  end
  if type(t.kickdown)~='boolean' or not finite(t.kickdownPedal) or t.kickdownPedal<50 or t.kickdownPedal>100 or not finite(t.kickdownPercent) or t.kickdownPercent<40 or t.kickdownPercent>90 then return false,'Kickdown invalide.' end
  local l=t.lockup
  if type(l)~='table' or type(l.enabled)~='boolean' or not finite(l.rpm) or l.rpm<500 or l.rpm>6000 or not finite(l.range) or l.range<100 or l.range>2000 or not finite(l.minGear) or l.minGear%1~=0 or l.minGear<1 or l.minGear>18 then return false,'Verrouillage convertisseur invalide.' end
  if t.blip~=nil and type(t.blip)~='boolean' or t.blipPct~=nil and (not finite(t.blipPct) or t.blipPct<0 or t.blipPct>100) or t.blipTime~=nil and (not finite(t.blipTime) or t.blipTime<.05 or t.blipTime>.6) then return false,'Coup de gaz invalide.' end
  local c=t.shiftCut
  if c~=nil then
    if type(c)~='table' or type(c.enabled)~='boolean' or c.style~='progressive' and c.style~='pulsed' then return false,'Type de coupure de passage invalide.' end
    for k,r in pairs({duration={.05,1},recovery={0,.5},strength={0,100},minRPM={1500,8000},minPedal={10,100}}) do if not finite(c[k]) or c[k]<r[1] or c[k]>r[2] then return false,'Coupure de passage hors limites : '..k end end
  end
  return true
end
local function upvalue(fn,name)
  if not debug or not debug.getupvalue or type(fn)~='function' then return nil end
  for i=1,100 do local n,value=debug.getupvalue(fn,i);if not n then break end;if n==name then return value end end
end
local function currentGear()
  return dct and dct.primaryAccess and gearbox[dct.primaryAccess.gearIndexName] or gearbox.gearIndex or 0
end
local function active()
  local cfg=getTune and getTune()
  local name=logic and logic.getGearName and logic.getGearName() or ''
  return cfg and cfg.enabled and not (getRemote and getRemote()) and currentGear()>0 and (name=='D' or name:match('^S%d*$')) and cfg or nil
end
local function blipConfig()
  local cfg=getTune and getTune()
  local name=logic and logic.getGearName and logic.getGearName() or ''
  local e=engineRef
  if not cfg or not cfg.blip or getRemote and getRemote() or getHold and getHold() or not e or e.hasFuel==false or e.isDisabled or e.isStalled or (e.ignitionCoef or 1)<=0 or (e.outputAV1 or 0)<30 then return nil end
  if currentGear()<=0 or not (name=='D' or name:match('^[SM]%d*$')) then return nil end
  return cfg
end
local function safeTarget(gear)
  local ratio=gearbox and gearbox.gearRatios and gearbox.gearRatios[gear]
  local av=gearbox and gearbox.outputAV1
  if not finite(ratio) or not finite(av) or ratio<=0 then return nil end
  local rpm=math.abs(av*ratio)*30/math.pi
  local ceiling=math.min(engineRef.maxRPM or 12000,engineRef.revLimiterRPM or 12000)-150
  return rpm<ceiling and rpm or nil
end
local function pedal() return clamp((tonumber(electrics.values.throttle_input) or 0)*100,0,100) end
local function stopShiftCut(reason)
  cutActive=false;cutElapsed=0
  state.shiftCutActive=false;state.shiftCutFactor=1;state.shiftCutElapsed=0;state.shiftCutPulse=false
  if reason then state.shiftCutReason=reason end
end
function M.cancelShiftCut() stopShiftCut('En attente de montée de rapport') end
local function shiftCutConfig()
  local cfg=getTune and getTune();local c=cfg and cfg.shiftCut;local e=engineRef
  if not state.shiftCutSupported or not c or not c.enabled or c.strength<=0 or cutBlocked or getRemote and getRemote() or getHold and getHold() then return nil end
  local mode=logic and logic.getGearName and logic.getGearName() or ''
  if not (mode=='D' or mode:match('^[SM]%d*$')) or currentGear()<=0 or gearbox.lockCoef==0 then return nil end
  if not e or e.isDisabled or e.isStalled or e.hasFuel==false or (e.ignitionCoef or 1)<=0 or (e.outputTorqueState or 1)<=0 or pedal()<c.minPedal or e.outputAV1*30/math.pi<c.minRPM then return nil end
  return c
end
local function beginShiftCut(from,to)
  local c=shiftCutConfig()
  if not c or not finite(from) or not finite(to) or from<1 or to<=from then return false end
  local key=from..':'..to
  if cutKey==key then return cutActive end
  cutKey=key;cutTo=to;cutActive=true;cutElapsed=0
  state.shiftCutCount=(state.shiftCutCount or 0)+1;state.shiftCutActive=true;state.shiftCutReason='Coupure de passage active'
  return true
end
-- Exact function identities keep limiter, launch and third-party cuts out of this adapter.
local function findNativeCutCallers(l)
  local found={}
  local function visit(fn,depth)
    if type(fn)~='function' or found[fn] or depth<0 then return end
    local info=debug.getinfo(fn,'S');if not info or info.what~='Lua' then return end
    found[fn]=true
    for i=1,100 do local n,value=debug.getupvalue(fn,i);if not n then break end;if type(value)=='function' then visit(value,depth-1) end end
  end
  visit(l.gearboxBehaviorChanged,5)
  local variants=upvalue(l.gearboxBehaviorChanged,'gearboxAvailableLogic') or {}
  for _,variant in pairs(variants) do if type(variant)=='table' then for _,fn in pairs(variant) do visit(fn,5) end end end
  return found
end
local function lockup(cfg)
  if not converterBase then return end
  if cfg and cfg.lockup.enabled then
    converter.lockupAV=cfg.lockup.rpm*math.pi/30;converter.lockupRange=cfg.lockup.range*math.pi/30;converter.lockupMinGear=cfg.lockup.minGear
  else for k,n in pairs(converterBase) do converter[k]=n end end
end
function M.reset()
  if engineRef and engineRef.cutIgnition==cutWrapper then engineRef.cutIgnition=originalCut end
  originalCut=nil;cutWrapper=nil;nativeCutCallers=nil;stopShiftCut();cutKey=nil;cutBlocked=false
  if clutchHandling and clutchBlipBase then clutchHandling.revMatchThrottle=clutchBlipBase end
  if expiryTable and expiryBase then expiryTable.revMatchExpired=expiryBase end
  clutchHandling=nil;clutchBlipBase=nil;expiryTable=nil;expiryBase=nil;engineRef=nil
  blipLeft=0;blipGear=0;blipCount=0
  if shared and shared.selectShiftPoints==selectWrapper then shared.selectShiftPoints=originalSelect end
  if gearbox and gearbox.setGearIndex==setWrapper then gearbox.setGearIndex=originalSet end
  if logic and upvalue(logic.init,'gearbox')==gearbox then lockup(nil) end
  if dct and dctBase and logic and upvalue(logic.init,'gearbox')==gearbox then dct.clutchTime=dctBase end
  dct=nil;dctBase=nil
  gearbox=nil;logic=nil;shared=nil;converter=nil;converterBase=nil
  state={supported=false,reason='Boîte automatique classique nécessaire.'}
end
function M.bind(engine,tuneReader,remoteReader,holdReader)
  M.reset();getTune=tuneReader;getRemote=remoteReader;getHold=holdReader
  local gb=powertrain.getDevice and powertrain.getDevice('gearbox')
  local isDCT=gb and gb.type=='dctGearbox'
  if not gb or (gb.type~='automaticGearbox' and not isDCT) or not finite(gb.maxGearIndex) or gb.maxGearIndex>18 then return false end
  if not isDCT and type(gb.setGearIndex)~='function' then return false end
  local ok,l=pcall(require,'controller/vehicleController/shiftLogic/'..(isDCT and 'dctGearbox' or 'automaticGearbox'))
  if not ok or type(l)~='table' or upvalue(l.init,'gearbox')~=gb or upvalue(l.init,'engine')~=engine then state.reason='Contrôleur de boîte personnalisé ou interface native indisponible.';return false end
  local sh=upvalue(l.init,'sharedFunctions')
  if type(sh)~='table' or type(sh.selectShiftPoints)~='function' or type(l.shiftBehavior)~='table' then state.reason='Seuils natifs de boîte indisponibles.';return false end
  local nativeDCT=isDCT and upvalue(l.init,'dct') or nil
  if isDCT and (type(nativeDCT)~='table' or not finite(nativeDCT.clutchTime) or not nativeDCT.primaryAccess or type(gb.setGearIndex1)~='function' or type(gb.setGearIndex2)~='function') then state.reason='Embrayages DCT natifs indisponibles.';return false end
  engineRef=engine;clutchHandling=isDCT and upvalue(l.init,'clutchHandling') or nil;clutchBlipBase=clutchHandling and clutchHandling.revMatchThrottle
  gearbox=gb;logic=l;shared=sh;converter=upvalue(l.init,'torqueConverterHandling')
  dct=nativeDCT;dctBase=dct and dct.clutchTime or nil
  if converter and converter.hasTorqueConverter and converter.hasLockup then converterBase={lockupAV=converter.lockupAV,lockupRange=converter.lockupRange,lockupMinGear=converter.lockupMinGear} end
  state={supported=true,reason='',kind=isDCT and 'dct' or 'automatic',gearCount=gb.maxGearIndex,lockupSupported=converterBase~=nil}
  state.shiftCutSupported=engine.requiredEnergyType=='gasoline' and type(engine.cutIgnition)=='function' and type(engine.electricsThrottleName)=='string'
  state.shiftCutActive=false;state.shiftCutCount=0;state.shiftCutFactor=1
  if state.shiftCutSupported then
    originalCut=engine.cutIgnition;nativeCutCallers=findNativeCutCallers(l)
    local nativeCut=originalCut;local callers=nativeCutCallers
    cutWrapper=function(device,time)
      local caller=debug.getinfo(2,'f')
      if engineRef==device and gearbox and caller and callers[caller.func] and beginShiftCut(currentGear(),l.currentGearIndex or 0) then return end
      return nativeCut(device,time)
    end
    engine.cutIgnition=cutWrapper
  end
  originalSelect=sh.selectShiftPoints
  selectWrapper=function(g,...)
    local result=originalSelect(g,...);local cfg=active();lockup(cfg)
    if cfg and g>=1 and g<=gb.maxGearIndex then
      local p=pedal();local up,down
      if getHold and getHold() then up=1e10;down=0
      elseif cfg.unit=='rpm' then up=interpolate(cfg.rpmUp[g],p);down=interpolate(cfg.rpmDown[g],p)
      else
        local speed=math.abs(tonumber(electrics.values.wheelspeed) or 0)*3.6
        local currentRatio=gb.gearRatios[currentGear()]
        if speed>1 and currentRatio and currentRatio~=0 then
          local rpmPerSpeed=math.abs(gb.inputAV/currentRatio*(gb.gearRatios[g] or 0))*30/math.pi/speed
          up=interpolate(cfg.speedUp[g],p)*rpmPerSpeed;down=interpolate(cfg.speedDown[g],p)*rpmPerSpeed
        end
      end
      if up then
        if cfg.kickdown and p>=cfg.kickdownPedal and not (getHold and getHold()) then down=math.max(down,engine.maxRPM*cfg.kickdownPercent/100) end
        l.shiftBehavior.shiftUpAV=up*math.pi/30;l.shiftBehavior.shiftDownAV=down*math.pi/30
        state.upRPM=up;state.downRPM=down
      end
    end
    state.active=cfg~=nil;return result
  end
  sh.selectShiftPoints=selectWrapper
  if isDCT then return true end
  originalSet=gb.setGearIndex
  setWrapper=function(device,index,time)
    local cfg=active()
    local bc=blipConfig()
    if index>0 and device.gearIndex>0 and index<device.gearIndex then
      local target=bc and safeTarget(index)
      if target and target>engineRef.outputAV1*30/math.pi+100 and (bc.blipPct or 50)>0 then
        blipLeft=bc.blipTime or .2;blipGear=index;blipCount=blipCount+1
      end
    elseif index~=device.gearIndex then blipLeft=0 end
    if cfg and index>0 and device.gearIndex>0 and index~=device.gearIndex then
      local duration=interpolate(index>device.gearIndex and cfg.upTime or cfg.downTime,pedal())
      local minimum=device.minimumGearChangeTime;device.minimumGearChangeTime=duration
      local previous=device.gearIndex
      local ok,result=pcall(originalSet,device,index,duration);device.minimumGearChangeTime=minimum
      if not ok then error(result) end;if index==device.gearIndex then beginShiftCut(previous,index) end;state.shiftTime=duration;return result
    end
    local previous=device.gearIndex;local result=originalSet(device,index,time)
    if index==device.gearIndex then beginShiftCut(previous,index) end;return result
  end
  gb.setGearIndex=setWrapper;return true
end
function M.update()
  if not gearbox then return state end
  local cfg=active();state.active=cfg~=nil;lockup(cfg)
  if cutActive and not shiftCutConfig() then stopShiftCut('Coupure suspendue') end
  if dct then
    local bc=blipConfig()
    if clutchHandling and clutchBlipBase then clutchHandling.revMatchThrottle=bc and (bc.blipPct or 50)/100 or clutchBlipBase end
    if logic.timerConstants and finite(logic.timerConstants.revMatchExpired) then
      if expiryTable~=logic.timerConstants then expiryTable=logic.timerConstants;expiryBase=expiryTable.revMatchExpired end
      expiryTable.revMatchExpired=bc and math.min(expiryBase,bc.blipTime or .2) or expiryBase
    end
    state.blipActive=bc~=nil and logic.isShifting==true and clutchHandling and not clutchHandling.didRevMatch and (logic.throttle or 0)>0 or false
    if cfg then
      local current=gearbox[dct.primaryAccess.gearIndexName] or gearbox.gearIndex
      local desired=upvalue(logic.updateGearboxGFX,'newDesiredGearIndex') or logic.currentGearIndex or current
      local duration=interpolate(desired>0 and desired<current and cfg.downTime or cfg.upTime,pedal())
      local aggression=upvalue(logic.updateGearboxGFX,'shiftAggression') or logic.shiftingAggression or 1
      dct.clutchTime=duration/clamp(10-9*aggression,1,10);state.shiftTime=duration
    else dct.clutchTime=dctBase end
  end
  state.blipEnabled=blipConfig()~=nil;state.blipCount=blipCount
  state.gear=currentGear();state.shifting=gearbox.isShifting==true or logic.isShifting==true
  state.lockupRatio=tonumber(electrics.values.lockupClutchRatio) or 0
  return state
end
-- Physical engine step: native throttle and protected cuts are restored/retained by the caller.
function M.shiftCutThrottle(value,dt,blocked)
  if not gearbox then return value end
  cutBlocked=blocked==true
  local c=shiftCutConfig()
  local desired=logic.currentGearIndex or currentGear()
  local shifting=logic.isShifting==true or gearbox.isShifting==true
  if not c then stopShiftCut('Désactivé ou conditions non réunies');return value end
  if dct and shifting then beginShiftCut(currentGear(),desired) end
  if not cutActive then if not shifting then cutKey=nil end;return value end
  if desired>0 and desired<cutTo then stopShiftCut('Rétrogradage : coupure arrêtée');return value end
  local t=cutElapsed;cutElapsed=t+math.max(0,dt or 0)
  if t>=c.duration+c.recovery then stopShiftCut('Coupure terminée');return value end
  local intensity=c.strength/100;local factor,pulse=1,false
  if c.style=='progressive' then
    local floor=1-.9*intensity;local attack=math.min(.025,c.duration*.25)
    factor=t<attack and 1-(1-floor)*t/attack or t<c.duration and floor or c.recovery>0 and math.min(1,floor+(1-floor)*(t-c.duration)/c.recovery) or 1
  else
    if t<c.duration then factor=1-.2*intensity;pulse=t%.034<.020*intensity
    else local floor=1-.65*intensity;factor=c.recovery>0 and math.min(1,floor+(1-floor)*(t-c.duration)/c.recovery) or 1 end
  end
  if pulse and originalCut then originalCut(engineRef,math.max(engineRef.ignitionCutTime or 0,(dt or 0)*1.1)) end
  state.shiftCutActive=true;state.shiftCutElapsed=t;state.shiftCutFactor=pulse and 0 or factor;state.shiftCutPulse=pulse;state.shiftCutReason='Coupure de passage active'
  return value*factor
end
-- Called only inside the owner's native engine step; returned throttle is temporary.
function M.blipThrottle(value,dt,blocked)
  if not gearbox or dct then return value end
  state.blipActive=false;state.blipTargetRPM=nil
  if blipLeft<=0 then return value end
  blipLeft=blipLeft-math.max(dt or 0,0)
  local cfg=blipConfig();local target=cfg and safeTarget(blipGear)
  if blocked or not target or blipLeft<=0 or math.abs(tonumber(electrics.values.wheelspeed) or 0)<1.4 or engineRef.outputAV1*30/math.pi>=target-100 or currentGear()~=blipGear or (engineRef.ignitionCutTime or 0)>0 then blipLeft=0;return value end
  state.blipActive=true;state.blipTargetRPM=target
  return math.max(value,(cfg.blipPct or 50)/100)
end
return M
