-- ECU-owned over-redline torque continuation. Physical damage stays native.
local M={}
function M.capture(engine,data)
  if type(engine.torqueCurve)~='table' or type(engine.maxRPM)~='number' then return nil end
  local nominal=type(data)=='table' and tonumber(data.maxRPM) or engine.maxRPM
  nominal=math.min(nominal or engine.maxRPM,engine.maxAvailableRPM or math.huge)
  local anchor=math.floor(nominal)
  local torque=engine.torqueCurve[anchor]
  if type(torque)~='number' or torque<=0 then return nil end
  return {curve=engine.torqueCurve,maxRPM=engine.maxRPM,maxAV=engine.maxAV,
    anchor=anchor,torque=torque,range=engine.redlineTorqueDropOffRange or 500}
end
function M.restore(engine,state)
  if not state then return end
  if engine.torqueCurve==state.ownedCurve then engine.torqueCurve=state.curve end
  if engine.maxRPM==state.ownedRPM then engine.maxRPM=state.maxRPM end
  if engine.maxAV==state.ownedAV then engine.maxAV=state.maxAV end
  state.target=nil;state.ownedCurve=nil;state.ownedRPM=nil;state.ownedAV=nil
end
function M.apply(engine,state,target)
  if not state then return end
  if target<=state.maxRPM then M.restore(engine,state);return end
  if state.target==target then return end
  -- Copy the native curve: never mutate the original table shared by the host.
  local curve={};for rpm,torque in pairs(state.curve) do curve[rpm]=torque end
  local anchor,range=state.anchor,math.max(10,state.range)
  local finish=math.ceil(math.max(target,anchor)+range*2)
  for rpm=anchor+1,finish do
    -- A modeled loss of 15% per extra 1000 RPM; no added torque peak.
    local torque=state.torque*.85^((rpm-anchor)/1000)
    if rpm>target then torque=torque*math.max(0,1-(rpm-target)/(range*2)) end
    curve[rpm]=torque
  end
  -- Remove any longer old tail so it cannot produce torque after this one.
  for rpm in pairs(curve) do if type(rpm)=='number' and rpm>finish then curve[rpm]=nil end end
  engine.torqueCurve=curve;engine.maxRPM=target;engine.maxAV=target*math.pi/30
  state.target=target;state.ownedCurve=curve;state.ownedRPM=target;state.ownedAV=engine.maxAV
end
return M
