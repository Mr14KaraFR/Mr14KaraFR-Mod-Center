-- ECU combustion catch only: no extra injection, random trigger or terminal bang.
local M={}
local function clamp(x,a,b)return math.max(a,math.min(b,tonumber(x)or 0))end
local function pick(seed,cycle,salt)local n=math.sin(seed*.137+cycle*127.1+salt*311.7)*43758.5453;return n-math.floor(n)end
local function smooth(x)x=clamp(x,0,1);return x*x*(3-2*x)end
function M.plan(p,seed,cycle)
 local support=clamp(p.demand,0,1)*(.4+.6*clamp(p.heat,0,1))*(.55+.45*(p.retard==nil and 1 or clamp(p.retard,0,1)))
 local a=.055+.040*(1-support)+.025*pick(seed,cycle,3)
 local b=a+.085+.090*(1-support)+.025*pick(seed,cycle,7)
 return {catch=a,gap=b,ready=b+.10+.15*(1-support)+.04*pick(seed,cycle,11)}
end
function M.factor(plan,time)
 if time<plan.catch then return .18+.42*smooth(time/plan.catch),'catch' end
 if time<plan.gap then return 0,'hesitate'end
 if time<plan.ready then return smooth((time-plan.gap)/(plan.ready-plan.gap)),'settling'end
 return 1,'ready'
end
return M
