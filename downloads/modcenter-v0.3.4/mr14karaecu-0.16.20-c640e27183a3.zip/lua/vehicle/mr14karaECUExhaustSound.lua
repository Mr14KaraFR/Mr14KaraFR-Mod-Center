-- ECU-only acoustics: measured tip size and mounted exhaust identity.
-- Existing native VBF audio remains untouched when ECU does not own the event.
local distance=require('mr14karaECUAcousticDistance')
local M={};local cache,sources,serial,last={},{},0,0
local diagnostic={plays=0,failures=0,sourceCount=0}
function M.stats()return diagnostic end
local function clamp(x,a,b)return math.max(a,math.min(b,tonumber(x) or 0))end
local function text(x)
 if type(x)=='string'then return x:lower()elseif type(x)~='table'then return ''end
 local out={};for _,v in pairs(x)do out[#out+1]=text(v)end;return table.concat(out,' ')
end
function M.reset()cache,sources,serial,last={},{},0,0;diagnostic={plays=0,failures=0,sourceCount=0}end
function M.character(data,node,pipes)
 if cache[node]then return cache[node]end
 local ok,p=pcall(require,'common/vbfProfile657')
 local size=ok and p.tipScale and clamp(p.tipScale(data,node),.65,3.125)or 1
 local class=ok and p.exhaustClass and p.exhaustClass(data,pipes)or 0
 local short=false
 for _,name in pairs(data and data.activeParts or {})do
  local part=data.activePartsData and data.activePartsData[name]or {}
  local id=text(name)..' '..text(part.slotType)..' '..text(part.information and part.information.name)
  if id:find('exhaust',1,true)or id:find('header',1,true)or id:find('downpipe',1,true)then
   id=id:gsub('[_%-]',' ')
   for _,tag in ipairs({'side','lateral','hood','short pipe','short exhaust','open header','zoomie','stinger','turbo exhaust','autobello exhaust turbo'})do
    if id:find(tag,1,true)then short=true;break end
   end
  end
 end
 -- Physical outlet direction supplies a fallback for unnamed side/hood pipes.
 for _,pipe in pairs(pipes or {})do
  if pipe.finish==node then
   local a=data and data.nodes and data.nodes[pipe.start]
   local b=data and data.nodes and data.nodes[pipe.finish]
   if a and b and a.pos and b.pos then
    local dx,dy,dz=b.pos.x-a.pos.x,b.pos.y-a.pos.y,b.pos.z-a.pos.z
    local len=math.sqrt(dx*dx+dy*dy+dz*dz)
    if len>.001 and (math.abs(dx)>.75*len or dz>.75*len)then short=true end
   end
  end
 end
 local hoodOK,hood=pcall(require,'common/vbfHood669')
 local exposed=hoodOK and hood.exposed and hood.exposed(data,node)
 local kind=exposed and 'hood' or short and 'short' or size>=1.10 and 'deep' or 'standard'
 local c={kind=kind,size=size,class=class,pitch=kind=='hood'and 1.005 or kind=='short'and 1.025 or kind=='deep'and .965 or 1}
 cache[node]=c;return c
end
function M.path(bank,index,inside,c)
 local kind=c and c.kind or 'standard'
 if kind=='hood'then return 'art/sound/mr14karaecu/01619/hood/'..(inside and 'cabin/'or '')..bank..'_'..index..'.wav'end
 if kind~='standard'then return 'art/sound/mr14karaecu/01617/'..kind..'/'..(inside and 'cabin/'or '')..bank..'_'..index..'.wav'end
 local root=bank=='pop'and 'vbf650' or bank=='breath'and 'vbf626' or bank=='mega'and 'vbf629'or 'vbf625'
 local path='art/sound/'..root..'/'..bank..'_'..index..'.wav'
 if inside then path=bank=='pop'and path:gsub('vbf650/','vbf650/cabin/')or path:gsub('^art/sound/','art/sound/vbf630/cabin/')end
 return path
end
function M.distantPath(bank,index,c)return 'art/sound/mr14karaecu/01620/far/'..(c and c.kind or 'standard')..'/'..bank..'_'..index..'.wav'end
local function choose(node,count)
 serial=serial+1;local i=1+math.floor((math.sin(serial*2.399963+node*.173)*.5+.5)*count)
 if i==last then i=i%count+1 end;last=i;return i
end
local function voice(obj,node,path,level,pitch)
 local ok,err=pcall(function()
  local key=node..':'..path;local id=sources[key]
  if id==nil then id=obj:createSFXSource2(path,'AudioDefault3D','ecu1617_'..node..'_'..serial,node,0);assert(type(id)=='number'and id>=0);sources[key]=id;diagnostic.sourceCount=diagnostic.sourceCount+1 end
  obj:setVolumePitchCT(id,math.max(0,level),clamp(pitch,.85,1.15),0,0);obj:playSFX(id)
 end)
 diagnostic.lastPath=path;diagnostic.lastPitch=pitch
 if ok then diagnostic.plays=diagnostic.plays+1 else diagnostic.failures=diagnostic.failures+1;diagnostic.lastError=tostring(err)end
 return ok
end

local function spatial(obj,node,bank,index,inside,c,level,pitch)
 local mix=distance.mix(inside);local ok=false
 diagnostic.logicalEvents=(diagnostic.logicalEvents or 0)+1;diagnostic.distanceBlend=mix
 if mix<.999 then ok=voice(obj,node,M.path(bank,index,inside,c),level*(1-mix),pitch)or ok end
 if mix>.001 then ok=voice(obj,node,M.distantPath(bank,index,c),level*mix,pitch)or ok end
 return ok
end
function M.play(obj,node,strength,count,rate,inside,scale,kind,c)
 local bang=kind=='bang';local bank=bang and 'bang'or 'pop'
 local level=(.20+1.15*clamp(strength,0,1)^1.1)*(bang and 1.45 or kind=='crackle'and .65 or 1)*(scale or 1)
  /math.sqrt(math.max(1,count or 1))*clamp(math.sqrt(8/math.max(1,rate or 5)),.55,1)
 local pitch=((bang and .945 or kind=='crackle'and 1.005 or .98)+.015*math.sin((serial+1)*1.754877))*(c and c.pitch or 1)
 return spatial(obj,node,bank,choose(node,6),inside,c,level,pitch)
end
function M.finish(obj,node,strength,time,count,scale,massive,class,inside,c)
 -- Preserve the approved strong terminal gain, source count and cabin assets.
 local outlet=class==2 and 3.16227766 or class==1 and 2.51188643 or 1
 local level=(1.45+.5*clamp(strength,0,1))*clamp(scale or 1,0,1.3)/math.sqrt(math.max(1,count or 1))*3*outlet
 if massive then level=level*2.2 end
 local gain=.82+.96*.28
 local bank=massive and 'mega'or 'bang'
 local pitch=clamp(1+(.96*(.97-.96*.065)-1)*.25,.95,1.05)*(c and c.pitch or 1)
 return spatial(obj,node,bank,choose(node,massive and 3 or 6),inside,c,level*gain*1.8,pitch)
end
return M
