local M={};local curve=require('common/mr14karaECUAcousticCurve')
local distance,blend,key,watched=0,0,nil,nil
function M.set(value,mix)
 value=tonumber(value);if not value or value~=value then return end
 distance=math.max(0,math.min(10000,value));blend=math.max(0,math.min(1,tonumber(mix)or curve.blend(distance)))
end
function M.mix(inside)return inside and 0 or blend end
function M.stats()return {distance=distance,blend=blend,watching=watched~=nil}end
function M.reset(obj)
 if watched and obj and obj.queueGameEngineLua then obj:queueGameEngineLua('if extensions.mr14karaECUDistance then extensions.mr14karaECUDistance.unwatch('..watched..')end')end
 distance,blend,key,watched=0,0,nil,nil
end
function M.watch(obj,engine)
 if not obj or not obj.queueGameEngineLua then return end
 local nodes,seen={},{}
 for _,p in pairs(engine and engine.thermals and engine.thermals.exhaustEndNodes or {})do
  local n=tonumber(p.finish)
  if n and n==n and n>=0 and n<100000 and n%1==0 and not seen[n]and #nodes<8 then nodes[#nodes+1]=n;seen[n]=true end
 end
 table.sort(nodes);local id=obj:getId();local k=id..':'..table.concat(nodes,',')
 if key==k then return end;key=k;watched=id
 obj:queueGameEngineLua("extensions.load('mr14karaECUDistance');extensions.mr14karaECUDistance.watch("..id..",{"..table.concat(nodes,',').."})")
end
return M
