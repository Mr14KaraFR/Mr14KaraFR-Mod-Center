-- Scale ECU smoke optical density after native simulation, without more parcels.
local M={}
local gains={}
local model,original,wrapper
local function bind()
  if model then return end
  local ok,m=pcall(require,'common/mr14karaDieselModel')
  if not ok or type(m)~='table' or type(m.advance)~='function' then return end
  model=m;original=m.advance
  local native=original
  wrapper=function(p,dt)
    local alive=native(p,dt)
    local entry=gains[p.vehicle]
    if dt>0 then
      if p.ecuDensityGain==nil then p.ecuDensityGain=entry and entry.gain or 1 end
      p.density=p.density*p.ecuDensityGain
    end
    return alive
  end
  model.advance=wrapper
end
function M.setGain(id,gain)
  if type(id)~='number' or type(gain)~='number' or gain~=gain or gain<0 or gain>8 then return end
  if not be:getObjectByID(id) then return end
  gains[id]={gain=gain,age=0};bind()
end
function M.onUpdate(dtReal,dtSim)
  for id,entry in pairs(gains) do
    entry.age=entry.age+math.max(0,dtSim or dtReal or 0)
    if entry.age>2 or not be:getObjectByID(id) then gains[id]=nil end
  end
end
function M.onVehicleDestroyed(id) gains[id]=nil end
function M.onExtensionUnloaded()
  if model and model.advance==wrapper then model.advance=original end
  model,original,wrapper=nil,nil,nil;gains={}
end
M.onClientEndMission=M.onExtensionUnloaded
return M
