-- Main acoustic listener position, sampled from real camera and outlet nodes.
local M={};local curve=require('common/mr14karaECUAcousticCurve');local watching={}
function M.watch(id,nodes)
 if type(id)~='number'or id~=id then return end
 local clean={};for _,n in ipairs(nodes or {})do if type(n)=='number'and n>=0 and n<100000 and n%1==0 and #clean<8 then clean[#clean+1]=n end end
 watching[id]={nodes=clean,blend=0,poll=0}
end
function M.unwatch(id)watching[id]=nil end
M.onVehicleDestroyed=M.unwatch;M.onVehicleResetted=M.unwatch
function M.onUpdate(dtReal)
 if not next(watching)then return end
 local camera=core_camera.getPosition()
 for id,s in pairs(watching)do
  local veh=be:getObjectByID(id)
  if not veh then watching[id]=nil else
   s.poll=s.poll+(dtReal or 0)
   if s.poll>=.10 then
    local elapsed=s.poll;s.poll=0;local origin=veh:getPosition();local nearest=math.huge
    for _,n in ipairs(s.nodes)do local p=origin+veh:getNodePosition(n);nearest=math.min(nearest,(p-camera):length())end
    if nearest==math.huge then nearest=(origin-camera):length()end
    s.blend=curve.approach(s.blend,curve.blend(nearest),elapsed)
    veh:queueLuaCommand(string.format("local a=package.loaded['mr14karaECUAcousticDistance'];if a then a.set(%.5f,%.6f)end",nearest,s.blend))
   end
  end
 end
end
function M.onClientEndMission()watching={}end
function M.onExtensionLoaded()setExtensionUnloadMode(M,'manual')end
return M
