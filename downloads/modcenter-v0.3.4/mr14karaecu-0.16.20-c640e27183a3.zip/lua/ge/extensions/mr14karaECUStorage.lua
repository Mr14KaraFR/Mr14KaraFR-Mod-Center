-- Persistent ECU profiles and CSV logs in the BeamNG user folder.
local M={}
local root='settings/mr14karaECU/'
local activeTunes={}
local function safeName(name)
  return type(name)=='string' and #name>0 and #name<=64 and name:match('^[%w_-]+$')
end
local function emit(event,data)
  guihooks.trigger(event,data)
  if extensions and extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.publish(event,jsonEncode(data)) end
end
local function notice(text,ok) emit('Mr14ECUFileNotice',{message=text,ok=ok}) end
local function listTunes()
  local names,index={},{}
  for _,path in ipairs(FS:findFiles(root,'*.json',0,false,false) or {}) do
    local name=path:match('([^/]+)%.json$'); if name then table.insert(names,name);local data=jsonReadFile(path);local meta=type(data)=='table' and data.profileMeta;local c=type(meta)=='table' and meta.context;if type(c)=='table' then index[#index+1]={name=name,displayName=meta.displayName or name,role=meta.role or 'tune',context={model=c.model,engine=c.engine,id=c.id,tuneKey=c.tuneKey,fuelType=c.fuelType}} end end
  end
  table.sort(names);emit('Mr14ECUProfiles',names);emit('Mr14ECUProfileIndex',index)
end
local function saveTune(name,json)
  if not safeName(name) or type(json)~='string' or #json>60000 then notice('Nom invalide : lettres, chiffres, _ et - uniquement.',false);return end
  local ok,data=pcall(jsonDecode,json)
  if not ok or type(data)~='table' or data.version~=1 then notice('Cartographie invalide.',false);return end
  FS:directoryCreate(root,true)
  local path=root..name..'.json'
  local written=jsonWriteFile(path,data,true,nil,true)
  if written then notice('Cartographie sauvegardee : '..path,true);listTunes() else notice('Echec de sauvegarde.',false) end
end
local function loadTune(name)
  if not safeName(name) then return end
  local data=jsonReadFile(root..name..'.json')
  if data then emit('Mr14ECULoadedTune',data) else notice('Cartographie introuvable.',false) end
end
local function exportLog(csv)
  if type(csv)~='string' or #csv>4000000 or not csv:match('^time_s,') then notice('Log invalide ou trop volumineux.',false);return end
  local dir=root..'logs/'
  FS:directoryCreate(dir,true)
  local path=dir..os.date('%Y%m%d_%H%M%S')..'.csv'
  local suffix=1
  while FS:fileExists(path) do path=dir..os.date('%Y%m%d_%H%M%S')..'_'..suffix..'.csv';suffix=suffix+1 end
  local written=writeFile(path,csv)
  notice(written and 'Log exporte : '..path or 'Echec export CSV.',written and true or false)
end
-- Session cache survives part-management respawns of the same vehicle object.
local function rememberActive(id,key,json)
  if type(id)~='number' or type(key)~='string' or key=='' or type(json)~='string' or #json>60000 then return end
  local ok,data=pcall(jsonDecode,json)
  if not ok or type(data)~='table' or data.version~=1 then return end
  activeTunes[id]={key=key,json=json}
end
local function restoreActive(id,key)
  local cached=activeTunes[id]
  if not cached or cached.key~=key then return false end
  local vehicle=be:getObjectByID(id)
  if not vehicle then return false end
  vehicle:queueLuaCommand('local c=controller.getController("mr14karaECU"); if c and c.restoreActiveJSON then c.restoreActiveJSON('..string.format('%q',key)..','..string.format('%q',cached.json)..') end')
  return true
end
M.rememberActive=rememberActive;M.restoreActive=restoreActive
M.listTunes=listTunes;M.saveTune=saveTune;M.loadTune=loadTune;M.exportLog=exportLog
return M
