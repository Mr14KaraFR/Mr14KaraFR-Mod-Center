-- BeamMP already relays custom electrics; no custom server events required.
local M={}
local age,connected=5,false
local remoteIDs={}
local vehicleStats={}
function M.reportVehicle(id,json)
  if type(id)~='number' or type(json)~='string' or #json>3000 then return end
  local ok,d=pcall(jsonDecode,json);if ok and type(d)=='table' then vehicleStats[id]=d end
end
local function queue(id,remote,active)
  local obj=be:getObjectByID(id)
  if obj then obj:queueLuaCommand('local c=controller.getController("mr14karaECU"); if c and c.setMultiplayerSession then c.setMultiplayerSession('..tostring(active)..','..tostring(remote)..'); if c.requestMultiplayerStatus then c.requestMultiplayerStatus() end else obj:queueGameEngineLua("if extensions.mr14karaECUMultiplayer then extensions.mr14karaECUMultiplayer.reportVehicle('..id..', \'{\\"installed\\":false}\') end") end') end
end
function M.onUpdate(dt)
  local active=MPCoreNetwork and MPCoreNetwork.isMPSession and MPCoreNetwork.isMPSession()==true or false
  age=age+dt
  if not active and connected then
    for id in pairs(remoteIDs) do queue(id,false,false) end;remoteIDs={};vehicleStats={}
  end
  if age<1 and active==connected then return end
  age=0;connected=active
  local data={connected=active,ready=false,protocol=1,native=true,vehicles={}}
  if active and MPVehicleGE and MPVehicleGE.getVehicles then
    for _,veh in pairs(MPVehicleGE.getVehicles()) do
      if veh.gameVehicleID and veh.gameVehicleID>0 then
        queue(veh.gameVehicleID,not veh.isLocal,true);remoteIDs[veh.gameVehicleID]=true
        local s=deepcopy(vehicleStats[veh.gameVehicleID] or {});s.id=veh.gameVehicleID;s.remote=not veh.isLocal;s.owner=veh.ownerName or '';data.vehicles[#data.vehicles+1]=s
        if s.remote and (s.frames or 0)>0 and (s.frameAge or 999)<.5 then data.ready=true end
      end
    end
  end
  guihooks.trigger('Mr14ECUMultiplayerStatus',data)
  if extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.publish('Mr14ECUMultiplayerStatus',jsonEncode(data)) end
end
function M.onVehicleDestroyed(id) remoteIDs[id]=nil;vehicleStats[id]=nil end
function M.onExtensionUnloaded() for id in pairs(remoteIDs) do queue(id,false,false) end end
return M
