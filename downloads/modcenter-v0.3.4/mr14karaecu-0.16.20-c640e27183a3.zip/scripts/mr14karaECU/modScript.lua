extensions.load('mr14karaECUMultiplayer')
setExtensionUnloadMode('mr14karaECUMultiplayer','manual')
extensions.load('mr14karaECUExternal')
setExtensionUnloadMode('mr14karaECUExternal','manual')
if extensions.mr14karaECUExternal then extensions.mr14karaECUExternal.start() end
