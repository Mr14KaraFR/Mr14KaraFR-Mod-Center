param([Parameter(Mandatory=$true)][string]$UserDirectory)
$ErrorActionPreference = 'Stop'
$mutex = [Threading.Mutex]::new($false, 'Local\Mr14KaraFR_ECUExternalLauncher')
if (-not $mutex.WaitOne(0)) { exit }
$settingsDirectory = Join-Path $UserDirectory 'settings'
$requestPath = Join-Path $settingsDirectory 'mr14kara_ecu_external_request.json'
$statePath = Join-Path $settingsDirectory 'mr14kara_ecu_external_launcher.json'
function Read-Request {
  try { Get-Content -LiteralPath $requestPath -Raw | ConvertFrom-Json } catch { $null }
}
function Write-State($RequestId, $Success) {
  $state = @{time=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds(); requestId=$RequestId; ok=$Success}
  $temporaryPath = $statePath + '.tmp'
  [IO.File]::WriteAllText($temporaryPath, ($state | ConvertTo-Json -Compress), [Text.UTF8Encoding]::new($false))
  Move-Item -LiteralPath $temporaryPath -Destination $statePath -Force
}
$lastId = (Read-Request).requestId
$lastSuccess = $false
try {
  while ($true) {
    $request = Read-Request
    if ($request.operation -eq 'openECU' -and $request.requestId -match '^\d{10}-\d{9}$' -and $request.requestId -ne $lastId) {
      $lastId = $request.requestId
      try {
        # The request never supplies a URL, command, program or shell argument.
        $launchInfo = [Diagnostics.ProcessStartInfo]::new('http://127.0.0.1:8724/')
        $launchInfo.UseShellExecute = $true
        [Diagnostics.Process]::Start($launchInfo) | Out-Null
        $lastSuccess = $true
      } catch { $lastSuccess = $false }
    }
    Write-State $lastId $lastSuccess
    Start-Sleep -Milliseconds 500
  }
} finally { $mutex.ReleaseMutex(); $mutex.Dispose() }
