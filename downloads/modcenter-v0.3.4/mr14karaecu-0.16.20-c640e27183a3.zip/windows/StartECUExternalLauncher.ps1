param([Parameter(Mandatory=$true)][string]$UserDirectory)
$helperPath = Join-Path $PSScriptRoot 'ECUExternalLauncher.ps1'
$arguments = '-NoProfile -ExecutionPolicy RemoteSigned -File "' + $helperPath + '" -UserDirectory "' + $UserDirectory + '"'
Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WindowStyle Hidden

