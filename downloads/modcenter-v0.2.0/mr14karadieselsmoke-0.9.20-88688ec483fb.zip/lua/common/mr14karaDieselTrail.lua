-- Join successive samples of the same exhaust after their motion/collisions.
-- A finite volume segment fills the actual gap without inflating spherical puffs.
local M={}
local function planes(p,q)
  local out={}
  for _,v in ipairs({p,q}) do for _,g in ipairs(v.planes or {}) do
    if g[1]~=0 or g[2]~=0 or g[3]~=0 then
      local duplicate=false
      for _,h in ipairs(out) do
        if g[1]*h[1]+g[2]*h[2]+g[3]*h[3]>.995 and math.abs(g[4]-h[4])<.015 then duplicate=true; break end
      end
      if not duplicate then out[#out+1]=g end
    end
  end end
  local x,y,z=(p.x+q.x)*.5,(p.y+q.y)*.5,(p.z+q.z)*.5
  table.sort(out,function(a,b) return a[1]*x+a[2]*y+a[3]*z+a[4]<b[1]*x+b[2]*y+b[3]*z+b[4] end)
  for i=7,#out do out[i]=nil end
  return out
end
function M.update(parcels,collision)
  local newer={}
  for i=#parcels,1,-1 do
    local p=parcels[i]
    p.trail=nil
    p.sourceHead=false
    p.renderPlanes=p.planes
    local key=tostring(p.vehicle)..':'..tostring(p.outlet or 1)
    local q=newer[key]
    newer[key]=p
    if q and p.age-q.age>.00001 and p.age-q.age<=.22 then
      local dx,dy,dz=q.x-p.x,q.y-p.y,q.z-p.z
      local length=math.sqrt(dx*dx+dy*dy+dz*dz)
      local maxGap=math.max(.8,(p.speed or 0)*.22+2*p.radius)
      if length>.001 and length<=maxGap then
        local hit=collision.hit(p.x,p.y,p.z,dx/length,dy/length,dz/length,length)
        if not hit then
          p.trail={x=q.x,y=q.y,z=q.z,radius=q.radius,density=q.density,planes=q.planes}
          p.renderPlanes=planes(p,q)
        end
      end
    end
  end
end
-- Keep the newest gas connected to the current nozzle between 10 Hz emissions.
-- This changes one existing segment, without creating extra simulated parcels.
function M.attachSources(parcels,world,collision,now)
  local seen={}
  for i=#parcels,1,-1 do
    local p=parcels[i]
    local key=tostring(p.vehicle)..':'..tostring(p.outlet or 1)
    if not seen[key] then
      seen[key]=true
      if (p.age<=.16 or (now and p.sourceUntil and now<=p.sourceUntil)) and p.strength>.0001 then
        local vehicle=world:getObjectByID(p.vehicle)
        if vehicle and vehicle.getNodePosition and vehicle.getPosition then
          local ok,node,position=pcall(function() return vehicle:getNodePosition(p.outlet),vehicle:getPosition() end)
          if ok and node and position then
            local x,y,z=node.x+position.x,node.y+position.y,node.z+position.z
            local dx,dy,dz=x-p.x,y-p.y,z-p.z
            local length=math.sqrt(dx*dx+dy*dy+dz*dz)
            -- Reject a teleport or malformed node coordinates, and solid crossings.
            if length==length and length<math.max(.8,(p.speed or 0)*.3+2*p.radius)
              and (length<.00001 or not collision.hit(p.x,p.y,p.z,dx/length,dy/length,dz/length,length)) then
              local rich=math.max(0,math.min(1,(p.strength-.45)/.55))
              p.sourceHead=true
              p.trail={x=x,y=y,z=z,radius=.11,
                density=p.strength*(1+5.5*rich)*(p.pulseGain or 1)*(p.ecuDensityGain or 1)}
              p.renderPlanes=p.planes
            end
          end
        end
      end
    end
  end
end
-- Refresh already-selected source endpoints at draw time, after physics/VE.
function M.refreshSources(selected,world,collision)
  for _,p in ipairs(selected) do
    if p.sourceHead then
      local v=world:getObjectByID(p.vehicle)
      if v and v.getNodePosition and v.getPosition then
        local ok,n,pos=pcall(function() return v:getNodePosition(p.outlet),v:getPosition() end)
        if ok and n and pos then
          local x,y,z=n.x+pos.x,n.y+pos.y,n.z+pos.z
          local dx,dy,dz=x-p.x,y-p.y,z-p.z
          local length=math.sqrt(dx*dx+dy*dy+dz*dz)
          if length==length and length<math.max(.8,(p.speed or 0)*.3+2*p.radius)
            and (length<.00001 or not collision.hit(p.x,p.y,p.z,dx/length,dy/length,dz/length,length)) then
            p.trail.x,p.trail.y,p.trail.z=x,y,z
          end
        end
      end
    end
  end
end
return M
