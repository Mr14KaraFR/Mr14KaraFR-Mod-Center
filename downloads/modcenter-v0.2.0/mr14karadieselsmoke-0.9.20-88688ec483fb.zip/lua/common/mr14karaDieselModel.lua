-- Visual soot proxy, not a combustion or fluid solver.
local M = {}
local function clamp(x,a,b) return math.max(a,math.min(b,x)) end
local function noise2(x,y)
  local ix,iy=math.floor(x),math.floor(y)
  local fx,fy=x-ix,y-iy
  fx,fy=fx*fx*(3-2*fx),fy*fy*(3-2*fy)
  local function h(a,b) local v=math.sin(a*127.1+b*311.7)*43758.5453;return v-math.floor(v) end
  local a,b,c,d=h(ix,iy),h(ix+1,iy),h(ix,iy+1),h(ix+1,iy+1)
  return (a+(b-a)*fx)*(1-fy)+(c+(d-c)*fx)*fy
end
function M.new() return {density=0,throttle=0,transient=0} end
function M.setAir(s,e,boost)
  local value=tonumber(boost)
  -- Pressure is the game's measured PSI, never the ECU wastegate target.
  s.boostPsi=e.turbocharger and e.turbocharger.isExisting==true and value
    and value==value and math.abs(value)<math.huge and math.max(0,value) or nil
end
function M.response(s,dt,target,throttle)
  dt=clamp(tonumber(dt) or 0,0,.1)
  if dt<=0 then return s.density or 0,1 end
  target=clamp(tonumber(target) or 0,0,1)
  throttle=clamp(tonumber(throttle) or 0,0,1)
  local rise=math.max(0,throttle-(s.throttle or 0))
  local air=s.boostPsi and 1/(1+s.boostPsi/7.35) or nil
  local tauPulse=air and (.12+.20*air) or .22
  -- Accumulate a progressive pedal rise; do not depend on a single frame's jump.
  s.transient=math.min(1,(s.transient or 0)*math.exp(-dt/tauPulse)+rise*1.5)
  if throttle<.025 then s.transient=0 end
  s.throttle=throttle
  local tau=target>(s.density or 0) and .07 or .035
  s.density=(s.density or 0)+(target-(s.density or 0))*(1-math.exp(-dt/tau))
  if s.density<.0001 then s.density=0 end
  return s.density,1+(air and .65*air or .45)*s.transient*target
end
function M.update(s,dt,e,throttle)
  dt=clamp(tonumber(dt) or 0,0,.1)
  throttle=clamp(tonumber(throttle) or 0,0,1)
  local rpm=math.abs(tonumber(e.outputAV1) or 0)*9.5492966
  local running=e.requiredEnergyType=='diesel' and not e.isDisabled and not e.isStalled
    and (e.ignitionCoef or 0)>0 and rpm>350
  if not running then s.density,s.transient,s.throttle=0,0,throttle; return 0,rpm end
  local load=clamp(tonumber(e.engineLoad) or 0,0,1)
  -- Explicitly clean engines stay nearly clean. No DPF parts are altered.
  local factor=clamp((tonumber(e.particulates) or .12)*4,.04,1)
  local demand=clamp((load-.25)/.75,0,1)
  local target=(.006+.90*demand*demand*throttle)*factor
  if throttle<.025 and rpm>(e.idleRPM or 800)*1.5 then target=0 end
  local density,pulse=M.response(s,dt,target,throttle)
  return density,rpm,pulse
end
function M.advance(p,dt)
  if dt<=0 then return p.age<3 end
  p.age=p.age+dt
  local rich=clamp((p.strength-.45)/.55,0,1)
  p.spawnX,p.spawnY,p.spawnZ=p.spawnX or p.x,p.spawnY or p.y,p.spawnZ or p.z
  p.sourceVX,p.sourceVY,p.sourceVZ=p.sourceVX or p.vx,p.sourceVY or p.vy,p.sourceVZ or p.vz
  -- Smooth spatial curl field: nearby gas rolls together rather than jittering.
  -- Each component is independent of its own coordinate (zero divergence).
  local t=((p.birthTime or 0)+p.age)*1.5+(p.seed or 0)*.037
  local x,y,z=p.x*.7,p.y*.7,p.z*.7
  local ramp=1-math.exp(-p.age*3)
  local rx,ry,rz=p.sourceVX-p.wx,p.sourceVY-p.wy,p.sourceVZ-p.wz
  local relativeSpeed=math.sqrt(rx*rx+ry*ry+rz*rz)
  local wake=1-math.exp(-relativeSpeed/18)
  -- A bounded near-body wake follows the actual outlet when GE provides it.
  -- Vehicle velocity is separate from the exhaust jet; parked jets do not
  -- create a fictitious aerodynamic suction zone.
  local bodyWake,lateralPullX,lateralPullY=0,0,0
  local carSpeed=math.sqrt((p.vehicleVX or 0)^2+(p.vehicleVY or 0)^2)
  if carSpeed>3 and p.age<1.2 then
    local fx,fy=p.vehicleVX/carSpeed,p.vehicleVY/carSpeed
    local dx=p.x+p.vx*dt-(p.wakeX or (p.spawnX+p.vehicleVX*p.age))
    local dy=p.y+p.vy*dt-(p.wakeY or (p.spawnY+p.vehicleVY*p.age))
    local dz=p.z+p.vz*dt-(p.wakeZ or (p.spawnZ+(p.vehicleVZ or 0)*p.age))
    local behind=-(dx*fx+dy*fy)
    local lateral=-dx*fy+dy*fx
    if behind>-.4 and behind<5 then
      local release=clamp((1.2-p.age)/.4,0,1)
      release=release*release*(3-2*release)
      -- A widening, smoothly bounded recirculation pocket. It acts only near
      -- the current outlet; old smoke keeps its inertia when the car turns away.
      local entry=clamp((behind+.4)/.5,0,1)
      local exit=clamp((5-behind)/1.2,0,1)
      entry=entry*entry*(3-2*entry);exit=exit*exit*(3-2*exit)
      local width=1.15+.16*math.max(0,behind)
      bodyWake=entry*exit*release*clamp((carSpeed-3)/12,0,1)
        *math.exp(-((behind-1)/2)^2-(lateral/width)^2-(dz/1.5)^2-p.age/1.2)
      local pull=-clamp(lateral,-1.5,1.5)*bodyWake
      lateralPullX,lateralPullY=-fy*pull,fx*pull
    end
  end
  p.bodyWake=bodyWake
  local swirl=(.18+.16*p.strength+.55*wake+.8*rich)*ramp
  swirl=swirl+1.3*bodyWake*ramp
  local cx=(noise2(y+t*.7,z-t*.45)-.5)*2
  local cy=(noise2(z-t*.45+17,x+t*.6)-.5)*2
  local cz=(noise2(x+t*.6+31,y+t*.7)-.5)*2
  local horizontal=math.sqrt(rx*rx+ry*ry)
  if horizontal>5 then
    local lateral=(cx*(-ry)+cy*rx)/horizontal
    cx,cy=-ry/horizontal*lateral,rx/horizontal*lateral
  end
  local dragRate=1.35+1.1*bodyWake*ramp
  local drag=1-math.exp(-dt*dragRate)
  local lift=(.12+.22*math.exp(-p.age*.8))*(1-.8*rich)
  -- The rolling wake initially lifts gas; outside it the ascent is gradual.
  lift=lift+1.8*bodyWake*(1-math.exp(-p.age*10))+.18*clamp((carSpeed-3)/12,0,1)*math.exp(-p.age*1.5)*(1-math.exp(-p.age*3))
  local entrainment=.12*wake*math.exp(-p.age*2)
  local recirculation=.88*bodyWake
  local tx=p.wx+rx*entrainment+((p.vehicleVX or p.wx)-p.wx)*recirculation+lateralPullX*ramp+swirl*cx
  local ty=p.wy+ry*entrainment+((p.vehicleVY or p.wy)-p.wy)*recirculation+lateralPullY*ramp+swirl*cy
  local tz=p.wz+lift+swirl*cz*.65*(1-.7*rich)
  -- Integrate exponential drag over the step, rather than moving the entire
  -- step at its final velocity. This reduces speed-dependent FPS drift.
  local travel=drag/dragRate
  p.x=p.x+tx*dt+(p.vx-tx)*travel
  p.y=p.y+ty*dt+(p.vy-ty)*travel
  p.z=p.z+tz*dt+(p.vz-tz)*travel
  p.vx=p.vx+(tx-p.vx)*drag;p.vy=p.vy+(ty-p.vy)*drag;p.vz=p.vz+(tz-p.vz)*drag
  -- Entrainment slows as the jet loses energy; smooth fade reaches zero before removal.
  local previousRadius=p.radius or .11
  p.radius=.11+(.30+.10*p.strength)*(1-math.exp(-p.age*1.1))+.055*p.age
    +.65*wake*math.sqrt(p.age)*(1-math.exp(-p.age*3))
    +1.1*rich*(.18+.82*wake)*math.sqrt(p.age)*(1-math.exp(-p.age*3))
  -- Delayed air entrainment widens the plume after the tight nozzle jet.
  -- A parcel's expansion stays monotonic as it leaves the wake; no new parcels
  -- or extra noise octaves are needed. The density law below dilutes this gas.
  local mixingAge=math.max(0,p.age-.12)
  p.radius=p.radius+.22*clamp((carSpeed-3)/20,0,1)
    *(1-math.exp(-mixingAge*2))*math.sqrt(mixingAge)
    +.12*bodyWake*ramp
  if rich>0 then p.radius=p.radius*(1+rich*(noise2(p.x*.4+11,p.y*.4+7)-.5)*.6) end
  p.radius=math.max(previousRadius,p.radius)
  local fade=clamp((3-p.age)/1.1,0,1)
  fade=fade*fade*(3-2*fade)
  -- High soot demand from ECU enrichment must remain visible after wake expansion.
  -- Keep the stock/light-smoke curve intact; dense soot retains optical depth longer.
  p.density=p.strength*(1+5.5*rich)*math.exp(-p.age*(.6-.25*rich))
    *(.11/p.radius)^(1.65-.55*rich)*fade*(p.pulseGain or 1)
  return p.age<3
end
return M
