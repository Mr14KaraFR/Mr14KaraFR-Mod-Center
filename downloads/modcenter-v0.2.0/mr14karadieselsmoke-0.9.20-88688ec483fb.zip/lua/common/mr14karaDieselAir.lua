-- Game-world wind, refreshed for existing smoke rather than captured at birth only.
local M={}
local function valid(w)
  if not w then return false end
  for _,v in ipairs({w.x,w.y,w.z}) do
    if type(v)~='number' or v~=v or math.abs(v)>200 then return false end
  end
  return type(w.x)=='number' and type(w.y)=='number' and type(w.z)=='number'
end
function M.new(world,environment,vector)
  local api={}
  function api.sample(p,dt,force)
    if not force and dt<=0 then return end
    p.airAge=(p.airAge or .12)+dt
    if not force and p.airAge<.1 then return end
    p.airAge=0
    local w
    if world and type(world.getWindAt)=='function' then
      local ok,value=pcall(world.getWindAt,world,vector(p.x,p.y,p.z))
      if ok and valid(value) then w=value end
    end
    if not w and environment and type(environment.getGroundWind)=='function' then
      local ok,value=pcall(environment.getGroundWind)
      if ok and valid(value) then w=value end
    end
    if w then p.wx,p.wy,p.wz=w.x,w.y,w.z end
  end
  return api
end
return M
