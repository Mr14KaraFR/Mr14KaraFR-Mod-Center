-- Read the scene sky explicitly: legacy PostEffect shaders do not expose the
-- modern material sunlight buffer. Intensity/scattering remain approximate.
local M={}
local function finite(v) return type(v)=='number' and v==v and math.abs(v)<1e6 end
function M.new(scene)
  local state={sun={0,0,1,0},color={1,1,1},source='unavailable'}
  local timer=1
  local api={}
  function api.update(dt)
    timer=timer+math.max(0,dt or 0)
    if timer<.5 then return state end
    timer=0
    local ok,sky=pcall(function()
      if not scene or type(scene.findClassObjects)~='function' then return nil end
      local names=scene.findClassObjects('ScatterSky')
      return names and names[1] and scene.findObject(names[1])
    end)
    if not ok or not sky then state.sun={0,0,1,0};state.source='unavailable';return state end
    local success,az,el,irradiance=pcall(function()
      return tonumber(sky.azimuth),tonumber(sky.elevation),sky:getField('atmoSunIrradiance',0)
    end)
    if not success or not finite(az) or not finite(el) then state.sun={0,0,1,0};state.source='unavailable';return state end
    az,el=az*math.pi/180,el*math.pi/180
    -- Approximate ScatterSky orientation; real atmosphere attenuation is not sampled.
    state.sun={math.sin(az)*math.cos(el),math.cos(az)*math.cos(el),math.sin(el),math.max(0,math.min(1,math.sin(el)*2))}
    local color={}
    if type(irradiance)=='string' then for n in irradiance:gmatch('[^%s,]+') do color[#color+1]=tonumber(n) end end
    if finite(color[1]) and finite(color[2]) and finite(color[3]) then
      local scale=math.max(1,color[1],color[2],color[3])
      state.color={math.max(0,color[1])/scale,math.max(0,color[2])/scale,math.max(0,color[3])/scale}
    else state.color={1,1,1} end
    state.source='sky'
    return state
  end
  function api.reset() timer=1 end
  return api
end
return M
