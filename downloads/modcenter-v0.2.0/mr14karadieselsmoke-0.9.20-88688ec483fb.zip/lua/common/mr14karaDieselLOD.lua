-- Fade unresolved microstructure, preserving geometry, lifetime and opacity inputs.
local M={near=35,far=75}
function M.viewScale(fov)
  if type(fov)~='number' or fov~=fov or fov<=0 or fov>=180 then return 1 end
  -- Zoom keeps detail rather than treating an enlarged distant cloud as tiny.
  return math.min(1,math.tan(fov*math.pi/360)/math.tan(math.pi/6))
end
function M.weight(p,tail,eye,scale)
  tail=tail or p
  local dx,dy,dz=tail.x-p.x,tail.y-p.y,tail.z-p.z
  local length2=dx*dx+dy*dy+dz*dz
  local t=length2>1e-10 and math.max(0,math.min(1,((eye.x-p.x)*dx+(eye.y-p.y)*dy+(eye.z-p.z)*dz)/length2)) or 0
  local x,y,z=eye.x-p.x-dx*t,eye.y-p.y-dy*t,eye.z-p.z-dz*t
  local distance=math.max(0,math.sqrt(x*x+y*y+z*z)-math.max(p.radius,tail.radius))*(scale or 1)
  local f=math.max(0,math.min(1,(distance-M.near)/(M.far-M.near)))
  return 1-f*f*(3-2*f)
end
-- The shader only needs a young-jet flag, leaving this channel for detail.
-- [0,1] is old gas; [2,3] is young gas, with the same detail weight.
function M.pack(age,weight) return (age<.3 and 2 or 0)+weight end
return M
