-- Swept parcel centers plus local surface planes used by the volume shader.
-- Ray queries are injected so collision behavior can be tested outside the game.
local M={}
local axes={{0,0,-1},{0,0,1},{1,0,0},{-1,0,0},{0,1,0},{0,-1,0}}
-- Face, edge and corner directions cover gaps between the original six rays.
for x=-1,1 do for y=-1,1 do for z=-1,1 do
  local n=x*x+y*y+z*z
  if n>1 then local l=math.sqrt(n); axes[#axes+1]={x/l,y/l,z/l} end
end end end
local function finite(x) return type(x)=='number' and x==x and math.abs(x)<1e8 end
function M.new(ray,staticRay,vector)
  local api={}
  local probeInterval=.16
  local surfaces,surfaceCursor={},0
  -- Native queries consume these vectors synchronously. Reuse per-instance
  -- scratch storage instead of allocating two vectors for every smoke ray.
  local origin,direction,endpoint=vector(0,0,0),vector(0,0,0),vector(0,0,0)
  function api.setInterval(value) probeInterval=math.max(.08,math.min(.3,value)) end
  function api.hit(x,y,z,dx,dy,dz,length)
    if length<.00001 then return nil end
    origin.x,origin.y,origin.z=x,y,z
    direction.x,direction.y,direction.z=dx,dy,dz
    local nx,ny,nz,hx,hy,hz
    local detailedNormal=false
    local staticDistance
    if type(staticRay)=='function' then
      local ok,d=pcall(staticRay,origin,direction,length)
      if ok and finite(d) and d>=0 then
        if d>=length-.0001 then return nil end
        staticDistance=d
        -- Validate a previously measured normal against a fresh nearest-hit
        -- distance. This reuses road/wall planes without skipping obstacle checks.
        for i=#surfaces,1,-1 do
          local g=surfaces[i]
          local toward=-(g[1]*dx+g[2]*dy+g[3]*dz)
          if toward>.05 then
            local distance=(g[1]*x+g[2]*y+g[3]*z+g[4])/toward
            if math.abs(distance-d)<.003 then return g end
          end
        end
      end
    end
    if type(ray)=='function' then
      endpoint.x,endpoint.y,endpoint.z=x+dx*length,y+dy*length,z+dz*length
      local ok,h=pcall(ray,origin,endpoint,true,true)
      -- A successful detailed query with no contact needs no second static query.
      if ok and (h==nil or h==false) and staticDistance==nil then return nil end
      if ok and h and h.pt and h.norm then
        hx,hy,hz=h.pt.x,h.pt.y,h.pt.z
        nx,ny,nz=h.norm.x,h.norm.y,h.norm.z
        detailedNormal=true
      end
    end
    if not (finite(hx) and finite(hy) and finite(hz) and finite(nx) and finite(ny) and finite(nz)) then
      if type(staticRay)~='function' then return nil end
      local ok,d=true,staticDistance
      if d==nil then ok,d=pcall(staticRay,origin,direction,length) end
      if not ok or not finite(d) or d<0 or d>=length-.0001 then return nil end
      hx,hy,hz=x+dx*d,y+dy*d,z+dz*d
      nx,ny,nz=-dx,-dy,-dz
    end
    local norm=math.sqrt(nx*nx+ny*ny+nz*nz)
    if norm<.00001 then return nil end
    nx,ny,nz=nx/norm,ny/norm,nz/norm
    if nx*dx+ny*dy+nz*dz>0 then nx,ny,nz=-nx,-ny,-nz end
    local distance=(hx-x)*dx+(hy-y)*dy+(hz-z)*dz
    if distance<-.001 or distance>length+.001 then return nil end
    local g={nx,ny,nz,-nx*hx-ny*hy-nz*hz}
    if staticDistance and detailedNormal then
      surfaceCursor=surfaceCursor%64+1;surfaces[surfaceCursor]=g
    end
    return g
  end
  function api.probe(p)
    local contacts={}
    for _,a in ipairs(axes) do
      local g=api.hit(p.x,p.y,p.z,a[1],a[2],a[3],p.radius+.035)
      if g then
        local duplicate=false
        for _,h in ipairs(contacts) do
          if g[1]*h[1]+g[2]*h[2]+g[3]*h[3]>.995 and math.abs(g[4]-h[4])<.015 then duplicate=true; break end
        end
        if not duplicate then contacts[#contacts+1]=g end
      end
    end
    table.sort(contacts,function(a,b)
      return a[1]*p.x+a[2]*p.y+a[3]*p.z+a[4]<b[1]*p.x+b[2]*p.y+b[3]*p.z+b[4]
    end)
    p.planes={}
    for i=1,6 do p.planes[i]=contacts[i] or {0,0,0,1} end
    p.probeAge=0
  end
  function api.move(p,ox,oy,oz,dt)
    if dt<=0 then return end
    local tx,ty,tz=p.x,p.y,p.z
    p.x,p.y,p.z=ox,oy,oz
    -- Up to three contacts handle a wall followed by a corner during one step.
    for _=1,3 do
      local dx,dy,dz=tx-p.x,ty-p.y,tz-p.z
      local length=math.sqrt(dx*dx+dy*dy+dz*dz)
      if length<.00001 then break end
      dx,dy,dz=dx/length,dy/length,dz/length
      local g=api.hit(p.x,p.y,p.z,dx,dy,dz,length+.012)
      if not g then p.x,p.y,p.z=tx,ty,tz; break end
      local gap=g[1]*p.x+g[2]*p.y+g[3]*p.z+g[4]
      local toward=-(g[1]*dx+g[2]*dy+g[3]*dz)
      local travel=math.max(0,math.min(length,(gap-.012)/math.max(toward,.00001)))
      p.x,p.y,p.z=p.x+dx*travel,p.y+dy*travel,p.z+dz*travel
      local remain=math.max(0,length-travel)
      local dot=dx*g[1]+dy*g[2]+dz*g[3]
      tx,ty,tz=p.x+(dx-dot*g[1])*remain,p.y+(dy-dot*g[2])*remain,p.z+(dz-dot*g[3])*remain
      local vn=p.vx*g[1]+p.vy*g[2]+p.vz*g[3]
      if vn<0 then p.vx=p.vx-vn*g[1]; p.vy=p.vy-vn*g[2]; p.vz=p.vz-vn*g[3] end
      -- Sliding on the same road plane must not launch 26 new rays every frame.
      local known=false
      for _,h in ipairs(p.planes or {}) do
        if g[1]*h[1]+g[2]*h[2]+g[3]*h[3]>.995 and math.abs(g[4]-h[4])<.015 then known=true;break end
      end
      if not known then p.probeAge=1 end -- a new wall still refreshes immediately
    end
    p.probeAge=(p.probeAge or 1)+dt
    if p.probeAge>=probeInterval then api.probe(p) end
  end
  return api
end
return M
