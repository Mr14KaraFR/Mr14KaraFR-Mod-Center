local M={}
-- Evict from the most represented vehicle, preserving sparse neighbouring trails.
function M.evict(parcels,incoming)
  local counts={}
  for _,p in ipairs(parcels) do counts[p.vehicle]=(counts[p.vehicle] or 0)+1 end
  local victim,n=nil,-1
  for id,count in pairs(counts) do
    if count>n or (count==n and (id==incoming or (victim~=incoming and id<victim))) then victim,n=id,count end
  end
  for i,p in ipairs(parcels) do if p.vehicle==victim then table.remove(parcels,i);return end end
end
-- Equal rounds reserve space for every visible vehicle (within the render budget).
function M.select(candidates,limit)
  local byId,groups={},{}
  for _,c in ipairs(candidates) do
    local id=c.p.vehicle
    if not byId[id] then byId[id]={id=id,items={}};groups[#groups+1]=byId[id] end
    local items=byId[id].items;items[#items+1]=c
  end
  local function better(a,b)
    if a.score==b.score then return a.p.sequence>b.p.sequence end
    return a.score>b.score
  end
  for _,g in ipairs(groups) do table.sort(g.items,better) end
  table.sort(groups,function(a,b)
    if a.items[1].score==b.items[1].score then return a.id<b.id end
    return a.items[1].score>b.items[1].score
  end)
  local out,round={},1
  while #out<limit do
    local added=false
    for _,g in ipairs(groups) do
      if #out==limit then break end
      if g.items[round] then out[#out+1]=g.items[round].p;added=true end
    end
    if not added then break end
    round=round+1
  end
  return out
end
return M
