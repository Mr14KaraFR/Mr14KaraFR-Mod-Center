-- Filter only native soot particles during this diesel's thermals update.
-- Uses normal Lua object forwarding, without changing private thermal state.
local M={}
function M.attach(thermals,active)
  local original=thermals.updateGFX
  if type(original)~='function' then return nil end
  local stats={suppressed=0,calls=0}
  local pipes,proxy,cachedObject={},{},nil
  local function pack(...) return {n=select('#',...),...} end
  local wrapper=function(...)
    if not active() then return original(...) end
    local engineObject=obj
    for key in pairs(pipes) do pipes[key]=nil end
    for _,p in pairs(thermals.exhaustEndNodes or {}) do
      pipes[tostring(p.finish)..':'..tostring(p.start)]=true
    end
    if cachedObject~=engineObject then
      cachedObject=engineObject
      proxy=setmetatable({}, {__index=function(table,key)
      if key=='addParticleByNodesRelative' then
        local method=function(_,finish,start,speed,particle,...)
          if type(particle)=='number' and particle>=40 and particle<=43 and pipes[tostring(finish)..':'..tostring(start)] then
            stats.suppressed=stats.suppressed+1; return
          end
          return engineObject:addParticleByNodesRelative(finish,start,speed,particle,...)
        end
        rawset(table,key,method);return method
      end
      local value=engineObject[key]
      if type(value)=='function' then
        local method=function(_,...) return value(engineObject,...) end
        rawset(table,key,method);return method
      end
      return value
    end})
    end
    obj=proxy
    stats.calls=stats.calls+1
    local result=pack(pcall(original,...))
    obj=engineObject
    if not result[1] then error(result[2],0) end
    return unpack(result,2,result.n)
  end
  thermals.updateGFX=wrapper
  return {stats=stats,thermals=thermals,isAttached=function() return thermals.updateGFX==wrapper end,
    detach=function() if thermals.updateGFX==wrapper then thermals.updateGFX=original end end}
end
return M
