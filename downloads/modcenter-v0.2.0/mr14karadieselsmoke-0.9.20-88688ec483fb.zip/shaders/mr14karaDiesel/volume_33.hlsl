// World-space soot density integrated along the camera ray.
#include "shaders/common/postFx/postFx.h.hlsl"
uniform_sampler2D(prepassTex,0);
uniform_sampler2D(prepassDepthTex,1);
uniform_sampler2D(noiseTex,2);
cbuffer perDraw : register(b0) {
  uniform float3 dieselEye;
  uniform float dieselCount;
  uniform float dieselTime;
  uniform float dieselSamples;
  uniform float dieselDetail;
  uniform float4 dieselSun;
  uniform float3 dieselSunColor;
  uniform float4 dieselBounds;
  uniform float4 dieselPositions[32];
  uniform float4 dieselEnds[32];
  uniform float4 dieselStates[32];
  uniform float4 dieselPlanes[192];
  POSTFX_UNIFORMS
};
#include "shaders/common/postFx/postFx.hlsl"
#ifdef SHADER_STAGE_VS
PFXVertToPix main(PFXVert IN) { return processPostFxVert(IN); }
#else
float noise3(float3 p) {
  float3 cell=floor(p),f=frac(p);f=f*f*(3-2*f);
  float z=cell.z-floor(cell.z/128)*128;
  float nextZ=z<127 ? z+1 : 0;
  float2 xy=(cell.xy-floor(cell.xy/128)*128)+f.xy+1.5;
  float2 tile0=float2(z-floor(z/16)*16,floor(z/16));
  float2 tile1=float2(nextZ-floor(nextZ/16)*16,floor(nextZ/16));
  float a=noiseTexTex.SampleLevel(noiseTex_sampler_,(tile0*130+xy)/float2(2080,1040),0).r;
  float b=noiseTexTex.SampleLevel(noiseTex_sampler_,(tile1*130+xy)/float2(2080,1040),0).r;
  return lerp(a,b,f.z);
}
void parcelGeometry(int i,out float4 pos,out float4 state,out float4 tail) {
  pos=dieselPositions[i];state=dieselStates[i];tail=dieselEnds[i];
}
void parcelPlanes(int i,out float4 p0,out float4 p1,out float4 p2,out float4 p3,out float4 p4,out float4 p5) {
  int base=i*6;p0=dieselPlanes[base];p1=dieselPlanes[base+1];p2=dieselPlanes[base+2];
  p3=dieselPlanes[base+3];p4=dieselPlanes[base+4];p5=dieselPlanes[base+5];
}
float4 main(PFXVertToPix IN) : SV_Target {
  float rayLength=length(IN.wsEyeRay);
  float3 rd=IN.wsEyeRay/max(rayLength,.00001);
  float3 boundsOC=dieselEye-dieselBounds.xyz;
  float boundsB=dot(boundsOC,rd);
  if(dieselCount<.5 || boundsB*boundsB-dot(boundsOC,boundsOC)+dieselBounds.w*dieselBounds.w<=0 ||
    (boundsB>0 && dot(boundsOC,boundsOC)>dieselBounds.w*dieselBounds.w)) discard;
  float depth=decodeGBuffer(TEX_SAMPLER(prepassDepthTex),TEX_SAMPLER(prepassTex),IN.uv0,projParams).w;
  float sceneDistance=depth*rayLength;
  float opticalDepth=0;
  float3 scatteredLight=0;
  float daylight=saturate(dieselSun.w);
  float3 sunTint=dieselSunColor;
  float3 sunDirection=dieselSun.xyz/max(length(dieselSun.xyz),.00001);
  [loop] for(int i=0;i<min((int)dieselCount,32);i++) {
    if(opticalDepth>=4.6) break; // less than 1.01% opacity remains
    float4 pos,state,tail; parcelGeometry(i,pos,state,tail);
    float3 segment=tail.xyz-pos.xyz;
    float segmentLength=length(segment);
    float3 axis=segment/max(segmentLength,.00001);
    float radius=max(pos.w,state.w);
    float3 oc=dieselEye-pos.xyz;
    float begin=0,end=sceneDistance;
    if(segmentLength>.001) {
      // Tight finite cylinder bounds: long trails keep adequate ray resolution.
      float along=dot(oc,axis),direction=dot(rd,axis);
      float3 lateral=oc-axis*along,rayLateral=rd-axis*direction;
      float a=dot(rayLateral,rayLateral),b=dot(lateral,rayLateral),c=dot(lateral,lateral)-radius*radius;
      if(a>.000001) {
        float h=b*b-a*c;
        if(h<=0) continue;
        h=sqrt(h); begin=max(begin,(-b-h)/a); end=min(end,(-b+h)/a);
      } else if(c>=0) continue;
      if(abs(direction)>.000001) {
        float t0=(-radius-along)/direction,t1=(segmentLength+radius-along)/direction;
        begin=max(begin,min(t0,t1)); end=min(end,max(t0,t1));
      } else if(along< -radius || along>segmentLength+radius) continue;
    } else {
      float b=dot(oc,rd),h=b*b-dot(oc,oc)+radius*radius;
      if(h<=0) continue;
      h=sqrt(h); begin=max(begin,-b-h); end=min(end,-b+h);
    }
    if(end<=begin) continue;
    float4 p0,p1,p2,p3,p4,p5;parcelPlanes(i,p0,p1,p2,p3,p4,p5);
    int sampleCount=clamp((int)dieselSamples,4,12);
    // Full quality resolves the small fresh jet; distant old gas keeps its budget.
    float distance2=dot(oc,oc);
    if(dieselSamples>=12 && state.y>=2 && distance2<400) sampleCount=24;
    if(distance2>6400) sampleCount=min(sampleCount,6);
    else if(distance2>1600) sampleCount=min(sampleCount,8);
    float fineWeight=saturate(state.y-(state.y>=2 ? 2 : 0));
    float stepSize=(end-begin)/sampleCount;
    [loop] for(int s=0;s<sampleCount;s++) {
      if(opticalDepth>=4.6) break;
      float3 world=dieselEye+rd*(begin+(s+.5)*stepSize);
      // These world-space planes also reject hidden gas from below the road
      // or the other side of a wall, independently of the viewing direction.
      float4 wp=float4(world,1);
      float surfaceDistance=min(min(min(dot(p0,wp),dot(p1,wp)),min(dot(p2,wp),dot(p3,wp))),min(dot(p4,wp),dot(p5,wp)));
      if(surfaceDistance<=.003) continue;
      float along=segmentLength>.001 ? saturate(dot(world-pos.xyz,axis)/segmentLength) : 0;
      float3 center=lerp(pos.xyz,tail.xyz,along);
      float localRadius=max(lerp(pos.w,state.w,along),.001);
      // Irregular, nested density masses without a periodic centerline wave.
      float3 q=(world-center)/localRadius;
      float radial=dot(q,q);
      if(radial>=1) continue; // no noise evaluation outside the volume
      float3 flow=world*.75+float3(state.z*.13,-dieselTime*.24,state.z*.07);
      float coarse=noise3(flow);

      float threshold=.18+.48*radial;

      if(radial>=.35 && coarse*(dieselDetail>.5 ? .45 : .70)+(dieselDetail>.5 ? .45+.10*fineWeight : .30)<=min(threshold,.48)) continue; // exact upper bound for remaining octaves

      float3 fineFlow=world*4+float3(state.z*.13,-dieselTime*.24,state.z*.07);
      float medium=noise3(fineFlow+float3(7,13,3));

      float n=coarse*.70+medium*.30;

      [branch] if(dieselDetail>.5) {
        // Smoothly filter the finest octave towards its mean, not towards zero.
        // Camera proximity and zoom are evaluated once per parcel on the CPU.
        float fine=.5;
        [branch] if(fineWeight>0) fine=noise3(fineFlow*3+float3(19,2,11));
        n=coarse*.45+medium*.35+lerp(.5,fine,fineWeight)*.20;
      }

      // Coherent 3D erosion exposes lobes and wisps instead of a filled sphere.

      float support=1-smoothstep(.70,1,length(q));

      float masses=smoothstep(threshold,threshold+.20,n);

      float wisps=smoothstep(.48,.72,n)*smoothstep(.35,.85,radial);

      float core=pow(masses,1.5)*saturate(1-radial);

      float fringe=.06*wisps*(1-masses)*pow(saturate(1-radial),2);

      float continuity=.015*(1-smoothstep(0,.35,radial));
      float edge=(core+fringe+continuity)*support;

      float density=edge*(.65+.8*coarse+.35*wisps)*lerp(state.x,tail.w,along)*smoothstep(.003,.025,surfaceDistance);

      float extinction=density*stepSize*24;
      opticalDepth+=extinction;
      // Local single-scattering approximation, using the engine's sunlight.
      // No extra light ray march; this does not cast smoke shadows.
      float3 outward=q/max(length(q),.001);
      float sunSide=saturate(dot(outward,sunDirection)*.5+.5);
      float rho=lerp(state.x,tail.w,along);
      float transmission=exp(-min(6,rho*localRadius*(1-sunSide)*1.5));
      float skySide=saturate(q.z*.5+.5);
      float3 illumination=sunTint*daylight*(.008+.014*skySide+.045*sunSide*transmission);
      scatteredLight+=extinction*illumination;
    }
  }
  float alpha=1-exp(-min(opticalDepth,12));
  // Premultiplied absorption: black soot darkens the scene, unlike additive fire.
  return hdrEncode(float4((float3(.004,.0045,.005)*daylight+scatteredLight/max(opticalDepth,.00001))*alpha,alpha));
}
#endif
