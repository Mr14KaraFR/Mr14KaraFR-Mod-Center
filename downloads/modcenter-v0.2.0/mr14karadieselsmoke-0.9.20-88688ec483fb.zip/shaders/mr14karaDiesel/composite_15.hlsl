// Depth-aware reconstruction of the low-resolution premultiplied smoke buffer.
#include "shaders/common/postFx/postFx.h.hlsl"
uniform_sampler2D(smokeTex,0);
uniform_sampler2D(prepassTex,1);
uniform_sampler2D(prepassDepthTex,2);
cbuffer perDraw : register(b0) {
  uniform float2 texSize0;
  POSTFX_UNIFORMS
};
#include "shaders/common/postFx/postFx.hlsl"
#ifdef SHADER_STAGE_VS
PFXVertToPix main(PFXVert IN) { return processPostFxVert(IN); }
#else
float sceneDepth(float2 uv) {
  return decodeGBuffer(TEX_SAMPLER(prepassDepthTex),TEX_SAMPLER(prepassTex),uv,projParams).w;
}
float4 main(PFXVertToPix IN) : SV_Target {
  float2 size=max(texSize0,float2(1,1));
  float2 pixel=IN.uv0*size-.5;
  float2 base=floor(pixel),f=frac(pixel);
  float4 taps[4];float coverage=0;
  [unroll] for(int ty=0;ty<2;ty++) [unroll] for(int tx=0;tx<2;tx++) {
    taps[ty*2+tx]=tex2D(smokeTex,(base+float2(tx,ty)+.5)/size);
    coverage+=taps[ty*2+tx].a;
  }
  // Most screen pixels contain no gas: skip all G-buffer reads there.
  if(coverage<=.00001) discard;
  float centerDepth=sceneDepth(IN.uv1);
  float4 smoke=0;float weightSum=0;
  [unroll] for(int y=0;y<2;y++) [unroll] for(int x=0;x<2;x++) {
    float2 uv=(base+float2(x,y)+.5)/size;
    float tapDepth=sceneDepth(uv);
    // Ignore samples across a road/car silhouette rather than blurring through it.
    float tolerance=max(.00002,centerDepth*.015);
    float match=1-smoothstep(tolerance,tolerance*2,abs(tapDepth-centerDepth));
    float weight=(x==0 ? 1-f.x : f.x)*(y==0 ? 1-f.y : f.y)*match;
    smoke+=taps[y*2+x]*weight;weightSum+=weight;
  }
  return weightSum>.00001 ? smoke/weightSum : float4(0,0,0,0);
}
#endif
