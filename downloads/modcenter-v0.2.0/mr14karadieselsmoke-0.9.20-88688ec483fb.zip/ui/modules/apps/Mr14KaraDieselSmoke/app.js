angular.module('beamng.apps').directive('mr14KaraDieselSmoke', ['$interval', function ($interval) {
  return {
    restrict: 'EA', replace: true,
    templateUrl: '/ui/modules/apps/Mr14KaraDieselSmoke/app.html',
    link: function (scope) {
      var pendingQuality = null;
      var names = ['performance', 'balanced', 'quality'];
      scope.qualityModes = [{id:'performance',label:'Performance'},
        {id:'balanced',label:'Équilibré'}, {id:'quality',label:'Qualité'}];
      var help = {
        performance: 'Rendu à 35 % par axe : 4 échantillons, collisions moins fréquentes. Portée : 120 m.',
        balanced: 'Rendu à 50 % par axe : 8 échantillons. Portée : 200 m ; microdétails atténués progressivement au loin, zoom préservé.',
        quality: 'Rendu à 100 % par axe : 12 échantillons, 24 sur la fumée jeune à moins de 20 m, coût plus élevé. Portée : 250 m ; microdétails atténués progressivement au loin, zoom préservé.'
      };
      scope.controls = {quality:'balanced',diagnostics:false}; scope.qualityHelp = help.balanced;
      scope.status = {}; 
      function engine(code) {
        bngApi.engineLua('if not extensions.mr14karaDieselRenderer then extensions.load("mr14karaDieselRenderer") end; if extensions.mr14karaDieselRenderer then ' + code + ' end');
      }
      function refresh() { engine('extensions.mr14karaDieselRenderer.requestStatus()'); }
      scope.changeQuality = function () {
        if (names.indexOf(scope.controls.quality) < 0) return;
        pendingQuality = scope.controls.quality;
        scope.qualityHelp = help[scope.controls.quality];
        scope.qualityPending = true;
        engine('extensions.mr14karaDieselRenderer.setQuality("' + scope.controls.quality + '"); extensions.mr14karaDieselRenderer.requestStatus()');
      };
      scope.chooseQuality = function (value, event) {
        if (event) { event.stopPropagation(); event.preventDefault(); }
        if (names.indexOf(value) < 0) return;
        scope.controls.quality = value;
        scope.changeQuality();
      };
      scope.changeDiagnostics = function () {
        engine('extensions.mr14karaDieselRenderer.setDiagnostics(' + (scope.controls.diagnostics ? 'true' : 'false') + '); extensions.mr14karaDieselRenderer.requestStatus()');
      };
      var remove = scope.$on('Mr14DieselSmokeStatus', function (event, state) {
        if (!state || names.indexOf(state.quality) < 0) return;
        scope.$evalAsync(function () {
          scope.status = state;
          if (!pendingQuality || state.quality === pendingQuality) {
            scope.controls.quality = state.quality; pendingQuality = null; scope.qualityPending = false;
          }
          scope.qualityHelp = help[scope.controls.quality]; scope.controls.diagnostics = state.diagnostics === true;
        });
      });
      refresh();
      var timer = $interval(refresh, 1000);
      scope.$on('$destroy', function () {
        $interval.cancel(timer); remove();
        bngApi.engineLua('if extensions.mr14karaDieselRenderer then extensions.mr14karaDieselRenderer.setDiagnostics(false) end');
      });
    }
  };
}]);
