# Essai fumée diesel — Mr14KaraFR 0.9.18

Compter environ 10 minutes. Redémarrer BeamNG avant l’essai.

1. **Point de départ** : D35 diesel, même carte et mêmes réglages graphiques pour les comparaisons. Dans l’application « Fumée diesel By Mr14KaraFR », commencer en Performance, diagnostic désactivé. Relever les FPS habituels sans grosse fumée.
2. **Émission** : accélérer en charge, puis relâcher. Noter les FPS pendant le panache, sa forme et sa densité. La nouvelle émission doit baisser, tandis que la fumée déjà sortie se disperse pendant environ trois secondes. Pour l’ECU, noter le carburant effectif et l’éventuelle limitation d’injection, pas seulement la table demandée.
3. **Ctrl+R** : réinitialiser le véhicule pendant une émission. Le panache de l’ancienne position doit disparaître et le nouveau doit repartir du pot. Répéter une fois après déplacement du véhicule.
4. **Changement de véhicule** : remplacer le diesel par une essence, puis revenir au diesel. Aucune émission diesel ne doit être attribuée à l’essence. Si l’ancien diesel reste présent avec son moteur en marche, son propre panache reste normal.
5. **Deux diesels** : comparer une cartographie riche et une moins riche, puis supprimer un seul véhicule. Les deux doivent avoir une part d’affichage ; supprimer l’un ne doit pas effacer la fumée de l’autre. Le budget partagé peut raccourcir les traînées dans une scène chargée.
6. **Contacts et vent** : observer le panache près du sol et d’un mur, puis changer le vent au sol du jeu. Regarder depuis plusieurs angles. Un pot vertical émet initialement vers le haut, même si la remontée ajoutée du panache riche est réduite.

Si les FPS baissent encore, activer brièvement le diagnostic et relever : mode de qualité, volumes simulés/affichés, temps de simulation Lua et FPS avec/sans fumée. Le temps Lua n’est pas le coût GPU. Comparer ensuite Équilibré dans la même situation.

Retour utile : véhicule/configuration, carte, mode de qualité, réglage ECU effectif, FPS sans fumée / avec fumée, problème vu au Ctrl+R ou lors du changement de véhicule. Une courte vidéo du jeu aide à distinguer le rendu du comportement.

Les tests automatiques utilisent des fonctions du moteur simulées. Cette fiche sert à vérifier le résultat réel ; elle ne garantit pas les performances ou la couverture de tous les objets/véhicules moddés.

Éclairage 0.8.0 : comparer brièvement une scène de jour puis de nuit, et tourner la caméra autour du panache. Noter si la fumée devient trop claire, si la direction éclairée paraît incorrecte ou si les FPS changent. L’éclairage ajouté ne tient pas compte des phares.

Essai 0.8.1 : comparer une remise des gaz à faible pression turbo et une reprise avec turbo déjà chargé. Observer une bouffée plus marquée avant la montée en pression, puis une diminution du supplément transitoire. Relâcher puis reprendre : la nouvelle émission doit baisser et repartir sans effacer le panache existant. Une richesse excessive peut maintenir une fumée dense malgré le turbo.

Essai 0.9.0 : redémarrer complètement BeamNG, choisir Performance dans l’application Fumée diesel et vérifier que « Mode actif » affiche performance, 6 échantillons, 40 % par axe. Comparer ensuite Équilibré (8 / 50 %) et Qualité (12 / 75 %) avec la même voiture, caméra et accélération. Comparer les FPS avec et sans fumée. Signaler un écran noir, une fumée absente ou des contours qui débordent sur la voiture : le nouveau tampon réduit et sa reconstruction n’ont pas été exécutés dans le jeu pendant le développement hors ligne.

Essai 0.9.1 : redémarrer le jeu et vérifier la présence de trois boutons. Si la liste déroulante est encore visible, retirer puis remettre l’application Fumée diesel dans la disposition UI. Cliquer Performance : le bouton doit devenir vert après confirmation, avec mode actif performance / 6 échantillons / 40 % par axe.

Essai 0.9.2 : redémarrer BeamNG ; Performance doit afficher 4 échantillons et 35 % par axe. Comparer le départ de fumée au ralenti puis à 60 et 120 km/h : il doit rester relié à la sortie, y compris entre les émissions. Relâcher les gaz : le raccord doit fermer rapidement et le panache existant rester libre. Comparer les FPS dans les mêmes conditions, avec et sans fumée.

Essai 0.9.3 : redémarrer complètement le jeu et reprendre la même Vivace, injection, caméra et mode de qualité que sur la capture 0.9.2. Comparer les contours du panache, les variations de densité, son raccord au pot et les FPS. Vérifier que la forte injection donne encore des masses noires, sans bande uniformément opaque.

Essai 0.9.4 : redémarrer complètement BeamNG puis reproduire les coupures avec la même voiture, vitesse, injection et qualité. Vérifier d’abord la continuité du panache ; son réalisme reste un travail distinct.

Essai 0.9.5 : redémarrer le jeu ; le mode Qualité doit afficher 100 % par axe et 12 échantillons. Le passage à pleine résolution ne résout pas la forme tubulaire du panache.

Essai 0.9.6 : redémarrer BeamNG. Comparer la fumée à l’arrêt, puis à 60 et 120 km/h avec le même réglage ECU. En mouvement, observer le gaz proche de l’arrière, les remous latéraux et une montée progressive. Signaler une accumulation trop forte contre la voiture, une fumée traversant la carrosserie, des coupures ou une variation de FPS.

Essai 0.9.7 : redémarrer le jeu ; Qualité doit afficher 12–24 échantillons et 100 %. Reproduire la vue latérale à environ 123 km/h pour comparer le raccord au pot, la montée du panache et les anneaux dans la fumée jeune. Comparer aussi les FPS en gros plan.

Essai 0.9.8 : après redémarrage, vérifier les portées actives 120 / 200 / 250 m selon le mode. Pour BeamMP, faire charger le mod par les deux clients puis comparer depuis le point de vue de l’autre joueur ; la synchronisation n’est pas garantie par le changement de portée.

Essai 0.9.9 : redémarrer le jeu et reproduire la même voiture, caméra, vitesse et injection, dans les trois modes. Noter les FPS sans puis avec fumée et comparer à la version précédente. Qualité reste à 100 %, avec échantillonnage réduit à distance. Les motifs de bruit changent : signaler aussi une texture trop granuleuse, des trous ou des contours instables.

Essai 0.9.10 : après redémarrage, activer Diagnostic léger. Laisser le moteur au ralenti sans fumée visible, attendre au moins 3 s après une accélération : volumes 0/0 et rendu inactif sont attendus. Comparer les FPS au ralenti et moteur coupé, puis accélérer pour vérifier la reprise du panache volumétrique. Si un gros écart persiste avec rendu inactif, comparer à la même scène avec le mod désactivé pour isoler le coût moteur/ECU.

Essai 0.9.11 : comparer les trois profils après redémarrage avec une forte injection ; longer un mur et un trottoir pour vérifier la découpe. Les contacts sont conservés et utilisent des requêtes simples avant les recherches détaillées. Le gain mesuré en scène fixe doit encore être confirmé en conduite et avec plusieurs voitures.


Essai 0.9.14 : redémarrer complètement BeamNG. Contrôler que l'UI affiche 0.9.14. Essayer Performance, Équilibré, Qualité, puis accélérer avec une forte injection. Comparer le gros panache, son raccord au pot et la découpe du sol. Le regroupement des données ne réduit ni le nombre d'échantillons ni la résolution du mode Qualité. Le gain est modeste ; relever les FPS dans la même scène et avec la même caméra.


## 0.9.18 — microdétails progressifs à distance

En Équilibré et Qualité, l'octave de bruit la plus fine est filtrée progressivement vers sa moyenne entre 35 et 75 m de la surface la plus proche du volume. Le test utilise tout le segment, pas seulement son centre ; un long volume qui arrive près de la caméra garde ses détails. Un zoom étroit repousse cette simplification. À 60° de champ de vision, les microdétails sont complets jusqu'à 35 m et leur calcul est omis au-delà de 75 m. Les deux autres échelles de bruit, les volumes, leur densité physique, leur durée, les collisions et la portée restent en place. Le mode Performance garde ses deux échelles de bruit actuelles. Les limites d'échantillons à distance de la 0.9.14 restent inchangées.

Le passage est continu ; il ne retire aucun volume à une distance seuil. La texture lointaine peut paraître plus lisse. La non-linéarité de l'absorption peut modifier légèrement son opacité locale ; aucune épaisseur identique pixel par pixel n'est promise au loin. Près du pot, le filtrage est nul. Les profils gardent leurs résolutions actuelles : le mode Qualité reste à 100 % par axe.

Essai : observer une forte fumée en s'éloignant lentement, puis zoomer dessus. Les microdétails doivent revenir progressivement. Comparer les FPS à caméra identique ; une suppression d'octave réduit ses calculs mais ne garantit pas un gain global de FPS sur une scène donnée.

Essai 0.9.18 : redémarrer le jeu après installation. Comparer une accélération en ligne droite puis un virage, avec la caméra de côté. Le jet doit rester attaché au pot ; la traînée doit s’élargir ensuite et la fumée ancienne rester sur sa trajectoire. Comparer les FPS avec la 0.9.16 sur les mêmes réglages.
