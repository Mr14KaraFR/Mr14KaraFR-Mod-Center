# Fumée diesel volumétrique By Mr14KaraFR — 0.9.18 prototype

Objectif : fumée discrète au ralenti et plus sombre lorsque le moteur diesel travaille fortement. Le mod détecte les moteurs et utilise leurs sorties d'échappement, sans pièce supplémentaire à installer.

## Installation

1. Ouvrir le dossier utilisateur depuis le lanceur BeamNG, puis le dossier `mods`.
2. Désactiver ou retirer les anciens ZIP de ce mod du dossier mods, puis y copier `Mr14KaraFR_Diesel_Volumetric.zip` sans le décompresser. Ne pas activer plusieurs versions ensemble. Le nom du ZIP reste fixe ; l'auteur Mr14KaraFR et la version 0.9.18 sont dans les informations internes du mod.
3. Activer le mod dans le gestionnaire de mods et recharger le véhicule avec Ctrl+R.
4. Pour le premier essai, choisir un diesel ; le test en jeu de la 0.9.11 a été effectué avec Direct3D 12.

Le mod est indépendant de l'ECU Mr14KaraFR et du mod de flammes. Pour le retirer, désactiver ce ZIP et recharger le véhicule.

## Fonctionnement

Le shader traverse des volumes de densité 3D dans l'espace du jeu. La fumée absorbe l'image derrière elle ; la profondeur des objets opaques coupe le volume. Ce rendu n'utilise pas de sprites tournés vers la caméra. Le calcul reste une approximation visuelle à partir de nuages mobiles, et non une simulation complète des fluides.

La charge réelle du moteur, la commande d'accélérateur et une courte transition d'accélération pilotent la densité. Les gaz prennent la vitesse de la voiture et une vitesse de sortie, ralentissent, montent légèrement et se dispersent. L'arrêt du moteur et les sorties sous l'eau coupent l'émission. Les moteurs essence ne sont pas concernés.

## Contacts avec le décor

Le déplacement de chaque centre de nuage est balayé par un rayon entre son ancienne et sa nouvelle position. À la rencontre d'une surface, la vitesse dirigée vers cette surface est supprimée et le déplacement restant glisse le long de celle-ci. Jusqu'à trois contacts successifs sont traités pour les angles.

Vingt-six sondes (axes, diagonales et coins) autour du nuage cherchent les surfaces voisines, y compris quand le volume grossit. Les contacts similaires sont regroupés ; les six plans les plus proches sont transmis au shader pour supprimer la densité du côté solide, quelle que soit la caméra. Un nuage dont le centre reste au-dessus de la route ne devrait ainsi plus afficher sa partie basse sous la route. Les sondes sont renouvelées toutes les 0,08 seconde de simulation et immédiatement après un contact.

Les requêtes utilisent `castRay` avec terrain et géométrie visible ; elles peuvent traiter les objets mobiles que cette API expose. Un secours `castRayStatic` traite le décor statique si la requête détaillée ne fournit pas de résultat utilisable. Il ne fournit pas de vraie normale : ce secours est moins précis sur les surfaces inclinées.

Le paramètre moteur `particulates` module la suie. Une valeur explicitement nulle maintient une fumée très faible : un diesel propre ne fera donc pas un gros nuage noir. Le mod ne retire aucun FAP. La détection d'un FAP par sa pièce n'est pas implémentée ; seul ce paramètre moteur est utilisé. Les courbes sont des approximations artistiques, pas des mesures d'émissions.

## Validation et limites

Vérifié automatiquement sous LuaJIT : moteur diesel/essence, charge, moteur propre, coupure, dispersion, positions d'échappement, sorties multiples, immersion, remise à zéro et limites de nuages. Les shaders vertex et pixel compilent pour Shader Model 5 avec les fichiers d'en-tête de l'installation locale de BeamNG. Le ZIP est vérifié.

Contacts vérifiés avec des scènes de test analytiques : sol, franchissement d'un mur fin évité à grande vitesse, angle sol/mur, glissement, plan incliné, découpe du rayon du nuage, pause et secours de l'API. Ces tests exécutent le code de collision mais simulent les réponses des rayons ; ils ne prouvent pas la couverture des objets par le moteur de jeu.

Le rendu, la luminosité, les performances et la compatibilité avec les autres effets restent à tester dans BeamNG. Compilation et tests simulés ne certifient pas le résultat visuel. Vulkan n'est pas pris en charge par ce prototype. BeamMP n'a pas été validé et aucune synchronisation dédiée de la charge diesel n'est fournie.

La suie native des moteurs diesel est supprimée pendant les appels thermiques quand le rendu volumétrique répond. Un filtre temporaire intercepte uniquement les particules natives de suie 40 à 43 aux nœuds de cet échappement pendant sa mise à jour thermique. Les autres appels sont transmis à l'objet moteur, qui est restauré immédiatement, même en cas d'erreur. Les valeurs thermiques internes restent intactes. La vapeur et les fumées de panne restent natives. Si le rendu ne répond plus pendant 4,5 secondes de simulation, la suie native revient. Le remplacement vise les émissions via addParticleByNodesRelative de BeamNG 0.39 ; un moteur personnalisé utilisant une autre méthode peut conserver sa fumée native. Les collisions de ce mod concernent le panache volumétrique. Aucun fichier moteur natif n'est remplacé. Le vent est maintenant interrogé côté monde à la position des volumes, toutes les 0,1 seconde de simulation, via be:getWindAt. core_environment.getGroundWind sert de secours. Si aucune requête n’est utilisable, la dernière valeur disponible est conservée. Pas d’ombres de fumée ou d’éclairage dynamique.

La collision reste une approximation locale à vingt-six directions, pas une grille de fluide avec tous les solides. Des objets très fins ou petits entre les sondes, malgré les directions diagonales supplémentaires, une géométrie non détectée par les rayons, un départ à l'intérieur d'un solide ou un obstacle mobile entrant dans un nuage peuvent encore laisser passer de la fumée. Les plans peuvent couper trop de volume aux bords d'un objet. On ne peut donc pas garantir l'absence totale de traversée sur tous les objets ; les voitures déformables et les objets mobiles doivent particulièrement être vérifiés en jeu. Les sondes supplémentaires ont aussi un coût CPU à mesurer.

Budget : 192 nuages simulés, 32 rendus au total, distance maximale 120/200/250 m selon Performance/Équilibré/Qualité, 12 échantillons par traversée de volume ; émission à 10 Hz, volumes superposés sur trois secondes, remous continus et extinction progressive. Plusieurs véhicules ou sorties se partagent le budget, ce qui peut rendre le panache moins continu. Pas d'émission pendant une pause normale de simulation.

## Essai visuel conseillé

Comparer un diesel ancien ou sans filtration modélisée et un diesel propre. Observer le ralenti, puis une accélération en charge en roulant ; accélérer au point mort ne produit pas nécessairement une fumée forte. Vérifier l'arrêt du moteur, la caméra autour et à travers le panache, les murs devant la fumée, la pause et Ctrl+R. Comparer les FPS avec le mod activé puis désactivé. Tester d'abord sans autre mod de fumée.

Pour les contacts, placer l'échappement près du sol et face à un mur, puis près d'un angle et d'une pente. Observer également depuis l'autre côté du mur ou sous le terrain en caméra libre : la profondeur seule ne suffit pas à valider la collision. Faire ensuite passer un autre véhicule ou un objet mobile dans le panache et vérifier le résultat et les FPS.

En cas de rendu absent, consulter `beamng.log` et chercher `mr14karaDiesel`, `Mr14Diesel` ou `volume_13.hlsl`. Cette version est une base de développement à régler à partir de ces essais.


## Évolution 0.4.0 — mouvement du panache

Le gaz suit maintenant un champ de remous spatial continu : les centres des volumes dévient progressivement, tout en conservant le vent, l’inertie et les contacts avec le décor. La montée diminue avec l’âge. La croissance ralentit avec la dispersion au lieu de former une ouverture conique constante.

L’intérieur des volumes se déforme dans le shader et leurs bords deviennent transparents. La densité baisse avec la dilution et atteint zéro en douceur avant la suppression à trois secondes. L’émission passe à 10 Hz : pour une sortie, toute cette durée tient dans les 32 volumes rendus, ce qui évite la troncature de la fin du panache par ce budget. Plusieurs sorties ou véhicules peuvent encore dépasser ce budget. La densité des moteurs peu polluants suit désormais plus finement leur valeur particulates.

Validation 0.4.0 : tests hors jeu LuaJIT, dérive latérale, extinction progressive, comparaison 30/120 Hz, budget d’une sortie, collisions et compilation des shaders DirectX 11. Le résultat visuel et les performances de cette révision restent à confirmer en jeu. Il s’agit toujours d’une approximation volumétrique avec remous, pas d’une simulation complète des fluides.

Après remplacement du ZIP, redémarrer BeamNG pour charger les nouvelles extensions et le nouveau shader. Tester d’abord un D35 diesel, ralenti puis accélération en charge ; relâcher ensuite l’accélérateur et observer le panache restant se déformer et se dissiper.


## Évolution 0.4.1 — continuité à vitesse élevée

Les échantillons successifs d’une même sortie d’échappement sont reliés après leur déplacement et leurs collisions. Le shader traverse ces segments volumétriques, avec un rayon et une densité interpolés entre les extrémités. Le bruit de densité partage le même champ spatial et la même horloge sur toute la traînée. Cette construction remplace les sphères isolées qui se séparaient à vitesse élevée ; le nombre maximal de volumes rendus reste de 32.

Une liaison est refusée lorsqu’un rayon entre les deux centres rencontre un obstacle, lorsque l’émission présente un intervalle de plus de 0,22 seconde, ou lorsque l’écart dépasse la limite calculée avec la vitesse. Deux sorties d’échappement et deux véhicules ne sont jamais reliés ensemble. Les plans de contact des deux extrémités sont regroupés pour la découpe du segment. Les collisions demeurent une approximation locale : un petit objet hors des sondes et du rayon central peut encore être manqué.

Les tests hors jeu reproduisent les espaces entre les anciennes sphères puis vérifient la continuité des segments à 0, 60, 120 et 200 km/h, avec des mises à jour à 30 et 120 Hz. Ils vérifient aussi les raccords de densité et de rayon, les murs, les sorties distinctes, les interruptions d’émission et les téléportations. Les shaders DirectX 11 compilent avec les en-têtes du jeu installé. Ces essais simulés ne remplacent pas une validation visuelle en roulant dans BeamNG.

Pour tester cette révision, redémarrer BeamNG et accélérer progressivement avec le D35 diesel. Observer le panache à 60, 120 puis 200 km/h si le véhicule et la route le permettent, puis relâcher l’accélérateur. Le panache doit rester relié pendant l’émission et se dissiper après la coupure. Vérifier aussi un virage, un mur proche et les performances ; le calcul du shader a été modifié même si le budget de volumes est inchangé.


## Évolution 0.4.2 — dispersion dans le sillage

Référence visuelle fournie : https://www.youtube.com/shorts/eBDw21gW0CQ (IBIZA 18/56 1.9 TDI NO SMOKE NO FUN). La référence sert à orienter le comportement du panache, sans prétendre reproduire ses émissions quantitativement.

La vitesse initiale du gaz augmente maintenant la diffusion latérale et les remous du modèle. La fumée s’élargit avec son âge et sa densité baisse avec cette expansion. Le shader décale progressivement le centre de la section selon un champ de remous continu ; les bords irréguliers restent dans l’enveloppe utilisée pour les contacts. Les segments restent reliés, mais leur section et leur position visuelle évoluent le long de la traînée.

Vérification hors jeu : continuité à 0/60/120/200 km/h, stabilité 30/120 Hz, diffusion plus large et densité plus faible dans le sillage d’un véhicule à 120 km/h, collisions, extinction et compilation shader. Le rendu et le coût en jeu restent à confirmer. Le modèle n’inclut pas l’aérodynamique réelle de chaque carrosserie : cette diffusion constitue une approximation du sillage.


## Évolution 0.4.3 — forte suie avec ECU Tuner

Les fortes demandes de suie sont plus opaques et se diluent plus lentement pendant l’élargissement du sillage. La courbe reste inchangée pour une intensité d’émission inférieure ou égale à 0,45. Au-delà, la densité optique initiale augmente progressivement jusqu’à un facteur 3,5 ; l’atténuation liée à l’expansion et à l’âge est également réduite. La fumée finit toujours par atteindre zéro à trois secondes.

Le calculateur ECU Mr14KaraFR transmet déjà sa demande de suie au modèle, puis applique un gain de densité suivant l’enrichissement effectif et l’estimation d’oxygène disponible. Cette révision conserve cette intégration et renforce la tenue des fortes demandes de suie, sans ajouter de réglage manuel. Les plafonds de couple et de richesse peuvent limiter le carburant effectivement injecté : augmenter une table d’injection ne garantit pas à lui seul une grosse fumée si ces plafonds interviennent ou si l’air disponible suffit.

Tests hors jeu : vrai contrôleur ECU avec cartographies propre/enrichie et effet du turbo, adaptateur de densité, maintien d’un panache fortement chargé après une seconde à 120 km/h, extinction complète et préservation de la courbe légère. Aucun essai visuel de cette révision dans BeamNG ; redémarrer le jeu avant de comparer en charge.


## Évolution 0.5.0 — vent courant et sillage orienté

La fumée déjà émise réagit maintenant au champ de vent courant à sa position : les rafales et changements de direction peuvent dévier le panache existant. La requête be:getWindAt est celle utilisée par util/windDebug dans l’installation locale de BeamNG ; getGroundWind fournit le vent au sol en secours. Les requêtes sont limitées à 10 Hz par volume et suspendues en pause.

Le sillage utilise la vitesse initiale des gaz relativement au vent actuel. À vitesse routière, les remous latéraux sont orientés perpendiculairement à ce mouvement relatif. L’entraînement initial du gaz par le déplacement est transitoire ; la vitesse du gaz rejoint progressivement celle de l’air. L’expansion dépend elle aussi de cette vitesse relative. Le modèle conserve la vitesse d’émission, plutôt que d’attacher la fumée à la position actuelle de la voiture.

Le shader continue d’intégrer une densité 3D le long de chaque rayon caméra. Une variation de gris à l’intérieur des volumes ajoute un indice de relief selon la densité et la hauteur locale. Il s’agit d’une approximation de lumière ambiante, pas d’un calcul des éclairages ou des ombres de la scène. Aucun calcul aérodynamique de carrosserie, d’obstruction du vent ou de sillage d’un autre véhicule n’est fourni.

Tests hors jeu : déplacement sous vent latéral de 6 m/s, inversion de vent affectant un nuage existant, fréquence bornée, pause, secours au vent au sol, données invalides, continuité jusqu’à 200 km/h, collisions, densité ECU et compilation des shaders. Le rendu visuel et la réponse aux réglages de vent dans le jeu restent à confirmer après redémarrage.


## Évolution 0.5.1 — masses irrégulières, référence photographique

La photo fournie représente une nappe opaque et large derrière le véhicule, avec des masses qui se mélangent et des contours irréguliers. Les sinusoïdes de déformation du centre du volume ont été retirées du shader. Un bruit spatial à trois échelles forme désormais l’intérieur et les contours ; une couche plus diffuse accompagne le cœur dense. Les déplacements des centres utilisent un champ interpolé de bruit au lieu d’oscillations régulières.

Les fortes demandes de suie élargissent davantage les volumes. Leur croissance varie doucement dans l’espace, tout en restant progressive : un volume ne rétrécit pas en traversant ce champ. La densité optique renforcée compense en partie cet élargissement ; les émissions légères conservent leur courbe précédente. La continuité des segments, le vent courant, la découpe des surfaces et l’extinction à trois secondes restent actifs.

Tests hors jeu réussis : continuité jusqu’à 200 km/h et stabilité 30/120 Hz, vent, collisions analytiques, intégration ECU propre/enrichie/turbo, densité et extinction. Compilation Shader Model 5 réussie. Le budget reste de 32 volumes rendus, mais des volumes plus larges et un bruit supplémentaire peuvent augmenter le coût GPU ; performances et résultat visuel à vérifier dans BeamNG.

Un aperçu CPU du modèle Lua et de la densité du shader est généré par tools/render_diesel_offline.py dans le projet de développement. C’est une scène de test avec caméra orthographique, vent et gain ECU imposés ; elle ne reproduit ni le rendu HDR de BeamNG, ni l’exposition, ni une carrosserie ou la perspective de la photo.


## Évolution 0.5.2 — émission sur place

Le jet initial passe à 1,6 + 0,0008 × RPM m/s, limité dans ce calcul à 6 000 RPM. Cette vitesse s’ajoute à la vitesse du nœud d’échappement, puis le modèle ralentit progressivement les gaz vers la vitesse de l’air. Ce réglage est une approximation visuelle et ne découle pas d’une mesure du débit de cet échappement.

L’expansion supplémentaire liée aux fortes demandes de suie dépend désormais du sillage : elle est réduite à l’arrêt pour éviter un amas sphérique surdimensionné près du pot, tout en restant plus large lorsque le véhicule se déplace. Le champ de remous utilise maintenant une horloge commune de simulation à partir de l’heure d’émission et de l’âge. Des émissions successives ne répètent donc plus toutes le même trajet en fonction de leur seul âge.

Tests hors jeu : éloignement du pot avant expansion, comparaison 30/120 Hz sur place, trajet variable avec l’heure d’émission, pause, continuité en roulant, vent et densité ECU. Aperçu CPU avec émission riche imposée, jet de 4 m/s et vent latéral de 1 m/s. Il ne représente pas un ralenti moteur d’origine et ne remplace pas une capture de BeamNG ; l’aspect et la naturalité du panache restent à vérifier en jeu.


## Évolution 0.5.3 — panache riche plus bas

Pour les fortes demandes de suie, la remontée ajoutée par le modèle diminue progressivement jusqu’à 80 %, et la composante verticale des remous jusqu’à 70 %. Les émissions légères conservent leur comportement précédent. Le vent vertical et l’orientation réelle de sortie du pot continuent de contribuer au mouvement ; un échappement dirigé vers le haut peut donc toujours envoyer les gaz vers le haut.

Ce réglage vise un panache bas dans le sillage comme sur la photo de référence. Il ne simule pas la masse ni la sédimentation des particules de suie. La collision avec le sol reste active. Validation hors jeu ; trajectoire et hauteur à confirmer dans BeamNG.


## Évolution 0.6.0 — contours et masses de densité

La densité dans le shader est maintenant érodée par un champ de bruit tridimensionnel dont le seuil augmente vers les bords du volume. Cela crée des portions sans densité et des contours plus découpés, au lieu de remplir une enveloppe presque sphérique. Le cœur reste dense ; les filaments visibles dépendent du champ spatial. Les valeurs s’annulent toujours à l’extérieur de l’enveloppe interrogée pour les contacts.

Les remous évoluent plus rapidement avec l’horloge commune. Pour la forte suie, leur amplitude latérale augmente ; la réduction de montée de la version 0.5.3 reste active. Le budget et le nombre de volumes restent identiques. Vent et mouvement du véhicule continuent de contribuer à la trajectoire.

Tests hors jeu : compilation des shaders, émission sur place, stabilité des trajectoires, continuité jusqu’à 200 km/h, vent, collisions et intégration ECU. L’aperçu CPU montre des bords plus irréguliers, mais le scénario très opaque à l’arrêt reste compact. Cette révision ne certifie pas un résultat photoréaliste ; naturalité et performances à vérifier dans BeamNG.


## Évolution 0.6.1 — accélérateur, anciens nuages et budgets

La réponse à une hausse de pédale est rapide (constante de 0,07 seconde) et inclut une brève hausse optique pouvant atteindre 45 % selon la demande de suie. Au relâchement, l’émission baisse plus rapidement (constante de 0,035 seconde). Moteur coupé, l’émission s’arrête. Les volumes déjà émis continuent à vivre et à se dissiper, avec leur gain ECU conservé au premier pas de simulation.

L’ECU 0.15.14 utilise cette réponse avec sa demande de suie calculée à partir du carburant effectif, des limites et de l’estimation d’air ; les voitures distantes utilisent les valeurs de pédale et de suie reçues. Aucun déplacement de table enregistrée ni multiplication de carburant supplémentaire.

Les émissions à plus de 70 m de la caméra ne créent plus de volumes. Les volumes sortant entièrement de cette portée sont retirés du calcul. Un résultat sans contact de la requête détaillée ne déclenche plus une requête statique de secours superflue. Les 26 directions de contact et le secours en cas d’API défaillante restent utilisés.

Tests : relâchement et courte bouffée, pause, gain à l’émission, demande propre/enrichie/turbo de l’ECU, volume de rayon 4 m près du sol/mur, budgets avec 1/4/8 véhicules à deux sorties. Le rapport de benchmark dans outputs mesure le code Lua avec un sol analytique et des fonctions natives simulées. Il ne mesure ni les FPS, ni le coût GPU, ni les rayons du moteur ; la couverture des objets réels reste à vérifier en jeu.


## Évolution 0.6.2 — allègement du rendu

Le shader teste l’enveloppe du volume avant de calculer le bruit 3D. Après le premier niveau de bruit, une borne mathématique sur les niveaux restants évite leur calcul lorsqu’ils ne peuvent produire aucune densité. Le rendu utilise désormais 12 échantillons par traversée, au lieu de 16. Lorsque la profondeur optique atteint 5,5, les calculs supplémentaires de ce pixel s’arrêtent : l’opacité restante pourrait changer de moins de 0,41 point de pourcentage. La variation de gris interne demeure une approximation et peut varier légèrement avec cet arrêt.

Les constantes inchangées du shader ne sont plus renvoyées au moteur à chaque image. Les six plans de contact, souvent identiques d’une image à l’autre, bénéficient particulièrement de ce cache. La version utilise de nouveaux noms de shader et d’effet pour éviter de réutiliser l’ancien shader chargé. Les 26 sondes de contact, le vent, les budgets de volumes, la densité et l’adaptateur ECU sont conservés.

Comparaison hors jeu du même scénario sur 6 secondes : pour 1, 4 et 8 véhicules à deux sorties, les appels de mise à jour des constantes diminuent d’environ 63 %. Les rayons et le vent sont simulés dans ce benchmark ; le temps mesuré ne reflète pas leur coût natif ni le GPU. Les FPS restent à comparer dans BeamNG, près de la fumée puis sans fumée, après redémarrage. La réduction de l’échantillonnage peut changer légèrement les détails fins : vérifier aussi la stabilité visuelle.


## Version 0.7.0 — profils et diagnostic

Après redémarrage de BeamNG, ajouter l’application « Fumée diesel By Mr14KaraFR » dans les applications UI. Elle propose trois modes :

- Performance : 8 échantillons et deux niveaux de bruit ; détails simplifiés pour réduire le travail GPU.
- Équilibré (par défaut) : 12 échantillons et trois niveaux de bruit.
- Qualité : 16 échantillons et trois niveaux de bruit ; coût plus élevé.

Les trois modes gardent les mêmes volumes, contacts, vent et réponse ECU. Changer de mode ne supprime pas le panache existant. Le choix est enregistré dans /settings/mr14karaDieselSmoke.json du dossier utilisateur par le moteur du jeu. Les sorties de densité peuvent varier légèrement avec le bruit simplifié et l’échantillonnage.

Le panneau contient un diagnostic activable : volumes simulés/affichés et temps moyen du code Lua de mise à jour. Il ne mesure pas le GPU et ne donne pas des FPS. Le chronométrage est désactivé par défaut ; fermer l’application le désactive et arrête son interrogation à 1 Hz.

La sélection des volumes favorise légèrement ceux déjà affichés et utilise un ordre déterministe en cas d’égalité pour limiter le remplacement rapide des volumes proches du seuil quand plusieurs diesels fument. Le budget de 32 volumes peut néanmoins tronquer certains panaches dans une scène chargée.

Tests hors jeu : modes et constantes shader, conservation des positions au changement de mode, mémorisation avec fonctions de fichier simulées, chronométrage opt-in, commandes du panneau, retour de statut et nettoyage du timer. Tests de fumée/ECU et compilation Shader Model 5 réussis. Chargement et rendu de l’application dans BeamNG et gain de FPS de chaque mode restent à confirmer.

Pour le prochain essai, commencer par Performance et diagnostic désactivé. Comparer ensuite Équilibré dans la même scène avec la même charge moteur ; activer le diagnostic seulement pour relever le nombre de volumes et le temps Lua.


## Évolution 0.7.1 — partage entre diesels et faible FPS

Les 32 places d’affichage sont distribuées par tours entre les véhicules visibles, puis selon l’importance des volumes à l’intérieur de chaque véhicule. Avec quatre panaches suffisamment fournis, chacun dispose de huit volumes : un diesel très dense ne prend plus toutes les places au détriment de trois panaches faibles. Si un véhicule a moins de volumes, les places restantes passent aux autres. Au-delà de 32 véhicules candidats, seuls les groupes les mieux classés peuvent être représentés. Cela ne garantit pas une traînée complète pour tous : le budget reste partagé.

Quand la simulation atteint 192 volumes, une nouvelle émission retire le plus ancien volume du véhicule le plus représenté. Le diagnostic expose renderedByVehicle pour vérifier le partage. Les profils de qualité conservent leurs budgets et réglages GPU.

Une image de simulation allant jusqu’à 0,3 seconde est maintenant intégrée par pas de 0,05 seconde au maximum. L’émetteur peut reconstituer jusqu’à trois émissions manquées à 10 Hz, datées et replacées avec la vitesse actuelle du nœud du pot. Les gaz rattrapés sont déplacés avec le modèle et les collisions avant d’être reliés au reste du panache. Les pauses normales n’ajoutent pas de fumée. Un blocage plus long perd le surplus de temps pour borner le travail et éviter un rattrapage illimité.

Les positions passées sont estimées avec la vitesse courante : un changement très rapide de direction ou une téléportation ne peut pas être reconstruit exactement. Les garde-fous de liaison restent actifs pour les grands écarts et les obstacles.

Tests hors jeu : partage avec un diesel dense et trois faibles, retrait d’un véhicule, éviction des volumes, émission à 10 Hz à 5/10/15/30/60 FPS, test couplé des vrais modules VE/GE à 200 km/h avec deux sorties, pauses, limites de portée, ECU et compilation shader. Les fonctions du moteur et l’environnement sont simulés : le résultat visuel et les FPS réels restent à vérifier dans BeamNG.


## Évolution 0.7.2 — réinitialisations et données retardées

Chaque connexion d’un émetteur au rendu reçoit une session. Après réinitialisation, destruction ou fin de mission, une émission ou un ordre de nettoyage portant une ancienne session est ignoré. Le nettoyage direct du véhicule réinitialisé retire uniquement ses volumes et invalide sa connexion. L’adaptateur de gain ECU chargé est également invité à oublier le gain de cet ancien véhicule. Les autres diesels conservent leurs données.

Le filtre de suie vérifie son rattachement au module thermique courant. Si celui-ci est remplacé ou si sa fonction de mise à jour change, l’ancien filtre est détaché sans écraser une fonction installée par un autre module, puis le filtre est rattaché à la nouvelle fonction. Un module initialement non compatible peut être réessayé lorsqu’une fonction thermique apparaît.

Tests hors jeu : sessions périmées, commandes de nettoyage retardées, réutilisation d’un ID, Ctrl+R simulé, destruction, fin de mission, nouveau module thermique et restauration après déchargement, sorties verticales et latérales, deux sorties et essence ignorée. Vérification que le modèle de mouvement et le shader sont identiques à la 0.7.1. La fiche ESSAI_FR.md décrit les vérifications en jeu ; compatibilité de tous les véhicules moddés non certifiée.


## Version 0.8.0 — éclairage et bords diffus

Le shader reçoit explicitement la direction du soleil reconstruite à partir des champs azimuth/elevation du ScatterSky. La couleur solaire est dérivée du champ atmoSunIrradiance quand il est exploitable, sinon une lumière neutre est utilisée. L’intensité est estimée avec l’élévation du soleil, pas avec la radiance atmosphérique réellement calculée. Ces paramètres sont lus au maximum deux fois par seconde, y compris lorsque la physique est en pause. Sans ciel exploitable, l’éclairage ajouté est coupé.

L’éclairage intérieur combine une contribution ambiante, l’orientation locale vers le soleil et une atténuation locale selon la densité et le rayon. Cela donne un indice de relief aux masses. Ce calcul ne simule pas les ombres du volume ou du décor, les phares, les éclairages locaux ni la teinte exacte du ciel. Il ne remplace pas un solveur de diffusion lumineuse. La nuit, la contribution solaire ajoutée est nulle.

Une frange de densité plus faible mélange les bords érodés avec l’air. Le cœur conserve sa forte densité ; toutes les contributions restent dans l’enveloppe testée et sont découpées par les contacts. Aucun échantillon supplémentaire de bruit ou rayon de lumière n’est ajouté. Les profils 8/12/16 échantillons sont conservés ; certaines zones de frange qui étaient auparavant ignorées demandent néanmoins un calcul supplémentaire.

Tests hors jeu : source du ciel, couleur, rotation du soleil, passage jour/nuit, paramètres invalides, fréquence bornée, smoke/ECU/sessions/collisions et compilation des shaders. Aperçu CPU avec soleil imposé. Éclairage réel, orientation, aspect des bords et FPS à confirmer dans BeamNG.

## Version 0.8.1 — bouffée liée au turbo

La bouffée de remise des gaz utilise la pression turbo mesurée (PSI), quand elle est disponible : plus forte et plus longue avant la montée en pression, plus courte avec un turbo déjà chargé. Une montée progressive de pédale accumule aussi cette bouffée. Le relâchement coupe la réserve transitoire ; la fumée déjà émise continue de se diffuser. Le calcul ECU de suie selon injection effective et air reste inchangé, comme la densité à régime stabilisé, le shader et le budget de particules. Sans mesure turbo valide, la réponse générique reste disponible. Il s’agit d’une approximation visuelle, pas d’une simulation de combustion. Vérifié hors jeu ; aspect et FPS restent à confirmer dans BeamNG.

## Version 0.9.0 — réduction du coût et contrôle de qualité

Le raymarching pleine résolution est remplacé par un tampon transparent réduit, suivi d’une reconstruction à quatre échantillons pondérés par la profondeur de la scène. Cela limite les débordements sur les silhouettes ; ce n’est pas une garantie de contact géométrique exact.

| Mode | Résolution par axe | Pixels du tampon par rapport à l’écran | Échantillons par volume | Intervalle des sondes de surface |
|---|---|---|---|---|
| Performance | 40 % | 16 % | 6, bruit à deux octaves | 0,24 s |
| Équilibré (défaut) | 50 % | 25 % | 8, bruit à trois octaves | 0,16 s |
| Qualité | 75 % | 56,25 % | 12, bruit à trois octaves | 0,08 s |

La reconstruction ajoute une passe légère pleine résolution : ces pourcentages concernent seulement le tampon volumétrique, pas la consommation GPU totale. Le changement de mode modifie immédiatement la taille du tampon et les constantes. L’interface utilise un objet de réglages afin d’éviter les valeurs masquées dans les sous-scopes Angular, et affiche le mode confirmé par le moteur ainsi que ses paramètres. Le réglage est sauvegardé.

Les contacts répétés avec un même plan (route, mur) ne forcent plus les 26 sondes à chaque image. Le déplacement du centre reste testé à chaque pas ; un contact avec un nouveau plan déclenche une nouvelle sonde immédiatement. Les sondes espacées peuvent détecter plus tard un petit obstacle proche du bord du panache, particulièrement en Performance.

Les extrémités de segments sont arrondies et diffusées au lieu d’être coupées au bout d’un cylindre. La densité ECU, l’éclairage et les budgets 192 volumes simulés / 32 affichés sont conservés ; les volumes ne sont pas supprimés pour atteindre le mode Performance.

Mesure hors jeu sur une scène synthétique avec sol et deux sorties par véhicule : le nombre d’appels de rayons diminue d’environ 35–36 % en Équilibré, et de 47–49 % en Performance, sur 1/4/8 véhicules. Les appels natifs sont simulés : ce résultat n’est pas une mesure de FPS, ni une promesse de gain GPU. Les deux shaders compilent avec les en-têtes du jeu. L’intégration graphique réelle et le rendu restent à vérifier dans BeamNG après redémarrage.

## Version 0.9.1 — boutons directs et composition moins coûteuse

La liste déroulante est remplacée par trois boutons qui transmettent explicitement le mode choisi. Le bouton vert correspond au mode confirmé par le moteur. La racine utilise la classe native bngApp et active les interactions de pointeur. Les calculs de profondeur de la reconstruction sont ignorés lorsque les quatre pixels voisins du tampon de fumée sont transparents. Les profils et le rendu de la fumée restent identiques à la 0.9.0. Les shaders et la transmission des trois modes sont vérifiés hors jeu ; clics dans le jeu et FPS restent à confirmer.

## Version 0.9.2 — raccord à l’échappement en mouvement

Le segment le plus récent de chaque sortie est raccordé à sa position actuelle via les coordonnées du nœud d’échappement dans la simulation GE. Il est prioritaire dans le budget de rendu, afin que son faible rayon ne le fasse pas disparaître derrière les volumes anciens et plus larges. Aucun volume ni événement d’émission supplémentaire n’est créé. Le raccord ferme après 0,16 s sans nouvelle émission ; les gaz déjà émis continuent de se diffuser. Un rayon empêche de raccorder à travers un solide, et une limite de distance rejette les téléportations. Si l’API de position de nœud est indisponible, l’ancienne traînée est conservée. Les cas hors jeu avec deux sorties passent à 0/60/120/200 km/h et 30/60/120 FPS. Les très faibles fréquences peuvent encore interrompre le raccord entre deux émissions.

Performance utilise maintenant 35 % par axe (12,25 % des pixels de l’écran dans le tampon volumétrique) et 4 échantillons. Équilibré reste à 50 % / 8, Qualité à 75 % / 12. Par rapport à Performance 0.9.1, cela réduit la taille du tampon d’environ 23 % et le nombre maximal d’échantillons par volume de 33 %. Ce sont des budgets de calcul, pas des gains de FPS mesurés. Le mode Performance peut perdre des détails ou montrer davantage de variations d’échantillonnage. Les budgets de simulation et de rendu restent 192 / 32. Aucun essai en jeu n’a été lancé pour cette correction.

## Version 0.9.3 — contours irréguliers et chevauchements moins opaques

Correction ciblée sur la capture utilisateur de la Vivace : la fumée formait une bande noire aux limites trop lisses. L’enveloppe de densité est maintenant érodée par le bruit 3D grossier déjà calculé, avant le bruit de détail. Les limites des capsules servent au rejet rapide des rayons, mais ne dessinent plus une enveloppe pleine aussi régulière. Les seuils des masses et le support des filaments sont ajustés pour conserver des zones opaques avec des bords plus transparents.

Un facteur géométrique réduit l’addition d’opacité entre les capsules courtes qui se recouvrent (rapport longueur / longueur + deux rayons, minimum 0,12). C’est une approximation de compensation du chevauchement, pas une reconstruction exacte de la densité fluide. Cela peut rendre certaines configurations moins denses ; l’injection effective et le gain ECU sont conservés. Aucun volume, rayon de collision, octave de bruit ou échantillon volumétrique n’est ajouté. Les budgets et profils 0.9.2 restent identiques. Les calculs scalaires du shader changent ; aucune mesure de FPS en jeu n’a été faite.

Les tests Lua de contacts, raccord à l’échappement et basse fréquence passent, et les deux shaders compilent avec les en-têtes du jeu. Un aperçu CPU confirme la présence de zones opaques et de contours diffus, mais ne reproduit pas l’éclairage HDR, la géométrie du véhicule ni le tampon réduit de BeamNG. La capture en jeu après redémarrage reste la validation visuelle nécessaire.

## Version 0.9.4 — retrait des modifications visuelles 0.9.3

Après le retour utilisateur signalant des coupures, les seuils de bruit, le support et les filaments de la 0.9.2 sont rétablis. Le rétrécissement de l’enveloppe et la compensation d’opacité 0.9.3 sont retirés. Une faible contribution centrale (0,015, décroissante jusqu’à rayon au carré 0,35) empêche le bruit seul de rendre entièrement transparent le cœur d’un segment fourni au shader. Le rejet anticipé du bruit respecte cette contribution centrale ; les contacts et la profondeur continuent de masquer les solides. Cela ne comble pas un segment manquant dans le budget de rendu et ne remplace pas une validation en jeu. Les réglages de qualité, le raccord à la sortie et les optimisations sont conservés. Tests Lua et compilation DX11 passent, sans ouverture du jeu. Cette version corrige une régression visuelle ; elle ne prétend pas résoudre le réalisme du panache.

## Version 0.9.5 — Qualité en pleine résolution

Qualité utilise maintenant 100 % par axe, soit la résolution complète du rendu principal, avec 12 échantillons. Performance reste à 35 % / 4 et Équilibré à 50 % / 8. Les shaders et la forme du panache ne changent pas. Cette correction rend le mode Qualité conforme à son attente de pleine résolution, mais ne corrige pas le tube noir visible sur la capture utilisateur. Le tampon contient environ 78 % de pixels de plus que Qualité 75 % : le coût GPU peut augmenter. Aucun gain de réalisme ni FPS n’est revendiqué.

## Version 0.9.6 — sillage proche et montée progressive

La vitesse du véhicule est transmise séparément de celle du jet d’échappement. Une zone de sillage limitée aux premières 1,2 secondes et à quelques mètres derrière la sortie entraîne partiellement la fumée avec la voiture. Les remous latéraux et verticaux sont renforcés localement. Une libération lissée termine cet entraînement, puis le gaz continue de se diffuser et monte progressivement. L’effet ne s’active pas sous 3 m/s de vitesse véhicule. Il ne crée pas une aspiration permanente pour un jet à l’arrêt.

La position actuelle de la sortie est mise en cache une fois par sortie et par mise à jour GE pour les gaz jeunes ; les messages anciens sans vitesse véhicule conservent leur comportement précédent. En l’absence d’API de position, la position de la voiture est approximée par sa vitesse à l’émission. La direction du sillage utilise aussi cette vitesse d’émission : les fortes rotations ne sont pas modélisées exactement. Ce champ ne connaît pas la carrosserie complète et n’est pas une simulation CFD ; les collisions existantes restent chargées d’éviter les solides.

Les shaders, budgets et modes de qualité ne changent pas : Qualité reste à 100 % / 12. Aucun volume supplémentaire n’est créé, mais le champ et les lectures de nœuds ajoutent du calcul CPU et la forme nouvelle peut modifier le coût GPU. Tests hors jeu : rétention locale, hauteur progressive, absence de sillage à l’arrêt et loin de la voiture, pause, libération, cohérence 30/120 Hz, contacts et raccord 0/60/120/200 km/h. Le rendu et les FPS en jeu restent à confirmer ; la qualité des images réelles de référence n’est pas garantie.

## Version 0.9.7 — raccord au rendu, sillage relevé et détails de fumée jeune

Le raccord des volumes déjà sélectionnés est actualisé dans le callback de rendu, afin de prendre en compte le mouvement intervenu après la mise à jour GE. Le rejet de téléportation et le rayon de contact restent actifs ; ils peuvent encore interrompre un raccord lorsque le trajet touche la carrosserie. Une validité de source de 0,25 s après réception de l’émission couvre les retards brefs de VM. Cela peut prolonger brièvement le raccord au relâchement ; la fumée déjà émise reste libre.

La montée et l’entraînement du sillage local sont renforcés. L’effet reste borné dans l’espace et le temps, et absent à l’arrêt. Les octaves de bruit intermédiaire et fin utilisent des longueurs plus petites, partagées en coordonnées monde entre les segments, pour donner des variations au jet étroit près du pot. Le cœur de continuité et les seuils de la 0.9.4 restent actifs.

Qualité reste à 100 % avec 12 échantillons sur les volumes anciens et 24 sur les volumes de moins de 0,3 s. L’application affiche cette plage. Performance et Équilibré conservent respectivement 4 et 8 échantillons. Aucun volume supplémentaire n’est créé, mais les volumes jeunes en Qualité et l’actualisation du raccord ajoutent du calcul ; le coût peut augmenter en gros plan. La densité ECU et la découpe des solides restent inchangées. Tests hors jeu : mouvement entre sélection et dessin, validité d’émission, téléportation, sillage, raccord 0–200 km/h et compilation DX11. La disparition des artefacts en jeu n’est pas confirmée.

## Version 0.9.8 — portée de rendu étendue

La limite de caméra passe de 70 m à 120 m en Performance, 200 m en Équilibré et 250 m en Qualité. Elle est appliquée à l’émission, la simulation et la sélection de rendu, et change avec le profil actif. La portée confirmée apparaît dans l’application. Le budget reste 192 volumes simulés / 32 affichés et la durée de vie reste 3 s. Avec plusieurs voitures visibles, le partage du budget peut réduire la continuité ; une plus grande zone visible peut augmenter le coût. Les tests hors jeu vérifient l’admission juste sous chaque limite, le rejet au-delà et la suppression après réduction de portée.

Cette modification ne transmet pas les volumes au réseau. Le rendu est calculé dans chaque client qui charge le mod ; les autres joueurs doivent disposer du mod. L’adaptateur ECU existant exploite les commandes distantes reçues, mais la visibilité complète et la concordance sur deux clients BeamMP ne sont pas validées par cette correction. Un essai multijoueur reste nécessaire.

## Version 0.9.9 — calcul du bruit et précision selon la distance

Le bruit volumétrique conserve son interpolation 3D et ses octaves, mais ses valeurs aux sommets sont calculées par un hachage entier au lieu du sinus. Cela retire les opérations trigonométriques du bruit du shader ; les motifs changent et le gain GPU dépend du matériel. La géométrie des volumes est lue avant les six plans de collision : les plans ne sont demandés que pour les rayons ayant une intersection visible avec le volume. L’intégration s’arrête à une profondeur optique de 4,6, où environ 1 % de transparence subsiste.

En Qualité, les 24 échantillons des gaz de moins de 0,3 s sont limités à moins de 20 m de la caméra. Au-delà de 40 m, au plus 8 échantillons sont utilisés ; au-delà de 80 m, au plus 6. Performance reste à 4, Équilibré à 8 près de la caméra. Qualité reste à 100 % de résolution, et les portées restent 120/200/250 m.

La simulation des volumes situés au-delà de 60 m est regroupée à 20 Hz. Le temps accumulé est conservé, y compris en pause ; les mouvements sont toujours testés contre les solides à chaque pas simulé. La durée de vie peut se terminer jusqu’à 0,05 s plus tard. Le budget reste 192 volumes simulés / 32 rendus. Dans un banc hors jeu avec sol analytique, deux sorties par voiture et 1/4/8 voitures à environ 100 m : les appels de rayons sur 6 s diminuent de 18–21 % et les écritures de constantes d’environ 52–62 %. Le banc simule les appels natifs : il ne mesure ni FPS, ni coût GPU ou rayons réels. Les shaders compilent avec les en-têtes du jeu ; les tests de pause, temps accumulé, expiration, portée, sillage et raccord passent. Rendu, collisions en scène et gain de FPS restent à vérifier dans BeamNG.

## Version 0.9.10 — arrêt du rendu volumétrique pour les demandes quasi invisibles

La densité minimale native de ralenti pouvait créer des volumes chaque dixième de seconde et maintenir le PostEffect actif même lorsque la fumée semblait absente. Le module véhicule n’émet maintenant en volumétrique qu’à partir d’une demande de densité de 0,008. Au-dessous, la très faible fumée native est conservée et le proxy de filtrage n’est pas activé. Les vapeurs et fumées de dommages restent natives. Ce compromis supprime la fumée volumétrique pour les très petites demandes ; il ne conserve pas un effet volumétrique permanent au ralenti.

Le proxy de filtrage réutilise maintenant son objet Lua et ses fonctions de transfert au lieu de les recréer à chaque appel thermique. La liste de sorties est rafraîchie et le changement d’objet moteur invalide le cache. Les tests vérifient vapeur/dommages, remplacement d’objet, erreur et restauration, ralenti sans émission ni filtrage, et reprise en charge.

Quand les volumes ont disparu, la mise à jour du renderer retourne avant l’échantillonnage du ciel, la lecture de caméra, le tri et les collisions. Le PostEffect est activé/désactivé uniquement à un changement d’état. Le panache existant continue de s’éteindre avant le repos complet. Le ciel est rééchantillonné au redémarrage de l’émission. Le diagnostic affiche rendu actif/inactif. Le comportement à vide a été testé pendant 180 mises à jour, sans accès par image à la caméra/au monde. Cela ne mesure pas les FPS réels et ne prouve pas que tout écart moteur allumé/éteint vient du mod ; le moteur et l’ECU ont aussi leurs propres calculs.


## Version 0.9.11 — collisions vérifiées dans le jeu

Le diagnostic en jeu a montré un coût CPU élevé des requêtes détaillées `castRay`. Chaque trajet utilise désormais d’abord `castRayStatic` : un trajet libre n’appelle plus l’API détaillée. Pour un contact, jusqu’à 64 plans récemment mesurés sont réutilisés uniquement si la distance du nouveau premier contact correspond à leur intersection à moins de 3 mm. Une surface différente déclenche une nouvelle recherche détaillée de normale. Les requêtes de distance restent actives à chaque trajet ; il ne s’agit pas de désactiver les collisions. Les plans sont une approximation locale des surfaces, particulièrement sur les bords et les surfaces courbes. Les objets sans géométrie de collision ne sont pas couverts par ce filtre.

Dans West Coast USA avec une Vivace immobile, Direct3D 12 et le profil Qualité à 100 %, un panache de test émis par le renderer au vrai pot à 10 Hz a été comparé à caméra fixe : environ 18 FPS avec l’ancienne collision, 72 FPS avec la correction. Il s’agit d’un test contrôlé d’une voiture, pas d’une garantie en roulant ou en multijoueur. Les paramètres visuels, la densité, la résolution et les portées n’ont pas été réduits. Les résultats bruts sont enregistrés dans `outputs/diesel-live-fps-0.9.10.json` du projet. Les tests LuaJIT vérifient le rejet des trajets libres, la réutilisation de normales, la détection d’une nouvelle surface et les API manquantes, en plus des tests existants de sol/mur/sillage.


## 0.9.14 — transmission groupée des volumes

Les positions, extrémités, densités et plans de collision passent maintenant par quatre tableaux float4. Cela remplace les centaines de constantes individuelles et les sélections par switch dans le shader. Les emplacements inutilisés sont effacés pour éviter une réapparition de gaz après une baisse du nombre de volumes. Le calcul de densité, les échantillons, la résolution des trois profils, la portée et la simulation restent identiques à la 0.9.11.

Essai réel : Vivace diesel, injection temporaire à 500 %, 28 volumes du panache réel conservés en pause, Smallgrid, Direct3D 12, qualité 100 %. Deux comparaisons avec effets indépendants : 221,55 -> 224,01 FPS puis 219,91 -> 224,48 FPS. Le gain mesuré est modeste et ne signifie pas que la perte de 20 FPS signalée est supprimée sur les autres cartes. Les anciennes variantes sans chargement vérifié sont exclues des conclusions. Détails et limites dans le rapport de diagnostic du projet.


## 0.9.18 — microdétails progressifs à distance

En Équilibré et Qualité, l'octave de bruit la plus fine est filtrée progressivement vers sa moyenne entre 35 et 75 m de la surface la plus proche du volume. Le test utilise tout le segment, pas seulement son centre ; un long volume qui arrive près de la caméra garde ses détails. Un zoom étroit repousse cette simplification. À 60° de champ de vision, les microdétails sont complets jusqu'à 35 m et leur calcul est omis au-delà de 75 m. Les deux autres échelles de bruit, les volumes, leur densité physique, leur durée, les collisions et la portée restent en place. Le mode Performance garde ses deux échelles de bruit actuelles. Les limites d'échantillons à distance de la 0.9.14 restent inchangées.

Le passage est continu ; il ne retire aucun volume à une distance seuil. La texture lointaine peut paraître plus lisse. La non-linéarité de l'absorption peut modifier légèrement son opacité locale ; aucune épaisseur identique pixel par pixel n'est promise au loin. Près du pot, le filtrage est nul. Les profils gardent leurs résolutions actuelles : le mode Qualité reste à 100 % par axe.

Essai : observer une forte fumée en s'éloignant lentement, puis zoomer dessus. Les microdétails doivent revenir progressivement. Comparer les FPS à caméra identique ; une suppression d'octave réduit ses calculs mais ne garantit pas un gain global de FPS sur une scène donnée.

0.9.16 : cache des vecteurs transmis au rendu et réutilisation des tableaux. Géométrie, densité, portée, collisions et shader visuel conservés. Le gain de préparation Lua ne garantit pas la disparition de la baisse de FPS sur les gros nuages.

0.9.17 : zone de sillage progressive, entraînement latéral limité, diffusion retardée après le jet initial, remontée liée à la vitesse atténuée avec l’âge. Déplacement intégré avec la traînée pour réduire les écarts selon les FPS. Physique approximative de panache, sans simulation complète des fluides.

0.9.18 : bruit volumétrique préparé dans un atlas 2D pour alléger le shader. Physique 0.9.17, densité réglée, portée et résolution conservées ; détails du bruit légèrement différents (champ périodique de 128 cellules). Gain mesuré modeste dans la scène testée.

## 0.9.20 — Jet chaud diesel piloté par ECU

Ajout d’un rendu rouge orangé émissif séparé, court et concentré à la sortie, commandé par ECU Studio 0.16.9. L’ECU estime la chaleur et la demande à partir des réglages réellement autorisés ; sans ECU ou sans demande, aucun jet n’apparaît. Les shaders de fumée, leur densité, dispersion et contacts restent inchangés. Le nouveau jet suit les nœuds d’échappement à chaque rendu, est masqué par la profondeur opaque et arrêté sous l’eau ou après expiration des données. Jusqu’à huit jets proches, avec portée de 100 m. Aucun son ni fichier du mod de flammes essence modifié. Nécessite une mise à jour des deux ZIP pour utiliser cette liaison, notamment en BeamMP.

Essai local 0.40.1 Direct3D12 : ETK 854 190d, cartographie de démonstration à 400 % et seuils 600/800 °C. Demande ECU observée avec EGT estimée 854 °C, jet inspecté au niveau des nœuds réels ; contrôle isolé du rendu maximal pour régler l’ordre après la fumée. À la levée de pied et restauration, zéro jet restant. Les seuils distribués restent 850/1100 °C. Validation réelle BeamMP à deux PC restant à effectuer.
