-- True 3D density rendering: ray integration through simulated gas parcels.
local M = {}
local sim = require('common/vbfSimulation669')
local nozzle = require('common/vbfNozzle671')
local wind = require('common/vbfWind665')
local hood=require('common/vbfHood669')
local body=require('common/vbfBody669').new(function(id)return core_vehicle_manager and core_vehicle_manager.getVehicleData(id)end)
local bodySlots={}
local ground=require('common/vbfGround637')
local terrain=ground.new(castRayStatic,vec3)
local lighting = require('common/vbfLighting667').new(createObject,vec3,castRay)
local parcels, connected = {}, {}
local emitters = {}
local fx, accumulator, sequence = nil, 0, 0
local STEP, MAX_SIM, MAX_RENDER, RANGE = 1/120, 768, 96, 90
local settings = require('common/vbfSettings').resolve()
MAX_SIM,MAX_RENDER,RANGE=settings.maxSim,settings.maxRender,settings.range
local failed = false
local selected = {}
local bounds={0,0,0,0}
local rendered = false
local reportedBurst = false
local interiorState={}
local renderBudget=MAX_RENDER
local nightModel=require('common/vbfNight667')
local nightBlend,nightTarget,nightPoll=0,0,0
local function packetScale(p,scale,native)
  p.flameScale=math.max(.04,math.min(1.65,tonumber(scale) or 1))
  p.nativeAfterfire=native
  p.renderRadius=p.radius*p.flameScale
  p.halfLength=p.halfLength*p.flameScale
end
local fxEnabled=false
local function setEffectEnabled(value)
  if fxEnabled==value then return end
  if value then fx:enable() else fx:disable() end
  fxEnabled=value
end

local function sendReady(id, value)
  local vehicle = be:getObjectByID(id)
  if vehicle then vehicle:queueLuaCommand('if volumetricBackfireBridge then volumetricBackfireBridge.setReady(' .. tostring(value) .. ') end') end
end

local function refreshAnchors()
  for key,e in pairs(emitters) do
    local vehicle=be:getObjectByID(e.vehicle)
    local pose=vehicle and nozzle.pose(vehicle,e.finish,e.start)
    if not pose then emitters[key]=nil else
      e.pose=pose
      local velocity=vehicle:getVelocity()
      e.vx,e.vy,e.vz=velocity.x,velocity.y,velocity.z
      local wx,wy,wz,known=wind.sample(be,pose[1],pose[2],pose[3],vec3,core_environment)
      if known then e.wx,e.wy,e.wz=wx,wy,wz end
      wind.relative(e.root,e.wx,e.wy,e.wz,e.vx,e.vy,e.vz)
      body.root(e.root,pose,vehicle)
      nozzle.anchor(e.root,pose,e.remaining)
      ground.root(e.root,pose,terrain.query(pose[1],pose[2],pose[3],e.root.ground))
    end
  end
end

local function refreshBounds()
  if #selected==0 then bounds={0,0,0,0}; return end
  local minX,minY,minZ,maxX,maxY,maxZ=math.huge,math.huge,math.huge,-math.huge,-math.huge,-math.huge
  for _,p in ipairs(selected) do
    local along=(p.wx or 0)*p.dx+(p.wy or 0)*p.dy+(p.wz or 0)*p.dz
    local cross=math.sqrt(math.max(0,(p.wx or 0)^2+(p.wy or 0)^2+(p.wz or 0)^2-along*along))
    local r=p.anchored and math.sqrt((p.radius*3+0.15+math.min(p.hood and .95 or .55,cross*(p.hood and .032 or .028)))^2+p.halfLength^2) or math.sqrt(4*(p.renderRadius or p.radius)^2+p.halfLength^2)
    minX,minY,minZ=math.min(minX,p.x-r),math.min(minY,p.y-r),math.min(minZ,p.z-r)
    maxX,maxY,maxZ=math.max(maxX,p.x+r),math.max(maxY,p.y+r),math.max(maxZ,p.z+r)
  end
  bounds={(minX+maxX)*0.5,(minY+maxY)*0.5,(minZ+maxZ)*0.5,
    math.sqrt((maxX-minX)^2+(maxY-minY)^2+(maxZ-minZ)^2)*0.5+0.001}
end

local function setup()
  if fx then return true end
  if failed then return false end
  local ok, err = pcall(function()
    local shader = scenetree.findObject('VBFVolumeShader670b')
    if not shader then
      shader = createObject('ShaderData')
      shader.DXVertexShaderFile = 'shaders/volumetricBackfire/volume_670b.hlsl'
      shader.DXPixelShaderFile = 'shaders/volumetricBackfire/volume_670b.hlsl'
      shader.pixVersion = 5.0
      shader:setField('samplerNames',0,'$prepassTex')
      shader:setField('samplerNames',1,'$prepassDepthTex')
      shader:registerObject('VBFVolumeShader670b')
    end
    local state = scenetree.findObject('VBFVolumeState')
    if not state then
      state = createObject('GFXStateBlockData')
      local parent = scenetree.findObject('PFX_DefaultStateBlock')
      if parent then state:inheritParentFields(parent) end
      state.zDefined=true; state.zEnable=false; state.zWriteEnable=false
      state.samplersDefined=true
      state:setField('samplerStates',0,'SamplerClampPoint')
      state:setField('samplerStates',1,'SamplerClampPoint')
      state.blendDefined=true; state.blendEnable=true
      state:setField('blendSrc',0,'GFXBlendOne')
      state:setField('blendDest',0,'GFXBlendOne')
      state:registerObject('VBFVolumeState')
    end
    fx = scenetree.findObject('VBFVolumeFX')
    if not fx then
      fx = createObject('PostEffect')
      fx.allowReflectPass=false
      fx:setField('renderTime',0,'PFXAfterBin')
      fx:setField('renderBin',0,'ObjTranslucentBin')
      fx:setField('renderPriority',0,'4.5')
      fx:setField('shader',0,'VBFVolumeShader670b')
      fx:setField('stateBlock',0,'VBFVolumeState')
      fx:setField('texture',0,'#prepass[RT0]')
      fx:setField('texture',1,'#prepass[Depth]')
      fx:setField('target',0,'$backBuffer')
      fx:registerObject('VBFVolumeFX')
    end
    -- Composite emission after glass/refraction. Drawing before the glass
    -- lets a background pane attenuate a flame in front of it. Opaque scene
    -- depth clipping remains in the unchanged volume shader. Reapply this
    -- phase for an existing PostEffect too (Lua reload / object reuse).
    fx:setField('renderTime',0,'PFXAfterBin')
    fx:setField('renderBin',0,'ObjTranslucentBin')
    fx:disable();fxEnabled=false
    rawset(_G,'VBFVolumeFXCallbacks',{
      onEnabled=function() return true end,
      setShaderConsts=function()
        if not fx then return end
        -- Vehicle physics may advance after onUpdate. Read the exhaust again
        -- at the actual draw, and move the culling bounds with the attached jet.
        body.beginFrame()
        refreshAnchors()
        refreshBounds()
        -- Custom PostEffects do not receive the native fog exposure binding.
        -- Leaving this uniform unset multiplies every flame pixel by zero.
        fx:setShaderConst('$exposure',1)
        fx:setShaderConst('$vbfNight',nightBlend)
        fx:setShaderConst('$vbfCount',#selected)
        fx:setShaderConst('$vbfBounds',string.format('%.6f %.6f %.6f %.6f',unpack(bounds)))
        for i,p in ipairs(selected) do
          fx:setShaderConst('$vbfPos'..(i-1),string.format('%.6f %.6f %.6f %.6f',p.x,p.y,p.z,p.renderRadius or p.radius))
          fx:setShaderConst('$vbfStyle'..(i-1),string.format('%.6f %.6f %.6f %.6f',(p.popVariant and 1 or p.ecuStyle or 0)+8*math.floor(math.max(0,math.min(1,p.coreFade or 0))*63+.5)+(p.hood and 512 or 0),p.ecuRich or 0,p.ecuRetard or 0,(p.outletForm or 0)+4*math.floor((p.anchored and p.mouthRadius or 0)*10000+.5)))
          fx:setShaderConst('$vbfHeat'..(i-1),string.format('%.6f %.6f %.6f %.6f',p.renderHeat or p.heat,p.exhaustHeat or .65,(p.anchored and p.popVariant and p.popAge) or p.noiseAge or p.age,p.seed%100))
          fx:setShaderConst('$vbfAxis'..(i-1),string.format('%.6f %.6f %.6f %.6f',p.dx,p.dy,p.dz,p.anchored and -p.halfLength or p.halfLength))
          if p.hood and not p.anchored and not p.inNozzleHole then local veh=be:getObjectByID(p.vehicle);if veh then p.bodyTriangle=body.query(veh,p.x,p.y,p.z)end end
          local t=p.bodyTriangle
          if t then
            local skip=p.anchored and math.max(.055,(p.mouthRadius or 0)+.025)or 0
            fx:setShaderConst('$vbfBodyA'..(i-1),string.format('%.6f %.6f %.6f 1',unpack(t.a)))
            fx:setShaderConst('$vbfBodyB'..(i-1),string.format('%.6f %.6f %.6f %.6f',t.b[1],t.b[2],t.b[3],skip))
            fx:setShaderConst('$vbfBodyC'..(i-1),string.format('%.6f %.6f %.6f %.6f',t.c[1],t.c[2],t.c[3],p.anchored and (p.hoodStandOff or 0)or 0))
            bodySlots[i]=true
          elseif bodySlots[i]~=false then fx:setShaderConst('$vbfBodyA'..(i-1),'0 0 0 0');bodySlots[i]=false end
          local g=p.ground or {0,0,0,1}
          fx:setShaderConst('$vbfGround'..(i-1),string.format('%.6f %.6f %.6f %.6f',g[1],g[2],g[3],g[4]))
          fx:setShaderConst('$vbfFlow'..(i-1),string.format('%.6f %.6f %.6f %.6f',p.wx or 0,p.wy or 0,p.wz or 0,p.contacted and -1 or (p.turbulence or 0.32)))
        end
        if not rendered and #selected>0 then
          rendered=true
          log('I','volumetricBackfire','renderer 6.72 beta shader constants callback executed; volumes='..#selected)
          for id in pairs(connected) do sendReady(id,true) end
        end
      end
    })
    log('I','volumetricBackfire','renderer 6.72 beta expanding torn tongues created; waiting for render callback')
  end)
  if not ok then
    failed = true; fx = nil
    log('E','volumetricBackfire',tostring(err))
    return false
  end
  return true
end

local function syncInterior(id,force)
  local name=core_camera.getActiveCamName and core_camera.getActiveCamName(0) or 'orbit'
  local player=be.getPlayerVehicleID and be:getPlayerVehicleID(0)
  local inside=id==player and (name=='driver' or name=='dash' or name:find('^occupant%.')~=nil)
  if id==player and not inside and core_camera.isCameraInside then
    local ok,value=pcall(core_camera.isCameraInside,0,core_camera.getPosition())
    inside=ok and (value==true or value==1)
  end
  if force or interiorState[id]~=inside then
    local vehicle=be:getObjectByID(id)
    if vehicle then vehicle:queueLuaCommand('if volumetricBackfireBridge and volumetricBackfireBridge.setInterior then volumetricBackfireBridge.setInterior('..tostring(inside)..') end') end
    interiorState[id]=inside
  end
end
function M.connect(id)
  connected[id] = true
  syncInterior(id,true)
  sendReady(id, setup() and rendered)
end

function M.burst(id, events)
  if not fx or failed then return end
  local camera = core_camera.getPosition()
  if not reportedBurst then log('I','volumetricBackfire','first burst received; exhausts='..#events); reportedBurst=true end
  for _,incoming in ipairs(events) do
    local e={unpack(incoming)}
    -- Native short backfires share the pop profile; long native holds stay neutral.
    if e[20]==nil and (e[13] or 0)<=.10 and (e[18] or 1)<=1 then e[20]=1 end
    -- Vehicle-to-GE messages can describe an earlier physics step. Start new
    -- gas at the current mouth, rather than at the delayed event position.
    local vehicle=be:getObjectByID(id)
    local pose=vehicle and e[10]~=nil and e[11]~=nil and nozzle.pose(vehicle,e[10],e[11])
    if pose then
      e={unpack(e)}
      for i=1,6 do e[i]=pose[i] end
      local velocity=vehicle:getVelocity()
      e[7],e[8],e[9]=velocity.x,velocity.y,velocity.z
    end
    local dx,dy,dz = e[1]-camera.x,e[2]-camera.y,e[3]-camera.z
    if dx*dx+dy*dy+dz*dz < RANGE*RANGE then
      local strength=math.max(0.2,math.min(1,e[12] or 1))
      local popVariant=(e[20]==1 or e[25]==0)and (e[13]or 0)<=.10
      local burstPhase=id*0.137+(e[10] or 0)*0.31+(popVariant and sequence*0.61803399 or 0)
      for j=1,4 do
        if #parcels >= MAX_SIM then table.remove(parcels,1) end
        sequence = sequence + 1
        local along = 0.04+(j-1)*0.025
        -- Start at the nozzle; overlapping parcels form one continuous jet.
        -- Parcels from a burst share their noise phase, avoiding isolated balls.
        local phase = burstPhase
        local p = sim.new(e[1]+e[4]*along,e[2]+e[5]*along,e[3]+e[6]*along,
          e[4],e[5],e[6],e[7],e[8],e[9],phase,strength)
        p.age=along/(4.2*(0.75+0.25*strength))
        p.fuel=math.exp(-18*p.age)
        p.radius=p.radius+along*0.11
        ground.constrain(p,terrain.query(p.x,p.y,p.z),0)
        p.vehicle=id
        p.exhaustHeat=math.max(0,math.min(1,e[19] or .65))
        p.outletForm=math.max(0,math.min(3,e[24] or 0))
        p.radius=p.radius*math.max(.65,math.min(1.45,e[23] or 1))
        p.ecuStyle,p.ecuRich,p.ecuRetard=e[20] or 0,e[21] or 0,e[22] or 0
        p.apertureFinish=e[10];p.apertureStart=e[11];p.apertureRadius=.04*math.max(.65,math.min(3.125,e[23]or 1))+.025
        p.popVariant=popVariant
        local vd=core_vehicle_manager and core_vehicle_manager.getVehicleData(id);p.hood=hood.exposed(vd and vd.vdata,e[10],e[11])
        p.ambientWx,p.ambientWy,p.ambientWz=e[15] or 0,e[16] or 0,e[17] or 0
        -- Slightly different jet velocities create a continuous volume.
        packetScale(p,e[26],e[25]==0)
        parcels[#parcels+1]=p
      end
      if e[10]~=nil and e[11]~=nil then
        local key=tostring(id)..':'..e[10]..':'..e[11]
        local emitter=emitters[key]
        if not emitter then
          emitter={vehicle=id,finish=e[10],start=e[11],root={age=0,seed=id*0.137+e[10]*0.31,vehicle=id}}
          emitters[key]=emitter
        end
        local attached=math.max(0,math.min(0.22,e[13] or 0))
        local duration=math.max(0.7,math.min(1.25,e[14] or 1))
        local life=math.max((0.065+0.04*strength)*duration,attached)
        emitter.remaining=math.max(emitter.remaining or 0,life)
        emitter.root.lifeSpan=life;emitter.root.popVariant=popVariant
        local vd=core_vehicle_manager and core_vehicle_manager.getVehicleData(id);emitter.root.hood=hood.exposed(vd and vd.vdata,e[10],e[11])
        emitter.root.strength=strength
        emitter.root.flameScale=math.max(.04,math.min(1.65,tonumber(e[26]) or 1))
        emitter.root.nativeAfterfire=e[25]==0
        emitter.root.exhaustHeat=math.max(0,math.min(1,e[19] or .65))
        emitter.root.ecuStyle,emitter.root.ecuRich,emitter.root.ecuRetard=e[20] or 0,e[21] or 0,e[22] or 0
        if popVariant then emitter.root.popAge=0;emitter.root.seed=burstPhase end
        emitter.root.outletForm=math.max(0,math.min(3,e[24] or 0))
        emitter.root.outletScale=math.max(.65,math.min(3.125,tonumber(e[23]) or 1))
        emitter.root.visualBoost=math.max(1,math.min(1.65,e[18] or 1))
        emitter.pose=e
        emitter.vx,emitter.vy,emitter.vz=e[7],e[8],e[9]
        emitter.wx,emitter.wy,emitter.wz=e[15] or 0,e[16] or 0,e[17] or 0
        wind.relative(emitter.root,emitter.wx,emitter.wy,emitter.wz,e[7],e[8],e[9])
        body.root(emitter.root,e,vehicle)
        nozzle.anchor(emitter.root,e,emitter.remaining)
      end
    end
  end
end

function M.removeVehicle(id)
  body.clear(id)
  connected[id]=nil; interiorState[id]=nil
  for i=#parcels,1,-1 do if parcels[i].vehicle==id then table.remove(parcels,i) end end
  for key,e in pairs(emitters) do if e.vehicle==id then emitters[key]=nil end end
end
M.onVehicleDestroyed=M.removeVehicle
M.onVehicleResetted=M.removeVehicle

function M.onUpdate(dtReal,dtSim)
  if not fx or failed then return end
  nightPoll=nightPoll-(dtReal or 0)
  if nightPoll<=0 then
    nightPoll=.2
    local ok,state=pcall(function()
      if core_environment and core_environment.getLightState then return core_environment.getLightState() end
      if core_environment and core_environment.getTimeOfDay then return core_environment.getTimeOfDay() end
    end)
    nightTarget=nightModel.factor(ok and state or nil)
  end
  nightBlend=nightBlend+(nightTarget-nightBlend)*(1-math.exp(-math.max(0,dtReal or 0)*6))
  terrain.beginFrame(dtReal)
  body.beginFrame()
  local wx,wy,wz,known=wind.sample(be,0,0,0,vec3,core_environment)
  if known then
    for _,p in ipairs(parcels) do p.ambientWx,p.ambientWy,p.ambientWz=wx,wy,wz end
  end
  for id in pairs(connected) do syncInterior(id,false) end
  refreshAnchors()
  -- Simulation clock: frozen while paused; bounded catch-up on frame stalls.
  accumulator=accumulator+math.min(math.max(dtSim or 0,0),0.1)
  while accumulator >= STEP do
    for i=#parcels,1,-1 do
      local p=parcels[i]
      if not sim.step(p,STEP,p.ambientWx,p.ambientWy,p.ambientWz) then table.remove(parcels,i) end
    end
    for key,e in pairs(emitters) do
      e.remaining=e.remaining-STEP
      e.root.age=e.root.age+STEP
      if e.root.popAge then e.root.popAge=e.root.popAge+STEP end
      e.root.noiseAge=(e.root.noiseAge or 0)+STEP*(e.root.flowRate or 1)
      if e.remaining<=0 then emitters[key]=nil else
        local pose=e.pose
        local p=sim.new(pose[1]+pose[4]*0.045,pose[2]+pose[5]*0.045,pose[3]+pose[6]*0.045,
          pose[4],pose[5],pose[6],e.vx,e.vy,e.vz,e.root.seed+e.root.age*47,e.root.strength)
        -- Detached gas packets shed into alternating transverse eddies;
        -- the attached jet retains its original axis and shape.
        local ax,ay,az=pose[4],pose[5],pose[6]
        local bx,by,bz=-ay,ax,0
        local bl=math.sqrt(bx*bx+by*by+bz*bz)
        if bl<.01 then bx,by,bz,bl=0,-az,ay,math.sqrt(az*az+ay*ay) end
        bx,by,bz=bx/bl,by/bl,bz/bl
        local cx,cy,cz=ay*bz-az*by,az*bx-ax*bz,ax*by-ay*bx
        local phase=e.root.seed+e.root.age*53
        local side=.95*math.sin(phase)
        local up=.75*math.cos(phase*1.31)
        p.vx=p.vx+bx*side+cx*up;p.vy=p.vy+by*side+cy*up;p.vz=p.vz+bz*side+cz*up
        ground.spawn(p,pose,e.root,.045)
        p.vehicle=e.vehicle
        p.exhaustHeat=e.root.exhaustHeat
        p.outletForm=e.root.outletForm
        p.radius=p.radius*math.min(1.45,e.root.outletScale or 1)
        p.ecuStyle,p.ecuRich,p.ecuRetard=e.root.ecuStyle,e.root.ecuRich,e.root.ecuRetard
        p.popVariant=e.root.popVariant;p.hood=e.root.hood
        p.apertureFinish=e.finish;p.apertureStart=e.start;p.apertureRadius=.04*math.max(.65,math.min(3.125,e.root.outletScale or 1))+.025
        p.ambientWx,p.ambientWy,p.ambientWz=e.wx,e.wy,e.wz
        if #parcels>=MAX_SIM then table.remove(parcels,1) end
        packetScale(p,e.root.flameScale,e.root.nativeAfterfire)
        parcels[#parcels+1]=p
        nozzle.anchor(e.root,pose,e.remaining)
      ground.root(e.root,pose,terrain.query(pose[1],pose[2],pose[3],e.root.ground))
      end
    end
    accumulator=accumulator-STEP
  end
  if #parcels==0 and next(emitters)==nil then selected={}; lighting.update({},core_camera.getPosition()); setEffectEnabled(false); return end
  -- Contacts are resolved once per rendered frame, not per 120 Hz gas step.
  -- The shader also clips the entire volume, including its turbulent boundary.
  for _,p in ipairs(parcels) do
    local g=terrain.query(p.x,p.y,p.z,p.ground)
    ground.constrain(p,g,math.min(math.max(dtSim or 0,0),.1))
    if p.hood then local veh=be:getObjectByID(p.vehicle);if veh then body.parcel(p,veh,math.min(math.max(dtSim or 0,0),.1))end end
  end
  local cam=core_camera.getPosition()
  local candidates={}
  local lightRoots={}
  for _,e in pairs(emitters) do
    local p=e.root
    lightRoots[#lightRoots+1]=p
    local x,y,z=p.x-cam.x,p.y-cam.y,p.z-cam.z
    p.distance=x*x+y*y+z*z
    if p.distance<RANGE*RANGE then candidates[#candidates+1]=p end
  end
  local player=be.getPlayerVehicleID and be:getPlayerVehicleID(0)
  local insideVehicle=player and interiorState[player] and player or nil
  local lightOK,lightError=lighting.update(lightRoots,cam,insideVehicle,nightBlend)
  if lightOK==false then log('W','volumetricBackfire','Scene lighting unavailable: '..lightError) end
  for _,p in ipairs(parcels) do
    local x,y,z=p.x-cam.x,p.y-cam.y,p.z-cam.z
    p.distance=x*x+y*y+z*z
    if p.distance < RANGE*RANGE then candidates[#candidates+1]=p end
  end
  table.sort(candidates,function(a,b)
    if (a.anchored==true)~=(b.anchored==true) then return a.anchored==true end
    return a.distance<b.distance
  end)
  -- Round-robin among visible vehicles so nearby traffic also receives a budget.
  local groups,order={},{}
  for _,p in ipairs(candidates) do
    if not groups[p.vehicle] then groups[p.vehicle]={}; order[#order+1]=p.vehicle end
    local group=groups[p.vehicle]; group[#group+1]=p
  end
  -- Keep the full HQ budget nearby; far-away detached gas needs fewer volumes.
  local nearest=math.huge
  for _,p in ipairs(candidates) do nearest=math.min(nearest,p.distance) end
  renderBudget=nearest>40*40 and math.min(MAX_RENDER,24) or
    (nearest>20*20 and math.min(MAX_RENDER,48) or MAX_RENDER)
  selected={}
  for index=1,renderBudget do
    for _,id in ipairs(order) do
      local p=groups[id][index]
      if p and #selected<renderBudget then selected[#selected+1]=p end
    end
    if #selected>=renderBudget then break end
  end
  if #selected>0 then
    -- One conservative sphere rejects empty screen pixels before ray marching.
    -- Include the full downstream wind bend.
    refreshBounds()
    setEffectEnabled(true)
  else setEffectEnabled(false) end
end

function M.getStats()
  local roots,clipped,contacts=0,0,0;for _,e in pairs(emitters) do roots=roots+1;if e.root.contactDistance then clipped=clipped+1 end end;for _,p in ipairs(parcels) do if p.contacted then contacts=contacts+1 end end
  local hoodRoots,bodyRoots,bodyParcels=0,0,0
  for _,e in pairs(emitters)do if e.root.hood then hoodRoots=hoodRoots+1 end;if e.root.bodyTriangle then bodyRoots=bodyRoots+1 end end
  for _,p in ipairs(parcels)do if p.bodyContacted then bodyParcels=bodyParcels+1 end end
  return {hoodRoots=hoodRoots,bodyRoots=bodyRoots,bodyParcels=bodyParcels,body=body.stats(),nightFactor=nightBlend,lights=lighting.stats(),simulated=#parcels,rendered=#selected,roots=roots,renderBudget=renderBudget,maxRender=MAX_RENDER,groundQueries=terrain.count(),clippedRoots=clipped,contacts=contacts}
end
local function clear()
  lighting.clear();body.clear();bodySlots={}
  for id in pairs(connected) do sendReady(id,false) end
  connected,parcels,emitters={},{},{};interiorState={};renderBudget=MAX_RENDER
  selected={}; rendered=false; reportedBurst=false
  accumulator=0;terrain=ground.new(castRayStatic,vec3)
  if fx then fx:disable(); fx:delete(); fx=nil end;fxEnabled=false
  failed=false
end
M.onClientEndMission=clear
M.onExtensionUnloaded=clear
return M





