-- Visual dimensions in metres. No long jet without a valid high EGT.
local M={}
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<1e7 end
local function clamp(x,a,b) return math.max(a,math.min(b,x)) end
function M.diameter(value)
  return finite(value) and clamp(value,.025,.20) or .08
end
function M.dimensions(demand,egt,diameter,time,seed)
  local d=clamp(demand,0,1)
  local extreme=finite(egt) and clamp((egt-1150)/200,0,1) or 0
  extreme=extreme*extreme*(3-2*extreme)
  local flutter=.94+.04*math.sin(time*19+seed)+.02*math.sin(time*31+seed*1.7)
  return (.03+.06*d+.24*extreme*d)*flutter,M.diameter(diameter)*.5
end
return M
