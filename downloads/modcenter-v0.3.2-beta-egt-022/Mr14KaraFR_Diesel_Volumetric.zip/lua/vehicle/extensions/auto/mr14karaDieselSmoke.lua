local M={}
local model=require('common/mr14karaDieselModel')
local native=require('common/mr14karaDieselNative')
local states,scan,timer,retry={},0,0,0
local hooks,readyLease={},0
local session=nil
function M.setSession(value) if type(value)=='number' and value>0 and value%1==0 then session=value end end
function M.setReady(value) readyLease=value==true and 4.5 or 0 end
function M.getStatus()
  local out={hotSupported=true,ready=readyLease>0,engines=0,suppressed=0,thermalCalls=0,session=session}
  for _,h in pairs(hooks) do if h then
    out.engines=out.engines+1
    out.suppressed=out.suppressed+h.stats.suppressed
    out.thermalCalls=out.thermalCalls+h.stats.calls
  end end
  return out
end
local function request()
  obj:queueGameEngineLua("extensions.load('mr14karaDieselRenderer'); if extensions.mr14karaDieselRenderer then extensions.mr14karaDieselRenderer.connect("..obj:getId()..") end")
end
local function discover()
  local old=states; states={}
  for _,e in pairs(powertrain.getDevices() or {}) do
    if e.requiredEnergyType=='diesel' and e.thermals then
      states[e]=old[e] or model.new()
      local previous=hooks[e]
      if previous and (previous.thermals~=e.thermals or not previous.isAttached()) then
        previous.detach();hooks[e]=nil
      end
      if hooks[e]==nil or (hooks[e]==false and type(e.thermals.updateGFX)=='function') then
        local h=native.attach(e.thermals,function() return readyLease>0 and states[e] and states[e].volumeActive==true end)
        hooks[e]=h or false
        if not h and not states[e].reportedNative then
          states[e].reportedNative=true
          log('W','mr14karaDiesel','Soot hook unavailable; preserving native smoke for '..tostring(e.name))
        end
      end
    end
  end
  for e,h in pairs(hooks) do if not states[e] then if h then h.detach() end; hooks[e]=nil end end
end
function M.updateGFX(dt)
  dt=math.max(0,tonumber(dt) or 0)
  readyLease=math.max(0,readyLease-dt)
  scan=scan-dt; retry=retry-dt
  if scan<=0 then discover(); scan=1 end
  if next(states) and retry<=0 then request(); retry=3 end
  timer=timer+dt
  -- Thirty overlapping volumes over three seconds fit the 32-volume renderer.
  local emitCount=math.min(3,math.floor(timer*10+1e-7))
  if emitCount>0 then timer=math.max(0,timer-math.floor(timer*10+1e-7)*.1) end
  local batch={}
  local hotPipes={};local hotDemand=0;local hotEGT=nil
  for e,s in pairs(states) do
    local hot=e.mr14karaDieselHot
    if hot and type(hot.lease)=='number' then
      hot.lease=hot.lease-dt
      if hot.lease>0 and type(hot.demand)=='number' and hot.demand==hot.demand and hot.demand>0 then
        local pipes=e.thermals.exhaustEndNodes or {}
        for _,p in pairs(pipes) do if #hotPipes<8 and p.finish~=nil and p.start~=nil and not obj:inWater(p.finish) then local node=v and v.data and v.data.nodes and v.data.nodes[p.finish]
          local diameter=p.mr14karaExhaustDiameter or (node and node.mr14karaExhaustDiameter)
          if type(diameter)~='number' or diameter~=diameter or diameter<.025 or diameter>.20 then diameter=.08 end
          hotPipes[#hotPipes+1]={p.finish,p.start,diameter} end end
        if hot.demand>=hotDemand then
          hotDemand=math.min(1,hot.demand)
          hotEGT=type(hot.egt)=='number' and hot.egt==hot.egt and hot.egt>=0 and hot.egt<=1600 and hot.egt or nil
        end
      end
    end
    model.setAir(s,e,electrics.values.turboBoost)
    local density,rpm,pulse
    local remaining=math.min(dt,.3)
    repeat
      local step=math.min(remaining,.05)
      density,rpm,pulse=model.update(s,step,e,electrics.values.throttle_input or electrics.values.throttle)
      remaining=remaining-step
    until remaining<.000001
    -- The native idle floor is almost invisible but kept the expensive full
    -- screen effect active. Preserve native faint soot below this threshold.
    s.volumeActive=density>=.008
    if session and emitCount>0 and s.volumeActive then
      local pipes=e.thermals.exhaustEndNodes or {}
      local count=0; for _ in pairs(pipes) do count=count+1 end
      for _,pipe in pairs(pipes) do
        if pipe.finish~=nil and pipe.start~=nil and not obj:inWater(pipe.finish) then
          local pos=obj:getNodePosition(pipe.finish)
          local dir=pos-obj:getNodePosition(pipe.start)
          if dir:length()>.0001 then
            dir:normalize(); pos=pos+obj:getPosition()
            local vel=obj:getNodeVelocityVector(pipe.finish)
            local wind=vec3(0,0,0)
            if obj.getWind then local ok,w=pcall(obj.getWind,obj); if ok and w then wind=w end end
            -- A narrow, faster initial jet transports soot out of the outlet before mixing.
            local jet=1.6+math.min(rpm,6000)*.0008
            for sample=1,emitCount do
              local lag=timer+(emitCount-sample)*.1
              batch[#batch+1]={pos.x-vel.x*lag,pos.y-vel.y*lag,pos.z-vel.z*lag,
                vel.x+dir.x*jet,vel.y+dir.y*jet,vel.z+dir.z*jet,
                density/math.max(count,1),wind.x,wind.y,wind.z,pipe.finish,pulse or 1,lag,vel.x,vel.y,vel.z}
            end
          end
        end
      end
    end
  end
  if emitCount>0 and (hotDemand>.001 or M.hotWasActive) then
    if #hotPipes==0 then hotDemand=0 end
    obj:queueGameEngineLua('extensions.load("mr14karaDieselHotRenderer"); if extensions.mr14karaDieselHotRenderer then extensions.mr14karaDieselHotRenderer.set('..obj:getId()..','..serialize(hotPipes)..','..hotDemand..','..(hotEGT and tostring(hotEGT) or 'nil')..') end')
    M.hotWasActive=hotDemand>.001
  end
  if #batch>0 then
    obj:queueGameEngineLua('if extensions.mr14karaDieselRenderer then extensions.mr14karaDieselRenderer.emit('..
      obj:getId()..','..serialize(batch)..','..session..') end')
  end
end
local function reset()
  M.hotWasActive=false
  obj:queueGameEngineLua('if extensions.mr14karaDieselHotRenderer then extensions.mr14karaDieselHotRenderer.removeVehicle('..obj:getId()..') end')
  for e in pairs(states) do e.mr14karaDieselHot=nil end
  local previousSession=session
  for _,h in pairs(hooks) do if h then h.detach() end end
  hooks,readyLease={},0
  session=nil
  states,scan,timer,retry={},0,0,0
  obj:queueGameEngineLua('if extensions.mr14karaDieselRenderer then extensions.mr14karaDieselRenderer.removeVehicle('..obj:getId()..','..tostring(previousSession)..') end')
  discover()
end
M.onExtensionLoaded=reset
M.onReset=reset
function M.onExtensionUnloaded()
  M.hotWasActive=false
  obj:queueGameEngineLua('if extensions.mr14karaDieselHotRenderer then extensions.mr14karaDieselHotRenderer.removeVehicle('..obj:getId()..') end')
  for e in pairs(states) do e.mr14karaDieselHot=nil end
  local previousSession=session
  for _,h in pairs(hooks) do if h then h.detach() end end
  hooks,states,readyLease,session={},{},0,nil
  obj:queueGameEngineLua('if extensions.mr14karaDieselRenderer then extensions.mr14karaDieselRenderer.removeVehicle('..obj:getId()..','..tostring(previousSession)..') end')
end
return M
