-- Separate additive hot-exhaust pass. No soot material or simulation is changed.
local M={}
local shape=require('common/mr14karaDieselHotShape')
local entries,fx={},nil
local time,failed=0,false
local function finite(n) return type(n)=='number' and n==n and math.abs(n)<1e7 end
local function disable() if fx then fx:disable() end end
local function setup()
  if fx then return true end
  if failed then return false end
  local ok,err=pcall(function()
    local shader=scenetree.findObject('Mr14DieselHotShader3')
    if not shader then
      shader=createObject('ShaderData');shader.DXVertexShaderFile='shaders/mr14karaDiesel/hotjet_03.hlsl';shader.DXPixelShaderFile=shader.DXVertexShaderFile;shader.pixVersion=5
      shader:setField('samplerNames',0,'$prepassTex');shader:setField('samplerNames',1,'$prepassDepthTex');shader:registerObject('Mr14DieselHotShader3')
    end
    local state=scenetree.findObject('Mr14DieselHotState3')
    if not state then
      state=createObject('GFXStateBlockData');local parent=scenetree.findObject('PFX_DefaultStateBlock');if parent then state:inheritParentFields(parent) end
      state.zDefined=true;state.zEnable=false;state.zWriteEnable=false;state.blendDefined=true;state.blendEnable=true
      state:setField('blendSrc',0,'GFXBlendOne');state:setField('blendDest',0,'GFXBlendOne');state.samplersDefined=true
      state:setField('samplerStates',0,'SamplerClampPoint');state:setField('samplerStates',1,'SamplerClampPoint');state:registerObject('Mr14DieselHotState3')
    end
    fx=scenetree.findObject('Mr14DieselHotFX3')
    if not fx then
      fx=createObject('PostEffect');fx.allowReflectPass=false
      fx:setField('renderTime',0,'PFXBeforeBin');fx:setField('renderBin',0,'ObjTranslucentBin');fx:setField('renderPriority',0,'4.5')
      fx:setField('shader',0,'Mr14DieselHotShader3');fx:setField('stateBlock',0,'Mr14DieselHotState3')
      fx:setField('texture',0,'#prepass[RT0]');fx:setField('texture',1,'#prepass[Depth]');fx:setField('target',0,'$backBuffer');fx:registerObject('Mr14DieselHotFX3')
    end
    rawset(_G,'Mr14DieselHotFX3Callbacks',{onEnabled=function() return true end,setShaderConsts=function()
      local eye=getCameraPosition();local jets={}
      for id,e in pairs(entries) do
        local v=be:getObjectByID(id)
        if v then for _,pipe in ipairs(e.pipes) do
          local success,node,start,pos=pcall(function() return v:getNodePosition(pipe[1]),v:getNodePosition(pipe[2]),v:getPosition() end)
          if success and node and start and pos then
            local x,y,z=node.x+pos.x,node.y+pos.y,node.z+pos.z
            local dx,dy,dz=node.x-start.x,node.y-start.y,node.z-start.z
            local length=math.sqrt(dx*dx+dy*dy+dz*dz)
            local distance=(x-eye.x)^2+(y-eye.y)^2+(z-eye.z)^2
            if finite(x) and finite(y) and finite(z) and finite(length) and length>.0001 and distance<10000 then
              dx,dy,dz=dx/length,dy/length,dz/length
              -- Stable phase per vehicle/outlet; smooth flicker follows simulation time.
              local seed=(id%997)*.173+pipe[1]*.619
              local jetLength,radius=shape.dimensions(e.demand,e.egt,pipe[3],time,seed)
              if castRayStatic then
                local hitOK,hit=pcall(castRayStatic,vec3(x,y,z),vec3(dx,dy,dz),jetLength)
                if hitOK and finite(hit) and hit>=0 then jetLength=math.min(jetLength,math.max(0,hit-.01)) end
              end
              if jetLength>.01 then jets[#jets+1]={x,y,z,radius,x+dx*jetLength,y+dy*jetLength,z+dz*jetLength,e.demand,distance,seed} end
            end
          end
        end end
      end
      table.sort(jets,function(a,b) return a[9]<b[9] end)
      local origins,ends,details={},{},{}
      for i=1,8 do
        local j=jets[i]
        origins[i]=j and string.format('%.6f %.6f %.6f %.6f',j[1],j[2],j[3],j[4]) or '0 0 0 0'
        details[i]=j and string.format('%.6f 0 0 0',j[10]) or '0 0 0 0'
        ends[i]=j and string.format('%.6f %.6f %.6f %.6f',j[5],j[6],j[7],j[8]) or '0 0 0 0'
      end
      fx:setShaderConst('$hotEye',string.format('%.6f %.6f %.6f',eye.x,eye.y,eye.z));fx:setShaderConst('$hotCount',math.min(#jets,8));fx:setShaderConst('$hotTime',time)
      fx:setShaderConst('$hotOrigins',table.concat(origins,'\t'));fx:setShaderConst('$hotEnds',table.concat(ends,'\t'));fx:setShaderConst('$hotJetData',table.concat(details,'\t'))
    end})
    fx:disable()
  end)
  if not ok then disable();fx=nil;failed=true;log('E','mr14karaDieselHot',tostring(err));return false end
  return true
end
function M.set(id,pipes,demand,egt)
  if not finite(id) or id%1~=0 or not finite(demand) or demand<0 or demand>1 or not be:getObjectByID(id) then return false end
  if egt~=nil and (not finite(egt) or egt<0 or egt>1600) then return false end
  if demand<=.001 then entries[id]=nil;if not next(entries) then disable() end;return true end
  if type(pipes)~='table' or #pipes>8 then return false end
  local valid={}
  for _,p in ipairs(pipes) do
    if type(p)~='table' or not finite(p[1]) or not finite(p[2]) or p[1]<0 or p[2]<0 or p[1]%1~=0 or p[2]%1~=0 then return false end
    if p[3]~=nil and (not finite(p[3]) or p[3]<.025 or p[3]>.20) then return false end
    valid[#valid+1]={p[1],p[2],shape.diameter(p[3])}
  end
  if #valid==0 then entries[id]=nil;if not next(entries) then disable() end;return false end
  if not setup() then return false end
  entries[id]={pipes=valid,demand=demand,egt=egt,age=0};fx:enable();return true
end
function M.onUpdate(dtReal,dtSim)
  local dt=math.max(0,dtSim or dtReal or 0);time=time+dt
  for id,e in pairs(entries) do e.age=e.age+dt;if e.age>.35 or not be:getObjectByID(id) then entries[id]=nil end end
  if not next(entries) then disable() end
end
function M.removeVehicle(id) entries[id]=nil;if not next(entries) then disable() end end
M.onVehicleDestroyed=M.removeVehicle
M.onVehicleResetted=M.removeVehicle
function M.onClientEndMission() entries={};time=0;disable() end
M.onExtensionUnloaded=M.onClientEndMission
return M
