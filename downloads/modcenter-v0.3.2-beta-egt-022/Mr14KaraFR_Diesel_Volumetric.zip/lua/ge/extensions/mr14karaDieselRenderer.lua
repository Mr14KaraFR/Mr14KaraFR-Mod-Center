local M={}
local model=require('common/mr14karaDieselModel')
local lod=require('common/mr14karaDieselLOD')
local trail=require('common/mr14karaDieselTrail')
local budget=require('common/mr14karaDieselBudget')
local lighting=require('common/mr14karaDieselLight').new(scenetree)
local lightState=lighting.update(0)
local air=require('common/mr14karaDieselAir').new(be,core_environment,vec3)
local collision=require('common/mr14karaDieselCollision').new(castRay,castRayStatic,vec3)
local parcels,selected,fx={}, {},nil
local effectEnabled=false
local function setEnabled(value)
  if fx and effectEnabled~=value then
    if value then fx:enable() else fx:disable() end
    effectEnabled=value
  end
end
local shaderValues={}
local function setConst(name,value)
  if shaderValues[name]~=value then fx:setShaderConst(name,value);shaderValues[name]=value end
end
local sequence,failed=0,false
local simulationTime=0
local profiles={performance={samples=4,detail=0,scale=.35,probe=.24,range=120},balanced={samples=8,detail=1,scale=.5,probe=.16,range=200},quality={samples=12,detail=1,scale=1,probe=.08,range=250}}
local quality,diagnostics,luaMs='balanced',false,nil
local configPath='/settings/mr14karaDieselSmoke.json'
local clock=os.clockhp or os.clock
local connected,renderSeen={},false
local sessions,sessionCounter={},0
local function ready(id,value)
  local vehicle=be:getObjectByID(id)
  if vehicle and type(vehicle.queueLuaCommand)=='function' then vehicle:queueLuaCommand('if extensions.mr14karaDieselSmoke then extensions.mr14karaDieselSmoke.setReady('..tostring(value)..') end') end
end
function M.connect(id)
  local vehicle=be:getObjectByID(id)
  if not vehicle then return nil end
  if not sessions[id] then sessionCounter=sessionCounter+1;sessions[id]=sessionCounter end
  if type(vehicle.queueLuaCommand)=='function' then
    vehicle:queueLuaCommand('if extensions.mr14karaDieselSmoke and extensions.mr14karaDieselSmoke.setSession then extensions.mr14karaDieselSmoke.setSession('..sessions[id]..') end')
  end
  connected[id]=true
  if renderSeen and fx then ready(id,true) end
  return sessions[id]
end
local MAX_SIM,MAX_RENDER,RANGE=192,32,200
local function vec(p) return string.format('%.6f %.6f %.6f %.6f',unpack(p)) end
-- Cache numeric components, not table identities: collision planes are mutable.
local function cachedVec(p,slot,x,y,z,w)
  local cache=p.renderUpload
  if not cache then cache={};p.renderUpload=cache end
  local v=cache[slot]
  if not v then v={};cache[slot]=v end
  if v[1]~=x or v[2]~=y or v[3]~=z or v[4]~=w then
    v[1],v[2],v[3],v[4]=x,y,z,w
    v.text=string.format('%.6f %.6f %.6f %.6f',x,y,z,w)
  end
  return v.text
end
local positions,ends,states,planes={},{},{},{}
local function clear()
  for id in pairs(connected) do ready(id,false) end
  connected,renderSeen={},false
  sessions={}
  parcels,selected={},{}
  simulationTime=0
  luaMs=nil
  shaderValues={}
  lighting.reset();lightState=lighting.update(0)
  setEnabled(false)
end
local function setup()
  if fx then return true end
  if failed then return false end
  local ok,err=pcall(function()
    local shader=scenetree.findObject('Mr14DieselShader33')
    if not shader then
      shader=createObject('ShaderData')
      shader.DXVertexShaderFile='shaders/mr14karaDiesel/volume_33.hlsl'
      shader.DXPixelShaderFile='shaders/mr14karaDiesel/volume_33.hlsl'
      shader.pixVersion=5.0
      shader:setField('samplerNames',0,'$prepassTex')
      shader:setField('samplerNames',1,'$prepassDepthTex')
      shader:setField('samplerNames',2,'$noiseTex')
      shader:registerObject('Mr14DieselShader33')
    end
    local state=scenetree.findObject('Mr14DieselState37')
    if not state then
      state=createObject('GFXStateBlockData')
      local parent=scenetree.findObject('PFX_DefaultStateBlock')
      if parent then state:inheritParentFields(parent) end
      state.zDefined=true; state.zEnable=false; state.zWriteEnable=false
      state.samplersDefined=true
      state:setField('samplerStates',0,'SamplerClampPoint')
      state:setField('samplerStates',1,'SamplerClampPoint')
      state:setField('samplerStates',2,'SamplerWrapLinear')
      state.blendDefined=true; state.blendEnable=false
      state:setField('blendSrc',0,'GFXBlendOne')
      state:setField('blendDest',0,'GFXBlendInvSrcAlpha')
      state:registerObject('Mr14DieselState37')
    end
    fx=scenetree.findObject('Mr14DieselFX37')
    if not fx then
      fx=createObject('PostEffect'); fx.allowReflectPass=false
      fx:setField('renderTime',0,'PFXBeforeBin')
      fx:setField('renderBin',0,'ObjTranslucentBin')
      fx:setField('renderPriority',0,'4.6')
      fx:setField('shader',0,'Mr14DieselShader33')
      fx:setField('stateBlock',0,'Mr14DieselState37')
      fx:setField('texture',0,'#prepass[RT0]')
      fx:setField('texture',1,'#prepass[Depth]')
      fx:setField('texture',2,'/art/mr14karaDiesel/noise_atlas.png')
      fx:setField('target',0,'$outTex')
      fx:setField('targetScale',0,tostring(profiles[quality].scale)..' '..tostring(profiles[quality].scale))
      fx:setField('targetFormat',0,'GFXFormatR16G16B16A16F')
      fx:setField('targetClear',0,'PFXTargetClear_OnDraw')
      fx:setField('targetClearColor',0,'0 0 0 0')
      fx:registerObject('Mr14DieselFX37')
    end
    local compositeShader=scenetree.findObject('Mr14DieselCompositeShader15')
    if not compositeShader then
      compositeShader=createObject('ShaderData')
      compositeShader.DXVertexShaderFile='shaders/mr14karaDiesel/composite_15.hlsl'
      compositeShader.DXPixelShaderFile='shaders/mr14karaDiesel/composite_15.hlsl'
      compositeShader.pixVersion=5.0
      compositeShader:setField('samplerNames',0,'$smokeTex')
      compositeShader:setField('samplerNames',1,'$prepassTex')
      compositeShader:setField('samplerNames',2,'$prepassDepthTex')
      compositeShader:registerObject('Mr14DieselCompositeShader15')
    end
    local compositeState=scenetree.findObject('Mr14DieselCompositeState15')
    if not compositeState then
      compositeState=createObject('GFXStateBlockData')
      local parent=scenetree.findObject('PFX_DefaultStateBlock')
      if parent then compositeState:inheritParentFields(parent) end
      compositeState.zDefined=true;compositeState.zEnable=false;compositeState.zWriteEnable=false
      compositeState.blendDefined=true;compositeState.blendEnable=true
      compositeState:setField('blendSrc',0,'GFXBlendOne')
      compositeState:setField('blendDest',0,'GFXBlendInvSrcAlpha')
      compositeState.samplersDefined=true
      for i=0,2 do compositeState:setField('samplerStates',i,'SamplerClampPoint') end
      compositeState:registerObject('Mr14DieselCompositeState15')
    end
    if not scenetree.findObject('Mr14DieselCompositeFX25') then
      local composite=createObject('PostEffect');composite.allowReflectPass=false
      composite:setField('shader',0,'Mr14DieselCompositeShader15')
      composite:setField('stateBlock',0,'Mr14DieselCompositeState15')
      composite:setField('texture',0,'$inTex')
      composite:setField('texture',1,'#prepass[RT0]')
      composite:setField('texture',2,'#prepass[Depth]')
      composite:setField('target',0,'$backBuffer')
      composite:registerObject('Mr14DieselCompositeFX25')
      fx:add(composite)
    end
    rawset(_G,'Mr14DieselFX37Callbacks',{onEnabled=function() return true end,
      setShaderConsts=function()
        trail.refreshSources(selected,be,collision)
        local eye=getCameraPosition()
        setConst('$dieselEye',string.format('%.6f %.6f %.6f',eye.x,eye.y,eye.z))
        setConst('$dieselCount',#selected)
        setConst('$dieselTime',simulationTime)
        setConst('$dieselSamples',profiles[quality].samples)
        setConst('$dieselDetail',profiles[quality].detail)
        setConst('$dieselSun',vec(lightState.sun))
        setConst('$dieselSunColor',string.format('%.6f %.6f %.6f',unpack(lightState.color)))
        local lo={math.huge,math.huge,math.huge}; local hi={-math.huge,-math.huge,-math.huge}
        local viewScale=1
        if profiles[quality].detail>0 and core_camera and type(core_camera.getFovDeg)=='function' then
          local ok,fov=pcall(core_camera.getFovDeg)
          if ok then viewScale=lod.viewScale(fov) end
        end
        for i,p in ipairs(selected) do
          local tail=p.trail or p
          positions[i]=cachedVec(p,1,p.x,p.y,p.z,p.radius)
          ends[i]=cachedVec(p,2,tail.x,tail.y,tail.z,tail.density)
          local fineWeight=profiles[quality].detail>0 and lod.weight(p,tail,eye,viewScale) or 0
          states[i]=cachedVec(p,3,p.density,lod.pack(p.age,fineWeight),p.seed,tail.radius)
          for j=1,6 do
            local g=(p.renderPlanes or p.planes or {})[j]
            planes[(i-1)*6+j]=g and cachedVec(p,3+j,g[1],g[2],g[3],g[4]) or '0 0 0 1' 
          end
          lo[1]=math.min(lo[1],p.x-p.radius,tail.x-tail.radius);hi[1]=math.max(hi[1],p.x+p.radius,tail.x+tail.radius)
          lo[2]=math.min(lo[2],p.y-p.radius,tail.y-tail.radius);hi[2]=math.max(hi[2],p.y+p.radius,tail.y+tail.radius)
          lo[3]=math.min(lo[3],p.z-p.radius,tail.z-tail.radius);hi[3]=math.max(hi[3],p.z+p.radius,tail.z+tail.radius)
        end
        -- The former age channel carries the young-jet flag and microdetail weight.
        -- Keep a fixed layout and clear unused slots when the visible count shrinks.
        for i=#selected+1,32 do
          positions[i]='0 0 0 0';ends[i]='0 0 0 0';states[i]='0 0 0 0'
          for j=1,6 do planes[(i-1)*6+j]='0 0 0 1' end
        end
        setConst('$dieselPositions',table.concat(positions,'\t'))
        setConst('$dieselEnds',table.concat(ends,'\t'))
        setConst('$dieselStates',table.concat(states,'\t'))
        setConst('$dieselPlanes',table.concat(planes,'\t'))
        local b={0,0,0,0}
        if #selected>0 then
          for j=1,3 do b[j]=(lo[j]+hi[j])*.5 end
          b[4]=math.sqrt((hi[1]-lo[1])^2+(hi[2]-lo[2])^2+(hi[3]-lo[3])^2)*.5
        end
        setConst('$dieselBounds',vec(b))
        if #selected>0 and not renderSeen then
          renderSeen=true
          for id in pairs(connected) do ready(id,true) end
          log('I','mr14karaDiesel','Volumetric shader callback active; native soot replacement ready')
        end
      end})
    fx:disable()
    effectEnabled=false
  end)
  if not ok then
    if fx then pcall(function() fx:disable() end) end
    fx=nil; failed=true; log('E','mr14karaDiesel',tostring(err)); return false
  end
  return true
end
function M.emit(id,batch,session)
  if session~=nil and sessions[id]~=session then return end
  if not be:getObjectByID(id) or not setup() then return end
  local camera=getCameraPosition()
  for i=1,math.min(#batch,48) do
    local e=batch[i]; local valid=type(e)=='table'
    if valid then for j=1,10 do if type(e[j])~='number' or e[j]~=e[j] or math.abs(e[j])>1e7 then valid=false; break end end end
    if valid and (e[1]-camera.x)^2+(e[2]-camera.y)^2+(e[3]-camera.z)^2<RANGE*RANGE then
      if #parcels==0 then lighting.reset();lightState=lighting.update(0) end
      sequence=sequence+1
      if #parcels>=MAX_SIM then budget.evict(parcels,id) end
      parcels[#parcels+1]={vehicle=id,x=e[1],y=e[2],z=e[3],vx=e[4],vy=e[5],vz=e[6],
        strength=math.max(0,math.min(1,e[7])),wx=e[8],wy=e[9],wz=e[10],age=0,
        radius=.11,density=math.max(0,math.min(1,e[7])),seed=id%97,birthTime=simulationTime,sequence=sequence,
        outlet=type(e[11])=='number' and e[11]==e[11] and e[11] or i,
        speed=math.sqrt(e[4]^2+e[5]^2+e[6]^2)}
      local p=parcels[#parcels]
      p.sourceUntil=simulationTime+.25
      local validVelocity=true
      for j=14,16 do if type(e[j])~='number' or e[j]~=e[j] or math.abs(e[j])>1000 then validVelocity=false end end
      if validVelocity then p.vehicleVX,p.vehicleVY,p.vehicleVZ=e[14],e[15],e[16] end
      p.pulseGain=type(e[12])=='number' and e[12]==e[12] and math.max(1,math.min(1.65,e[12])) or 1
      local lag=type(e[13])=='number' and e[13]==e[13] and math.max(0,math.min(.3,e[13])) or 0
      p.birthTime=simulationTime-lag
      collision.probe(p);air.sample(p,0,true)
      while lag>.000001 do
        local step=math.min(lag,.05);local x,y,z=p.x,p.y,p.z
        model.advance(p,step);collision.move(p,x,y,z,step);lag=lag-step
      end
    end
  end
end
function M.removeVehicle(id,session)
  if session~=nil and sessions[id]~=session then return end
  ready(id,false)
  connected[id]=nil
  sessions[id]=nil
  for i=#parcels,1,-1 do if parcels[i].vehicle==id then table.remove(parcels,i) end end
  for i=#selected,1,-1 do if selected[i].vehicle==id then table.remove(selected,i) end end
  if #selected==0 then setEnabled(false) end
end
function M.onVehicleDestroyed(id) M.removeVehicle(id) end
function M.onVehicleResetted(id)
  M.removeVehicle(id)
  local ecu=extensions and extensions.mr14karaECUDieselRenderer
  if ecu and type(ecu.onVehicleDestroyed)=='function' then ecu.onVehicleDestroyed(id) end
end
function M.onUpdate(dtReal,dtSim)
  local started=diagnostics and clock()
  if #parcels==0 then
    selected={};setEnabled(false)
    if diagnostics then luaMs=0 end
    return
  end
  lightState=lighting.update(dtReal)
  -- Zero simulation time means pause: preserve the cloud.
  local dt=math.max(0,math.min(tonumber(dtSim) or 0,.3))
  simulationTime=simulationTime+dt
  local camera=getCameraPosition()
  local wakeSources={}
  for i=#parcels,1,-1 do
    local p=parcels[i]
    local far=(p.x-camera.x)^2+(p.y-camera.y)^2+(p.z-camera.z)^2>(RANGE+p.radius)^2
    local vehicle=not far and be:getObjectByID(p.vehicle)
    local alive=vehicle~=nil and vehicle~=false
    if alive and dt>0 and p.vehicleVX and p.age<1.2 and vehicle.getNodePosition and vehicle.getPosition then
      local key=tostring(p.vehicle)..':'..tostring(p.outlet)
      if wakeSources[key]==nil then
        local ok,node,position=pcall(function() return vehicle:getNodePosition(p.outlet),vehicle:getPosition() end)
        wakeSources[key]=ok and node and position and {node.x+position.x,node.y+position.y,node.z+position.z} or false
      end
      local source=wakeSources[key]
      if source then p.wakeX,p.wakeY,p.wakeZ=unpack(source) end
    end
    local remaining=dt
    -- Preserve elapsed simulation time while batching distant gas at 20 Hz.
    -- Center sweeps and surface probes still run on every simulated step.
    local distance2=(p.x-camera.x)^2+(p.y-camera.y)^2+(p.z-camera.z)^2
    if dt>0 then
      local accumulated=(p.simAccumulator or 0)+dt
      if distance2>3600 and accumulated<.05 then
        p.simAccumulator=accumulated;remaining=0
      else
        p.simAccumulator=0;remaining=accumulated
      end
    end
    while alive and remaining>.000001 do
      local step=math.min(remaining,.05);local x,y,z=p.x,p.y,p.z
      air.sample(p,step)
      alive=model.advance(p,step)
      if alive then collision.move(p,x,y,z,step) end
      remaining=remaining-step
    end
    if not alive then table.remove(parcels,i) end
  end
  trail.update(parcels,collision)
  trail.attachSources(parcels,be,collision,simulationTime)
  selected={}
  local candidates={}
  for _,p in ipairs(parcels) do
    local distance=(p.x-camera.x)^2+(p.y-camera.y)^2+(p.z-camera.z)^2
    if distance<RANGE*RANGE then candidates[#candidates+1]={p=p,score=(p.sourceHead and 1e6 or 0)+p.density*p.radius*p.radius/(1+distance*.02)*(p.selectedLast and 1.1 or 1)} end
  end
  selected=budget.select(candidates,MAX_RENDER)
  for _,p in ipairs(parcels) do p.selectedLast=false end
  for _,p in ipairs(selected) do p.selectedLast=true end
  setEnabled(#selected>0)
  if started then local elapsed=(clock()-started)*1000;luaMs=luaMs and luaMs*.9+elapsed*.1 or elapsed end
end
M.onClientEndMission=clear
M.onExtensionUnloaded=clear
function M.onExtensionLoaded()
  clear();failed=false
  if type(jsonReadFile)=='function' then
    local ok,c=pcall(jsonReadFile,configPath)
    if ok and type(c)=='table' and profiles[c.quality] then quality=c.quality end
  end
  RANGE=profiles[quality].range
  collision.setInterval(profiles[quality].probe)
  if fx then fx:setField('targetScale',0,tostring(profiles[quality].scale)..' '..tostring(profiles[quality].scale)) end
end
function M.setQuality(value)
  if not profiles[value] then return false end
  quality=value
  RANGE=profiles[quality].range
  collision.setInterval(profiles[quality].probe)
  if fx then fx:setField('targetScale',0,tostring(profiles[quality].scale)..' '..tostring(profiles[quality].scale)) end
  if type(jsonWriteFile)=='function' then pcall(jsonWriteFile,configPath,{quality=quality},true) end
  return true
end
function M.setDiagnostics(value) diagnostics=value==true;luaMs=nil end
function M.getStatus()
  local perVehicle={}
  for _,p in ipairs(selected) do perVehicle[p.vehicle]=(perVehicle[p.vehicle] or 0)+1 end
  return {simulated=#parcels,rendered=#selected,renderActive=effectEnabled,maxSimulated=MAX_SIM,maxRendered=MAX_RENDER,range=RANGE,
    quality=quality,samples=profiles[quality].samples,maxSamples=quality=='quality' and 24 or profiles[quality].samples,resolutionScale=profiles[quality].scale,probeInterval=profiles[quality].probe,diagnostics=diagnostics,luaMs=luaMs,renderedByVehicle=perVehicle,version='0.9.22'}
end
function M.requestStatus() if guihooks then guihooks.trigger('Mr14DieselSmokeStatus',M.getStatus()) end end
return M
