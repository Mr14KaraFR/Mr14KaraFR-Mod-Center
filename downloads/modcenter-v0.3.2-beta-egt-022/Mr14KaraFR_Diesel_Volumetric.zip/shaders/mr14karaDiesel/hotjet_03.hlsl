// Advected, irregular hot exhaust in a nozzle-local frame. Separate soot pass.
#include "shaders/common/postFx/postFx.h.hlsl"
uniform_sampler2D(prepassTex,0);
uniform_sampler2D(prepassDepthTex,1);
cbuffer perDraw : register(b0) {
  uniform float3 hotEye;
  uniform float hotCount;
  uniform float hotTime;
  uniform float4 hotOrigins[8];
  uniform float4 hotEnds[8];
  uniform float4 hotJetData[8];
  POSTFX_UNIFORMS
};
#include "shaders/common/postFx/postFx.hlsl"
#ifdef SHADER_STAGE_VS
PFXVertToPix main(PFXVert IN) { return processPostFxVert(IN); }
#else
float hash(float3 p) { return frac(sin(dot(p,float3(127.1,311.7,74.7)))*43758.5453); }
float noise(float3 p) {
  float3 i=floor(p),f=frac(p);f=f*f*(3-2*f);
  return lerp(lerp(lerp(hash(i),hash(i+float3(1,0,0)),f.x),
                   lerp(hash(i+float3(0,1,0)),hash(i+float3(1,1,0)),f.x),f.y),
              lerp(lerp(hash(i+float3(0,0,1)),hash(i+float3(1,0,1)),f.x),
                   lerp(hash(i+float3(0,1,1)),hash(i+float3(1,1,1)),f.x),f.y),f.z);
}
float4 main(PFXVertToPix IN) : SV_Target {
  if(hotCount<.5) discard;
  float rayLength=length(IN.wsEyeRay);
  float3 rd=IN.wsEyeRay/max(rayLength,.00001);
  float sceneDistance=decodeGBuffer(TEX_SAMPLER(prepassDepthTex),TEX_SAMPLER(prepassTex),IN.uv0,projParams).w*rayLength;
  float3 light=0;
  [loop] for(int i=0;i<min((int)hotCount,8);i++) {
    float3 segment=hotEnds[i].xyz-hotOrigins[i].xyz;
    float len=length(segment);if(len<.01) continue;
    float3 axis=segment/len;float radius=hotOrigins[i].w;
    float3 oc=hotEye-hotOrigins[i].xyz;
    float along=dot(oc,axis),direction=dot(rd,axis);
    float3 lateral=oc-axis*along,rayLateral=rd-axis*direction;
    float a=dot(rayLateral,rayLateral),b=dot(lateral,rayLateral),c=dot(lateral,lateral)-radius*radius;
    float begin=0,end=sceneDistance;
    if(a>.000001) {
      float h=b*b-a*c;if(h<=0) continue;h=sqrt(h);
      begin=max(begin,(-b-h)/a);end=min(end,(-b+h)/a);
    } else if(c>=0) continue;
    if(abs(direction)>.000001) {
      float t0=-along/direction,t1=(len-along)/direction;
      begin=max(begin,min(t0,t1));end=min(end,max(t0,t1));
    } else if(along<0 || along>len) continue;
    if(end<=begin) continue;
    float3 reference=abs(axis.z)<.9 ? float3(0,0,1) : float3(0,1,0);
    float3 tangent=normalize(cross(axis,reference));
    float3 bitangent=cross(axis,tangent);
    float seed=hotJetData[i].x;
    float pulse=.9+.1*sin(hotTime*23+seed);
    float step=(end-begin)/16;
    [loop] for(int j=0;j<16;j++) {
      float3 p=hotEye+rd*(begin+(j+.5)*step)-hotOrigins[i].xyz;
      float u=saturate(dot(p,axis)/len);
      float2 radial=float2(dot(p,tangent),dot(p,bitangent))/max(radius,.001);
      // Travel from nozzle to tip, instead of translating noise in world space.
      float phase=u*9-hotTime*19+seed;
      float bend=smoothstep(.05,.8,u)*.08;
      radial-=bend*float2(sin(phase),sin(phase*.73+seed));
      float n=noise(float3(radial*2.8,u*7-hotTime*13)+seed);
      float r=length(radial);
      // The flame opens just after the nozzle, then breaks into tapered tongues.
      // Width + bend stays inside the cylinder used for ray intersection.
      float envelope=1-.08*smoothstep(.05,.8,u)-.80*smoothstep(.12,1,u);
      float width=envelope*lerp(1,.72+.28*n,smoothstep(.03,.35,u));
      float core=1-smoothstep(0,max(width,.001),r);
      float erosion=smoothstep(.20+.30*u,.54+.24*u,n);
      float body=lerp(1,erosion,smoothstep(.12,.9,u));
      float root=smoothstep(0,.025,u);
      float tip=1-smoothstep(.72,1,u);
      float density=core*body*root*tip;
      // Warm centre and dimmer red fringe; no uniformly bright solid cone.
      float hot=pow(core,2)*(1-.8*u);
      float3 color=lerp(float3(1,.025,.003),float3(1,.38,.065),hot);
      light+=color*density*step/max(radius,.005)*hotEnds[i].w*2.6*pulse;
    }
  }
  if(dot(light,light)<.0000001) discard;
  return float4(2*(1-exp(-light*.8)),0);
}
#endif
